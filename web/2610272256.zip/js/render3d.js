// Cenário 3D (HD-2D): chão e paredes em 3D com a arte LPC, heróis e monstros em pé (sprites),
// luz de tochas, sombras, brilho e desfoque nas bordas. Os efeitos, números e barras continuam
// no canvas 2D por cima (render.js), que usa a mesma projeção desta câmera.
import * as THREE from 'three';
import { mark, note } from './diag.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

// HD: cenário com modelos 3D (KayKit) e câmera em perspectiva; os outros modos usam blocos com a arte LPC
export let HD = false;
export let PITCH = 55 * Math.PI / 180;  // inclinação da câmera
const FOV_HD = 30;
export let SIN_P = Math.sin(PITCH), COS_P = Math.cos(PITCH);
const camUp = new THREE.Vector3(0, COS_P, -SIN_P);
function setMode(hd) {
  HD = hd; PITCH = (hd ? 50 : 55) * Math.PI / 180; SIN_P = Math.sin(PITCH); COS_P = Math.cos(PITCH);
  camUp.set(0, COS_P, -SIN_P);
  if (W3.renderer) W3.renderer.toneMappingExposure = hd ? 1.4 : 1.15;
  W3.cam = hd ? new THREE.PerspectiveCamera(FOV_HD, 1, 0.5, 300) : new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 200);
}
const PX = 1.3 / 64;                               // 1 pixel de sprite em unidades do mundo (64 px = 1,3 casa)
const WALL_H = 1.0;

export const QUALITY = {
  hd: { pr: 1.5, shadow: 1024, bloom: true, hd: true },
  hd_leve: { pr: 1, shadow: 0, bloom: false, hd: true, noTilt: true },   // HD econômico: sem brilho, sem sombra, sem desfoque
  alta: { pr: 2, shadow: 2048, bloom: true },
  media: { pr: 1.5, shadow: 1024, bloom: true },
  baixa: { pr: 1, shadow: 0, bloom: false },
};

const W3 = window.__W3 = {
  ok: false, renderer: null, scene: null, cam: null, composer: null, bloom: null, tilt: null, q: 'media',
  floorKey: null, world: null, kitLoading: {}, ents: new Map(), texCache: new Map(), models: {}, lastFog: 0,
};

const TiltShift = {
  uniforms: { tDiffuse: { value: null }, res: { value: new THREE.Vector2(1, 1) }, focus: { value: 0.5 }, band: { value: 0.24 }, amount: { value: 5.0 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform vec2 res; uniform float focus, band, amount; varying vec2 vUv;
  void main(){ float d = max(0.0, abs(vUv.y - focus) - band); float k = smoothstep(0.0, 0.35, d) * amount; vec4 c = vec4(0.0); float tw = 0.0;
    for (int i = 0; i < 12; i++) { float a = float(i) * 2.39996; float r = sqrt(float(i) + 0.5) / 3.5; vec2 o = vec2(cos(a), sin(a)) * r * k / res; float w = 1.0 - r * 0.5; c += texture2D(tDiffuse, vUv + o) * w; tw += w; }
    c /= tw; vec2 q = vUv - 0.5; float v = 1.0 - 0.38 * dot(q, q) * 2.2; gl_FragColor = vec4(c.rgb * v, c.a); }`,
};

export function init3d(canvas2d, quality = 'media') {
  try {
    const r = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.domElement.id = 'gl3d';
    Object.assign(r.domElement.style, { position: 'fixed', inset: '0', zIndex: '0', pointerEvents: 'none' });
    canvas2d.parentNode.insertBefore(r.domElement, canvas2d);
    W3.renderer = r;
  } catch (e) { console.warn('3D indisponível', e); return false; }
  W3.scene = new THREE.Scene();
  W3.ok = true;
  setQuality(quality);
  const load = (n) => new Promise((ok) => new GLTFLoader().load(`assets/3d/${n}.gltf.glb`, (g) => ok(g.scene), undefined, () => ok(null)));
  const names = ['torch_mounted', 'barrel_large', 'box_small', 'candle_lit'];
  W3.pending = names.length;
  for (const n of names) load(n).then((m) => { W3.models[n] = m; if (--W3.pending === 0) W3.floorKey = null; });
  return true;
}
export const ready3d = () => W3.ok;
export function show3d(on) { if (W3.renderer) W3.renderer.domElement.style.display = on ? 'block' : 'none'; }

export function setQuality(q) {
  W3.q = QUALITY[q] ? q : 'media';
  const wantHD = !!QUALITY[W3.q].hd;
  if (!W3.cam || HD !== wantHD) setMode(wantHD);
  if (!W3.ok) return;
  const Q = QUALITY[W3.q];
  W3.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, Q.pr));
  W3.renderer.shadowMap.enabled = Q.shadow > 0;
  W3.renderer.shadowMap.type = THREE.PCFShadowMap;
  W3.renderer.shadowMap.autoUpdate = false; W3.renderer.shadowMap.needsUpdate = true;
  if (W3.composer) { for (const p of W3.composer.passes) p.dispose && p.dispose(); W3.composer.dispose(); }
  W3.composer = null; W3.floorKey = null;   // reconstrói tudo com a nova qualidade
}

function buildComposer(W, H) {
  const Q = QUALITY[W3.q];
  if (W3.composer) { for (const p of W3.composer.passes) p.dispose && p.dispose(); W3.composer.dispose(); }
  const c = new EffectComposer(W3.renderer);
  c.addPass(new RenderPass(W3.scene, W3.cam));
  if (Q.bloom) c.addPass(new UnrealBloomPass(new THREE.Vector2(W, H), 0.32, 0.45, 0.86));
  if (Q.noTilt) W3.tilt = null; else { W3.tilt = new ShaderPass(TiltShift); c.addPass(W3.tilt); }
  c.addPass(new OutputPass());
  W3.composer = c; W3.size = `${W}x${H}@${W3.renderer.getPixelRatio()}`;
  c.setSize(W, H);
}

const pxTex = (src) => { const t = src.isTexture ? src : new THREE.CanvasTexture(src); t.magFilter = THREE.NearestFilter; t.minFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace; t.generateMipmaps = false; return t; };
function texOf(key, src) {
  let t = W3.texCache.get(key);
  if (!t) { t = pxTex(src); W3.texCache.set(key, t); }
  return t;
}
const hexColor = (h) => new THREE.Color(h);

// várias cópias de um modelo GLTF numa chamada só (uma InstancedMesh por pedaço do modelo)
function instModel(name, list) {
  const src = W3.models[name]; if (!src || !list.length) return [];
  const out = []; src.updateMatrixWorld(true);
  src.traverse((k) => {
    if (!k.isMesh) return;
    const geo = k.geometry.clone().applyMatrix4(k.matrixWorld);
    const im = new THREE.InstancedMesh(geo, k.material, list.length);
    im.castShadow = true; im.receiveShadow = true;
    list.forEach((it, i) => { im.setMatrixAt(i, it.mtx); im.setColorAt(i, new THREE.Color(1, 1, 1)); });
    im.instanceMatrix.needsUpdate = true;
    im.userData.list = list;
    out.push(im);
  });
  return out;
}
const S4 = 0.25;   // KayKit: 4 unidades por casa

// ---------------- Cenário HD: cada bioma com o seu kit de modelos ----------------
// masmorra: muros e piso de pedra (KayKit Dungeon) · cemitério: cercas, túmulos, árvores secas (KayKit Halloween)
// floresta: árvores e pedras (KayKit Medieval Hexagon)
const KF = (n) => 'kf/' + n;
const KIT_MODELS = {
  dungeon: ['hx/rock_single_A', 'hx/rock_single_C', 'hx/rock_single_E', 'wall', 'wall_cracked', 'floor_tile_large', 'floor_tile_large_rocks', 'floor_tile_small', 'floor_tile_small_broken_A', 'floor_tile_small_broken_B', 'floor_tile_grate', 'rubble_half', 'banner_red', 'banner_patternA_red', 'banner_thin_red', 'candle_melted', 'candle_triple', 'torch_mounted', 'barrel_large', 'box_small', 'candle_lit', 'hw/bone_A', 'hw/bone_B', 'hw/skull', 'hw/ribcage'],
  grave: ['hw/fence', 'hw/fence_broken', 'hw/floor_dirt', 'hw/floor_dirt_grave', 'hw/path_A', 'hw/path_B', 'hw/path_C', 'hw/path_D', 'hw/pumpkin_orange_small', 'hw/pumpkin_yellow_small', 'hw/skull_candle', 'hw/candle_melted', 'hw/grave_A', 'hw/grave_B', 'hw/gravestone', 'hw/gravemarker_A', 'hw/gravemarker_B', 'hw/tree_dead_large', 'hw/tree_dead_medium', 'hw/tree_dead_small', 'hw/bone_A', 'hw/bone_B', 'hw/bone_C', 'hw/skull', 'hw/ribcage', 'hw/lantern_standing', 'candle_lit'],
  forest: ['Tree_1_A', 'Tree_1_B', 'Tree_1_C', 'Tree_2_A', 'Tree_2_B', 'Tree_2_C', 'Tree_3_A', 'Tree_3_B', 'Tree_4_A', 'Tree_4_B', 'Bush_1_A', 'Bush_1_B', 'Bush_2_A', 'Bush_2_B', 'Bush_3_A', 'Bush_4_A', 'Bush_4_B', 'Rock_1_A', 'Rock_1_B', 'Rock_1_C', 'Rock_2_A', 'Rock_2_B', 'Rock_3_A', 'Rock_3_B', 'Grass_1_A', 'Grass_1_B', 'Grass_2_A', 'Grass_2_B'].map(KF).concat(['hw/lantern_standing', 'box_small', 'barrel_large']),
  desert: ['qn/Cactus_1', 'qn/Cactus_2', 'qn/Cactus_3', 'qn/Cactus_4', 'qn/Cactus_5', 'qn/CactusFlowers_2', 'qn/CactusFlowers_3', 'qn/PalmTree_1', 'qn/PalmTree_2', 'qn/PalmTree_3', 'qn/PalmTree_4', 'qn/Rock_1', 'qn/Rock_2', 'qn/Rock_3', 'qn/Rock_4', 'qn/Rock_5', 'qn/Rock_6', 'qn/Rock_7', 'kp/rocks-sand-a', 'kp/rocks-sand-b', 'kp/rocks-sand-c', 'kp/barrel', 'kp/crate', 'hw/bone_A', 'hw/bone_B', 'hw/bone_C', 'hw/skull', 'hw/ribcage', 'hw/lantern_standing'],
  ice: ['qn/PineTree_Snow_1', 'qn/PineTree_Snow_2', 'qn/PineTree_Snow_3', 'qn/PineTree_Snow_4', 'qn/PineTree_Snow_5', 'qn/Rock_Snow_1', 'qn/Rock_Snow_2', 'qn/Rock_Snow_3', 'qn/Rock_Snow_4', 'qn/Rock_Snow_5', 'qn/Rock_Snow_6', 'qn/Rock_Snow_7', 'qn/Bush_Snow_1', 'qn/Bush_Snow_2', 'qn/TreeStump_Snow', 'qn/WoodLog_Snow', 'qn/CommonTree_Dead_Snow_1', 'qn/CommonTree_Dead_Snow_2', 'hw/bone_A', 'hw/bone_B', 'hw/skull', 'hw/lantern_standing'],
  lava: ['qn/Rock_1', 'qn/Rock_2', 'qn/Rock_3', 'qn/Rock_4', 'qn/Rock_5', 'qn/Rock_6', 'qn/Rock_7', 'floor_dirt_large', 'floor_dirt_large_rocky', 'hw/bone_A', 'hw/bone_B', 'hw/skull', 'hw/ribcage', 'hw/lantern_standing'],
  ship: ['floor_wood_large', 'floor_wood_large_dark', 'barrier', 'barrier_column', 'kp/barrel', 'kp/crate', 'kp/crate-bottles', 'kp/cannon', 'kp/cannon-mobile', 'kp/chest', 'kp/mast-ropes', 'kp/flag-pirate', 'kp/bottle-large', 'hw/bone_A', 'hw/bone_B', 'hw/skull', 'hw/ribcage', 'hw/lantern_standing', 'candle_lit'],
};
for (const k of Object.keys(KIT_MODELS)) KIT_MODELS[k].push('stairs');
const kitOf = (th) => /Campos/.test(th.name) ? 'forest' : /Cemit/.test(th.name) ? 'grave' : /Dunas/.test(th.name) ? 'desert'
  : /Abismo/.test(th.name) ? 'lava' : /Navio/.test(th.name) ? 'ship' : /Pico/.test(th.name) ? 'ice' : 'dungeon';
const modelURL = (n) => n.startsWith('kf/') ? `assets/3d/${n}_Color1.gltf` : /^(qn|kp)\//.test(n) ? `assets/3d/${n}.glb` : n.includes('/') ? `assets/3d/${n}.gltf` : `assets/3d/${n}.gltf.glb`;
function loadKit(kit) {
  if (W3.kitLoading[kit]) return;
  W3.kitLoading[kit] = true; mark(`baixa modelos ${kit}`);
  for (const n of KIT_MODELS[kit]) if (!(n in W3.models)) {
    W3.models[n] = null; W3.pending++;
    // remonta o andar uma vez só, quando o kit inteiro chegou (antes remontava a cada modelo: 25 vezes!)
    const done = () => { if (--W3.pending === 0) { W3.floorKey = null; mark('modelos ok'); } };
    new GLTFLoader().load(modelURL(n), (gl) => { W3.models[n] = gl.scene; if (n === 'wall' || n === 'wall_cracked') demoss(gl.scene); done(); }, undefined, done);
  }
}
// tira o musgo verde do atlas das paredes (ficava esquisito na masmorra)
function demoss(scene) {
  scene.traverse((k) => {
    const map = k.isMesh && k.material && k.material.map; if (!map || !map.image || map.userData.demossed) return;
    const im = map.image, c = document.createElement('canvas'); c.width = im.width; c.height = im.height;
    const x = c.getContext('2d'); x.drawImage(im, 0, 0);
    const d = x.getImageData(0, 0, c.width, c.height), p = d.data;
    for (let i = 0; i < p.length; i += 4) { const r = p[i], g = p[i + 1], b = p[i + 2]; if (g > r + 25) { const l = (r * 0.5 + g * 0.3 + b * 0.2) * 0.62; p[i] = l; p[i + 1] = l; p[i + 2] = l * 1.04; } }
    x.putImageData(d, 0, 0);
    const t = new THREE.CanvasTexture(c); t.colorSpace = map.colorSpace; t.flipY = map.flipY; t.wrapS = map.wrapS; t.wrapT = map.wrapT;
    t.magFilter = map.magFilter; t.minFilter = map.minFilter; t.userData.demossed = true;
    k.material = k.material.clone(); k.material.map = t;
  });
}

// ---------- pequenos modelos feitos aqui mesmo (low-poly, no estilo dos kits) ----------
function procMesh(name, geo, mat) { const gr = new THREE.Group(); gr.add(new THREE.Mesh(geo, mat)); W3.models[name] = gr; }
function colored(geo, fn) {   // pinta vértices: fn(y normalizado 0..1) -> Color
  geo = geo.index ? geo.toNonIndexed() : geo; geo.computeBoundingBox();
  const p = geo.attributes.position, b = geo.boundingBox, c = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) { const k = fn((p.getY(i) - b.min.y) / Math.max(1e-6, b.max.y - b.min.y), i); c[i * 3] = k.r; c[i * 3 + 1] = k.g; c[i * 3 + 2] = k.b; }
  geo.setAttribute('color', new THREE.BufferAttribute(c, 3)); geo.computeVertexNormals(); return geo;
}
function merge(geos) {   // junta geometrias não indexadas com cor
  let n = 0; for (const g of geos) n += g.attributes.position.count;
  const P = new Float32Array(n * 3), C = new Float32Array(n * 3); let o = 0;
  for (const g of geos) { P.set(g.attributes.position.array, o * 3); C.set(g.attributes.color.array, o * 3); o += g.attributes.position.count; }
  const r = new THREE.BufferGeometry(); r.setAttribute('position', new THREE.BufferAttribute(P, 3)); r.setAttribute('color', new THREE.BufferAttribute(C, 3)); r.computeVertexNormals(); return r;
}
const rnd = (seed) => () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
function tuft(seed, base, tip, blades = 6, hgt = 0.16) {
  const r = rnd(seed), gs = [];
  for (let i = 0; i < blades; i++) {
    const a = r() * 6.28, d = r() * 0.07, h = hgt * (0.6 + r() * 0.6), w = 0.018 + r() * 0.012, lean = (r() - 0.5) * 0.08;
    const bx = Math.cos(a) * d, bz = Math.sin(a) * d, px = Math.cos(a + 1.57) * w, pz = Math.sin(a + 1.57) * w;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array([bx - px, 0, bz - pz, bx + px, 0, bz + pz, bx + Math.cos(a) * lean, h, bz + Math.sin(a) * lean]), 3));
    gs.push(colored(g, (t) => base.clone().lerp(tip, t)));
  }
  return merge(gs);
}
function flower(seed, petal) {
  const r = rnd(seed), gs = [];
  for (let i = 0; i < 3; i++) {
    const ox = (r() - 0.5) * 0.16, oz = (r() - 0.5) * 0.16, h = 0.09 + r() * 0.06;
    const stem = new THREE.CylinderGeometry(0.006, 0.006, h, 3).translate(ox, h / 2, oz);
    gs.push(colored(stem, () => new THREE.Color(0x3f7a2c)));
    const head = new THREE.ConeGeometry(0.035, 0.02, 5).rotateX(Math.PI).translate(ox, h + 0.01, oz);
    gs.push(colored(head, (t) => t > 0.5 ? petal : new THREE.Color(0xffe27a)));
  }
  return merge(gs);
}
function mushroom(seed) {
  const r = rnd(seed), gs = [];
  for (let i = 0; i < 2 + (seed % 2); i++) {
    const ox = (r() - 0.5) * 0.18, oz = (r() - 0.5) * 0.18, k = 0.6 + r() * 0.6;
    gs.push(colored(new THREE.CylinderGeometry(0.018 * k, 0.024 * k, 0.07 * k, 6).translate(ox, 0.035 * k, oz), () => new THREE.Color(0xf1e6cf)));
    gs.push(colored(new THREE.SphereGeometry(0.05 * k, 7, 3, 0, 6.28, 0, 1.4).translate(ox, 0.065 * k, oz), (t) => new THREE.Color(t > 0.85 ? 0xffffff : 0xc8382c)));
  }
  return merge(gs);
}
function crystal(seed, col) {
  const r = rnd(seed), gs = [];
  for (let i = 0; i < 3; i++) {
    const h = 0.14 + r() * 0.16, gg = new THREE.OctahedronGeometry(0.05, 0).scale(1, h / 0.1, 1).rotateZ((r() - 0.5) * 0.7).rotateX((r() - 0.5) * 0.5).translate((r() - 0.5) * 0.12, h * 0.4, (r() - 0.5) * 0.12);
    gs.push(colored(gg, (t) => col.clone().lerp(new THREE.Color(1, 1, 1), t * 0.5)));
  }
  return merge(gs);
}
function rugTex(accent, dark) {
  const c = document.createElement('canvas'); c.width = 128; c.height = 96; const x = c.getContext('2d');
  x.fillStyle = dark; x.fillRect(0, 0, 128, 96);
  x.strokeStyle = accent; x.lineWidth = 6; x.strokeRect(8, 8, 112, 80); x.lineWidth = 2; x.strokeRect(18, 18, 92, 60);
  x.fillStyle = accent; x.beginPath(); x.moveTo(64, 30); x.lineTo(84, 48); x.lineTo(64, 66); x.lineTo(44, 48); x.closePath(); x.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function makeProc(th, kit) {
  const vc = (o = {}) => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, flatShading: true, side: THREE.DoubleSide, ...o });
  const C = (h) => new THREE.Color(h);
  if (kit === 'forest') {
    procMesh('p/grass0', tuft(11, C(0x5a9a40), C(0x9cdc66)), vc());
    procMesh('p/grass1', tuft(23, C(0x4c8a36), C(0x86cc58), 8, 0.2), vc());
    procMesh('p/grass2', tuft(37, C(0x62a246), C(0xb4e478), 5, 0.12), vc());
    procMesh('p/fl0', flower(5, C(0xffffff)), vc()); procMesh('p/fl1', flower(9, C(0xffd23f)), vc());
    procMesh('p/fl2', flower(13, C(0xff8fb8)), vc()); procMesh('p/fl3', flower(17, C(0xb48cff)), vc());
    procMesh('p/mush', mushroom(7), vc());
  }
  if (kit === 'grave') {
    procMesh('p/dry0', tuft(41, C(0x4d4a36), C(0x9a9070), 6, 0.13), vc());
    procMesh('p/dry1', tuft(53, C(0x3f4a3a), C(0x7d8a68), 5, 0.1), vc());
  }
  const acc = C(kit === 'ice' ? '#9fdcff' : kit === 'lava' ? '#ff5a2a' : th.accent || '#c9a6ff');
  procMesh('p/crystal', crystal(3, acc), vc({ emissive: acc, emissiveIntensity: 0.6 }));
  if (kit === 'lava') procMesh('p/ember', colored(new THREE.DodecahedronGeometry(0.045, 0).translate(0, 0.03, 0), () => C(0xff7a2a)), vc({ emissive: C(0xff5a1a), emissiveIntensity: 1.4 }));
  if (kit === 'dungeon') {
    const dark = '#' + C([].concat(th.wall)[1] || '#222').getHexString();
    procMesh('p/rug', new THREE.BoxGeometry(0.86, 0.012, 0.62).translate(0, 0.008, 0), new THREE.MeshStandardMaterial({ map: rugTex(th.accent || '#c9a6ff', dark), roughness: 1 }));
  }
}

// ---------- água, lava, buracos e escadas (afundados no chão) ----------
const LIQ = {   // base, brilho, luz própria (lava brilha no escuro)
  agua: ['#1d4f7e', '#7fbde8', 0], lodo: ['#2a4424', '#7ea85a', 0.12], areia: ['#9a7840', '#e2c486', 0],
  lava: ['#b8300f', '#ffc04a', 1], gelo: ['#5f8fb0', '#cfe6f4', 0.05], vazio: ['#1a0f2e', '#9a6ae8', 0.4],
};
function sunkKind(m, th, x, y) {
  if (x < 0 || y < 0 || x >= m.w || y >= m.h) return null;
  const t = m.t[y * m.w + x];
  if (t === 3) return 'stairs';
  if (t === 4 || (t === 5 && th.liquid === 'lava')) return 'liquid';
  if (t === 5) return 'pit';
  return null;
}
const sunk = (m, th, x, y) => !!sunkKind(m, th, x, y);
const SUNK_D = { liquid: 0.14, pit: 1.3, stairs: 0.55 };
const LiquidShader = {
  vertexShader: `attribute float shore; varying float vShore; varying vec2 vP;
    void main(){ vShore = shore; vec4 w = modelMatrix * vec4(position, 1.0); vP = w.xz; gl_Position = projectionMatrix * viewMatrix * w; }`,
  fragmentShader: `uniform vec3 base, hi; uniform float time, glow, flow; uniform vec2 hero; varying float vShore; varying vec2 vP;
    float wave(vec2 p){ return sin(p.x * 3.1 + time * 1.3 * flow + sin(p.y * 2.3 + time * 0.7 * flow)) * sin(p.y * 2.7 - time * 1.1 * flow + sin(p.x * 1.7)); }
    void main(){
      float n = wave(vP) * 0.5 + wave(vP * 1.9 + 3.7) * 0.35;
      float band = smoothstep(0.50, 0.56, n) - smoothstep(0.60, 0.70, n);
      float sh = smoothstep(0.72, 1.0, vShore);
      vec3 col = mix(base, hi, band * 0.5 + sh * 0.35);
      float d = distance(vP, hero);
      float light = max(glow, mix(0.18, 1.0, smoothstep(7.5, 1.0, d)));
      gl_FragColor = vec4(col * light, 1.0);
    }`,
};
function buildSunk(env, g, parts) {
  const { m, th } = env, kit = kitOf(th), W = m.w;
  const L = LIQ[th.liquid] || LIQ.agua;
  const pos = [], shore = [], wallP = [], botP = [];
  const quad = (arr, a, b, c, d) => arr.push(...a, ...b, ...c, ...a, ...c, ...d);
  const isLiq = (x, y) => sunkKind(m, th, x, y) === 'liquid';
  const stairs = [];
  for (let y = 0; y < m.h; y++) for (let x = 0; x < W; x++) {
    const k = sunkKind(m, th, x, y); if (!k) continue;
    const D = SUNK_D[k], i = y * W + x;
    if (k === 'liquid') {
      const lv = -D * 0.45;
      quad(pos, [x, lv, y], [x, lv, y + 1], [x + 1, lv, y + 1], [x + 1, lv, y]);
      const c = (cx, cy) => (isLiq(cx - 1, cy - 1) && isLiq(cx, cy - 1) && isLiq(cx - 1, cy) && isLiq(cx, cy)) ? 0 : 1;
      const s00 = c(x, y), s01 = c(x, y + 1), s11 = c(x + 1, y + 1), s10 = c(x + 1, y);
      shore.push(s00, s01, s11, s00, s11, s10);
    } else {
      quad(botP, [x, -D, y], [x, -D, y + 1], [x + 1, -D, y + 1], [x + 1, -D, y]);
      if (k === 'stairs') stairs.push([x, y, i]);
    }
    // paredes do buraco onde encosta em chão firme (ou num buraco mais raso)
    const side = (nx, ny) => { const nk = sunkKind(m, th, nx, ny); return !nk || SUNK_D[nk] < D; };
    if (side(x, y - 1)) quad(wallP, [x, 0.012, y], [x + 1, 0.012, y], [x + 1, -D, y], [x, -D, y]);
    if (side(x, y + 1)) quad(wallP, [x + 1, 0.012, y + 1], [x, 0.012, y + 1], [x, -D, y + 1], [x + 1, -D, y + 1]);
    if (side(x - 1, y)) quad(wallP, [x, 0.012, y + 1], [x, 0.012, y], [x, -D, y], [x, -D, y + 1]);
    if (side(x + 1, y)) quad(wallP, [x + 1, 0.012, y], [x + 1, 0.012, y + 1], [x + 1, -D, y + 1], [x + 1, -D, y]);
  }
  const bank = { dungeon: '#4a4652', grave: '#3d3428', forest: '#5a4128' }[kit];
  if (wallP.length) {
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(wallP, 3)); geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: bank, roughness: 1, side: THREE.DoubleSide })); mesh.receiveShadow = true; g.add(mesh);
  }
  if (botP.length) {
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(botP, 3)); geo.computeVertexNormals();
    g.add(new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0x030304, side: THREE.DoubleSide })));
  }
  // escada descendo para o próximo andar (a parte alta fica do lado da câmera)
  if (W3.models.stairs) {
    const list = stairs.map(([x, y, i]) => ({ mtx: new THREE.Matrix4().compose(new THREE.Vector3(x + 0.5, -0.56, y + 1.0), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI), new THREE.Vector3(0.19, 0.11, 0.25)), cells: [i] }));
    const tint = kit === 'dungeon' ? hexColor([].concat(th.wall || '#888888')[0]).lerp(new THREE.Color(1, 1, 1), 0.6) : new THREE.Color(0.85, 0.82, 0.78);
    for (const im of instModel('stairs', list)) { im.material = im.material.clone(); im.material.color.copy(tint); g.add(im); parts.push(im); }
    for (const [x, y] of stairs) {   // brilho lá embaixo: dá para achar a descida de longe
      const gl = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.5), new THREE.MeshBasicMaterial({ color: hexColor(th.accent || '#9ad8ff').multiplyScalar(0.9), transparent: true, opacity: 0.55, depthWrite: false, toneMapped: false }));
      gl.rotation.x = -Math.PI / 2; gl.position.set(x + 0.5, -0.5, y + 0.3); g.add(gl);
    }
  }
  if (!pos.length) return null;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('shore', new THREE.Float32BufferAttribute(shore, 1));
  const uniforms = { base: { value: hexColor(L[0]) }, hi: { value: hexColor(L[1]) }, glow: { value: L[2] }, time: { value: 0 }, flow: { value: th.liquid === 'gelo' ? 0.0 : th.liquid === 'lava' ? 0.45 : 1 }, hero: { value: new THREE.Vector2() } };
  const mat = new THREE.ShaderMaterial({ uniforms, vertexShader: LiquidShader.vertexShader, fragmentShader: LiquidShader.fragmentShader });
  g.add(new THREE.Mesh(geo, mat));
  return { uniforms };
}

function buildHD(env, g, props) {
  const { m, th } = env;
  const kit = kitOf(th); loadKit(kit); makeProc(th, kit);
  const W = m.w, isW = (x, y) => x < 0 || y < 0 || x >= W || y >= m.h || m.t[y * W + x] === env.WALL;
  const hsh = (x, y, k) => (Math.abs(((x * 374761393 + y * 668265263 + k * 1013904223) | 0) ^ ((x * 31 + y * 17 + k) << 9)) >>> 0) % 1000;
  const UP = new THREE.Vector3(0, 1, 0);
  const lists = {};
  // vis: casas cuja visibilidade revela o objeto
  const put = (name, x, z, ry, sx, sy, sz, vis, y = 0) => {
    if (!W3.models[name]) return;
    (lists[name] = lists[name] || []).push({ mtx: new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromAxisAngle(UP, ry), new THREE.Vector3(sx, sy ?? sx, sz ?? sx)), cells: [].concat(vis) });
  };
  const pick = (arr, x, y, k) => arr[hsh(x, y, k) % arr.length];
  const R90 = Math.PI / 2;
  const floorCell = (x, y) => !isW(x, y);
  for (let y = 0; y < m.h; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x;
    if (!isW(x, y)) {
      const t = m.t[i];
      // piso
      if (t === 1) {
        const rot = (hsh(x, y, 9) % 4) * R90;
        const hf = hsh(x, y, 5);
        if (kit === 'dungeon') {
          if (hf < 260) {   // 4 lajotas pequenas, algumas quebradas
            for (const [qx, qz] of [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]]) { const hq = hsh(x * 2 + qx * 2, y * 2 + qz * 2, 6); put(hq < 380 ? (hq % 2 ? 'floor_tile_small_broken_A' : 'floor_tile_small_broken_B') : 'floor_tile_small', x + qx, y + qz, (hq % 4) * R90, S4, S4, S4, i); }
          } else if (hf < 115) put('floor_tile_large_rocks', x + 0.5, y + 0.5, rot, S4, S4, S4, i);
          else put('floor_tile_large', x + 0.5, y + 0.5, rot, S4, S4, S4, i);
          if (hf % 23 === 0) put(pick(['hx/rock_single_C', 'hx/rock_single_E', 'hx/rock_single_A'], x, y, 30), x + 0.3 + (hf % 5) * 0.1, y + 0.3 + (hf % 4) * 0.12, hf, 1.4, null, null, i);
        }
        if (kit === 'grave') {
          put(hf < 50 ? 'hw/floor_dirt_grave' : 'hw/floor_dirt', x + 0.5, y + 0.5, rot, S4, S4, S4, i);
          if (hf >= 50 && hf < 190) put(pick(['hw/path_A', 'hw/path_B', 'hw/path_C', 'hw/path_D'], x, y, 7), x + 0.5 + (hf % 5 - 2) * 0.06, y + 0.5 + (hf % 7 - 3) * 0.05, (hf % 360) * 0.0175, 0.24, 0.24, 0.24, i, 0.01);
          if (hf % 2 === 0) put(hf % 4 ? 'p/dry0' : 'p/dry1', x + 0.2 + (hf % 6) * 0.1, y + 0.25 + (hf % 5) * 0.12, hf, 1.9, null, null, i);
          if (hf % 5 === 1) put('p/dry0', x + 0.75 - (hf % 4) * 0.1, y + 0.7, hf + 1, 1.5, null, null, i);
        }
        if (kit === 'forest') {
          const dense = m.decor[i] === 'grass' ? 5 : 2;
          for (let k = 0; k < dense; k++) { const hk = hsh(x, y, 40 + k); if (hk < 700 || m.decor[i] === 'grass') put(KF(pick(['Grass_1_A', 'Grass_1_B', 'Grass_2_A', 'Grass_2_B'], x, y, 41 + k)), x + 0.1 + (hk % 9) * 0.1, y + 0.1 + ((hk >> 4) % 9) * 0.1, hk, 0.2 + (hk % 5) * 0.025, null, null, i); }
          if (m.decor[i] === 'flower' || hf < 110) put('p/fl' + (hf % 4), x + 0.5 + (hf % 5 - 2) * 0.08, y + 0.5 + (hf % 7 - 3) * 0.06, hf, 1.8, null, null, i);
          if (hf > 985) put('p/mush', x + 0.5, y + 0.5, hf, 1.2, null, null, i);
        }
        if (kit === 'desert') {   // areia lisa (no chão) com pedrinhas e um ou outro cacto pequeno
          if (hf < 90) put(pick(['qn/Rock_2', 'qn/Rock_3', 'qn/Rock_5'], x, y, 31), x + 0.25 + (hf % 6) * 0.1, y + 0.3 + (hf % 5) * 0.1, hf, 0.2 + (hf % 3) * 0.05, null, null, i);
          else if (hf > 975 || m.decor[i] === 'cactus') put(pick(['qn/Cactus_1', 'qn/Cactus_5', 'qn/CactusFlowers_3'], x, y, 32), x + 0.5, y + 0.5, hf, 0.32, null, null, i);
        }
        if (kit === 'ice') {
          if (hf < 70) put(pick(['qn/Rock_Snow_2', 'qn/Rock_Snow_3', 'qn/Rock_Snow_6'], x, y, 31), x + 0.25 + (hf % 6) * 0.1, y + 0.3 + (hf % 5) * 0.1, hf, 0.22 + (hf % 3) * 0.05, null, null, i);
        }
        if (kit === 'lava') {
          put(hf < 300 ? 'floor_dirt_large_rocky' : 'floor_dirt_large', x + 0.5, y + 0.5, rot, S4, S4, S4, i);
          if (hf % 17 === 0) put('p/ember', x + 0.3 + (hf % 5) * 0.1, y + 0.3 + (hf % 4) * 0.12, hf, 1, null, null, i);
        }
        if (kit === 'ship') put(hsh(x, y >> 1, 5) < 500 ? 'floor_wood_large_dark' : 'floor_wood_large', x + 0.5, y + 0.5, (x % 2) * Math.PI, S4, S4, S4, i);
      }
      // bordas
      if (kit === 'dungeon') {
        const seg = (cx, cz, ry, hy, cell, k) => put(hsh(x, y, k) < 120 ? 'wall_cracked' : 'wall', cx, cz, ry, 1.25 * S4, hy * S4, S4, cell);
        if (isW(x, y - 1) && y > 0) {
          seg(x + 0.5, y - 0.125, 0, 1.6, i - W, 1);
          const hb = hsh(x, y, 70);
          if (hb < 55) put(pick(['banner_red', 'banner_patternA_red', 'banner_thin_red'], x, y, 71), x + 0.5, y - 0.125, 0, S4 * 0.9, S4 * 1.1, S4, i - W, 0.15);
          else if (hb > 975) put('rubble_half', x + 0.05, y - 0.2, 0, 0.15, 0.13, 0.15, i - W);
        }
        if (isW(x, y + 1) && y < m.h - 1) seg(x + 0.5, y + 1.125, 0, 0.28, i + W, 2);
        if (isW(x - 1, y) && x > 0) seg(x - 0.125, y + 0.5, R90, 1.15, i - 1, 3);
        if (isW(x + 1, y) && x < W - 1) seg(x + 1.125, y + 0.5, R90, 1.15, i + 1, 4);
      } else if (kit === 'ship') {
        const rail = (cx, cz, ry, cell) => put('barrier', cx, cz, ry, 1.05 * S4, S4 * 1.3, S4, cell);
        if (isW(x, y - 1) && y > 0) rail(x + 0.5, y - 0.07, 0, i - W);
        if (isW(x, y + 1) && y < m.h - 1) rail(x + 0.5, y + 1.07, 0, i + W);
        if (isW(x - 1, y) && x > 0) rail(x - 0.07, y + 0.5, R90, i - 1);
        if (isW(x + 1, y) && x < W - 1) rail(x + 1.07, y + 0.5, R90, i + 1);
      } else if (kit === 'grave') {
        const fence = (cx, cz, ry, cell, k) => put(hsh(x, y, k) < 200 ? 'hw/fence_broken' : 'hw/fence', cx, cz, ry, 1.02 * S4, S4, S4, cell);
        if (isW(x, y - 1) && y > 0) fence(x + 0.5, y - 0.06, 0, i - W, 1);
        if (isW(x, y + 1) && y < m.h - 1) fence(x + 0.5, y + 1.06, 0, i + W, 2);
        if (isW(x - 1, y) && x > 0) fence(x - 0.06, y + 0.5, R90, i - 1, 3);
        if (isW(x + 1, y) && x < W - 1) fence(x + 1.06, y + 0.5, R90, i + 1, 4);
      }
      // decoração 3D no lugar dos desenhos do chão
      const d = m.decor[i], h = hsh(x, y, 21), jx = (h % 7 - 3) * 0.05, jz = ((h >> 3) % 7 - 3) * 0.05, ry = (h % 360) * Math.PI / 180;
      const KP = kit === 'ship' || kit === 'desert';
      if (d === 'barrel') KP ? put('kp/barrel', x + 0.5, y + 0.5, ry, 0.3, null, null, i) : put('barrel_large', x + 0.5, y + 0.5, ry, 0.28, 0.28, 0.28, i);
      else if (d === 'crate') KP ? put(pick(['kp/crate', 'kp/crate-bottles'], x, y, 2), x + 0.5, y + 0.5, ry, 0.36, null, null, i) : put('box_small', x + 0.5, y + 0.5, ry, 0.28, 0.28, 0.28, i);
      else if (d === 'ember') put('p/ember', x + 0.5 + jx, y + 0.5 + jz, ry, 1.3, null, null, i);
      else if (d === 'crystal' && kit !== 'dungeon') put('p/crystal', x + 0.5 + jx, y + 0.5 + jz, ry, 1.3, null, null, i);
      else if (d === 'rock' && kit === 'ice') put(pick(['qn/Rock_Snow_1', 'qn/Rock_Snow_5'], x, y, 4), x + 0.5 + jx, y + 0.5 + jz, ry, 0.4, null, null, i);
      else if (d === 'rock' && kit === 'lava') put(pick(['qn/Rock_1', 'qn/Rock_4', 'qn/Rock_6'], x, y, 4), x + 0.5 + jx, y + 0.5 + jz, ry, 0.4, null, null, i);
      else if (d === 'candle') put(kit === 'grave' ? pick(['hw/skull_candle', 'hw/candle_melted', 'candle_lit'], x, y, 2) : pick(['candle_lit', 'candle_melted', 'candle_triple'], x, y, 2), x + 0.5 + jx, y + 0.5 + jz, ry, kit === 'grave' ? 0.3 : 0.5, null, null, i);
      else if (!d && kit === 'grave' && h % 97 === 0 && (isW(x - 1, y) || isW(x + 1, y) || isW(x, y - 1))) put(pick(['hw/pumpkin_orange_small', 'hw/pumpkin_yellow_small'], x, y, 8), x + 0.5 + jx * 2, y + 0.4, ry, 0.32, null, null, i);
      else if (d === 'bones') put(pick(['hw/bone_A', 'hw/bone_B', 'hw/ribcage'], x, y, 3), x + 0.5 + jx, y + 0.5 + jz, ry, 0.3, 0.3, 0.3, i, 0.03);
      else if (d === 'carpet' && kit === 'dungeon') put('p/rug', x + 0.5, y + 0.5, (h % 2) * R90, 1, 1, 1, i);
      else if (d === 'crystal' && kit === 'dungeon') put('p/crystal', x + 0.5 + jx, y + 0.5 + jz, ry, 1.3, null, null, i);
      else if (d === 'skull') put('hw/skull', x + 0.5 + jx, y + 0.5 + jz, ry, 0.22, 0.22, 0.22, i);
      else if (d === 'rock' && kit === 'forest') put(KF(pick(['Rock_1_A', 'Rock_1_B', 'Rock_2_A'], x, y, 4)), x + 0.5 + jx, y + 0.5 + jz, ry, 0.45, null, null, i);
      else if (d === 'rock' && kit === 'grave') put(pick(['hw/gravemarker_A', 'hw/gravemarker_B'], x, y, 4), x + 0.5 + jx, y + 0.5, (h % 30 - 15) * 0.01, 0.3, 0.3, 0.3, i);
      continue;
    }
    // casa de parede: o que fica em pé nela depende do kit
    const nb = [[0, -1], [0, 1], [-1, 0], [1, 0], [-1, -1], [1, -1], [-1, 1], [1, 1]].map(([dx, dy]) => [x + dx, y + dy]).filter(([a, b]) => a >= 0 && b >= 0 && a < W && b < m.h);
    const touch = nb.some(([a, b]) => floorCell(a, b));
    const near2 = !touch && [[0, -2], [0, 2], [-2, 0], [2, 0], [-2, -1], [2, -1], [-2, 1], [2, 1], [-1, -2], [1, -2], [-1, 2], [1, 2]].some(([dx, dy]) => floorCell(x + dx, y + dy) && !isW(x + dx, y + dy) && x + dx >= 0 && y + dy >= 0 && x + dx < W && y + dy < m.h);
    if (!touch && !near2) continue;
    const vis = nb.map(([a, b]) => b * W + a).concat(i);
    const southOfRoom = floorCell(x, y - 1) || (floorCell(x - 1, y - 1) && floorCell(x + 1, y - 1)) || (!touch && floorCell(x, y - 2));
    const h = hsh(x, y, 33), jx = (h % 9 - 4) * 0.04, jz = ((h >> 4) % 9 - 4) * 0.04, ry = (h % 360) * Math.PI / 180;
    const OUT = {   // [na frente (baixo), encostado na sala, mais ao fundo, extra] -> [modelos, escala]
      forest: [[['Bush_1_A', 'Bush_1_B', 'Bush_2_A', 'Bush_2_B', 'Bush_4_A', 'Bush_4_B'].map(KF), 0.55], [['Tree_1_A', 'Tree_1_B', 'Tree_1_C', 'Tree_2_A', 'Tree_2_B', 'Tree_3_A', 'Tree_3_B', 'Tree_4_A'].map(KF), 0.36], [['Tree_1_C', 'Tree_2_C', 'Tree_3_B', 'Tree_4_B'].map(KF), 0.4], [['Rock_1_A', 'Rock_1_C', 'Rock_3_A', 'Rock_3_B'].map(KF), 0.5]],
      desert: [[['qn/Rock_2', 'qn/Rock_3', 'qn/Rock_5', 'qn/Cactus_1', 'qn/Cactus_5'], 0.5], [['kp/rocks-sand-a', 'kp/rocks-sand-b', 'kp/rocks-sand-c', 'kp/rocks-sand-c', 'qn/PalmTree_1', 'qn/PalmTree_3', 'qn/Cactus_2', 'qn/Cactus_3', 'qn/CactusFlowers_2'], 1], [['kp/rocks-sand-a', 'kp/rocks-sand-b', 'qn/PalmTree_2', 'qn/PalmTree_4'], 1], [['qn/Rock_1', 'qn/Rock_6'], 0.45]],
      ice: [[['qn/Rock_Snow_1', 'qn/Rock_Snow_4', 'qn/Rock_Snow_6', 'qn/Bush_Snow_1', 'qn/Bush_Snow_2'], 0.55], [['qn/PineTree_Snow_1', 'qn/PineTree_Snow_2', 'qn/PineTree_Snow_3', 'qn/PineTree_Snow_4', 'qn/PineTree_Snow_5', 'qn/CommonTree_Dead_Snow_1', 'qn/Rock_Snow_7'], 0.58], [['qn/PineTree_Snow_1', 'qn/PineTree_Snow_3', 'qn/PineTree_Snow_5'], 0.65], [['qn/Rock_Snow_2', 'qn/Rock_Snow_3', 'qn/TreeStump_Snow'], 0.45]],
      lava: [[['qn/Rock_2', 'qn/Rock_3', 'qn/Rock_5'], 0.7], [['qn/Rock_1', 'qn/Rock_4', 'qn/Rock_6', 'qn/Rock_7'], 1.6], [['qn/Rock_1', 'qn/Rock_7'], 1.9], [['qn/Rock_2', 'qn/Rock_5'], 0.6]],
    };
    // tamanho certo dos modelos (cada pack vem numa escala)
    const SCL = (n, k) => /rocks-sand/.test(n) ? 0.24 * k : /PalmTree/.test(n) ? 0.36 * k : /Cactus/.test(n) ? (k > 0.9 ? 0.6 : 0.4) * k : k;
    if (OUT[kit]) {
      const [front, edge, far, extra] = OUT[kit];
      const pk = (lst, k) => lst[0][hsh(x, y, k) % lst[0].length];
      if (southOfRoom) {   // na frente: só coisas baixas
        const n = pk(front, 5); put(n, x + 0.4 + jx, y + 0.45 + jz, ry, SCL(n, front[1]), null, null, vis);
        if (h % 2) { const n2 = pk(extra, 16); put(n2, x + 0.75 - jx, y + 0.65 - jz, ry + 2, SCL(n2, extra[1]), null, null, vis); }
      } else if (touch) {
        const n = pk(edge, 7); put(n, x + 0.5 + jx, y + 0.5 + jz, ry, SCL(n, edge[1] * (0.9 + (h % 5) * 0.05)), null, null, vis);
        if (h % 3 === 0) { const n2 = pk(extra, 8); put(n2, x + 0.15 + jz, y + 0.8 + jx, ry + 1, SCL(n2, extra[1]), null, null, vis); }
      } else {
        const n = pk(far, 9); put(n, x + 0.5 + jx, y + 0.5 + jz, ry, SCL(n, far[1]), null, null, vis);
      }
    } else if (kit === 'ship') {
      if (southOfRoom || !touch) continue;
      const r = h % 12, P = ['kp/barrel', 'kp/crate', 'kp/crate-bottles', 'kp/cannon', 'kp/chest', 'kp/bottle-large'];
      if (r < 1) put('kp/mast-ropes', x + 0.5, y + 0.5, (h % 2) * R90, 0.3, null, null, vis);
      else if (r < 7) { const n = P[h % P.length]; put(n, x + 0.5 + jx, y + 0.5 + jz, ry, n === 'kp/cannon' ? 0.32 : n === 'kp/bottle-large' ? 0.35 : 0.34, null, null, vis); }
    } else if (kit === 'grave') {
      if (southOfRoom || !touch && h % 2) continue;
      const r = h % 10;
      if (r < 3) put(pick(['hw/tree_dead_large', 'hw/tree_dead_medium', 'hw/tree_dead_small'], x, y, 10), x + 0.5 + jx, y + 0.45 + jz, ry, 0.3, 0.3, 0.3, vis);
      else if (r < 6) put(pick(['hw/gravestone', 'hw/gravemarker_A', 'hw/gravemarker_B'], x, y, 11), x + 0.5 + jx, y + 0.5, (h % 30 - 15) * 0.012, 0.3, 0.3, 0.3, vis);
      else if (r < 8) put(pick(['hw/grave_A', 'hw/grave_B'], x, y, 12), x + 0.5, y + 0.5, 0, 0.3, 0.3, 0.3, vis);
    }
  }
  // tochas: na masmorra, presas no muro; lá fora, lampiões em pé
  const torches = [];
  for (let y = 0; y < m.h - 1; y++) for (let x = 0; x < W; x++) if (m.decor[y * W + x] === 'torch' && isW(x, y) && !isW(x, y + 1)) torches.push([x, y]);
  for (const [x, y] of torches) {
    const outdoor = kit !== 'dungeon' && kit !== 'lava';
    const mdl = outdoor ? W3.models['hw/lantern_standing'] : W3.models.torch_mounted; if (!mdl) continue;
    const o = mdl.clone(true);
    if (outdoor) { o.scale.setScalar(0.42); o.position.set(x + 0.5, 0, y + 0.75); } else { o.scale.setScalar(0.3); o.position.set(x + 0.5, 0.35, y + 1.02); }
    o.userData = { x, y, prop: true }; g.add(o); props.push(o);
    const fl = new THREE.Mesh(new THREE.SphereGeometry(outdoor ? 0.045 : 0.06, 8, 6), new THREE.MeshBasicMaterial({ color: hexColor(th.light), toneMapped: false }));
    fl.material.color.multiplyScalar(2.2); fl.position.set(x + 0.5, outdoor ? 0.27 : 0.86, outdoor ? y + 0.75 : y + 1.12); fl.userData = { x, y, prop: true, flame: true }; g.add(fl); props.push(fl);
  }
  const parts = [];
  const tint = kit === 'dungeon' ? hexColor([].concat(th.wall || '#888888')[0]).lerp(new THREE.Color(1, 1, 1), 0.6) : null;
  const KTINT = { lava: [/^(qn\/Rock|floor_dirt)/, new THREE.Color(0.42, 0.3, 0.27)], ship: [/^(floor_wood|barrier)/, new THREE.Color(0.62, 0.72, 0.7)] }[kit];
  for (const [name, list] of Object.entries(lists)) for (const im of instModel(name, list)) {
    if (tint && /^(wall|floor_|rubble)/.test(name)) { im.material = im.material.clone(); im.material.color.copy(tint); if (/^floor_tile_small/.test(name)) im.material.color.multiplyScalar(0.8); }
    if (KTINT && KTINT[0].test(name)) { im.material = im.material.clone(); im.material.color.multiply(KTINT[1]); }
    g.add(im); parts.push(im);
  }
  return parts;
}

// ---------------- Montagem do andar ----------------
// env: { m, th, theme, ground (canvas com o chão desenhado), wallTex: {top, side}, natural, trees }
// solta da memória (inclusive da placa de vídeo) tudo do andar atual
function disposeMat(mt, keepTex) {
  for (const k of ['map', 'emissiveMap', 'alphaMap', 'normalMap', 'aoMap']) { const t = mt[k]; if (t && !keepTex(t)) t.dispose(); }
  if (mt.uniforms) for (const u of Object.values(mt.uniforms)) if (u.value && u.value.isTexture && !keepTex(u.value)) u.value.dispose();
  mt.dispose();
}
export function freeWorld() {
  const old = W3.world;
  for (const e of W3.ents.values()) dropEnt(e);
  W3.ents.clear();
  if (!old) return;
  W3.scene.remove(old.group);
  const keep = new Set(); for (const v of W3.texCache.values()) keep.add(v);
  for (const k in W3.models) W3.models[k]?.traverse?.((o) => { for (const mt of [].concat(o.material || [])) for (const kk of ['map', 'emissiveMap', 'normalMap']) if (mt[kk]) keep.add(mt[kk]); });
  const keepMats = new Set(); for (const k in W3.models) W3.models[k]?.traverse?.((o) => { for (const mt of [].concat(o.material || [])) keepMats.add(mt); });
  const keepGeo = new Set(); for (const k in W3.models) W3.models[k]?.traverse?.((o) => { if (o.geometry) keepGeo.add(o.geometry); });
  old.group.traverse((o) => {
    if (o.geometry && !keepGeo.has(o.geometry)) o.geometry.dispose();
    for (const mt of [].concat(o.material || [])) if (!keepMats.has(mt)) disposeMat(mt, (t) => keep.has(t));
    if (o.isInstancedMesh) o.dispose();
  });
  if (old.fogTex) old.fogTex.dispose();
  W3.world = null; W3.floorKey = null;
}
function dropEnt(e) {
  W3.scene.remove(e.mesh);
  e.mesh.geometry.dispose();
  const mt = e.mesh.material; if (e.key.startsWith('h:') && mt.map) mt.map.dispose();   // a do herói é uma cópia
  mt.dispose();
}
export const worldBuilt = () => !!W3.world;

function buildFloor(env) {
  const old = W3.world;
  freeWorld();
  const { m, th } = env;
  const g = new THREE.Group();
  const Q = QUALITY[W3.q];
  // fundo e névoa da cor do bioma
  W3.scene.background = hexColor('#07080c');
  // chão: uma textura só com o andar inteiro desenhado (texturas LPC, líquidos, escadas, decoração rasteira)
  let groundCv = env.ground;
  if (HD) {   // no HD o miolo das paredes é escuro (as paredes de verdade ficam nas bordas)
    groundCv = document.createElement('canvas'); groundCv.width = env.ground.width; groundCv.height = env.ground.height;
    const gx = groundCv.getContext('2d'); gx.drawImage(env.ground, 0, 0); gx.fillStyle = { forest: '#1b2716', grave: '#16191b', dungeon: '#07080c', desert: '#4a3a22', ice: '#6d7f94', lava: '#0e0807', ship: '#04070a' }[kitOf(th)];
    const S = env.ground.width / m.w;
    for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) if (m.t[y * m.w + x] === env.WALL) gx.fillRect(x * S, y * S, S, S);
    const SMOOTH = { forest: [[86, 142, 62], [34, 58, 28], 0.12], desert: [[206, 170, 112], [150, 116, 70], 0.07], ice: [[226, 236, 246], [168, 186, 206], 0.05] }[kitOf(th)];
    if (SMOOTH) {
      // chão liso, no mesmo estilo dos modelos (sem desenho de pixel); escadas e água continuam do mapa
      const [cf, cw, amp] = SMOOTH;
      const sm = document.createElement('canvas'); sm.width = m.w * 4; sm.height = m.h * 4; const sx = sm.getContext('2d');
      for (let y = 0; y < m.h * 4; y++) for (let x = 0; x < m.w * 4; x++) {
        const c = m.t[(y >> 2) * m.w + (x >> 2)], n = (Math.sin(x * 0.9 + y * 0.35) + Math.sin(x * 0.23 - y * 0.71) + Math.sin((x + y) * 0.13)) / 3;
        const k = 1 + n * amp, b = c === env.WALL ? cw : cf;
        sx.fillStyle = `rgb(${b[0] * k | 0},${b[1] * k | 0},${b[2] * k | 0})`;
        sx.fillRect(x, y, 1, 1);
      }
      gx.imageSmoothingEnabled = true; gx.filter = 'blur(6px)'; gx.drawImage(sm, 0, 0, groundCv.width, groundCv.height); gx.filter = 'none';
      for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) { const t = m.t[y * m.w + x]; if (t !== env.WALL && t !== 1) gx.drawImage(env.ground, x * S, y * S, S, S, x * S, y * S, S, S); }
    }
    // água, lava, buracos e escadas afundam: o chão fica vazado ali
    for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) if (sunk(m, th, x, y)) gx.clearRect(x * S, y * S, S, S);
  }
  const gt = pxTex(new THREE.CanvasTexture(groundCv));
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(m.w, m.h), new THREE.MeshStandardMaterial({ map: gt, roughness: 1, alphaTest: 0.5 }));
  ground.rotation.x = -Math.PI / 2; ground.position.set(m.w / 2, 0, m.h / 2); ground.receiveShadow = true; g.add(ground);
  // paredes: caixas com o topo e a face do LPC
  const walls = [];
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) if (m.t[y * m.w + x] === env.WALL) walls.push([x, y]);
  const side = new THREE.MeshStandardMaterial({ map: pxTex(env.wallTex.side), roughness: 1 });
  const top = new THREE.MeshStandardMaterial({ map: pxTex(env.wallTex.top), roughness: 1 });
  const box = new THREE.BoxGeometry(1, WALL_H, 1);
  const wm = new THREE.InstancedMesh(box, [side, side, top, top, side, side], HD ? 0 : walls.length);
  wm.castShadow = true; wm.receiveShadow = true;
  const mtx = new THREE.Matrix4();
  if (wm.count) walls.forEach(([x, y], i) => { mtx.makeTranslation(x + 0.5, WALL_H / 2, y + 0.5); wm.setMatrixAt(i, mtx); wm.setColorAt(i, new THREE.Color(1, 1, 1)); });
  wm.instanceMatrix.needsUpdate = true; if (wm.instanceColor) wm.instanceColor.needsUpdate = true;
  g.add(wm);
  const props = [];
  const hdParts = HD ? buildHD(env, g, props) : [];
  // árvores dos Campos (em pé sobre as paredes que dão para o chão)
  if (!HD && env.trees && env.trees.length) {
    for (const [x, y] of walls) {
      const open = [[0, 1], [0, -1], [1, 0], [-1, 0]].some(([dx, dy]) => { const t = m.t[(y + dy) * m.w + x + dx]; return t !== undefined && t !== env.WALL; });
      if (!open) continue;
      const h = Math.abs((x * 374761393 + y * 668265263) | 0);
      const img = env.trees[(h >>> 3) % env.trees.length];
      const tex = texOf('tree' + ((h >>> 3) % env.trees.length), img);
      const w = 1.55, hh = w * img.height / img.width;
      const mat = new THREE.MeshStandardMaterial({ map: tex, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 1 });
      const pl = new THREE.Mesh(new THREE.PlaneGeometry(w, hh), mat);
      pl.castShadow = true;
      pl.userData = { x, y, bill: true, foot: [x + 0.5, y + 0.9], hh, scaleY: 1 };
      g.add(pl); props.push(pl);
    }
  }
  // tochas nas paredes, barris, caixas, velas
  const torchSpots = [];
  if (!HD) for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const d = m.decor[y * m.w + x]; if (!d) continue;
    if (d === 'torch' && m.t[y * m.w + x] === env.WALL && m.t[(y + 1) * m.w + x] !== env.WALL) torchSpots.push([x, y]);
    const model = { barrel: 'barrel_large', crate: 'box_small', candle: 'candle_lit' }[d];
    if (model && W3.models[model]) {
      const o = W3.models[model].clone(true); const s = model === 'candle_lit' ? 0.5 : 0.28;
      o.scale.setScalar(s); o.position.set(x + 0.5, 0, y + 0.5); o.rotation.y = ((x * 7 + y * 13) % 8) * 0.4;
      o.traverse((k) => { if (k.isMesh) { k.castShadow = true; k.receiveShadow = true; } });
      o.userData = { x, y, prop: true }; g.add(o); props.push(o);
    }
  }
  for (const [x, y] of torchSpots) {
    if (!W3.models.torch_mounted) break;
    const o = W3.models.torch_mounted.clone(true); o.scale.setScalar(0.3); o.position.set(x + 0.5, 0.35, y + 1.02);
    o.userData = { x, y, prop: true }; g.add(o); props.push(o);
    const fl = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), new THREE.MeshBasicMaterial({ color: hexColor(th.light), toneMapped: false }));
    fl.material.color.multiplyScalar(2.2); fl.position.set(x + 0.5, 0.86, y + 1.12); fl.userData = { x, y, prop: true, flame: true }; g.add(fl); props.push(fl);
  }
  // luzes: ambiente do bioma, luz do herói, tochas (as mais próximas), lua/sol com sombra
  const amb = new THREE.HemisphereLight(0x9aa8d8, 0x201810, 0.55); g.add(amb);
  const sun = new THREE.DirectionalLight(hexColor(th.light).lerp(new THREE.Color(0xffffff), 0.6), 0.55);
  sun.castShadow = Q.shadow > 0;
  if (Q.shadow) { sun.shadow.mapSize.set(Q.shadow, Q.shadow); sun.shadow.bias = -0.0015; Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -14, near: 1, far: 60 }); }
  g.add(sun); g.add(sun.target);
  const heroLight = new THREE.PointLight(hexColor(th.light), 9, 9, 1.6); g.add(heroLight);
  const pool = []; for (let i = 0; i < 2; i++) { const l = new THREE.PointLight(hexColor(th.light), 0, 6, 1.6); g.add(l); pool.push(l); }
  // névoa de guerra: textura com um texel por casa, suavizada
  const fogData = new Uint8Array(m.w * m.h * 4);
  const fogTex = new THREE.DataTexture(fogData, m.w, m.h, THREE.RGBAFormat);
  fogTex.magFilter = THREE.LinearFilter; fogTex.minFilter = THREE.LinearFilter; fogTex.flipY = false; fogTex.needsUpdate = true;
  const fog = new THREE.Mesh(new THREE.PlaneGeometry(m.w, m.h), new THREE.MeshBasicMaterial({ color: 0x06050e, alphaMap: fogTex, transparent: true, depthWrite: false }));
  fog.rotation.x = -Math.PI / 2; fog.position.set(m.w / 2, 0.02, m.h / 2); fog.renderOrder = 2; g.add(fog);
  // alphaMap usa o canal verde
  W3.scene.add(g);
  const liquid = HD ? buildSunk(env, g, hdParts) : null;
  W3.world = { group: g, m, walls, wm, hdParts, props, liquid, sun, heroLight, pool, fogData, fogTex, theme: env.theme, lights: env.lights || [] };
}

// visibilidade: o que nunca foi visto some; o que já foi visto fica escuro
function updateFog(m, fov) {
  note('névoa');
  const w = W3.world; const d = w.fogData;
  // a textura cresce para cima e o mapa para baixo: linha y vai para a linha (h-1-y)
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const i = y * m.w + x, o = ((m.h - 1 - y) * m.w + x) * 4;
    const a = !m.seen[i] ? 255 : fov[i] ? 0 : 150;
    d[o] = d[o + 1] = d[o + 2] = a; d[o + 3] = 255;
  }
  w.fogTex.needsUpdate = true;
  const mtx = new THREE.Matrix4(), c = new THREE.Color();
  w.walls.forEach(([x, y], k) => {
    const i = y * m.w + x;
    if (!m.seen[i]) mtx.makeScale(0, 0, 0); else mtx.makeTranslation(x + 0.5, WALL_H / 2, y + 0.5);
    w.wm.setMatrixAt(k, mtx);
    c.setScalar(fov[i] ? 1 : 0.38); w.wm.setColorAt(k, c);
  });
  w.wm.instanceMatrix.needsUpdate = true; if (w.wm.instanceColor) w.wm.instanceColor.needsUpdate = true;
  const Z = new THREE.Matrix4().makeScale(0, 0, 0);
  for (const im of w.hdParts || []) {
    im.userData.list.forEach((it, k) => { const sn = it.cells.some((j) => m.seen[j]); im.setMatrixAt(k, sn ? it.mtx : Z); c.setScalar(it.cells.some((j) => fov[j]) ? 1 : 0.38); im.setColorAt(k, c); });
    im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
  }
  for (const p of w.props) {
    const i = p.userData.y * m.w + p.userData.x;
    p.visible = !!m.seen[i];
  }
}

// ---------------- Sprites (heróis e monstros) ----------------
function spriteMesh(key, tex, wpx, hpx) {
  note(`sprite ${key.slice(0, 18)}`);
  const mat = new THREE.MeshStandardMaterial({ map: tex, emissiveMap: tex, emissive: 0xffffff, emissiveIntensity: 0.42, color: 0xa0a0a0, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 1 });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(wpx * PX, hpx * PX), mat);
  mesh.castShadow = true; mesh.quaternion.copy(W3.cam.quaternion);
  W3.scene.add(mesh);
  return { mesh, key };
}
// coloca o sprite com o ponto "pé" (fx, fy em pixels da imagem) sobre o chão (gx, gz), mais um deslocamento na tela (dy em casas)
function placeSprite(mesh, wpx, hpx, fxp, fyp, gx, gz, upTiles = 0) {
  const ox = (wpx / 2 - fxp) * PX, oy = (fyp - hpx / 2) * PX + upTiles;
  mesh.position.set(gx + ox, 0, gz).addScaledVector(camUp, oy);
  mesh.quaternion.copy(W3.cam.quaternion);
}

// ents: [{id, kind:'hero', img, sx, sy, cell, feet, x, y, flash, alpha}] ou [{id, kind:'mon', canvas, type, x, y, up, sq, flash}]
function syncEntities(list, now) {
  const seen = new Set();
  for (const e of list) {
    seen.add(e.id);
    let s = W3.ents.get(e.id);
    if (e.kind === 'hero') {
      if (!e.img) continue;
      const key = 'h:' + e.img.src;
      if (!s || s.key !== key) {
        if (s) dropEnt(s);
        const t = texOf(key, e.img).clone(); t.needsUpdate = true;
        t.repeat.set(e.cell / e.img.width, e.cell / e.img.height);
        s = spriteMesh(key, t, e.cell, e.cell); W3.ents.set(e.id, s);
      }
      const t = s.mesh.material.map;
      t.offset.set(e.sx / e.img.width, 1 - (e.sy + e.cell) / e.img.height);
      s.mesh.scale.set(e.flip ? -1 : 1, 1, 1);
      placeSprite(s.mesh, e.cell, e.cell, e.cell / 2, e.feet, e.x + 0.5, e.y + 0.78, e.up || 0);
    } else {
      if (!e.canvas || !e.canvas.width) continue;
      const key = 'm:' + e.type;
      if (!s || s.key !== key) {
        if (s) dropEnt(s);
        s = spriteMesh(key, texOf(key, e.canvas), e.canvas.width, e.canvas.height); W3.ents.set(e.id, s);
      }
      const S = e.canvas.width;
      s.mesh.scale.set(1 / (e.sq || 1), e.sq || 1, 1);
      placeSprite(s.mesh, S, S, S / 2, S * 0.97, e.x + 0.5, e.y + 0.78, e.up || 0);
    }
    const mat = s.mesh.material;
    mat.emissiveIntensity = e.flash ? 1.6 : 0.42;
    mat.transparent = e.alpha < 1; mat.opacity = e.alpha ?? 1;
  }
  for (const [id, s] of W3.ents) if (!seen.has(id)) { dropEnt(s); W3.ents.delete(id); }
}

// ---------------- Quadro ----------------
// view: { camX, camY, TS, W, H, viewCY, shake:[x,y], now, hero:{x,y}, fov, envFn }
export function render3d(view) {
  if (!W3.ok) return true;
  const { m } = view;
  const R3 = W3.renderer;
  // BUG antigo: comparava com Math.round, mas o three arredonda para baixo (375 × 1,5 = 562,5 → 562).
  // Em telas assim a "tela 3D" era recriada em TODO quadro, sem soltar a anterior: a memória de vídeo enchia e o celular caía.
  const sizeKey = `${view.W}x${view.H}@${R3.getPixelRatio()}`;
  if (!W3.composer || W3.size !== sizeKey) {
    R3.setSize(view.W, view.H);
    buildComposer(view.W, view.H); mark(`tela 3D ${R3.domElement.width}x${R3.domElement.height}`);
  }
  const key = m;
  if (W3.floorKey !== key || !W3.world || W3.world.m !== m) {
    const env = view.envFn();
    if (HD) loadKit(kitOf(env.th));
    if (W3.pending > 0) { if (W3.world && W3.world.m !== m) freeWorld(); return false; }   // modelos ainda chegando: tela de carregamento
    mark(`monta andar ${m.w}x${m.h}`); buildFloor(env); W3.floorKey = key; W3.lastFog = -1; W3.shadowKey = ''; mark('montou');
    W3.builds = (W3.builds || 0) + 1;
  }
  // câmera ortográfica inclinada: um tile = TS pixels na largura e TS*sen(inclinação) na altura
  const cam = W3.cam, TS = view.TS; W3.vw = view.W; W3.vh = view.H;
  const tx = view.camX + 0.5 - view.shake[0] / TS, tz = view.camY + 0.5 - view.shake[1] / TS / SIN_P;
  const dir = new THREE.Vector3(0, -SIN_P, -COS_P);
  if (cam.isPerspectiveCamera) {
    // distância em que uma casa no centro mede TS pixels; o alvo fica na altura viewCY da tela
    const D = view.H / (2 * TS * Math.tan(FOV_HD * Math.PI / 360));
    cam.aspect = view.W / view.H; cam.setViewOffset(view.W, view.H, 0, view.H / 2 - view.viewCY, view.W, view.H);
    cam.position.set(tx, 0, tz).addScaledVector(dir, -D);
  } else {
    cam.left = -view.W / 2 / TS; cam.right = view.W / 2 / TS;
    cam.top = view.viewCY / TS; cam.bottom = -(view.H - view.viewCY) / TS;
    cam.position.set(tx, 0, tz).addScaledVector(dir, -60);
  }
  cam.up.set(0, 1, 0); cam.lookAt(tx, 0, tz);
  cam.updateProjectionMatrix(); cam.updateMatrixWorld();
  // névoa de guerra: atualiza quando o campo de visão muda
  let moved = false;
  if (view.fovStamp !== W3.lastFog) { updateFog(m, view.fov); W3.lastFog = view.fovStamp; moved = true; }
  // luzes perto do herói
  const w = W3.world, t = view.now / 1000;
  w.heroLight.position.set(view.hero.x + 0.5, 1.6, view.hero.y + 0.6);
  if (w.liquid) { w.liquid.uniforms.time.value = t; w.liquid.uniforms.hero.value.set(view.hero.x + 0.5, view.hero.y + 0.5); }
  w.sun.position.set(tx - 6, 14, tz + 6); w.sun.target.position.set(tx, 0, tz);
  const near = w.lights.filter((l) => m.seen[l.y * m.w + l.x]).map((l) => [l, Math.hypot(l.x - view.hero.x, l.y - view.hero.y)]).sort((a, b) => a[1] - b[1]);
  w.pool.forEach((pl, i) => {
    const e = near[i];
    if (!e || e[1] > 13) { pl.intensity = 0; return; }
    const l = e[0];
    pl.position.set(l.x + 0.5, 1.1, l.y + 0.7);
    if (l.color) pl.color.set(l.color);
    pl.distance = (l.r || 3.5) * 1.6;
    pl.intensity = 6 * (0.88 + 0.12 * Math.sin(t * 9 + l.x * 3));
  });
  for (const p of w.props) if (p.userData.bill) {
    p.quaternion.copy(cam.quaternion);
    const [fx, fz] = p.userData.foot; p.position.set(fx, 0, fz).addScaledVector(camUp, p.userData.hh * 0.47);
  } else if (p.userData.flame) p.scale.setScalar(1 + 0.18 * Math.sin(t * 13 + p.userData.x));
  syncEntities(view.ents, view.now);
  if (W3.tilt) { W3.tilt.uniforms.res.value.set(view.W * R3.getPixelRatio(), view.H * R3.getPixelRatio()); W3.tilt.uniforms.focus.value = 1 - view.viewCY / view.H; }
  // sombra: só recalcula quando a câmera, alguém ou a visão muda (antes era em todo quadro)
  if (R3.shadowMap.enabled) {
    let k = `${tx.toFixed(1)},${tz.toFixed(1)}`;
    for (const e of view.ents) k += `|${e.id}:${e.x.toFixed(1)},${e.y.toFixed(1)}`;
    if (moved || k !== W3.shadowKey) { W3.shadowKey = k; R3.shadowMap.needsUpdate = true; note('sombra'); }
  }
  W3.composer.render();
  const np = R3.info.programs ? R3.info.programs.length : 0; if (np !== W3.np) { if (W3.np) note(`shader novo (${np})`); W3.np = np; }
  return true;
}

export function clearFloor3d() { W3.floorKey = null; }

// tela <-> mundo (o canvas 2D por cima usa isto para casar barras, números e toques com a câmera em perspectiva)
const _v = new THREE.Vector3(), _ray = new THREE.Raycaster(), _pl = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), _n = new THREE.Vector2();
export function project(wx, wz, wy = 0) {
  _v.set(wx, wy, wz).project(W3.cam);
  return [(_v.x + 1) / 2 * W3.vw, (1 - _v.y) / 2 * W3.vh];
}
export function unproject(px, py) {
  _n.set(px / W3.vw * 2 - 1, 1 - py / W3.vh * 2);
  _ray.setFromCamera(_n, W3.cam);
  const hit = _ray.ray.intersectPlane(_pl, _v);
  return hit ? { x: hit.x - 0.5, y: hit.z - 0.5 } : null;
}
