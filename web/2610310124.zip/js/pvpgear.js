// Equipamento de PvP: uma instância separada da campanha.
// As peças não têm números fixos: acompanham o nível do herói (o "tier" do PvP), copiando a peça da campanha
// daquele tier e linha (pesada / robe / leve), multiplicada pela qualidade (Recruta, Soldado, Veterano, Campeão).
// Recruta = kit básico: sem slot, não refina, nunca quebra e nunca acaba. As outras se compram com Medalhas de Honra.
import { ITEMS, WTYPES, CLASSES } from './data.js';

export const GRADES = [
  { id: 0, name: 'Recruta', mul: 0.85 },
  { id: 1, name: 'Soldado', mul: 1.0 },
  { id: 2, name: 'Veterano', mul: 1.1 },
  { id: 3, name: 'Campeão', mul: 1.2 },
];
// slots por qualidade (arma / demais peças)
export const GRADE_SLOTS = { weapon: [0, 1, 2, 3], other: [0, 1, 1, 1] };

// tier do PvP pelo nível (mesmos degraus da campanha: 12, 20, 30, 40, 55, 65)
const TIER_CAPS = [12, 20, 30, 40, 55, 65];
export const pvpTierFor = (lv) => Math.min(7, 1 + TIER_CAPS.filter((c) => lv >= c).length);
let TIER = 1;
export function setPvpTier(t) { TIER = Math.max(1, Math.min(7, t | 0)); }
export const pvpTier = () => TIER;

// linhas de peças da campanha usadas como molde
const LINES = {
  armor: { heavy: ['roupa_algodao', 'tunica_couro', 'cota_malha', 'armadura_placas', 'armadura_runica', 'couraca_almirante', 'armadura_glacial'],
    robe: ['roupa_algodao', 'manto_aprendiz', 'robe_arcano', 'manto_estelar', 'manto_mares', 'veste_vazio'],
    light: ['roupa_algodao', 'tunica_couro', 'traje_ladino', 'couraca_sombra', 'traje_corsario', 'couraca_noturna'] },
  head: { heavy: ['bandana_couro', 'elmo_ferro', 'elmo_aco', 'elmo_cavaleiro', 'elmo_runico', 'elmo_almirante', 'elmo_glacial'],
    robe: ['chapeu_palha', 'chapeu_estudante', 'chapeu_mago', 'chapeu_arcano', 'diadema_estelar', 'coroa_mares', 'coroa_vazio'],
    light: ['bandana', 'capuz_couro', 'capuz_ladino', 'mascara_cacador', 'capuz_sombras', 'lenco_corsario', 'capuz_noturno'] },
  shield: { escudo: ['broquel', 'escudo_madeira', 'escudo_ferro', 'escudo_torre', 'escudo_runico', 'escudo_almirante', 'escudo_glacial'],
    livro: ['tomo_gasto', 'grimorio_estudante', 'grimorio_arcano', 'livro_estrelas', 'codice_estelar', 'grimorio_mares', 'livro_vazio'] },
};
const KIND_NAME = {
  armor: { heavy: 'Couraça', robe: 'Manto', light: 'Traje' },
  head: { heavy: 'Elmo', robe: 'Chapéu', light: 'Capuz' },
  shield: { escudo: 'Escudo', livro: 'Grimório' },
};
const ACC_NAME = { str: 'Anel da Força', agi: 'Botas da Agilidade', vit: 'Colar da Vida', int: 'Brinco da Sabedoria', dex: 'Luvas da Precisão', luk: 'Trevo da Sorte' };
const ACC_ICON = { str: 'anel_forca', agi: 'botas_leves', vit: 'colar_vida', int: 'brinco_sabio', dex: 'luvas_precisas', luk: 'trevo' };

// melhor molde da linha até o tier atual
function moldOf(list, kind, extra) {
  let best = null;
  for (const id of list) { const d = ITEMS[id]; if (d && d.kind === kind && (d.tier || 1) <= TIER && (!best || (d.tier || 1) >= (ITEMS[best].tier || 1))) best = id; }
  return best || list[0];
}
function weaponMold(wt) {
  let best = null;
  for (const [id, d] of Object.entries(ITEMS)) if (d.kind === 'weapon' && d.wtype === wt && (d.tier || 1) <= TIER && !d.boss && (!best || (d.tier || 1) > (ITEMS[best].tier || 1))) best = id;
  if (!best) for (const [id, d] of Object.entries(ITEMS)) if (d.kind === 'weapon' && d.wtype === wt) { best = id; break; }
  return best;
}
const scale = (mods, k) => { const o = {}; for (const [a, v] of Object.entries(mods || {})) o[a] = typeof v === 'number' ? Math.round(v * k) : v; return o; };

// bônus de refino do PvP: +7 dá um extra; +9 dá 2,5× esse extra (não soma com o do +7)
export const REFINE_EXTRA = {
  weapon: { key: 'pvpDmg', v7: 5, name: 'dano em jogadores', unit: '%' },
  armor: { key: 'pvpRes', v7: 5, name: 'resistência a jogadores', unit: '%' },
  shield: { key: 'hpPct', v7: 4, name: 'HP máximo', unit: '%' },
  head: { key: 'ccRes', v7: 6, name: 'resistência a atordoar e lentidão', unit: '%' },
};
export function refineExtra(slotKind, r) {
  const e = REFINE_EXTRA[slotKind]; if (!e || r < 7) return null;
  return { [e.key]: r >= 9 ? e.v7 * 2.5 : e.v7 };
}

// definição de uma peça de PvP (o que o itemDef devolve)
export function pvpDef(it) {
  const g = GRADES[it.g || 0];
  if (it.ps === 'weapon') {
    const m = ITEMS[weaponMold(it.wt)] || {};
    return { ...m, kind: 'weapon', wtype: it.wt, pvp: true, grade: g.id, tier: TIER, name: `${WTYPES[it.wt].name} de ${g.name}`,
      atk: Math.round((m.atk || 0) * g.mul), matk: m.matk ? Math.round(m.matk * g.mul) : m.matk, mods: scale(m.mods, g.mul), el: undefined, noRefine: g.id === 0 };
  }
  if (it.ps === 'acc') {
    return { kind: 'acc', pvp: true, grade: g.id, tier: TIER, stat: it.st, icon: ACC_ICON[it.st], name: `${ACC_NAME[it.st]} de ${g.name}`, mods: { [it.st]: TIER + 1 + g.id }, noRefine: true };
  }
  const list = LINES[it.ps][it.k];
  const m = ITEMS[moldOf(list, it.ps)] || {};
  return { ...m, kind: it.ps, pvp: true, grade: g.id, tier: TIER, name: `${KIND_NAME[it.ps][it.k]} de ${g.name}`,
    def: Math.round((m.def || 0) * g.mul), mdef: Math.round((m.mdef || 0) * g.mul), matk: m.matk ? Math.round(m.matk * g.mul) : m.matk, mods: scale(m.mods, g.mul), noRefine: g.id === 0 };
}

// perfil de equipamento de cada linha de classe (arma padrão, peso da armadura, cabeça e mão esquerda)
export const LINE_GEAR = {
  cavaleiro: { wt: ['espada', 'lanca'], armor: 'heavy', head: 'heavy', left: 'escudo' },
  bruxo: { wt: ['cajado', 'varinha'], armor: 'robe', head: 'robe', left: 'livro' },
  cacador: { wt: ['arco', 'besta'], armor: 'light', head: 'light', left: null },
  assassino: { wt: ['adaga', 'katar'], armor: 'light', head: 'light', left: null },
  monge: { wt: ['maca', 'soqueira'], armor: 'heavy', head: 'heavy', left: 'escudo' },
  shinobi: { wt: ['kunai', 'fuuma'], armor: 'light', head: 'light', left: null },
  mestre_taekwon: { wt: ['faixa'], armor: 'light', head: 'light', left: null },
  aprendiz: { wt: ['espada'], armor: 'light', head: 'light', left: 'escudo' },
};
// linha de qualquer classe (Lorde → cavaleiro, Mago Alto → bruxo...)
const FIRST = { espadachim: 'cavaleiro', mago: 'bruxo', arqueiro: 'cacador', gatuno: 'assassino', novico: 'monge', ninja: 'shinobi', taekwon: 'mestre_taekwon' };
export function lineOf(cls) {
  let c = cls, guard = 0;
  while (c && guard++ < 8) {
    const b = CLASSES[c] && CLASSES[c].base;
    if (FIRST[c]) return FIRST[c];
    if (b && FIRST[b]) return FIRST[b];
    if (b && b !== c && LINE_GEAR[b]) return b;
    if (LINE_GEAR[c] && c !== 'aprendiz') return c;
    c = CLASSES[c] && CLASSES[c].from;
  }
  return 'aprendiz';
}

export function makePvpItem(spec, extra = {}) {
  const g = spec.g || 0;
  const slots = g === 0 ? 0 : spec.ps === 'weapon' ? GRADE_SLOTS.weapon[g] : GRADE_SLOTS.other[g];
  return { uid: Math.floor(Math.random() * 1e9), id: 'pvp', ...spec, g, refine: 0, slots, cards: [], ...extra };
}
// o kit básico (Recruta) da classe: preenche qualquer espaço vazio do equipamento de PvP
export function basicKit(cls, wtPick) {
  const L = LINE_GEAR[lineOf(cls)] || LINE_GEAR.aprendiz;
  const wt = wtPick && L.wt.includes(wtPick) ? wtPick : L.wt[0];
  const two = !!(WTYPES[wt] && WTYPES[wt].hands === 2);
  return {
    weapon: makePvpItem({ ps: 'weapon', wt, g: 0 }, { basic: true, uid: -1 }),
    armor: makePvpItem({ ps: 'armor', k: L.armor, g: 0 }, { basic: true, uid: -2 }),
    head: makePvpItem({ ps: 'head', k: L.head, g: 0 }, { basic: true, uid: -3 }),
    left: L.left && !two ? makePvpItem({ ps: 'shield', k: L.left, g: 0 }, { basic: true, uid: -4 }) : null,
    acc1: null, acc2: null,
  };
}
// equipamento efetivo no PvP: o que o herói equipou, e o básico onde estiver vazio
export function pvpLoadout(h) {
  const eq = (h.pvp && h.pvp.equip) || {};
  const b = basicKit(h.cls, h.pvp && h.pvp.basicWt);
  const out = {};
  for (const k of ['weapon', 'armor', 'head', 'left', 'acc1', 'acc2']) out[k] = eq[k] || b[k];
  // arma de 2 mãos: mão esquerda vazia
  if (out.weapon && WTYPES[out.weapon.wt] && WTYPES[out.weapon.wt].hands === 2) out.left = null;
  return out;
}

// loja de PvP (preços em Medalhas de Honra)
export const PVP_PRICES = { weapon: [0, 60, 150, 320], armor: [0, 50, 120, 260], head: [0, 35, 90, 200], shield: [0, 35, 90, 200], acc: [0, 80, 200, 400] };
export const PVP_SHOP_ITEMS = { diario: 250, trevo_dourado: 200 };

// ajuste de PvP por estágio (1ª classe, 2ª classe, transclasse) e linha de classe: multiplicador do dano causado e da vida.
// Calibrado com milhares de duelos simulados entre aventureiros (cada classe perto de 50% de vitórias em cada estágio).
export const PVP_LINE = {
  t1: { cavaleiro: { dmg: 1.63, hp: 1.34 }, bruxo: { dmg: 1.66, hp: 1.46 }, cacador: { dmg: 2.2, hp: 1.63 }, assassino: { dmg: 1.93, hp: 1.51 }, monge: { dmg: 1.54, hp: 1.31 }, shinobi: { dmg: 1.83, hp: 1.37 }, mestre_taekwon: { dmg: 1.29, hp: 1.16 }, aprendiz: { dmg: 1, hp: 1 } },
  t2: { cavaleiro: { dmg: 1.9, hp: 1.49 }, bruxo: { dmg: 2.59, hp: 1.92 }, cacador: { dmg: 1.84, hp: 1.45 }, assassino: { dmg: 1.31, hp: 1.17 }, monge: { dmg: 1.63, hp: 1.36 }, shinobi: { dmg: 1.9, hp: 1.4 }, mestre_taekwon: { dmg: 0.88, hp: 0.91 }, aprendiz: { dmg: 1, hp: 1 } },
  tr: { cavaleiro: { dmg: 0.88, hp: 0.92 }, bruxo: { dmg: 4.27, hp: 2.47 }, cacador: { dmg: 1.73, hp: 1.41 }, assassino: { dmg: 1.38, hp: 1.25 }, monge: { dmg: 2.06, hp: 1.57 }, shinobi: { dmg: 3.53, hp: 2.09 }, mestre_taekwon: { dmg: 1.12, hp: 1.09 }, aprendiz: { dmg: 1, hp: 1 } },
};
export const stageOf = (cls) => { const c = CLASSES[cls] || {}; return (c.tier || 0) >= 2 ? (c.trans ? 'tr' : 't2') : 't1'; };
// começo da 1ª classe (nível de classe baixo, quase sem habilidades): tabela própria, que vira a da 1ª classe até o nível de classe 15
PVP_LINE.t0 = { cavaleiro: { dmg: 2.73, hp: 1.85 }, bruxo: { dmg: 2.88, hp: 2.06 }, cacador: { dmg: 1.31, hp: 1.18 }, assassino: { dmg: 2.1, hp: 1.59 }, monge: { dmg: 1.61, hp: 1.35 }, shinobi: { dmg: 2.07, hp: 1.48 }, mestre_taekwon: { dmg: 1.92, hp: 1.48 }, aprendiz: { dmg: 1, hp: 1 } };
export function pvpLine(cls, jobLv) {
  const st = stageOf(cls), ln = lineOf(cls);
  const a = PVP_LINE[st][ln] || PVP_LINE.t1.aprendiz;
  if (st !== 't1' || jobLv === undefined) return a;
  const b = PVP_LINE.t0[ln] || a, k = Math.min(1, Math.max(0, ((jobLv || 1) - 1) / 14));
  return { dmg: b.dmg + (a.dmg - b.dmg) * k, hp: b.hp + (a.hp - b.hp) * k };
}
