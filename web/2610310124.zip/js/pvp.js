// PvP: Guilda PvP Owners, Sala de PvP, Batalha Campal (Flavius e KVM) e Guerra do Emperium (WoE).
// O jogo é offline: os outros "jogadores" são aventureiros controlados pelo computador. Eles seguem o nível de base,
// o nível de classe e a evolução do herói, usam o equipamento de PvP e as habilidades da própria classe.
// Cada aventureiro é uma unidade na lista de monstros do andar, marcada com m.pvp (time, classe, pontos...).
import { G, fx, log, recalc, save, damageHero, updateView, hasBuff, chiOf, lineage, _heroDefense, _occupied } from './game.js';
import { CLASSES, SKILLS, MONSTERS, BOOSTS, BASIC_MUL, WTYPES, ITEMS, POTION_BY_TIER, jobMax, baseCls } from './data.js';
import { derive, physHit, magicHit, statCost, statPtsForLevel, REBORN_STAT_BONUS, itemDef, makeCard } from './rules.js';
import { T, passable, tileAt, setTile, hasLos, findPath, inb } from './map.js';
import { rnd, chance, pick, weighted, dist, uid } from './util.js';
import { makePvpItem, LINE_GEAR, lineOf, pvpTierFor, setPvpTier, PVP_PRICES, PVP_SHOP_ITEMS, GRADES, PVP_LINE, pvpLine } from './pvpgear.js';

const S = () => G.state;
const run = () => G.state.run;
const hero = () => G.state.hero;

// ---------------- Regras gerais ----------------
export const PVP_MUL = 0.45;           // todo dano entre jogadores sai a 45% (lutas de vários golpes: a iniciativa não decide sozinha)
export const PVP_REGEN = 0.3;
export const BOT_EDGE = 1.2;
export const PVP_HEAL = 0.5;
// 1ª classe recém-feita ainda não tem habilidades de dano: o PvP dá um reforço que some conforme o nível de classe sobe
// (×2 no nível de classe 1, ×1 no 15). Da 2ª classe em diante não há reforço: as habilidades da 1ª já estão completas.
export const earlyMul = (cls, jobLv) => { const c = CLASSES[cls] || {}; if ((c.tier || 0) >= 2) return 1; const m = jobMax(cls) || 15; return 1 + Math.max(0, 1 - ((jobLv || 1) - 1) / (m - 1)); };           // curas de habilidade valem metade entre jogadores (senão a luta não acaba)
// duração dos efeitos entre jogadores (igual para o herói e os aventureiros): ninguém fica travado muito tempo
export const PVP_STATUS = { stun: 1, freeze: 2, petrify: 2, snare: 2, burn: 3, poison: 4, slow: 3 };          // os aventureiros não usam as mecânicas de classe (Ritmo, Fervor, Chi...): compensação igual para todos          // no PvP a vida volta bem mais devagar (senão ninguém cai)
export const SALA_START = 5;           // pontos ao entrar na sala
export const WOE_COOLDOWN_MS = 6 * 3600e3;
export const GUILD_NAME = 'PvP Owners';
const LEADER = { name: 'Kaiser', line: 'cavaleiro' };
const RIVALS = ['Lâminas do Norte', 'Corvos de Ferro', 'Ordem da Aurora', 'Sangue Real'];
const NAMES = ['Kaio', 'Shiro', 'Valquíria', 'Nyx', 'Ragnar', 'Lili', 'Tóin', 'Mel', 'Kira', 'Zeca', 'Ayumi', 'Draco', 'Luna', 'Fênix', 'Pipoca', 'Biruta', 'Jujuba',
  'Odin', 'Sakura', 'Bento', 'Iara', 'Rubi', 'Tchê', 'Mago Zé', 'Duda', 'Gaia', 'Hiro', 'Juma', 'Lobão', 'Maya', 'Nina', 'Orion', 'Pérola', 'Quim', 'Rafa',
  'Sol', 'Tainá', 'Ulisses', 'Vivi', 'Yuri', 'Zara', 'Bia', 'Caco', 'Dante', 'Elfo', 'Fumaça', 'Gringo', 'Íris', 'Joca', 'Kenji', 'Lia', 'Mika', 'Neko'];
const CHAT = {
  calmo: ['alguém vende carta?', 'kkkk', 'boa noite, galera', 'q lag hoje', 'alguém pra grupo?', 'vende-se +7', 'tô só de boa aqui', 'olha o pôr do sol', 'quem quer trocar?', 'bora jogar Flavius?', 'afk 5 min', 'gg'],
  cacador: ['quem é o próximo?', 'corre!', 'ninguém escapa', 'saiam da frente'],
  vitoria: ['ez', 'gg', 'próximo!', 'kkk'],
  morte: ['lag!!', 'volto já', 'injusto', 'ah não'],
  bravo: ['ei! tava quieto aqui', 'agora é pessoal', 'tá bom então'],
};
const LINES = ['cavaleiro', 'bruxo', 'cacador', 'assassino', 'monge', 'shinobi', 'mestre_taekwon'];
const TEAM_COLORS = ['#7fe08a', '#ff6a6a', '#6ab8ff', '#ffd86b', '#d08aff', '#ff9a4a', '#7fe0d0', '#ff8ad0', '#c8b48a', '#a8f070'];

// perfis de cada linha (atributos e ordem das habilidades), os mesmos do robô de teste
const PROFILE = {
  cavaleiro: { path: ['espadachim', 'cavaleiro', 'espadachim_alto', 'lorde'], stats: { str: 3, vit: 2, dex: 1, agi: 1 }, app: ['primeiros_socorros', 'resistencia'], trans: ['furia_batalha', 'frenesi', 'perfuracao_espiral'],
    sk: ['golpe_fulminante', 'maestria_espada', 'impacto_explosivo', 'contra_ataque', 'revidar_projetil', 'vigor', 'corte_cruzado', 'aparar_golpe', 'redemoinho', 'fervor_batalha', 'ofensiva_furiosa', 'ambidestria'] },
  bruxo: { path: ['mago', 'bruxo', 'mago_alto', 'arquimago'], stats: { int: 4, dex: 2, vit: 1.2 }, app: ['faisca_arcana', 'primeiros_socorros'], trans: ['campo_gravitacional', 'absorver_alma'],
    sk: ['relampago', 'lanca_gelo', 'congelar', 'escudo_petrificante', 'meditacao', 'nevasca', 'olhar_medusa', 'ira_thor', 'vortice_jupiter', 'meteoro', 'lanca_fogo', 'amplificacao'] },
  cacador: { path: ['arqueiro', 'cacador', 'arqueiro_alto', 'atirador_elite'], stats: { dex: 4, agi: 2, vit: 1.2 }, app: ['arremessar_pedra', 'primeiros_socorros'], trans: ['tiro_preciso', 'ataque_falcao'],
    sk: ['tiro_duplo', 'olhos_coruja', 'olho_aguia', 'chuva_flechas', 'salto_tras', 'tiro_certeiro', 'rede', 'armadilha', 'virote_impacto', 'falcao', 'instinto'] },
  assassino: { path: ['gatuno', 'assassino', 'gatuno_alto', 'algoz'], stats: { agi: 3, str: 2.5, vit: 1, dex: 1, luk: 1 }, app: ['primeiros_socorros', 'resistencia'], trans: ['destruidor_almas', 'veneno_mortal'],
    sk: ['ataque_duplo', 'envenenar_arma', 'apunhalar', 'explosao_veneno', 'bomba_fumaca', 'esconderijo', 'laminas_sonicas', 'execucao', 'maestria_katar', 'furtividade', 'garra_sombria'] },
  monge: { path: ['novico', 'monge', 'novico_alto', 'mestre'], stats: { str: 3, vit: 2, agi: 1.5, dex: 1, int: 0.6 }, app: ['primeiros_socorros', 'resistencia'], trans: ['asura', 'zen'],
    sk: ['curar:1', 'luz_divina', 'chi', 'curar', 'kyrie', 'prece', 'bencao', 'punhos_triplos', 'palma_ferro', 'investida_monge', 'esferas_espirituais', 'postura_imovel', 'combo_cadeia'] },
  shinobi: { path: ['ninja', 'shinobi', 'ninja_alto', 'kagerou'], stats: { str: 2.5, dex: 2, agi: 2.5, vit: 1.5 }, app: ['arremessar_pedra', 'primeiros_socorros'], trans: ['kunai_sangrenta', 'lua_crescente'],
    sk: ['kunai', 'pulsar_sangue', 'respiracao_ninja', 'passos_sombra', 'fio_aco', 'substituicao', 'lamina_fantasma', 'hemorragia', 'arte_ninja', 'chuva_shuriken', 'clones_sombra'] },
  mestre_taekwon: { path: ['taekwon', 'mestre_taekwon', 'taekwon_alto', 'imperador_estelar'], stats: { str: 3, agi: 2.5, vit: 1.5, dex: 1 }, app: ['primeiros_socorros', 'resistencia'], trans: ['fusao_estelar', 'calor_sol'],
    sk: ['chute_machado', 'ritmo', 'chute_rasteira', 'corrida', 'postura_taekwon', 'chute_giratorio', 'chute_voador', 'chute_ascendente', 'unidade_corpo', 'furia_solar', 'protecao_estelar'] },
};
const PROJ = { bruxo: '#9ac8ff', cacador: '#f0e2b6', shinobi: '#c8d0dc', monge: '#fff2b0' };

// ---------------- Dados do herói no PvP ----------------
export function ensurePvp(h = hero()) {
  if (!h) return null;
  if (!h.pvp) h.pvp = {};
  const p = h.pvp;
  p.equip = p.equip || { weapon: null, left: null, head: null, armor: null, acc1: null, acc2: null };
  p.bag = p.bag || [];
  p.medals = p.medals || 0;
  p.stock = p.stock || {};
  p.stats = p.stats || { salaKills: 0, salaBest: 0, bcWins: 0, bcLosses: 0, woeWins: 0 };
  p.woeNext = p.woeNext || 0;
  return p;
}
// a guilda convida quem já é 1ª classe ou mais
export const pvpUnlocked = (h = hero()) => !!(h && CLASSES[h.cls] && (CLASSES[h.cls].tier || 0) >= 1);
export function ensureGuild(h = hero()) {
  const p = ensurePvp(h);
  if (!pvpUnlocked(h)) return null;
  if (!p.guild) {
    p.guild = { name: GUILD_NAME, leader: LEADER.name, joined: Date.now(), members: [], nextJoin: 0, rival: pick(RIVALS) };
    // os outros membros chegam depois de você: começa com 2, e vai entrando gente com o tempo (até 8)
    for (let i = 0; i < 2; i++) addMember(p.guild);
    p.newGuild = true;
  }
  return p.guild;
}
function addMember(g) {
  const used = new Set(g.members.map((m) => m.name).concat([LEADER.name]));
  const name = pick(NAMES.filter((n) => !used.has(n)));
  const have = new Set(g.members.map((m) => m.line));
  const line = pick(LINES.filter((l) => !have.has(l)).concat(LINES.filter(() => have.size >= LINES.length)));
  g.members.push({ name, line, since: Date.now() });
}
// a cada partida terminada, chance de um novo membro aparecer
function guildGrow(h) {
  const g = h.pvp.guild; if (!g || g.members.length >= 8) return;
  if (chance(35)) { addMember(g); const m = g.members[g.members.length - 1]; log(`${m.name} entrou para a ${GUILD_NAME}!`, '#7fe08a'); }
}

// ---------------- Construção dos aventureiros ----------------
function clsFor(line, h) {
  const c = CLASSES[h.cls], P = PROFILE[line];
  const tier = c.tier || 1, trans = !!(c.reborn || c.trans);
  return trans ? (tier >= 2 ? P.path[3] : P.path[2]) : (tier >= 2 ? P.path[1] : P.path[0]);
}
function spendStatsV(vh, ratios, pts) {
  let g = 0;
  while (pts > 0 && g++ < 2000) {
    const ks = Object.keys(ratios).sort((x, y) => vh.base[x] / ratios[x] - vh.base[y] / ratios[y]);
    let ok = false;
    for (const k of ks) { const c = statCost(vh.base[k]); if (pts >= c && vh.base[k] < 99) { pts -= c; vh.base[k]++; ok = true; break; } }
    if (!ok) break;
  }
}
// pontos de habilidade: classes anteriores completas; a classe atual só até o nível de classe do aventureiro
function learnV(vh, line, jobLv) {
  const P = PROFILE[line];
  for (const c of lineage(vh.cls)) {
    let pts = c === vh.cls ? Math.max(0, Math.min(jobMax(c), jobLv) - 1) : jobMax(c) - 1;
    const own = CLASSES[c].skills;
    const order = (CLASSES[c].tier === 0 ? P.app : (CLASSES[c].trans ? P.trans.concat(P.sk) : P.sk)).concat(own);
    for (const e of order) {
      const [id, cap] = e.split(':');
      if (!own.includes(id) || !SKILLS[id]) continue;
      while (pts > 0 && (vh.skills[id] || 0) < Math.min(SKILLS[id].max, cap ? +cap : 99)) { vh.skills[id] = (vh.skills[id] || 0) + 1; pts--; }
    }
  }
}
// equipamento de PvP de um aventureiro: todo mundo começa com o kit de Recruta. Conforme você joga partidas de PvP,
// aparece aos poucos uma chance baixíssima de alguém ter uma peça um pouco melhor (k vai de 0 a 1 em ~100 partidas)
export const gearAge = () => { const p = hero() && hero().pvp; return Math.min(1, ((p && p.stats && p.stats.matches) || 0) / 100); };
function botGear(line, tier) {
  const L = LINE_GEAR[line];
  const k = gearAge();
  const g = () => (chance(2 + 18 * k) ? (chance(70) ? 1 : chance(80) ? 2 : 3) : 0);   // Soldado a Campeão: de 2% a 20% por peça
  const ref = () => weighted([[0, 40], [1, 20], [2, 15], [3, 10 * k], [4, 7 * k], [5, 4 * k], [6, 2 * k], [7, 0.6 * k], [8, 0.2 * k], [9, 0.05 * k]]);
  const piece = (spec) => { const it = makePvpItem({ ...spec, g: g() }); if (it.g > 0) it.refine = spec.ps === 'acc' ? 0 : ref(); return it; };
  const wt = pick(L.wt);
  const eq = { weapon: piece({ ps: 'weapon', wt }), armor: piece({ ps: 'armor', k: L.armor }), head: piece({ ps: 'head', k: L.head }), left: null, acc1: null, acc2: null };
  if (L.left && !(WTYPES[wt] && WTYPES[wt].hands === 2)) eq.left = piece({ ps: 'shield', k: L.left });
  const st = Object.keys(PROFILE[line].stats);
  // acessórios só existem comprados (não há kit básico): raros no começo
  if (chance(3 + 30 * k)) eq.acc1 = makePvpItem({ ps: 'acc', st: st[0], g: 1 });
  if (chance(1 + 15 * k)) eq.acc2 = makePvpItem({ ps: 'acc', st: st[1] || st[0], g: 1 });
  // cartas de PvP de vez em quando
  const CARD = { weapon: ['tubarao'], left: ['sapo'], head: ['sereia', 'espectro_sombrio'], acc1: ['rato', 'diabrete', 'alma_perdida'], acc2: ['rato', 'diabrete', 'alma_perdida'] };
  for (const [slot, opts] of Object.entries(CARD)) { const it = eq[slot]; if (it && it.slots > 0 && chance(15 * k)) it.cards.push(pick(opts)); }
  return eq;
}
// nomes sem repetir dentro da mesma partida
function freshName() {
  const r0 = run(), P = r0 && r0.pvp, used = new Set([hero().name]);
  if (r0) for (const u of r0.monsters) if (u.pvp) used.add(u.pvp.name);
  if (P) { for (const q of P.pending || []) used.add(q.u.pvp.name); for (const t of Object.values(P.roster || {})) for (const u of t) used.add(u.pvp.name); }
  const g = hero().pvp && hero().pvp.guild; if (g) { used.add(g.leader); for (const m of g.members) used.add(m.name); }
  const free = NAMES.filter((n) => !used.has(n));
  return free.length ? pick(free) : pick(NAMES) + ' ' + rnd(2, 99);
}
// poção do aventureiro: a mesma que o herói teria nessa fase (cura fixa + % da vida, como as do Empório)
function potionHeal(lv, maxHp, vit) {
  const it = ITEMS[POTION_BY_TIER[Math.min(POTION_BY_TIER.length - 1, pvpTierFor(lv) - 1)]] || ITEMS.pocao_vermelha;
  return Math.floor((it.heal + maxHp * (it.healPct || 0) / 100) * (1 + vit * 0.01));
}
let NEXT = 1;
export let _lastGear = null;   // (testes) último equipamento gerado
export function makeBot(spec) {
  const h = hero();
  const line = spec.line || pick(LINES);
  const cls = spec.cls || clsFor(line, h);
  const lv = Math.max(1, spec.lv || h.lv + rnd(-2, 2));
  const jobLv = Math.max(1, (h.jobLv || 1) + rnd(-1, 1));   // segue o seu nível de classe
  const reborn = !!(CLASSES[cls].reborn || CLASSES[cls].trans);
  const vh = { name: spec.name, cls, lv, jobLv, reborn: reborn ? 1 : 0, base: { str: 1, agi: 1, vit: 1, int: 1, dex: 1, luk: 1 }, skills: {}, equip: {}, buffs: [], status: {},
    inPvp: true, pvp: { equip: spec.gear || botGear(line, pvpTierFor(lv)) } };
  // histórico de classes (bônus por nível de classe), como no Dev.setClass
  const chain = []; let c = cls; while (c) { chain.unshift(c); c = CLASSES[c].from; }
  vh.clsHistory = chain.map((k, i) => ({ cls: k, since: i === 0 ? 1 : Math.min(lv, ({ 1: 7, 2: 25 })[CLASSES[k].tier] || 1) }));
  let pts = 10 + (reborn ? REBORN_STAT_BONUS : 0); for (let l = 2; l <= lv; l++) pts += statPtsForLevel(l);
  spendStatsV(vh, PROFILE[line].stats, pts);
  learnV(vh, line, jobLv);
  _lastGear = vh.pvp.equip;
  const d = derive(vh, null);   // derive já aplica o ajuste de vida da classe no PvP (inPvp)
  setPvpTier(pvpTierFor(h.lv));
  const id = 'pvpu_' + (NEXT++) + '_' + uid();
  const u = {
    uid: uid(), type: id, x: 0, y: 0, lv,
    hp: d.maxHp, maxHp: d.maxHp, atk: d.atk, matk: d.matk, def: d.def, mdef: d.mdef, hit: d.hit, flee: d.flee, crit: d.crit, critDmg: d.critDmg,
    perfectDodge: d.perfectDodge, speed: d.speed, range: d.range, el: d.el, armorEl: d.armorEl, race: 'humanoide', dmgReduce: d.dmgReduce, raceDmg: {}, pierce: d.mods.pierce || 0,
    xp: 0, zeny: 0, boss: null, energy: rnd(0, 90), status: {}, cd: {}, ai: [], awake: true, asleep: false, tx: null, ty: null,
    pvp: { kind: 'bot', jobLv, name: spec.name || freshName(), cls, line, team: spec.team, pers: spec.pers || 'reativo', sp: d.maxSp, maxSp: d.maxSp, regenSp: d.regenSp, regenHp: d.regenHp,
      energy: !!d.energy, skills: vh.skills, dexAtk: d.dexAtk, ranged: d.ranged, wtype: d.wtype, statusResist: d.statusResist,
      mods: { pvpDmg: d.mods.pvpDmg || 0, pvpRes: d.mods.pvpRes || 0, ccRes: d.mods.ccRes || 0, kbImmune: d.mods.kbImmune || 0, spBurn: d.mods.spBurn || 0, reveal: d.mods.reveal || 0, pvpKillHeal: d.mods.pvpKillHeal || 0 },
      stats: vh.base, gearTxt: gearSummary(vh.pvp.equip), pots: spec.pots ?? 3, potHeal: potionHeal(lv, d.maxHp, vh.base.vit), potCd: 0, points: SALA_START, kills: 0, deaths: 0, color: spec.color || '#ff6a6a', guild: spec.guild || null, home: spec.home || null, post: spec.post || null },
  };
  registerUnit(u);
  return u;
}
function gearSummary(eq) {
  return Object.values(eq).filter(Boolean).map((it) => `${it.refine ? '+' + it.refine + ' ' : ''}${itemDef(it).name}${it.cards && it.cards.length ? ' [' + it.cards.map((c) => MONSTERS[c].name).join(', ') + ']' : ''}`);
}
// cada unidade ganha uma entrada própria na lista de monstros (nome, aparência), refeita ao carregar
export function registerUnit(u) {
  const p = u.pvp;
  if (p.kind === 'bot') MONSTERS[u.type] = { name: p.name, lv: u.lv, race: 'humanoide', el: 'neutro', ai: [], pvpUnit: true, magic: false, proj: PROJ[p.line] || '#fff',
    sprite: { shape: 'hero', c: [p.color, '#333'] }, card: { slot: 'acc', mods: {} } };
  else if (p.kind === 'guardian') MONSTERS[u.type] = { ...MONSTERS.cavaleiro_fantasma, name: p.name, art: 'cavaleiro_fantasma', pvpUnit: true, boss: false };
  else MONSTERS[u.type] = { name: p.name, lv: u.lv, race: 'objeto', el: 'neutro', ai: [], pvpUnit: true, structure: p.kind, color: p.color, sprite: { shape: 'blob', c: [p.color, '#222'] }, card: { slot: 'acc', mods: {} } };
}
function makeStructure(kind, team, hp, color, name) {
  const id = 'pvps_' + (NEXT++) + '_' + uid();
  const u = { uid: uid(), type: id, x: 0, y: 0, lv: hero().lv, hp, maxHp: hp, atk: 0, matk: 0, def: kind === 'emperium' ? 0 : 20, mdef: 20, hit: 0, flee: 0, crit: 0, critDmg: 0, perfectDodge: 0,
    speed: 100, range: 1, el: 'neutro', armorEl: 'neutro', race: 'objeto', dmgReduce: 0, raceDmg: {}, pierce: 0, xp: 0, zeny: 0, boss: false, energy: 0, status: {}, cd: {}, ai: [], awake: true, asleep: false,
    pvp: { kind, team, name, color, mods: {}, pots: 0 } };
  registerUnit(u);
  return u;
}

// ---------------- Mapas ----------------
function blankMap(w, h, theme) {
  return { w, h, t: new Array(w * h).fill(T.WALL), seen: new Array(w * h).fill(0), decor: new Array(w * h).fill(0), lights: [], rooms: [], theme, floor: 1, isBoss: false, pvpMap: true, stairs: null, portal: null };
}
const carve = (m, x0, y0, w, h) => { for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) setTile(m, x, y, T.FLOOR); };
const wall = (m, x, y) => setTile(m, x, y, T.WALL);
function torches(m, pts) { for (const [x, y] of pts) { m.lights.push({ x, y }); m.decor[y * m.w + x] = 'torch'; } }
// ---- cidade no estilo Prontera: praça com chafariz, avenidas, quarteirões de casas (os prédios da vila) e becos ----
// blocks: retângulos de parede onde fica um prédio; árvores e chafariz também são parede
function cityBase(w, h) {
  const m = blankMap(w, h, 0);
  m.city = true; m.blocks = [];
  carve(m, 1, 1, w - 2, h - 2);
  return m;
}
function block(m, x, y, bw, bh, model) {
  for (let yy = y; yy < y + bh; yy++) for (let xx = x; xx < x + bw; xx++) wall(m, xx, yy);
  m.blocks.push({ x, y, w: bw, h: bh, model });
}
function tree(m, x, y) { wall(m, x, y); m.decor[y * m.w + x] = 'tree'; }
function fountain(m, x, y) {   // poço 2×2 no meio e um anel de água em volta
  for (let yy = y - 1; yy <= y + 2; yy++) for (let xx = x - 1; xx <= x + 2; xx++) setTile(m, xx, yy, T.LIQUID);
  block(m, x, y, 2, 2, 'well');
}
function lamps(m) {   // lampiões na frente dos prédios (parede com chão logo abaixo)
  for (const b of m.blocks) if (b.model !== 'well') { const y = b.y + b.h - 1, x = b.x + (b.w > 3 ? 1 : 0); if (tileAt(m, x, y + 1) === T.FLOOR) m.decor[y * m.w + x] = 'torch'; }
}
function props(m, list) { for (const [x, y, d] of list) if (tileAt(m, x, y) === T.FLOOR) m.decor[y * m.w + x] = d; }
function mapSala() {
  const m = cityBase(32, 28);
  // quarteirões nos quatro cantos (a praça e as avenidas ficam livres)
  block(m, 2, 2, 5, 4, 'church'); block(m, 8, 2, 4, 3, 'home_A'); block(m, 2, 7, 3, 4, 'home_B');
  block(m, 25, 2, 5, 4, 'market'); block(m, 20, 2, 4, 3, 'home_B'); block(m, 27, 7, 3, 4, 'tower_B');
  block(m, 2, 17, 4, 4, 'blacksmith'); block(m, 2, 22, 5, 4, 'home_A'); block(m, 8, 23, 4, 3, 'lumbermill');
  block(m, 26, 17, 4, 4, 'tavern'); block(m, 25, 22, 5, 4, 'barracks'); block(m, 20, 23, 4, 3, 'home_A');
  fountain(m, 15, 13);
  for (const [x, y] of [[8, 8], [23, 8], [8, 19], [23, 19], [12, 5], [19, 5], [12, 22], [19, 22]]) tree(m, x, y);
  props(m, [[7, 6, 'barrel'], [24, 6, 'crate'], [7, 21, 'crate'], [24, 21, 'barrel'], [13, 3, 'barrel'], [18, 24, 'crate']]);
  lamps(m);
  m.start = { x: 15, y: 20 };
  return m;
}
function mapFlavius() {
  const m = cityBase(44, 22);
  // casas nas bordas de cima e de baixo; bases nas pontas com o cristal
  for (const [x, w, md] of [[11, 4, 'home_A'], [17, 3, 'tower_A'], [23, 4, 'market'], [29, 4, 'home_B']]) { block(m, x, 1, w, 3, md); block(m, x, 18, w, 3, md === 'market' ? 'tavern' : md); }
  block(m, 1, 1, 3, 3, 'tower_B'); block(m, 1, 18, 3, 3, 'tower_B'); block(m, 40, 1, 3, 3, 'tower_B'); block(m, 40, 18, 3, 3, 'tower_B');
  fountain(m, 21, 10);
  for (const [x, y] of [[15, 7], [15, 14], [28, 7], [28, 14]]) tree(m, x, y);
  props(m, [[10, 5, 'barrel'], [33, 16, 'crate'], [10, 16, 'crate'], [33, 5, 'barrel']]);
  lamps(m);
  m.spawnA = { x: 4, y: 11 }; m.spawnB = { x: 39, y: 11 }; m.crystalA = { x: 6, y: 11 }; m.crystalB = { x: 37, y: 11 };
  m.start = m.spawnA;
  return m;
}
function mapKvm() {
  const m = cityBase(28, 20);
  block(m, 1, 1, 4, 3, 'home_A'); block(m, 23, 1, 4, 3, 'home_B'); block(m, 1, 16, 4, 3, 'home_B'); block(m, 23, 16, 4, 3, 'home_A');
  block(m, 10, 1, 3, 3, 'tower_A'); block(m, 15, 16, 3, 3, 'tower_A');
  fountain(m, 13, 9);
  for (const [x, y] of [[7, 6], [20, 6], [7, 13], [20, 13]]) tree(m, x, y);
  lamps(m);
  m.spawnA = { x: 3, y: 10 }; m.spawnB = { x: 24, y: 10 }; m.start = m.spawnA;
  return m;
}
function mapCastle() {
  const m = blankMap(30, 40, 3);
  carve(m, 10, 30, 10, 8);              // pátio de entrada
  carve(m, 13, 22, 4, 8);               // corredor
  carve(m, 5, 14, 20, 8);               // salão
  carve(m, 13, 8, 4, 6);                // corredor do trono
  carve(m, 8, 2, 14, 6);                // sala do Emperium
  for (const [x, y] of [[8, 16], [21, 16], [8, 19], [21, 19]]) wall(m, x, y);
  torches(m, [[8, 2], [21, 2], [5, 14], [24, 14], [10, 30], [19, 30]]);
  m.emp = { x: 15, y: 4 }; m.spawnA = { x: 15, y: 36 }; m.spawnD = { x: 15, y: 6 }; m.start = m.spawnA;
  return m;
}
function freeSpot(near, rad = 3, avoid) {
  const r = run();
  for (let k = 0; k < 200; k++) {
    const x = near.x + rnd(-rad, rad), y = near.y + rnd(-rad, rad);
    if (!passable(tileAt(r.map, x, y)) || _occupied(x, y)) continue;
    if (avoid && avoid(x, y)) continue;
    return { x, y };
  }
  return null;
}
function randomSpot(avoidFoes) {
  const r = run(), m = r.map;
  for (let k = 0; k < 400; k++) {
    const x = rnd(1, m.w - 2), y = rnd(1, m.h - 2);
    if (!passable(tileAt(m, x, y)) || _occupied(x, y)) continue;
    if (avoidFoes && (dist(x, y, r.px, r.py) < 6 || r.monsters.some((o) => o.hp > 0 && dist(o.x, o.y, x, y) < 4))) continue;
    return { x, y };
  }
  return { x: r.map.start.x, y: r.map.start.y };
}
function place(u, spot) { const s = spot || randomSpot(true); u.x = s.x; u.y = s.y; run().monsters.push(u); }

// ---------------- Início e fim das partidas ----------------
function newRun(map, pvp) {
  const h = hero();
  h.buffs = (h.buffs || []).filter((b) => b.aura || b.toggle);
  h.status = {};
  h.inPvp = true;
  S().run = { floor: 1, log: [], telegraphs: [], items: [], monsters: [], time: 0, turns: 0, energy: 100, px: map.start.x, py: map.start.y, reviveUsed: false,
    map, traps: [], smokes: [], fields: [], sinceSpawn: 0, pvp };
  S().mode = 'dungeon';
  recalc();
  h.hp = G.d.maxHp; h.sp = G.d.maxSp;
  for (let i = 0; i < map.t.length; i++) if (map.t[i] !== T.WALL) map.seen[i] = 1;
}
export function canPvp() {
  const h = hero();
  if (!pvpUnlocked(h)) return 'A guilda só aceita quem já é 1ª classe.';
  if (S().mode !== 'town') return 'Volte para a vila primeiro.';
  return null;
}
// Sala de PvP: todos contra todos, pontos à moda do Ragnarok
export function startSala() {
  const e = canPvp(); if (e) return e;
  ensureGuild();
  const map = mapSala();
  newRun(map, { mode: 'sala', heroTeam: 'H', heroPts: SALA_START, heroKills: 0, heroDeaths: 0, best: 99, pending: [], arrivals: 0, maxBots: 8, rankTurns: 0 });
  const n = rnd(6, 8);
  let duo = null;
  for (let i = 0; i < n; i++) {
    const pers = weighted([['calmo', 35], ['reativo', 30], ['cacador', 20], ['dupla', 15]]);
    const team = pers === 'dupla' ? (duo || (duo = 'D' + uid())) : 'S' + i;
    const u = makeBot({ team, pers, color: TEAM_COLORS[(i + 1) % TEAM_COLORS.length] });
    place(u);
  }
  updateView();
  log('Sala de PvP: você começa com 5 pontos. Derrotar alguém dá +1, cair tira 5. Abaixo de 0, você é expulso.', '#ffd86b');
  fx({ type: 'floor' });
  save();
  return null;
}
// Batalha Campal 5×5: Flavius (cristal) ou KVM (eliminação), melhor de 3
export function startBC(kind) {
  const e = canPvp(); if (e) return e;
  const g = ensureGuild();
  const map = kind === 'flavius' ? mapFlavius() : mapKvm();
  const rival = g.rival || pick(RIVALS);
  newRun(map, { mode: kind, heroTeam: 'A', round: 1, score: { A: 0, B: 0 }, rival, roundTurns: 0, heroOut: false, pending: [] });
  const P = run().pvp;
  // seu time: você e 4 da guilda; o outro: 5 da guilda rival
  const mates = g.members.slice(0, 4).map((mm) => ({ name: mm.name, line: mm.line }));
  while (mates.length < 4) mates.push({ name: pick(NAMES), line: pick(LINES) });
  P.roster = { A: mates.map((mm) => makeBot({ name: mm.name, line: mm.line, team: 'A', pers: 'time', color: '#7fe08a', guild: GUILD_NAME, pots: 3 })),
    B: Array.from({ length: 5 }, () => makeBot({ team: 'B', pers: 'time', color: '#ff6a6a', guild: rival, pots: 3 })) };
  setupRound();
  log(`Batalha Campal (${kind === 'flavius' ? 'Flavius' : 'KVM'}) contra ${rival}: melhor de 3. Quem cai fica fora até o fim da rodada.`, '#ffd86b');
  if (kind === 'flavius') log('Destrua o cristal deles antes que destruam o seu.', '#ffd86b');
  fx({ type: 'floor' });
  save();
  return null;
}
function setupRound() {
  const r = run(), P = r.pvp, m = r.map, h = hero();
  r.monsters = [];
  P.roundTurns = 0; P.heroOut = false; P.roundOver = false;
  recalc(); h.hp = G.d.maxHp; h.sp = G.d.maxSp; h.status = {}; h.cd = {};
  r.px = m.spawnA.x; r.py = m.spawnA.y;
  for (const t of ['A', 'B']) for (const u of P.roster[t]) {
    u.hp = u.maxHp; u.pvp.sp = u.pvp.maxSp; u.status = {}; u.cd = {}; u.pvp.pots = 3; u.pvp.potCd = 0;
    place(u, freeSpot(t === 'A' ? m.spawnA : m.spawnB, 2));
  }
  if (P.mode === 'flavius') {
    const avg = P.roster.A.concat(P.roster.B).reduce((a, u) => a + u.maxHp, 0) / 10;
    const hp = Math.round(avg * 4);
    P.crystal = { A: makeStructure('crystal', 'A', hp, '#6ab8ff', 'Cristal azul'), B: makeStructure('crystal', 'B', hp, '#ff6a6a', 'Cristal vermelho') };
    place(P.crystal.A, m.crystalA); place(P.crystal.B, m.crystalB);
    for (const t of ['A', 'B']) for (let i = 0; i < 2; i++) {
      const c = t === 'A' ? m.crystalA : m.crystalB;
      const gd = makeGuardian(t, { x: c.x + (t === 'A' ? 2 : -2), y: c.y + (i ? 2 : -2) });
      place(gd, freeSpot(gd.pvp.post, 1));
    }
  }
  updateView();
}
function makeGuardian(team, post, extra = 0) {
  const h = hero();
  const b = makeBot({ line: 'cavaleiro', team, pers: 'guarda', lv: h.lv + 1 + Math.floor(extra / 2), color: team === 'A' || team === 'D' ? '#7fe08a' : '#ff6a6a', pots: 0, name: 'Guardião' });
  b.pvp.kind = 'guardian'; b.pvp.post = post; b.pvp.skills = {}; b.maxHp = b.hp = Math.round(b.maxHp * (1.3 + extra * 0.06)); b.def += 5 + extra * 2;
  registerUnit(b);
  return b;
}
// WoE: atacar o castelo da guilda rival (ou defender o seu)
export function woeStatus(h = hero()) {
  const p = ensurePvp(h);
  const left = Math.max(0, (p.woeNext || 0) - Date.now());
  return { ready: left <= 0, left, owned: !!(p.castle && p.castle.owned), castle: p.castle || null };
}
export function startWoe() {
  const e = canPvp(); if (e) return e;
  const st = woeStatus(); if (!st.ready) return 'A Guerra do Emperium ainda não começou.';
  const g = ensureGuild(), h = hero(), p = h.pvp;
  p.woeNext = Date.now() + WOE_COOLDOWN_MS;   // a recarga conta do começo da guerra (fechar o app não dá outra chance)
  const map = mapCastle();
  const defend = st.owned;
  const rival = g.rival;
  const ourTeam = 'A', theirTeam = 'B';
  newRun(map, { mode: 'woe', heroTeam: ourTeam, defend, rival, turnsLeft: defend ? 160 : 200, pending: [], heroOut: false });
  const P = run().pvp;
  if (defend) { r().px = map.spawnD.x; r().py = map.spawnD.y; }
  const empHp = 50 + (defend ? (p.castle.defense || 0) * 8 : 10);
  P.emp = makeStructure('emperium', defend ? ourTeam : theirTeam, empHp, '#ffd86b', 'Emperium');
  place(P.emp, map.emp);
  const mates = g.members.slice(0, 6).map((mm) => ({ name: mm.name, line: mm.line }));
  while (mates.length < 5) mates.push({ name: pick(NAMES), line: pick(LINES) });
  const ours = mates.map((mm) => makeBot({ name: mm.name, line: mm.line, team: ourTeam, pers: 'time', color: '#7fe08a', guild: GUILD_NAME, pots: 4, home: defend ? map.spawnD : map.spawnA }));
  // quem ataca vem com um a mais (você conta no seu time); quem defende tem guardiões e o caminho curto
  const theirs = Array.from({ length: defend ? mates.length + 2 : Math.max(3, mates.length - 1) }, () => makeBot({ team: theirTeam, pers: 'time', color: '#ff6a6a', guild: rival, pots: 4, home: defend ? map.spawnA : map.spawnD }));
  for (const u of ours) place(u, freeSpot(u.pvp.home, 2));
  for (const u of theirs) place(u, freeSpot(u.pvp.home, 2));
  // guardiões de quem defende (mais fortes com o investimento em defesa)
  const defTeam = defend ? ourTeam : theirTeam, lvl = defend ? (p.castle.defense || 0) : 1;
  const posts = [{ x: 12, y: 10 }, { x: 18, y: 10 }, { x: 10, y: 18 }, { x: 20, y: 18 }].slice(0, 2 + Math.floor(lvl / 4));
  for (const post of posts) { const gd = makeGuardian(defTeam, post, lvl); place(gd, freeSpot(post, 1)); }
  P.units = { [ourTeam]: ours, [theirTeam]: theirs };
  updateView();
  log(defend ? `Guerra do Emperium: ${rival} ataca o seu castelo! Proteja o Emperium por ${P.turnsLeft} turnos.` : `Guerra do Emperium: invada o castelo de ${rival} e quebre o Emperium em ${P.turnsLeft} turnos.`, '#ffd86b');
  log('O Emperium só sente o ataque básico: cada golpe tira 1. Na WoE ninguém é empurrado.', '#ffd86b');
  fx({ type: 'floor' });
  save();
  return null;
}
const r = () => run();

// fim da partida: marcado na hora, executado no fim do turno (em ponto seguro)
function endMatch(res) { const P = run() && run().pvp; if (P && !P.finishRes) P.finishRes = res; }
// troca de rodada e fim de partida pendentes; devolve true se a partida acabou
export function pvpFlush() {
  const P = run() && run().pvp; if (!P) return false;
  if (P.finishRes) { doEndMatch(P.finishRes); return true; }
  if (P.nextRound) { P.nextRound = false; P.round++; setupRound(); log(`Rodada ${P.round}!`, '#ffd86b'); fx({ type: 'floor' }); }
  return false;
}
function doEndMatch(res) {
  const h = hero(), p = ensurePvp(h), P = run().pvp;
  p.stats.matches = (p.stats.matches || 0) + 1;   // com o tempo os outros aventureiros aparecem um pouco mais equipados
  p.medals += res.medals || 0;
  for (const [k, n] of Object.entries(res.stock || {})) p.stock[k] = (p.stock[k] || 0) + n;
  S().pvpResult = { ...res, mode: P.mode, at: Date.now() };
  h.inPvp = false;
  h.buffs = (h.buffs || []).filter((b) => b.aura || b.toggle);
  h.status = {};
  S().run = null;
  S().mode = 'town';
  S().townLog = [];
  recalc();
  h.hp = G.d.maxHp; h.sp = G.d.maxSp;
  guildGrow(h);
  fx({ type: 'sfx', name: res.win ? 'levelup' : 'click' });
  save();
}
// sair no meio (botão de voltar): na sala leva o que fez; nas batalhas conta como derrota
export function leaveMatch() {
  const P = run() && run().pvp; if (!P) return;
  if (P.mode === 'sala') endSala('saiu');
  else if (P.mode === 'woe') endWoe(false, 'abandonou');
  else endBC('B', true);
  pvpFlush();
}

// ---------------- Sala: pontos, chegadas, recompensa ----------------
function salaRank() {
  const P = run().pvp;
  const all = run().monsters.filter((u) => u.pvp && u.pvp.kind === 'bot' && u.hp > 0).map((u) => u.pvp.points).concat(P.pending.map((q) => q.u.pvp.points));
  return 1 + all.filter((v) => v > P.heroPts).length;
}
export function salaBoard() {
  const r0 = run(); if (!r0 || !r0.pvp || r0.pvp.mode !== 'sala') return [];
  const P = r0.pvp;
  const rows = r0.monsters.filter((u) => u.pvp && u.pvp.kind === 'bot' && u.hp > 0).concat(P.pending.map((q) => q.u)).map((u) => ({ name: u.pvp.name, pts: u.pvp.points, k: u.pvp.kills, cls: u.pvp.cls }));
  rows.push({ name: hero().name, pts: P.heroPts, k: P.heroKills, cls: hero().cls, me: true });
  return rows.sort((a, b) => b.pts - a.pts);
}
function endSala(why) {
  const P = run().pvp, h = hero(), p = ensurePvp(h);
  const best = Math.min(P.best, salaRank());
  const kills = P.heroKills;
  // medalhas: 1 por vitória (até 25) + bônus pela melhor posição alcançada
  const podium = kills >= 3 ? best : 99;   // posição só conta para quem derrubou alguém (todos começam empatados em 1º)
  let medals = Math.min(25, kills) + (podium === 1 ? 6 : podium === 2 ? 4 : podium === 3 ? 2 : 0);
  if (why === 'expulso') medals = Math.floor(medals / 2);
  const stock = {};
  if (podium === 1 && P.rankTurns >= 30 && chance(25)) stock.trevo_dourado = 1;   // segurou o 1º lugar por um bom tempo
  if (podium === 1 && kills >= 15 && chance(15)) stock.diario = 1;
  p.stats.salaKills += kills; if (podium < 99) p.stats.salaBest = p.stats.salaBest ? Math.min(p.stats.salaBest, podium) : podium;
  endMatch({ title: why === 'expulso' ? 'Expulso da Sala de PvP' : 'Você saiu da Sala de PvP', win: podium === 1, lines: [`Vitórias: ${kills}`, `Quedas: ${P.heroDeaths}`, podium < 99 ? `Melhor posição: ${podium}º` : 'Posição só conta a partir de 3 vitórias'], medals, stock });
}
function salaArrival() {
  const P = run().pvp;
  const alive = run().monsters.filter((u) => u.pvp && u.pvp.kind === 'bot' && u.hp > 0).length + P.pending.length;
  if (alive >= P.maxBots || !chance(alive < 4 ? 30 : 8)) return;
  // às vezes chega alguém disposto a derrubar todo mundo
  const pers = chance(35) ? 'cacador' : weighted([['calmo', 45], ['reativo', 55]]);
  const u = makeBot({ team: 'S' + uid(), pers, color: pick(TEAM_COLORS), lv: hero().lv + rnd(-2, pers === 'cacador' ? 5 : 3) });
  place(u);
  log(`${u.pvp.name} (${CLASSES[u.pvp.cls].name}) entrou na sala${pers === 'cacador' ? ' com cara de poucos amigos' : ''}.`, '#c9ccd6');
}

// ---------------- Batalha Campal: rodadas ----------------
function teamAlive(t) { return run().monsters.some((u) => u.pvp && u.pvp.kind === 'bot' && u.pvp.team === t && u.hp > 0) || (t === run().pvp.heroTeam && !run().pvp.heroOut); }
function checkRound() {
  const P = run().pvp; if (!P || P.roundOver) return;
  let win = null;
  if (P.mode === 'flavius') { if (P.crystal.B.hp <= 0) win = 'A'; else if (P.crystal.A.hp <= 0) win = 'B'; }
  if (!win) { const a = teamAlive('A'), b = teamAlive('B'); if (!a && !b) win = 'B'; else if (!a) win = 'B'; else if (!b) win = 'A'; }
  if (!win && P.roundTurns >= 220) { // tempo esgotado: quem tem mais vida (e cristal) vence
    const sc = (t) => run().monsters.filter((u) => u.pvp && u.pvp.team === t && u.hp > 0).reduce((a, u) => a + u.hp / u.maxHp, 0) + (t === 'A' && !P.heroOut ? hero().hp / G.d.maxHp : 0);
    win = sc('A') >= sc('B') ? 'A' : 'B';
  }
  if (win) roundWon(win);
}
function roundWon(t) {
  const P = run().pvp; P.roundOver = true;
  P.score[t]++;
  log(`Rodada ${P.round}: ${t === 'A' ? 'vitória da ' + GUILD_NAME : 'vitória de ' + P.rival}! (${P.score.A} × ${P.score.B})`, t === 'A' ? '#7fe08a' : '#ff8a8a');
  fx({ type: 'text', x: run().px, y: run().py, text: t === 'A' ? 'Rodada nossa!' : 'Rodada deles', color: t === 'A' ? '#7fe08a' : '#ff8a8a' });
  if (P.score[t] >= 2) return endBC(t);
  P.nextRound = true;   // a próxima rodada começa no fim do turno
}
function endBC(winner, quit) {
  const P = run().pvp, p = ensurePvp();
  const win = winner === 'A' && !quit;
  if (win) p.stats.bcWins++; else p.stats.bcLosses++;
  const stock = {};
  if (win && chance(8)) stock[pick(['diario', 'trevo_dourado'])] = 1;
  endMatch({ title: win ? 'Vitória na Batalha Campal!' : quit ? 'Você deixou a Batalha Campal' : 'Derrota na Batalha Campal', win, lines: [`Placar: ${P.score.A} × ${P.score.B}`, `Contra: ${P.rival}`], medals: quit ? 0 : win ? 12 : 4, stock });
}
// o herói caiu numa rodada: os outros terminam a rodada sem ele (acelerado)
function simulateRest() {
  const r0 = run(), P = r0.pvp;
  let guard = 0;
  while (S().mode === 'dungeon' && run() === r0 && !P.roundOver && !P.finishRes && guard++ < 6000) {
    r0.time++;
    for (const u of [...r0.monsters]) {
      if (u.hp <= 0) continue;
      u.energy += u.speed / 10 * ((u.status.slow || 0) > 0 ? 0.5 : 1);
      while (u.energy >= 100 && u.hp > 0 && !P.roundOver && !P.finishRes) { u.energy -= 100; unitAct(u); }
      if (P.roundOver || P.finishRes || run() !== r0) return;
    }
    r0.monsters = r0.monsters.filter((u) => u.hp > 0);
    if (r0.time % 10 === 0) { pvpTurnEnd(); tickUnits(); }
    checkRound();
  }
}
function tickUnits() {
  for (const m of run().monsters) {
    if (m.hp <= 0) continue;
    for (const k of Object.keys(m.status)) { m.status[k]--; if (m.status[k] <= 0) delete m.status[k]; }
    for (const k of Object.keys(m.cd)) if (m.cd[k] > 0) m.cd[k]--;
  }
}

// ---------------- WoE ----------------
function endWoe(win, why) {
  const P = run().pvp, h = hero(), p = ensurePvp(h);
  p.woeNext = Date.now() + WOE_COOLDOWN_MS;
  const lines = [];
  let medals = 0; const stock = {};
  if (P.defend) {
    if (win) { medals = 30; p.stats.woeWins++; lines.push('O castelo continua da ' + GUILD_NAME + '.'); }
    else { p.castle.owned = false; medals = 8; lines.push(`${P.rival} tomou o castelo.`); }
  } else if (win) {
    p.castle = { owned: true, since: Date.now(), econ: (p.castle && p.castle.econ) || 0, defense: (p.castle && p.castle.defense) || 0, lastChest: 0 };
    medals = 40; p.stats.woeWins++; lines.push('O castelo agora é da ' + GUILD_NAME + '!');
    if (chance(30)) stock[pick(['diario', 'trevo_dourado'])] = 1;
  } else { medals = 6; lines.push(why === 'abandonou' ? 'Você deixou a batalha.' : 'O Emperium resistiu.'); }
  if (why === 'abandonou') medals = 0;
  lines.push('A próxima WoE abre em 6 horas.');
  endMatch({ title: win ? 'Vitória na Guerra do Emperium!' : 'Fim da Guerra do Emperium', win, lines, medals, stock });
}

// ---------------- Castelo: baú diário e investimentos ----------------
export const CHEST_MS = 24 * 3600e3;
export function castleInfo(h = hero()) {
  const p = ensurePvp(h), c = p.castle;
  if (!c || !c.owned) return null;
  return { ...c, chestReady: Date.now() - (c.lastChest || 0) >= CHEST_MS, chestLeft: Math.max(0, (c.lastChest || 0) + CHEST_MS - Date.now()),
    econCost: 40 + (c.econ || 0) * 30, defCost: 40 + (c.defense || 0) * 30 };
}
export function openChest() {
  const h = hero(), p = ensurePvp(h), c = castleInfo(h);
  if (!c) return { msg: 'Sua guilda não tem castelo.' };
  if (!c.chestReady) return { msg: 'O baú ainda está vazio.' };
  p.castle.lastChest = Date.now();
  const medals = 15 + (c.econ || 0) * 5 + rnd(0, 10);
  p.medals += medals;
  const got = [`${medals} Medalhas de Honra`];
  if (chance(12 + (c.econ || 0) * 4)) { const k = pick(['diario', 'trevo_dourado']); p.stock[k] = (p.stock[k] || 0) + 1; got.push(BOOSTS[k].name); }
  if (chance(10 + (c.econ || 0) * 3)) { const mon = pick(['rato', 'sapo', 'diabrete', 'alma_perdida', 'sereia', 'tubarao', 'espectro_sombrio']); h.inv.push(makeCard(mon)); got.push('Carta ' + MONSTERS[mon].name); }
  save();
  return { ok: true, msg: 'Baú do castelo: ' + got.join(', ') };
}
export function invest(kind) {
  const p = ensurePvp(), c = castleInfo();
  if (!c) return 'Sua guilda não tem castelo.';
  const key = kind === 'econ' ? 'econ' : 'defense';
  if ((p.castle[key] || 0) >= 10) return 'Já está no máximo.';
  const cost = kind === 'econ' ? c.econCost : c.defCost;
  if (p.medals < cost) return 'Medalhas insuficientes.';
  p.medals -= cost; p.castle[key] = (p.castle[key] || 0) + 1;
  save();
  return null;
}

// ---------------- Loja e equipamento de PvP ----------------
export function buyPvp(spec) {
  const p = ensurePvp();
  let price;
  if (spec.boost) price = PVP_SHOP_ITEMS[spec.boost];
  else price = (PVP_PRICES[spec.ps === 'shield' ? 'shield' : spec.ps] || [])[spec.g];
  if (!price) return 'Item inválido.';
  if (p.medals < price) return 'Medalhas insuficientes.';
  if (!spec.boost && p.bag.length >= 40) return 'A bolsa de PvP está cheia.';
  p.medals -= price;
  if (spec.boost) p.stock[spec.boost] = (p.stock[spec.boost] || 0) + 1;
  else p.bag.push(makePvpItem(spec));
  save();
  return null;
}
const PSLOT = { weapon: ['weapon'], armor: ['armor'], head: ['head'], shield: ['left'], acc: ['acc1', 'acc2'] };
export function equipPvp(u, slot) {
  const h = hero(), p = ensurePvp(h);
  const it = p.bag.find((o) => o.uid === u); if (!it) return 'Item não encontrado.';
  let opts = PSLOT[it.ps] || [];
  if (it.ps === 'weapon' && (CLASSES[h.cls] && ['gatuno', 'assassino', 'ninja', 'shinobi'].includes(baseCls(h.cls)) || /gatuno|ninja/.test(h.cls)) && !(WTYPES[it.wt] && WTYPES[it.wt].hands === 2)) opts = ['weapon', 'left'];
  if (!opts.length) return 'Não serve.';
  if (it.ps === 'shield' && LINE_GEAR[lineOf(h.cls)] && !LINE_GEAR[lineOf(h.cls)].left) return 'Sua classe não usa escudo.';
  if (!opts.includes(slot)) slot = opts.find((k) => !p.equip[k]) || opts[0];
  const old = p.equip[slot];
  p.bag = p.bag.filter((o) => o !== it);
  p.equip[slot] = it;
  if (old) p.bag.push(old);
  if (it.ps === 'weapon' && slot === 'weapon' && WTYPES[it.wt] && WTYPES[it.wt].hands === 2 && p.equip.left) { p.bag.push(p.equip.left); p.equip.left = null; }
  if (slot === 'left' && p.equip.weapon && WTYPES[p.equip.weapon.wt] && WTYPES[p.equip.weapon.wt].hands === 2) { p.bag.push(p.equip.weapon); p.equip.weapon = null; }
  save();
  return null;
}
export function unequipPvp(slot) {
  const p = ensurePvp(); const it = p.equip[slot]; if (!it) return;
  p.equip[slot] = null; p.bag.push(it); save();
}
export function sellPvp(u) {
  const p = ensurePvp(); const it = p.bag.find((o) => o.uid === u); if (!it) return 0;
  const price = (PVP_PRICES[it.ps === 'shield' ? 'shield' : it.ps] || [])[it.g] || 0;
  const back = Math.floor(price * 0.3);
  p.bag = p.bag.filter((o) => o !== it); p.medals += back; save();
  return back;
}
const pvpFind = (u) => { const p = ensurePvp(); return p.bag.find((o) => o.uid === u) || Object.values(p.equip).find((o) => o && o.uid === u); };
// refino de PvP: sem martelo. Qualquer falha quebra a peça
export const PVP_REFINE_RATES = [100, 100, 100, 100, 70, 60, 50, 40, 25, 15];
export function pvpRefineInfo(it) {
  const d = itemDef(it);
  if (!it || it.g === 0 || it.ps === 'acc' || d.noRefine) return null;
  const r0 = it.refine || 0;
  if (r0 >= 10) return { max: true };
  return { rate: PVP_REFINE_RATES[r0], cost: (r0 + 1) * 8, next: r0 + 1, safe: PVP_REFINE_RATES[r0] >= 100 };
}
export function refinePvp(u) {
  const p = ensurePvp(), it = pvpFind(u);
  if (!it) return { msg: 'Item não encontrado.' };
  const info = pvpRefineInfo(it);
  if (!info || info.max) return { msg: 'Não pode ser refinado.' };
  if (p.medals < info.cost) return { msg: 'Medalhas insuficientes.' };
  p.medals -= info.cost;
  if (chance(info.rate)) { it.refine = (it.refine || 0) + 1; fx({ type: 'sfx', name: 'refineok' }); save(); return { ok: true, msg: `Sucesso! +${it.refine} ${itemDef(it).name}` }; }
  for (const k of Object.keys(p.equip)) if (p.equip[k] === it) p.equip[k] = null;
  p.bag = p.bag.filter((o) => o !== it);
  fx({ type: 'sfx', name: 'refinefail' }); save();
  return { ok: false, msg: `O refino falhou... ${itemDef(it).name} se quebrou.` };
}
// cartas: saem da mochila do herói e entram na peça de PvP (para sempre)
export function insertPvpCard(cardUid, itemUid) {
  const h = hero(), it = pvpFind(itemUid), card = h.inv.find((o) => o.uid === cardUid);
  if (!it || !card) return 'Item não encontrado.';
  const cd = itemDef(card), d = itemDef(it);
  const kind = d.kind === 'shield' ? 'shield' : d.kind;
  if (cd.slot !== kind) return 'Esta carta não encaixa nesta peça.';
  if ((it.cards || []).length >= (it.slots || 0)) return 'Sem slot livre.';
  it.cards.push(card.mon);
  h.inv = h.inv.filter((o) => o !== card);
  save();
  return null;
}

// ---------------- Unidades: dano, queda, turno ----------------
const isFoeOf = (a, b) => a && b && a !== b && a.pvp && b.pvp && a.pvp.team !== b.pvp.team;
export const isAlly = (m) => { const P = run() && run().pvp; return !!(P && m.pvp && m.pvp.team === P.heroTeam); };
const heroFoe = (u) => { const P = run().pvp; return u.pvp.team !== P.heroTeam; };
const unitName = (u) => (u === 'hero' ? hero().name : u && u.pvp ? u.pvp.name : '?');
function say(u, list) { if (!u || u.hp <= 0) return; fx({ type: 'text', x: u.x, y: u.y, text: '💬 ' + pick(list), color: '#e8eaf2', delay: 200 }); }

// o herói acerta uma unidade (chamado pelo damageMonster): ajusta o dano e devolve null se não pega
export function heroHitsUnit(m, v, info = {}) {
  const P = run().pvp, p = m.pvp;
  if (p.team === P.heroTeam) return null;
  if (p.kind === 'emperium') {
    if (!info.basic) { fx({ type: 'text', x: m.x, y: m.y, text: 'imune', color: '#c8b8a0' }); return null; }
    return 1;
  }
  if (p.kind === 'crystal') return Math.max(1, Math.round(v * PVP_MUL));
  v = v * PVP_MUL * earlyMul(hero().cls, hero().jobLv) * pvpLine(hero().cls, hero().jobLv).dmg * (1 + (G.d.mods.pvpDmg || 0) / 100) * (1 - Math.min(80, p.mods.pvpRes || 0) / 100);
  if (G.d.mods.spBurn && p.sp !== undefined) p.sp = Math.max(0, p.sp - Math.ceil((p.maxSp || 0) * G.d.mods.spBurn / 100));
  p.lastHit = 'hero';
  if (p.pers === 'calmo' && !p.angry) { p.angry = true; say(m, CHAT.bravo); }
  p.angry = true;
  return Math.max(1, Math.round(v));
}
// uma unidade cai (pelo herói ou por outra unidade)
export function unitDown(m, by) {
  const r0 = run(), P = r0.pvp, p = m.pvp;
  m.hp = 0;
  fx({ type: 'death', x: m.x, y: m.y, color: p.color || '#888', uid: m.uid, mtype: m.type });
  fx({ type: 'sfx', name: 'kill' });
  if (p.kind === 'crystal' || p.kind === 'emperium') {
    log(`${p.name} foi destruído!`, '#ffd86b');
    if (P.mode === 'flavius') checkRound();
    if (P.mode === 'woe') endWoe(!P.defend, 'quebrou');
    return;
  }
  const killer = by === 'hero' ? 'hero' : by;
  if (P.mode === 'sala') {
    p.points -= 5; p.deaths++;
    if (killer === 'hero') { P.heroPts++; P.heroKills++; heroKillHeal(); }
    else if (killer && killer.pvp) { killer.pvp.points++; killer.pvp.kills++; unitKillHeal(killer); if (chance(30)) say(killer, CHAT.vitoria); }
    if (chance(25)) say(m, CHAT.morte);
    if (p.points < 0) log(`${p.name} foi expulso da sala.`, '#9ab');
    else P.pending.push({ u: m, at: r0.turns + 3 });
  } else if (P.mode === 'woe') {
    if (killer === 'hero') heroKillHeal(); else if (killer && killer.pvp) unitKillHeal(killer);
    if (p.kind === 'bot') P.pending.push({ u: m, at: r0.turns + (P.emp && P.emp.pvp.team === p.team ? 6 : 4) });
  } else {
    if (killer === 'hero') heroKillHeal(); else if (killer && killer.pvp) unitKillHeal(killer);
    checkRound();
  }
  log(`${unitName(killer)} derrotou ${p.name}.`, killer === 'hero' ? '#9fe08a' : '#c9ccd6');
}
function heroKillHeal() { const k = G.d.mods.pvpKillHeal; if (!k) return; const h = hero(); h.hp = Math.min(G.d.maxHp, h.hp + Math.ceil(G.d.maxHp * k / 100)); h.sp = Math.min(G.d.maxSp, h.sp + Math.ceil(G.d.maxSp * k / 100)); }
function unitKillHeal(u) { const k = u.pvp.mods.pvpKillHeal; if (!k) return; u.hp = Math.min(u.maxHp, u.hp + Math.ceil(u.maxHp * k / 100)); u.pvp.sp = Math.min(u.pvp.maxSp, u.pvp.sp + Math.ceil(u.pvp.maxSp * k / 100)); }

// o herói caiu no PvP (não perde nada da campanha)
export function heroDown(source) {
  const r0 = run(), P = r0.pvp, h = hero();
  const by = P.lastHeroHit;
  if (P.mode === 'sala') {
    P.heroPts -= 5; P.heroDeaths++;
    if (by && by.pvp && by.hp > 0) { by.pvp.points++; by.pvp.kills++; unitKillHeal(by); if (chance(40)) say(by, CHAT.vitoria); }
    log(`${source || 'Alguém'} derrubou você. (${P.heroPts} pontos)`, '#ff8a8a');
    if (P.heroPts < 0) return endSala('expulso');
    respawnHero(randomSpot(true));
    return;
  }
  if (P.mode === 'woe') {
    log(`Você caiu e voltou para a base.`, '#ff8a8a');
    respawnHero(freeSpot(P.defend ? r0.map.spawnD : r0.map.spawnA, 2) || r0.map.start);
    return;
  }
  // Batalha Campal: fora até o fim da rodada; o resto da rodada corre sem você
  h.hp = 0; P.heroOut = true;
  log('Você caiu! Sua equipe continua a rodada…', '#ff8a8a');
  checkRound();
  if (!P.roundOver) simulateRest();
}
function respawnHero(spot) {
  const r0 = run(), h = hero();
  recalc(); h.hp = G.d.maxHp; h.sp = G.d.maxSp; h.status = {};
  r0.px = spot.x; r0.py = spot.y;
  fx({ type: 'levelup', x: r0.px, y: r0.py });
  updateView();
}

// a cada turno completo (10 tiques): regeneração das unidades, recargas, volta de quem caiu, chegadas, relógios
export function pvpTurnEnd() {
  const r0 = run(), P = r0.pvp; if (!P || P.finishRes || P.roundOver) return;
  for (const u of r0.monsters) {
    if (u.hp <= 0 || !u.pvp || u.pvp.kind === 'crystal' || u.pvp.kind === 'emperium') continue;
    const p = u.pvp;
    p.hpAcc = (p.hpAcc || 0) + (p.regenHp || 0) * PVP_REGEN;
    if (p.hpAcc >= 1) { const v = Math.floor(p.hpAcc); p.hpAcc -= v; if (!u.status.poison) u.hp = Math.min(u.maxHp, u.hp + v); }
    if (p.sp !== undefined) p.sp = Math.min(p.maxSp, p.sp + (p.regenSp || 0));
    if (p.potCd > 0) p.potCd--;
    if (u.status.burn > 0) u.hp = Math.max(1, u.hp - Math.max(1, Math.floor(u.maxHp * 0.03)));
  }
  // quem caiu volta (sala e WoE)
  if (P.pending && P.pending.length) {
    const back = P.pending.filter((q) => q.at <= r0.turns); P.pending = P.pending.filter((q) => q.at > r0.turns);
    for (const q of back) {
      const u = q.u; u.hp = u.maxHp; u.pvp.sp = u.pvp.maxSp; u.status = {}; u.cd = {};
      const spot = P.mode === 'woe' ? freeSpot(u.pvp.home || r0.map.start, 2) : randomSpot(true);
      if (spot) { u.x = spot.x; u.y = spot.y; r0.monsters.push(u); }
    }
  }
  if (P.mode === 'sala') {
    salaArrival();
    const rk = salaRank(); P.best = Math.min(P.best, rk);
    if (rk === 1 && P.heroKills >= 3) P.rankTurns++;
  }
  if (P.mode === 'flavius' || P.mode === 'kvm') { P.roundTurns++; checkRound(); }
  if (P.mode === 'woe') {
    P.turnsLeft--;
    if (P.turnsLeft <= 0) return endWoe(P.defend, 'tempo');
  }
}

// ---------------- IA das unidades ----------------
function heroTargetable(u) {
  const P = run().pvp;
  if (P.heroOut || !heroFoe(u) || hero().hp <= 0) return false;
  if (hasBuff('oculto')) return u.pvp.mods.reveal && dist(u.x, u.y, run().px, run().py) <= u.pvp.mods.reveal;
  return true;
}
function foesOf(u) {
  const r0 = run(), out = [];
  if (heroTargetable(u)) out.push({ ref: 'hero', x: r0.px, y: r0.py, hp: hero().hp, maxHp: G.d.maxHp });
  for (const o of r0.monsters) if (o.hp > 0 && isFoeOf(u, o)) out.push({ ref: o, x: o.x, y: o.y, hp: o.hp, maxHp: o.maxHp });
  return out;
}
function pickTarget(u, foes) {
  const p = u.pvp, P = run().pvp;
  const live = foes.filter((f) => !(f.ref !== 'hero' && (f.ref.pvp.kind === 'crystal' || f.ref.pvp.kind === 'emperium')));
  if (p.pers === 'calmo' && !p.angry) return null;
  let pool = live;
  if (p.pers === 'reativo' && !p.angry) pool = live.filter((f) => dist(f.x, f.y, u.x, u.y) <= 4);
  if (p.pers === 'guarda') pool = live.filter((f) => dist(f.x, f.y, p.post.x, p.post.y) <= 6);
  if (p.angry && p.lastHit) { const lh = p.lastHit === 'hero' ? live.find((f) => f.ref === 'hero') : live.find((f) => f.ref === p.lastHit); if (lh && dist(lh.x, lh.y, u.x, u.y) <= 8) return lh; }
  if (!pool.length) return null;
  const score = (f) => dist(f.x, f.y, u.x, u.y) + (f.hp / f.maxHp) * (p.pers === 'cacador' ? 6 : 2);
  return pool.sort((a, b) => score(a) - score(b))[0];
}
function objectiveOf(u) {
  const P = run().pvp, p = u.pvp;
  if (P.mode === 'flavius') { const c = P.crystal[p.team === 'A' ? 'B' : 'A']; if (c && c.hp > 0) return { ref: c, x: c.x, y: c.y, hp: c.hp, maxHp: c.maxHp }; }
  if (P.mode === 'woe' && P.emp && P.emp.hp > 0 && P.emp.pvp.team !== p.team) return { ref: P.emp, x: P.emp.x, y: P.emp.y, hp: P.emp.hp, maxHp: P.emp.maxHp };
  return null;
}
function stepTo(u, tx, ty) {
  const m = run().map;
  if (dist(u.x, u.y, tx, ty) <= 1) return false;
  let path = u.pvp.path;
  if (!path || !path.length || u.pvp.pathFor !== tx + ',' + ty || (u.pvp.pathAge = (u.pvp.pathAge || 0) + 1) > 4) {
    path = findPath(m, u.x, u.y, tx, ty, (x, y) => !(x === tx && y === ty) && _occupied(x, y)) || [];
    u.pvp.path = path; u.pvp.pathFor = tx + ',' + ty; u.pvp.pathAge = 0;
  }
  const nx = path.length ? path[0] : null;
  if (nx && !_occupied(nx[0] ?? nx.x, nx[1] ?? nx.y)) {
    const x = nx[0] ?? nx.x, y = nx[1] ?? nx.y;
    path.shift(); fx({ type: 'move', id: u.uid, fx: u.x, fy: u.y }); u.x = x; u.y = y; return true;
  }
  // caminho bloqueado: passo guloso
  u.pvp.path = null;
  let best = null, bd = dist(u.x, u.y, tx, ty);
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
    const x = u.x + dx, y = u.y + dy; if ((!dx && !dy) || !passable(tileAt(m, x, y)) || _occupied(x, y)) continue;
    const dd = dist(x, y, tx, ty); if (dd < bd) { bd = dd; best = [x, y]; }
  }
  if (best) { fx({ type: 'move', id: u.uid, fx: u.x, fy: u.y }); u.x = best[0]; u.y = best[1]; return true; }
  return false;
}
function stepAwayFrom(u, fx0, fy0) {
  const m = run().map; let best = null, bd = dist(u.x, u.y, fx0, fy0);
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
    const x = u.x + dx, y = u.y + dy; if ((!dx && !dy) || !passable(tileAt(m, x, y)) || _occupied(x, y)) continue;
    const dd = dist(x, y, fx0, fy0); if (dd > bd) { bd = dd; best = [x, y]; }
  }
  if (best) { fx({ type: 'move', id: u.uid, fx: u.x, fy: u.y }); u.x = best[0]; u.y = best[1]; return true; }
  return false;
}
function wanderU(u) {
  const m = run().map;
  const opts = [];
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const x = u.x + dx, y = u.y + dy; if ((dx || dy) && passable(tileAt(m, x, y)) && !_occupied(x, y)) opts.push([x, y]); }
  if (opts.length) { const [x, y] = pick(opts); fx({ type: 'move', id: u.uid, fx: u.x, fy: u.y }); u.x = x; u.y = y; }
}
// habilidades que o aventureiro sabe usar: dano direto, em área ou cura
function skillOptions(u) {
  const p = u.pvp, out = [];
  for (const [id, l] of Object.entries(p.skills || {})) {
    const sk = SKILLS[id]; if (!sk || !l) continue;
    if (sk.target === 'passive' || sk.aura || sk.toggle || sk.needsPoison || sk.smoke || sk.field || sk.allSp) continue;
    if (sk.heal) { out.push({ id, l, sk, heal: true }); continue; }
    if (!sk.mult && !sk.base) continue;
    if (sk.needsBow && !['arco', 'besta'].includes(p.wtype)) continue;
    out.push({ id, l, sk });
  }
  return out;
}
const spCost = (sk, l) => (sk.sp ? sk.sp(l) : 0);
function usable(u, o) { const p = u.pvp; return (u.cd[o.id] || 0) <= 0 && p.sp >= spCost(o.sk, o.l); }
function skillRange(u, o) {
  const sk = o.sk;
  if (sk.target === 'self') return 0;
  if (sk.target === 'enemy') return sk.range || u.range || 1;
  return sk.range || 1;
}
// combos (gelo + vento, pedra + fogo, queimando + água): contra jogadores rendem 35% do que rendem nos monstros
const COMBO_PVP = 0.35;
function targetStatus(f) { return f.ref === 'hero' ? hero().status : f.ref.status || {}; }
function comboOf(f, sk) {
  const st = targetStatus(f);
  if ((st.freeze || 0) > 0 && sk.el === 'vento') return 6 * COMBO_PVP;
  if ((st.petrify || 0) > 0 && sk.el === 'fogo') return 10 * COMBO_PVP;
  if ((st.burn || 0) > 0 && sk.el === 'agua' && !(st.freeze > 0)) return 5.5 * COMBO_PVP;
  return 1;
}
function estimate(u, o) { const sk = o.sk; const a = sk.kind === 'magic' ? u.matk : sk.useDex ? u.pvp.dexAtk : u.atk; return (sk.base ? sk.base(o.l) : 0) + a * (sk.mult ? sk.mult(o.l) : 1) * (sk.hits && typeof sk.hits === 'number' ? 1 : 1); }
function botAct(u) {
  const r0 = run(), P = r0.pvp, p = u.pvp;
  // poção: vida baixa
  if (u.hp < u.maxHp * 0.35 && p.pots > 0 && p.potCd <= 0) {
    p.pots--; p.potCd = 5; const v = p.potHeal || Math.ceil(u.maxHp * 0.15); u.hp = Math.min(u.maxHp, u.hp + v);
    fx({ type: 'text', x: u.x, y: u.y, text: `+${v}`, color: '#7af0a0' }); return;
  }
  const opts = skillOptions(u);
  const heal = opts.find((o) => o.heal && usable(u, o));
  if (heal && u.hp < u.maxHp * 0.45 && chance(55)) {
    const v = Math.round((heal.sk.heal(heal.l, { lv: u.lv }, p.stats || { int: 10, vit: 10 }) || u.maxHp * 0.2) * PVP_HEAL);
    p.sp -= spCost(heal.sk, heal.l); if (heal.sk.cooldown) u.cd[heal.id] = heal.sk.cooldown(heal.l);
    u.hp = Math.min(u.maxHp, u.hp + v); fx({ type: 'text', x: u.x, y: u.y, text: `+${v}`, color: '#7af0a0' }); fx({ type: 'burst', x: u.x, y: u.y, color: '#7af0a0', n: 8 }); return;
  }
  const foes = foesOf(u);
  let tgt = pickTarget(u, foes);
  // calmo: conversa e passeia até alguém mexer com ele
  if (!tgt && p.pers === 'calmo' && P.mode === 'sala') { if (chance(4)) say(u, CHAT.calmo); if (chance(25)) wanderU(u); return; }
  // objetivos: cristal (Flavius) ou Emperium (WoE) quando não há inimigo perto
  const obj = objectiveOf(u);
  if (obj && P.mode === 'woe' && dist(obj.x, obj.y, u.x, u.y) <= 1 && chance(65)) { basicHit(u, obj); return; }
  if (obj && P.mode === 'woe' && (!tgt || dist(tgt.x, tgt.y, u.x, u.y) > 2) && chance(50)) { stepTo(u, obj.x, obj.y); return; }
  if (obj && (!tgt || dist(tgt.x, tgt.y, u.x, u.y) > 4)) {
    if (dist(obj.x, obj.y, u.x, u.y) <= 1) { basicHit(u, obj); return; }
    if (!tgt) { stepTo(u, obj.x, obj.y); return; }
  }
  // defensores da WoE não se afastam muito do Emperium
  if (P.mode === 'woe' && P.emp && P.emp.pvp.team === p.team && tgt && dist(tgt.x, tgt.y, P.emp.x, P.emp.y) > 10) tgt = null;
  if (!tgt) {
    const home = P.mode === 'woe' && P.emp && P.emp.pvp.team === p.team ? P.emp : null;
    if (home && dist(u.x, u.y, home.x, home.y) > 3) stepTo(u, home.x, home.y);
    else if (P.mode === 'sala' || chance(30)) wanderU(u);
    else if (P.mode !== 'sala') { const any = foes.filter((f) => f.ref === 'hero' || f.ref.pvp.kind === 'bot').sort((a, b) => dist(a.x, a.y, u.x, u.y) - dist(b.x, b.y, u.x, u.y))[0]; if (any) stepTo(u, any.x, any.y); }
    return;
  }
  const d0 = dist(u.x, u.y, tgt.x, tgt.y);
  const los = hasLos(r0.map, u.x, u.y, tgt.x, tgt.y);
  // atiradores e magos mantêm distância de quem luta de perto
  const kiter = u.range > 1 || p.line === 'bruxo';
  const tMelee = tgt.ref === 'hero' ? (G.d.range || 1) <= 1 : (tgt.ref.range || 1) <= 1;
  if (kiter && tMelee && d0 <= 2 && chance(p.line === 'bruxo' ? 55 : 45) && stepAwayFrom(u, tgt.x, tgt.y)) return;
  // habilidade: área se pegar 2+, senão a de maior dano que alcança
  const cand = [];
  for (const o of opts) {
    if (o.heal || !usable(u, o)) continue;
    const rg = skillRange(u, o);
    if (o.sk.target === 'self') { const n = foes.filter((f) => dist(f.x, f.y, u.x, u.y) <= (o.sk.aoe || 1)).length; if (n >= 1) cand.push({ o, at: u, score: estimate(u, o) * (n >= 2 ? 1.6 : 1) * 0.85 }); continue; }
    if (d0 <= rg && (d0 <= 1 || los)) {
      const n = o.sk.aoe ? foes.filter((f) => dist(f.x, f.y, tgt.x, tgt.y) <= o.sk.aoe).length : 1;
      cand.push({ o, at: tgt, score: estimate(u, o) * (n >= 2 ? 1.4 : 1) * comboOf(tgt, o.sk) });
    }
  }
  if (cand.length && chance(92)) { const c = cand.sort((a, b) => b.score - a.score)[0]; castU(u, c.o, c.at, foes); return; }
  if (d0 <= u.range && (d0 <= 1 || los)) { basicHit(u, tgt); return; }
  stepTo(u, tgt.x, tgt.y);
}
function guardAct(u) {
  const p = u.pvp, foes = foesOf(u).filter((f) => f.ref === 'hero' || f.ref.pvp.kind === 'bot');
  const near = foes.filter((f) => dist(f.x, f.y, p.post.x, p.post.y) <= 6).sort((a, b) => dist(a.x, a.y, u.x, u.y) - dist(b.x, b.y, u.x, u.y))[0];
  if (near) { if (dist(near.x, near.y, u.x, u.y) <= 1) basicHit(u, near); else stepTo(u, near.x, near.y); return; }
  if (dist(u.x, u.y, p.post.x, p.post.y) > 1) stepTo(u, p.post.x, p.post.y);
}
export function unitAct(u) {
  if (!u.pvp || u.hp <= 0) return;
  const P = run() && run().pvp; if (!P || P.finishRes || P.roundOver) return;
  const k = u.pvp.kind;
  if (k === 'crystal' || k === 'emperium') return;
  if ((u.status.stun || 0) > 0 || (u.status.freeze || 0) > 0 || (u.status.petrify || 0) > 0) return;
  if (k === 'guardian') return guardAct(u);
  botAct(u);
}

// golpes das unidades
function strike(u, f, mult, opt = {}) {
  const r0 = run(), P = r0.pvp;
  const tRef = f.ref;
  const def = tRef === 'hero' ? _heroDefense() : tRef;
  if (tRef !== 'hero' && tRef.pvp.kind === 'emperium') {
    if (!opt.basic) return;
    if (tRef.hp > 0) { tRef.hp -= 1; fx({ type: 'dmg', uid: tRef.uid, x: tRef.x, y: tRef.y, val: 1, color: '#ffd86b' }); fx({ type: 'flash', id: tRef.uid }); if (tRef.hp <= 0) unitDown(tRef, u); }
    return;
  }
  const sk = opt.sk;
  const kind = sk ? sk.kind : 'phys';
  const baseAdd = sk && sk.base ? sk.base(opt.l) / Math.max(0.01, mult) : 0;
  const agi = (u.pvp.stats && u.pvp.stats.agi) || 0;
  const A = { atk: (sk && sk.useDex ? u.pvp.dexAtk : sk && sk.agiBonus ? u.atk + agi * 2 : u.atk) + (kind === 'magic' ? 0 : baseAdd), matk: u.matk + (kind === 'magic' ? baseAdd : 0), hit: u.hit, crit: u.crit, critDmg: u.critDmg, el: u.el, raceDmg: {}, pierce: u.pierce || 0 };
  // mesma regra do herói: só não erra quem tem 'nunca erra', área/si mesmo ou muitos golpes
  const sure = !!(sk && (sk.sureHit || sk.target !== 'enemy' || (typeof sk.hits === 'number' && sk.hits > 2))) || opt.sure;
  const res = kind === 'magic' ? magicHit(A, def, mult, sk.el || 'neutro') : physHit(A, def, mult, { el: sk && sk.el, sure, ignoreDef: !!(sk && sk.ignoreDef), defPierce: sk && sk.defPierce, critBonus: (sk && sk.critBonus) || 0 });
  if (res.miss) { fx({ type: 'text', x: f.x, y: f.y, text: 'errou', color: '#9ab', delay: 120 }); return; }
  let dmg = res.dmg + (sk && sk.flat ? sk.flat(opt.l) : 0);
  if (sk) {
    // mesmas regras do herói: distância dos tiros do Caçador, Execução, bônus contra envenenado
    const dd = dist(u.x, u.y, f.x, f.y);
    if (sk.needsBow && (u.pvp.line === 'cacador')) dmg *= dd <= 1 ? 0.7 : dd <= 3 ? 1 : dd <= 5 ? 1.25 : 1.5;
    if (sk.execute3 && f.hp <= f.maxHp * 0.4) dmg *= 2;
    if (sk.poisonBonus && (targetStatus(f).poison || 0) > 0) dmg *= 1 + sk.poisonBonus / 100;
  }
  if (sk) { const c = comboOf(f, sk); if (c > 1) { dmg *= c; const st = targetStatus(f); delete st.freeze; delete st.petrify; if (sk.el === 'agua') delete st.burn; fx({ type: 'text', x: f.x, y: f.y, text: sk.el === 'vento' ? 'estilhaçou!' : sk.el === 'fogo' ? 'rachou!' : 'vapor!', color: '#b9fff0', delay: 200 }); } }
  const isStruct = tRef !== 'hero' && tRef.pvp.kind === 'crystal';
  if (!isStruct) {
    const res2 = tRef === 'hero' ? (G.d.mods.pvpRes || 0) : (tRef.pvp.mods.pvpRes || 0);
    dmg = dmg * PVP_MUL * (1 + (BOT_EDGE - 1) * Math.min(1, ((u.pvp.jobLv || 1) - 1) / ((jobMax(u.pvp.cls) || 15) - 1))) * earlyMul(u.pvp.cls, u.pvp.jobLv) * pvpLine(u.pvp.cls, u.pvp.jobLv).dmg * (1 + (u.pvp.mods.pvpDmg || 0) / 100) * (1 - Math.min(80, res2) / 100);
  } else dmg *= PVP_MUL;
  dmg = Math.max(1, Math.round(dmg));
  if (tRef === 'hero') {
    P.lastHeroHit = u;
    if (u.pvp.mods.spBurn) hero().sp = Math.max(0, hero().sp - Math.ceil(G.d.maxSp * u.pvp.mods.spBurn / 100));
    damageHero(dmg, { crit: res.crit, source: u.pvp.name, delay: opt.delay || 0 });
    if (!run() || run() !== r0 || hero().hp <= 0) return;
    if (sk) statusOnHero(u, sk, opt.l);
    if (sk && sk.knock && P.mode !== 'woe' && !G.d.mods.kbImmune) pushHero(u, sk.knock);
  } else {
    tRef.hp -= dmg;
    fx({ type: 'dmg', uid: tRef.uid, x: tRef.x, y: tRef.y, val: dmg, color: res.crit ? '#ffd23f' : '#ffffff', crit: res.crit, delay: opt.delay || 0 });
    fx({ type: 'flash', id: tRef.uid, delay: opt.delay || 0 });
    if (tRef.pvp.kind === 'bot') { tRef.pvp.lastHit = u; tRef.pvp.angry = true; if (u.pvp.mods.spBurn) tRef.pvp.sp = Math.max(0, tRef.pvp.sp - Math.ceil(tRef.pvp.maxSp * u.pvp.mods.spBurn / 100)); }
    if (tRef.hp <= 0) { unitDown(tRef, u); return; }
    if (sk) statusOnUnit(u, tRef, sk, opt.l);
    if (sk && sk.knock && P.mode !== 'woe' && tRef.pvp.kind === 'bot' && !tRef.pvp.mods.kbImmune) pushUnit(u, tRef, sk.knock);
  }
}
const pctOf = (v, l) => (typeof v === 'function' ? v(l) : v === true ? 30 : v || 0);
function statusOnHero(u, sk, l) {
  const st = hero().status, ccr = G.d.mods.ccRes || 0;
  const res = (G.d.statusResist || 0);
  const roll = (c) => chance(c) && !chance(res);
  const D = PVP_STATUS;
  if (sk.stun && roll(pctOf(sk.stun, l)) && !chance(ccr)) { st.stun = D.stun; log(`${u.pvp.name} te atordoou!`, '#9ac8ff'); }
  if (sk.freeze && roll(pctOf(sk.freeze, l)) && !G.d.mods.freezeImmune) { st.freeze = D.freeze; log(`${u.pvp.name} te congelou!`, '#9ad8ff'); }
  if (sk.slow && !chance(ccr)) st.slow = D.slow;
  if (sk.snare && roll(pctOf(sk.snare, l))) st.snare = D.snare;
  if (sk.burn && roll(pctOf(sk.burn, l)) && !st.burn) st.burn = D.burn;
  if (sk.petrify && roll(pctOf(sk.petrify, l))) st.petrify = D.petrify;
}
function statusOnUnit(u, t, sk, l) {
  const ccr = t.pvp.mods.ccRes || 0, res = t.pvp.statusResist || 0;
  const roll = (c) => chance(c) && !chance(res);
  const D = PVP_STATUS;
  if (sk.stun && roll(pctOf(sk.stun, l)) && !chance(ccr)) t.status.stun = D.stun;
  if (sk.freeze && roll(pctOf(sk.freeze, l))) t.status.freeze = D.freeze;
  if (sk.slow && !chance(ccr)) t.status.slow = D.slow;
  if (sk.snare && roll(pctOf(sk.snare, l))) t.status.snare = D.snare;
  if (sk.burn && roll(pctOf(sk.burn, l))) t.status.burn = D.burn;
  if (sk.petrify && roll(pctOf(sk.petrify, l))) t.status.petrify = D.petrify;
}
function pushHero(u, n) {
  const r0 = run(), dx = Math.sign(r0.px - u.x), dy = Math.sign(r0.py - u.y);
  for (let i = 0; i < n; i++) { const x = r0.px + dx, y = r0.py + dy; if (!passable(tileAt(r0.map, x, y)) || _occupied(x, y)) break; fx({ type: 'move', id: 'hero', fx: r0.px, fy: r0.py }); r0.px = x; r0.py = y; }
  updateView();
}
function pushUnit(u, t, n) {
  const r0 = run(), dx = Math.sign(t.x - u.x), dy = Math.sign(t.y - u.y);
  for (let i = 0; i < n; i++) { const x = t.x + dx, y = t.y + dy; if (!passable(tileAt(r0.map, x, y)) || _occupied(x, y)) break; fx({ type: 'move', id: t.uid, fx: t.x, fy: t.y }); t.x = x; t.y = y; }
}
function basicHit(u, f) {
  const ranged = dist(u.x, u.y, f.x, f.y) > 1;
  if (ranged) fx({ type: 'proj', fx: u.x, fy: u.y, tx: f.x, ty: f.y, color: MONSTERS[u.type]?.proj || '#fff', arrow: ['arco', 'besta'].includes(u.pvp.wtype) });
  else fx({ type: 'lunge', id: u.uid, tx: f.x, ty: f.y });
  strike(u, f, BASIC_MUL[baseCls(u.pvp.cls || 'aprendiz')] ?? 1, { basic: true, delay: ranged ? 150 : 0 });
}
function castU(u, o, at, foes) {
  const sk = o.sk, p = u.pvp;
  p.sp -= spCost(sk, o.l);
  const cast = typeof sk.cast === 'function' ? sk.cast(o.l) : sk.cast || 1;
  if (cast > 1) u.energy -= Math.round(100 * (cast - 1) * (1 - Math.min(60, (p.stats ? p.stats.dex : 0) * 0.35) / 100));
  if (sk.cooldown) u.cd[o.id] = sk.cooldown(o.l);
  fx({ type: 'cast', x: u.x, y: u.y, color: '#9ac8ff', icon: sk.icon });
  fx({ type: 'text', x: u.x, y: u.y, text: sk.name, color: '#cfe7ff' });
  const cx = at.x, cy = at.y;
  let targets;
  if (sk.target === 'self') targets = foes.filter((f) => dist(f.x, f.y, u.x, u.y) <= (sk.aoe || 1));
  else if (sk.aoe) targets = foes.filter((f) => dist(f.x, f.y, cx, cy) <= sk.aoe);
  else targets = [at];
  if (sk.target !== 'self' && dist(u.x, u.y, cx, cy) > 1) fx({ type: 'proj', fx: u.x, fy: u.y, tx: cx, ty: cy, color: sk.proj || MONSTERS[u.type]?.proj || '#fff' });
  else if (sk.target !== 'self') fx({ type: 'lunge', id: u.uid, tx: cx, ty: cy });
  if (sk.aoe) fx({ type: 'ring', x: sk.target === 'self' ? u.x : cx, y: sk.target === 'self' ? u.y : cy, r: sk.aoe, color: '#ffd86b' });
  const mult = sk.mult ? sk.mult(o.l) : 1;
  for (const f of targets) {
    if (f.ref !== 'hero' && (f.ref.hp <= 0)) continue;
    if (f.ref === 'hero' && (!run() || hero().hp <= 0)) continue;
    strike(u, f, mult, { sk, l: o.l, delay: 150 });
    if (!run() || !run().pvp) return;
  }
}

// ---------------- Na volta do app ----------------
// partida aberta quando o app fechou: é abandonada (sem prêmio e sem perder nada)
export function pvpOnLoad(state) {
  for (const h of state.roster || []) { if (h) { h.inPvp = false; if (pvpUnlocked(h)) ensureGuild(h); } }
  if (state.run && state.run.pvp) { state.run = null; if (state.mode === 'dungeon') state.mode = 'town'; }
}
export { endSala, endBC, endWoe, strike as _strike };
export { pvpLoadout as pvpLoadoutOf } from './pvpgear.js';
