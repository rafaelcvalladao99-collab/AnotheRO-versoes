// Telas do PvP: salão da guilda PvP Owners, equipamento e loja de PvP, placar, resultado
import * as Game from './game.js';
import { G } from './game.js';
import * as PvP from './pvp.js';
import { CLASSES, MONSTERS, BOOSTS, WTYPES } from './data.js';
import { itemDef, itemName, itemColor, modsText, weaponAtk, weaponMatk, armorDef, armorMdef, equipMods } from './rules.js';
import { makePvpItem, LINE_GEAR, lineOf, GRADES, PVP_PRICES, PVP_SHOP_ITEMS, REFINE_EXTRA, setPvpTier, pvpTierFor } from './pvpgear.js';
import { itemIconURL } from './sprites.js';
import { fmt } from './util.js';
import { Audio } from './audio.js';

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let UI = null;   // openSheet, toast, renderTown (injetados pelo ui.js, para não haver import circular)
export function bindPvpUI(api) { UI = api; }
const medal = (n) => `<span class="price">🎖️ ${fmt(n)}</span>`;
const clsName = (c) => (CLASSES[c] ? CLASSES[c].name : c);
const LINE_COLOR = { cavaleiro: '#ff6b5e', bruxo: '#c48aff', cacador: '#5ee08a', assassino: '#b0a8d8', monge: '#ffd25e', shinobi: '#5ed6d6', mestre_taekwon: '#ffae5e' };
const LINE_NAME = { cavaleiro: 'Espadachim', bruxo: 'Mago', cacador: 'Arqueiro', assassino: 'Gatuno', monge: 'Noviço', shinobi: 'Ninja', mestre_taekwon: 'Taekwon' };
const left = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)}h${String(m % 60).padStart(2, '0')}` : `${m} min`; };

function statLine(it) {
  const d = itemDef(it), out = [];
  if (d.kind === 'weapon') { const a = weaponAtk(it), m = weaponMatk(it); if (a) out.push(`ATQ ${a}`); if (m) out.push(`ATQM ${m}`); }
  if (d.kind === 'armor' || d.kind === 'head' || d.kind === 'shield') { out.push(`DEF ${armorDef(it)}`); if (armorMdef(it)) out.push(`DEFM ${armorMdef(it)}`); if (d.matk) out.push(`ATQM ${d.matk}`); }
  const mt = modsText(equipMods(it)); if (mt) out.push(mt);
  if (it.cards && it.cards.length) out.push('Cartas: ' + it.cards.map((c) => MONSTERS[c].name).join(', '));
  return out.join(' · ');
}
function itemRow(it, side, extra = '') {
  return `<div class="row ${extra}"><img src="${itemIconURL(it)}"><div class="info"><strong style="color:${itemColor(it)}">${esc(itemName(it))}</strong><small style="white-space:normal">${esc(statLine(it))}</small></div><div class="side">${side}</div></div>`;
}

// ---------------- Salão da guilda ----------------
export function pvpSheet() {
  const h = G.state.hero;
  if (!PvP.pvpUnlocked(h)) {
    UI.openSheet({ title: '⚔️ Guilda PvP Owners', html: `<div class="empty-msg">A PvP Owners só convida quem já virou 1ª classe. Volte quando tiver uma classe!</div>` });
    return;
  }
  const g = PvP.ensureGuild(h), p = PvP.ensurePvp(h);
  const w = PvP.woeStatus(h), ci = PvP.castleInfo(h);
  const st = p.stats;
  const stock = Object.entries(p.stock || {}).filter(([, n]) => n > 0);
  const tg = (cls, txt) => `<span class="tg ${cls}">${txt}</span>`;
  const mode = (c, ic, title, sub, tags, btns) => `<div class="mode" style="--c:${c}"><div class="mode-ic">${ic}</div><div class="mode-tx"><b>${title}</b><small>${sub}</small>${tags.length ? `<div class="tgs">${tags.join('')}</div>` : ''}</div><div class="mode-go">${btns}</div></div>`;
  const btn = (c, go, txt, off) => `<button class="btn small tint" style="--c:${c}" data-go="${go}" ${off ? 'disabled' : ''}>${txt}</button>`;
  const html = `
    <div class="hub" style="--acc:#ff5d6c">
      <div class="hub-top"><div class="hub-crest">⚔️</div><div><b>${esc(g.name)}</b><small>Líder ${esc(g.leader)} · você é <b style="display:inline;font-size:13px;color:#ffd25e">vice-líder</b></small></div>${tg('medal', '🎖️ ' + fmt(p.medals))}</div>
      <div class="hub-mem">${g.members.map((m) => `<span class="tg" style="--tc:${LINE_COLOR[m.line] || '#ccc'}">${esc(m.name)} · ${LINE_NAME[m.line] || ''}</span>`).join('')}</div>
      <div class="hub-stats"><div><b>${st.salaKills}</b><small>vitórias na Sala</small></div><div><b>${st.bcWins}<span style="color:#9aa0c8;font-size:13px"> × </span>${st.bcLosses}</b><small>Batalha Campal</small></div><div><b>${st.woeWins}</b><small>WoE vencidas${ci ? ' · 🏰' : ''}</small></div></div>
    </div>
    ${mode('#ff6b5e', '🗡️', 'Sala de PvP', 'Todos contra todos. Tem quem só conversa e quem chega caçando.', [tg('dim', 'começa com 5 pts'), tg('go', '+1 por vitória'), tg('risk', '−5 por queda'), tg('medal', '🎖️ até 31')], btn('#ff6b5e', 'sala', 'Entrar'))}
    ${mode('#5aa8ff', '🛡️', 'Batalha Campal 5×5', `Você e 4 da guilda contra ${esc(g.rival)}, melhor de 3.`, [tg('info', 'Flavius: cristal'), tg('info', 'KVM: eliminação'), tg('medal', '🎖️ 12 ou 4')], btn('#5aa8ff', 'flavius', 'Flavius') + btn('#5aa8ff', 'kvm', 'KVM'))}
    ${mode('#c48aff', '🏰', 'Guerra do Emperium', w.owned ? 'O castelo é seu: defenda o Emperium até o tempo acabar.' : `Invada o castelo de ${esc(g.rival)} e quebre o Emperium.`, [tg('dim', 'só ataque básico: 1 de dano'), tg('dim', 'sem empurrão'), w.ready ? tg('go', 'aberta agora!') : tg('warn', `abre em ${left(w.left)}`)], btn('#c48aff', 'woe', w.owned ? 'Defender' : 'Atacar', !w.ready))}
    ${ci ? mode('#ffd25e', '💰', 'Castelo da guilda', 'Baú todo dia. Invista para melhorar o baú e a defesa.', [ci.chestReady ? tg('go', 'baú cheio!') : tg('dim', `baú em ${left(ci.chestLeft)}`), tg('zeny', `Economia ${ci.econ || 0}/10`), tg('info', `Defesa ${ci.defense || 0}/10`)], btn('#ffd25e', 'chest', 'Abrir baú', !ci.chestReady) + btn('#ffd25e', 'econ', `Economia 🎖️${ci.econCost}`) + btn('#7fb2ff', 'def', `Defesa 🎖️${ci.defCost}`)) : ''}
    ${mode('#5ed6d6', '🎽', 'Equipamento de PvP', 'Só vale no PvP. Vazio = kit de Recruta.', [tg('risk', 'refino sem martelo: falhou, quebrou'), tg('matk', '+7 e +9 com bônus')], btn('#5ed6d6', 'equip', 'Abrir'))}
    ${mode('#ffae5e', '🎖️', 'Loja de PvP', 'Peças de Soldado, Veterano e Campeão.', [tg('medal', 'Diário da Aventura'), tg('medal', 'Trevo Dourado')], btn('#ffae5e', 'shop', 'Abrir'))}
    ${stock.map(([k, n]) => mode('#3fd47a', BOOSTS[k].icon, `${BOOSTS[k].name} ×${n}`, `${BOOSTS[k].desc} nos próximos ${BOOSTS[k].kills} monstros da campanha.`, [tg('warn', `não soma com ${k === 'diario' ? 'o Manual de Batalha' : 'o Chiclete da Sorte'}`)], `<button class="btn small go" data-use="${k}">Usar</button>`)).join('')}`;
  const body = UI.openSheet({ title: '⚔️ Guilda PvP Owners', html, acc: '#ff5d6c' });
  body.querySelectorAll('[data-go]').forEach((b) => b.onclick = () => {
    Audio.play('click');
    const go = b.dataset.go;
    let e = null;
    if (go === 'sala') e = PvP.startSala();
    else if (go === 'flavius' || go === 'kvm') e = PvP.startBC(go);
    else if (go === 'woe') e = PvP.startWoe();
    else if (go === 'chest') { const r = PvP.openChest(); UI.toast(r.msg, 3200); pvpSheet(); return; }
    else if (go === 'econ' || go === 'def') { e = PvP.invest(go === 'econ' ? 'econ' : 'def'); if (!e) { UI.toast('Investimento feito!'); pvpSheet(); return; } }
    else if (go === 'equip') return pvpEquipSheet();
    else if (go === 'shop') return pvpShopSheet();
    if (e) { UI.toast(e, 2400); return; }
    UI.closeSheet(true); UI.refresh('screen');
  });
  body.querySelectorAll('[data-use]').forEach((b) => b.onclick = () => { const e = Game.activateBoostItem(b.dataset.use); UI.toast(e || `${BOOSTS[b.dataset.use].name} ativado!`, 2400); pvpSheet(); });
}

// ---------------- Equipamento de PvP ----------------
const SLOT_NAME = { weapon: 'Mão direita', left: 'Mão esquerda', head: 'Cabeça', armor: 'Armadura', acc1: 'Acessório', acc2: 'Acessório' };
export function pvpEquipSheet() {
  const h = G.state.hero, p = PvP.ensurePvp(h);
  setPvpTier(pvpTierFor(h.lv));
  h.inPvp = true; const L = PvP.pvpLoadoutOf(h); h.inPvp = false;
  const refTxt = (it) => { const ri = PvP.pvpRefineInfo(it); return ri && !ri.max ? `<button class="btn small" data-ref="${it.uid}">+${ri.next} · ${ri.rate}% ${medal(ri.cost)}</button>` : ''; };
  const cardBtn = (it) => (it.slots || 0) > (it.cards || []).length ? `<button class="btn small" data-card="${it.uid}">Carta</button>` : '';
  const slots = ['weapon', 'left', 'head', 'armor', 'acc1', 'acc2'].map((k) => {
    const mine = p.equip[k], it = L[k];
    if (!it) return `<div class="row"><div class="info"><strong class="mk-dim">${SLOT_NAME[k]}: vazio</strong></div></div>`;
    return itemRow(it, mine ? `<div style="display:flex;flex-direction:column;gap:6px">${refTxt(mine)}${cardBtn(mine)}<button class="btn small" data-off="${k}">Tirar</button></div>` : '<small class="mk-dim">básico</small>');
  }).join('');
  const bag = p.bag.map((it) => itemRow(it, `<div style="display:flex;flex-direction:column;gap:6px"><button class="btn small" data-eq="${it.uid}">Equipar</button>${refTxt(it)}${cardBtn(it)}<button class="btn small" data-sell="${it.uid}">Vender</button></div>`)).join('');
  const ex = Object.entries(REFINE_EXTRA).map(([k, e]) => `<span class="tg matk">${k === 'weapon' ? 'arma' : k === 'armor' ? 'armadura' : k === 'shield' ? 'escudo' : 'cabeça'}: +${e.v7}${e.unit} → +${e.v7 * 2.5}${e.unit} ${e.name}</span>`).join('');
  const html = `<div class="tgs" style="margin:0 0 6px"><span class="tg medal">🎖️ ${fmt(p.medals)}</span><span class="tg dim">acompanha o seu nível</span><span class="tg risk">refino sem martelo: falhou, quebrou</span></div>
    <div class="section" style="margin-top:8px">Bônus no +7 → +9</div><div class="tgs" style="margin:0 0 4px">${ex}</div>
    <div class="section">Equipado</div><div class="list">${slots}</div>
    <div class="section">Bolsa de PvP (${p.bag.length})</div><div class="list">${bag || '<div class="empty-msg">Vazia. Compre peças na Loja de PvP.</div>'}</div>`;
  const body = UI.openSheet({ title: '🎽 Equipamento de PvP', html, acc: '#5ed6d6' });
  const again = () => pvpEquipSheet();
  body.querySelectorAll('[data-eq]').forEach((b) => b.onclick = () => { const e = PvP.equipPvp(+b.dataset.eq); if (e) UI.toast(e); again(); });
  body.querySelectorAll('[data-off]').forEach((b) => b.onclick = () => { PvP.unequipPvp(b.dataset.off); again(); });
  body.querySelectorAll('[data-sell]').forEach((b) => b.onclick = () => { const v = PvP.sellPvp(+b.dataset.sell); UI.toast(`Vendido por ${v} medalhas`); again(); });
  body.querySelectorAll('[data-ref]').forEach((b) => b.onclick = () => { const r = PvP.refinePvp(+b.dataset.ref); UI.toast(r.msg, 2600); again(); });
  body.querySelectorAll('[data-card]').forEach((b) => b.onclick = () => cardPicker(+b.dataset.card));
}
function cardPicker(itemUid) {
  const h = G.state.hero, p = PvP.ensurePvp(h);
  const it = p.bag.concat(Object.values(p.equip)).find((o) => o && o.uid === itemUid); if (!it) return;
  const d = itemDef(it), kind = d.kind;
  const cards = h.inv.filter((o) => o.id === 'card' && itemDef(o).slot === kind);
  const html = `<p class="note">A carta sai da sua mochila e fica para sempre nesta peça de PvP.</p><div class="list">${cards.map((c) => `<div class="row"><img src="${itemIconURL(c)}"><div class="info"><strong style="color:${itemColor(c)}">${esc(itemName(c))}</strong><small style="white-space:normal">${esc(modsText(itemDef(c).mods))}</small></div><div class="side"><button class="btn small" data-c="${c.uid}">Encaixar</button></div></div>`).join('') || '<div class="empty-msg">Nenhuma carta que sirva nesta peça na sua mochila.</div>'}</div>`;
  const body = UI.openSheet({ title: '🃏 Encaixar carta', html, acc: '#ffd25e', onClose: () => pvpEquipSheet() });
  body.querySelectorAll('[data-c]').forEach((b) => b.onclick = () => { const e = PvP.insertPvpCard(+b.dataset.c, itemUid); UI.toast(e || 'Carta encaixada!'); pvpEquipSheet(); });
}

// ---------------- Loja ----------------
export function pvpShopSheet(tab = 'weapon') {
  const h = G.state.hero, p = PvP.ensurePvp(h), line = lineOf(h.cls), LG = LINE_GEAR[line];
  setPvpTier(pvpTierFor(h.lv));
  const tabs = [['weapon', 'Armas'], ['armor', 'Armaduras'], ['head', 'Cabeça'], ['shield', 'Escudos'], ['acc', 'Acessórios'], ['special', 'Especiais']];
  let specs = [];
  if (tab === 'weapon') for (const wt of LG.wt) specs.push({ ps: 'weapon', wt });
  if (tab === 'armor') for (const k of ['heavy', 'robe', 'light']) specs.push({ ps: 'armor', k });
  if (tab === 'head') for (const k of ['heavy', 'robe', 'light']) specs.push({ ps: 'head', k });
  if (tab === 'shield') for (const k of ['escudo', 'livro']) specs.push({ ps: 'shield', k });
  if (tab === 'acc') for (const st of ['str', 'agi', 'vit', 'int', 'dex', 'luk']) specs.push({ ps: 'acc', st });
  let rows = '';
  if (tab === 'special') rows = Object.entries(PVP_SHOP_ITEMS).map(([k, price]) => `<div class="row"><div class="info"><strong>${BOOSTS[k].icon} ${BOOSTS[k].name}</strong><small style="white-space:normal">${BOOSTS[k].desc} nos próximos ${BOOSTS[k].kills} monstros da campanha. Fica guardado até você usar.</small></div><div class="side"><button class="btn small" data-boost="${k}">${medal(price)}</button></div></div>`).join('');
  else for (const sp of specs) for (const g of [1, 2, 3]) {
    const it = makePvpItem({ ...sp, g }), price = PVP_PRICES[sp.ps === 'shield' ? 'shield' : sp.ps][g];
    rows += itemRow(it, `<button class="btn small" data-buy='${JSON.stringify({ ...sp, g })}'>${medal(price)}</button>`);
  }
  if (tab === 'shield' && !LG.left) rows = `<p class="note">${CLASSES[h.cls].name} não usa escudo.</p>` + rows;
  const html = `<p class="note" style="margin:0 0 8px">${medal(p.medals)} · Ganhe medalhas na Sala, na Batalha Campal e na WoE. Os números acompanham o seu nível.</p>
    <div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div class="list">${rows}</div>`;
  const body = UI.openSheet({ title: '🎖️ Loja de PvP', html, acc: '#ffae5e' });
  body.querySelectorAll('[data-t]').forEach((b) => b.onclick = () => pvpShopSheet(b.dataset.t));
  body.querySelectorAll('[data-buy]').forEach((b) => b.onclick = () => { const e = PvP.buyPvp(JSON.parse(b.dataset.buy)); UI.toast(e || 'Comprado! Está na Bolsa de PvP.'); pvpShopSheet(tab); });
  body.querySelectorAll('[data-boost]').forEach((b) => b.onclick = () => { const e = PvP.buyPvp({ boost: b.dataset.boost }); UI.toast(e || 'Comprado! Use no salão da guilda.'); pvpShopSheet(tab); });
}

// ---------------- Na partida ----------------
export function pvpHudText() {
  const r = G.state.run, P = r && r.pvp; if (!P) return null;
  if (P.mode === 'sala') { const b = PvP.salaBoard(); const i = b.findIndex((x) => x.me) + 1; return `⚔ Sala · ${P.heroPts} pts · ${i}º de ${b.length}`; }
  if (P.mode === 'woe') return `🏰 WoE · Emperium ${Math.max(0, P.emp ? P.emp.hp : 0)} · ${P.turnsLeft} turnos`;
  return `${P.mode === 'flavius' ? 'Flavius' : 'KVM'} · R${P.round} · ${P.score.A}×${P.score.B}`;
}
export function pvpBoardSheet() {
  const r = G.state.run, P = r && r.pvp; if (!P) return;
  let html = '';
  if (P.mode === 'sala') {
    html = `<p class="note">Começa com 5 pontos · derrubar alguém: +1 · cair: −5 · abaixo de 0: expulso. Para sair levando as medalhas, use o botão de voltar à vila.</p><div class="list">` +
      PvP.salaBoard().map((x, i) => `<div class="row"><div class="info"><strong ${x.me ? 'style="color:#ffd86b"' : ''}>${i + 1}º ${esc(x.name)}</strong><small>${clsName(x.cls)} · ${x.k} vitórias</small></div><div class="side"><b>${x.pts}</b></div></div>`).join('') + '</div>';
  } else if (P.mode === 'woe') {
    const ally = r.monsters.filter((u) => u.pvp && u.pvp.kind === 'bot' && u.pvp.team === P.heroTeam && u.hp > 0).length;
    const foe = r.monsters.filter((u) => u.pvp && u.pvp.kind === 'bot' && u.pvp.team !== P.heroTeam && u.hp > 0).length;
    html = `<p class="note">${P.defend ? 'Defenda o Emperium até o tempo acabar.' : 'Quebre o Emperium antes do tempo acabar: só o ataque básico funciona nele, 1 de dano por golpe.'} Quem cai volta à base depois de alguns turnos. Ninguém é empurrado.</p>
      <div class="list"><div class="row"><div class="info"><strong>Emperium</strong></div><div class="side"><b>${Math.max(0, P.emp.hp)} / ${P.emp.maxHp}</b></div></div>
      <div class="row"><div class="info"><strong>Tempo</strong></div><div class="side"><b>${P.turnsLeft} turnos</b></div></div>
      <div class="row"><div class="info"><strong>De pé</strong><small>${GUILD_TXT} × ${esc(P.rival)}</small></div><div class="side"><b>${ally} × ${foe}</b></div></div></div>`;
  } else {
    const alive = (t) => r.monsters.filter((u) => u.pvp && u.pvp.kind === 'bot' && u.pvp.team === t && u.hp > 0).length + (t === 'A' && !P.heroOut ? 1 : 0);
    html = `<p class="note">${P.mode === 'flavius' ? 'Flavius: destrua o cristal deles (vermelho) e proteja o seu (azul).' : 'KVM: derrube o time todo deles.'} Melhor de 3. Quem cai fica fora até o fim da rodada.</p>
      <div class="list"><div class="row"><div class="info"><strong>Placar</strong><small>${GUILD_TXT} × ${esc(P.rival)}</small></div><div class="side"><b>${P.score.A} × ${P.score.B}</b></div></div>
      <div class="row"><div class="info"><strong>Rodada ${P.round}</strong><small>De pé</small></div><div class="side"><b>${alive('A')} × ${alive('B')}</b></div></div>
      ${P.crystal ? `<div class="row"><div class="info"><strong>Cristais</strong><small>nosso × deles</small></div><div class="side"><b>${Math.max(0, P.crystal.A.hp)} × ${Math.max(0, P.crystal.B.hp)}</b></div></div>` : ''}</div>`;
  }
  UI.openSheet({ title: '🏆 Placar', html, acc: '#ffd25e' });
}
const GUILD_TXT = 'PvP Owners';
export function pvpResultSheet() {
  const res = G.state.pvpResult; if (!res) return false;
  delete G.state.pvpResult;
  const stock = Object.entries(res.stock || {}).map(([k, n]) => `${BOOSTS[k].icon} ${BOOSTS[k].name} ×${n}`);
  const html = `<div style="text-align:center;padding:6px 0 12px"><div style="font-size:40px">${res.win ? '🏆' : '⚔️'}</div>
    ${(res.lines || []).map((l) => `<p class="note" style="margin:4px 0">${esc(l)}</p>`).join('')}
    <p style="margin:12px 0 0;font-size:18px">${medal(res.medals || 0)} Medalhas de Honra</p>
    ${stock.length ? `<p style="margin:8px 0 0;color:#ffd86b"><b>${stock.join(' · ')}</b></p>` : ''}</div>`;
  UI.openSheet({ title: esc(res.title || 'PvP'), html, center: true, acc: res.win ? '#3fd47a' : '#ff6b5e' });
  return true;
}
// convite da guilda (uma vez)
export function guildInviteSheet() {
  const h = G.state.hero; if (!h || !h.pvp || !h.pvp.newGuild) return false;
  delete h.pvp.newGuild; Game.save();
  const g = h.pvp.guild;
  UI.openSheet({ title: '✉️ Convite da guilda', center: true, acc: '#ff5d6c', html: `<p class="note" style="font-size:15px">"Vi você virar ${esc(clsName(h.cls))}. A <b>${esc(g.name)}</b> precisa de alguém assim. Quero você como meu <b>vice-líder</b>."</p><p class="note" style="text-align:right">— ${esc(g.leader)}, líder da ${esc(g.name)}</p><p class="note">O PvP está liberado: Sala de PvP, Batalha Campal e Guerra do Emperium, no prédio da guilda na vila.</p>` });
  return true;
}
