// =============================================================
// Núcleo do jogo: estado, turnos, combate, IA, habilidades,
// cidade e salvamento.
// =============================================================
import { FX_META } from './fx_meta.js';
import { BOOSTS, BOSS_RESPAWN_MIN, baseCls, MAX_TIER, LAST_FLOOR, FIRST_LIFE_FLOOR, handsOf, isTwoHanded } from './data.js';
import { CLASSES, SKILLS, MONSTERS, ITEMS, themeForFloor, CLASS_LV, CLASS_STARTER, REFINE_RATES, LEGACY, POTION_BY_TIER, SP_POTION_BY_TIER, SHOP_GEAR, ELEMENTS, BASIC_MUL, oldLv, SKILL_OLD_MAX, newLvFromOld } from './data.js';
import { rnd, chance, pick, clamp, dist, uid, weighted, DIRS8, setUidFloor } from './util.js';
import * as Mk from './market.js';
import { T, generateFloor, computeFov, bfs, tileAt, setTile, passable, randomFloorTile, hasLos, lineTiles, inb } from './map.js';
import { REBORN_STAT_BONUS, derive, monsterStats, physHit, magicHit, xpToNext, statCost, statPtsForLevel, makeItem, makeCard, randomEquip, itemDef, itemName, isStack, isEquip, sellPrice, buyPrice, legacyCost, STATS } from './rules.js';
export const BAR_N = 8; // atalhos de habilidade no leque

const SAVE_KEY = 'anothero_save_v1';
const invCap = () => 30 + 5 * (S().meta.legacy.mochila || 0);
const storageCap = () => 120 + 40 * (S().meta.legacy.armazem || 0);
export { invCap, storageCap };
const FOV_R = 7;   // névoa: visão até 7 casas

export const G = {
  state: null,
  d: null,         // atributos derivados do herói
  fov: null,       // visibilidade atual
  dmap: null,      // mapa de distâncias até o jogador
  fx: [],          // eventos visuais/sonoros para o renderizador
  dirty: true,     // UI precisa atualizar
};

// ---------------- Utilidades de estado ----------------
const S = () => G.state;
const run = () => G.state.run;
const hero = () => G.state.hero;
// enquanto uma habilidade é lançada, números, brilhos e mortes esperam o golpe chegar no alvo (o quadro de impacto da animação)
let castDelay = 0;
// no jogo (não no robô): o turno dos monstros só roda quando a animação da habilidade termina, e os toques esperam
let animWait = false, lockUntil = 0;
export function setAnimWait(v) { animWait = v; }
export const animLocked = () => lockUntil > Date.now();
export let onDeferredTurn = null;
export function setDeferredTurnHook(fn) { onDeferredTurn = fn; }
// cópias extras do efeito nos pontos vazios da área (além de uma em cada monstro)
const ONE_FX = new Set(['olhar_medusa', 'ofensiva_furiosa']);   // um efeito só, no centro da área (sem cópias espalhadas)
const AOE_EXTRA = { olhar_medusa: 2, meteoro: 4, nevasca: 3, ira_thor: 3, jutsu_fogo: 2, kunai_explosiva: 2, garra_sombria: 1, chuva_flechas: 0 };
const DELAYED = new Set(['dmg', 'flash', 'text', 'death', 'burst', 'shake', 'splash', 'cardDrop', 'ring', 'quake']);
export const fx = (e) => {
  if (castDelay && (DELAYED.has(e.type) || (e.type === 'move' && e.id !== 'hero'))) e.delay = (e.delay || 0) + castDelay;
  G.fx.push(e);
};

export function log(text, color = '#e8eaf2') {
  const r = run();
  const target = r ? r.log : (G.state.townLog = G.state.townLog || []);
  target.push({ text, color, at: performance.now() });
  if (target.length > 40) target.shift();
  G.dirty = true;
}

export function recalc() {
  const h = hero();
  if (!h) { G.d = null; return; }
  G.d = derive(h, S().meta);
  h.hp = Math.min(h.hp, G.d.maxHp);
  h.sp = Math.min(h.sp, G.d.maxSp);
  G.dirty = true;
}

export function lineage(cls) {
  const out = [];
  let c = cls;
  while (c) { out.unshift(c); c = CLASSES[c].from; }
  return out;
}

export const hasBuff = (id) => (hero()?.buffs || []).some((b) => b.id === id);
function removeBuff(id) {
  const h = hero();
  const before = h.buffs.length;
  h.buffs = h.buffs.filter((b) => b.id !== id);
  if (before !== h.buffs.length) recalc();
}

// ---------------- Novo jogo / herói ----------------
export function newState() {
  G.state = {
    v: 1,
    mode: 'title',
    meta: { zeny: 0, storage: [], legacy: {}, heroesLost: 0, victories: 0, bestFloor: 0, graveyard: [] },
    hero: null,
    roster: [], active: -1,
    run: null,
    settings: { sound: true, vibrate: true },
  };
  return G.state;
}

export const MAX_HEROES = 8;
// Hardcore: morte permanente, mas +30% XP e zeny e drops ×1,5
export const HC = { xp: 1.3, zeny: 1.3, drop: 1.5 };
export function createHero(name, hardcore = false) {
  if ((S().roster || []).length >= MAX_HEROES) return 'Todas as vagas estão ocupadas.';
  const meta = S().meta;
  const leg = meta.legacy;
  const h = {
    name: name || 'Aventureiro',
    cls: 'aprendiz', lv: 1, xp: 0,
    statPts: 10, skillPts: 1,
    base: { str: 1, agi: 1, vit: 1, int: 1, dex: 1, luk: 1 },
    skills: {}, skillRemap: 1, bar: Array(BAR_N).fill(null), clsHistory: [{ cls: 'aprendiz', since: 1 }],
    hp: 1, sp: 1, zeny: 0,
    equip: { weapon: makeItem('espada_treino'), left: null, armor: makeItem('roupa_algodao'), head: null, acc1: null, acc2: null },
    inv: [], buffs: [], status: {},
    checkpoint: 1, kills: 0, created: Date.now(), deepest: 0, hardcore: !!hardcore, deaths: 0,
  };
  S().roster = S().roster || [];
  S().roster.push(h);
  S().active = S().roster.length - 1;
  S().hero = h;
  addToInv(makeItem('pocao_vermelha', { qty: 4 + (leg.kit || 0) * 3 }), h);
  addToInv(makeItem('asa_borboleta', { qty: 1 + Math.floor((leg.kit || 0) / 2) }), h);
  if (leg.kit) addToInv(makeItem('asa_mosca', { qty: leg.kit }), h);
  if ((leg.kit || 0) >= 3) addToInv(makeItem('pocao_laranja', { qty: leg.kit - 1 }), h);
  // Aprendiz Veterano: começa no nível 8 com os pontos desse nível
  if (leg.veterano) { while (h.lv < 8) { h.lv++; h.statPts += statPtsForLevel(h.lv); h.skillPts += 1; } }
  recalc();
  h.hp = G.d.maxHp; h.sp = G.d.maxSp;
  S().mode = 'town';
  S().townLog = [];
  log(`${h.name} chega à Vila de Runa.`, '#ffe08a');
  save();
}

// ---------------- Inventário ----------------
export function addToInv(it, h = hero()) {
  if (isStack(it)) {
    const ex = h.inv.find((o) => o.id === it.id);
    if (ex) { ex.qty += it.qty; return true; }
  }
  if (h.inv.length >= invCap()) return false;
  h.inv.push(it);
  return true;
}

function consume(it, n = 1) {
  const h = hero();
  it.qty -= n;
  if (it.qty <= 0) h.inv = h.inv.filter((o) => o !== it);
}

export const findInv = (u) => hero().inv.find((o) => o.uid === u);

// ---------------- Equipamento: 6 espaços ----------------
export const SLOTS = ['weapon', 'left', 'head', 'armor', 'acc1', 'acc2'];
export const SLOT_NAMES = { weapon: 'Mão direita', left: 'Mão esquerda', head: 'Cabeça', armor: 'Armadura', acc1: 'Acessório 1', acc2: 'Acessório 2' };
// onde um item pode ir (para a classe atual)
export function slotsFor(it, h = hero()) {
  const d = itemDef(it);
  if (d.kind === 'armor') return ['armor'];
  if (d.kind === 'head') return ['head'];
  if (d.kind === 'acc') return ['acc1', 'acc2'];
  if (d.kind === 'shield') return handsOf(h.cls).noShield ? [] : ['left'];
  if (d.kind === 'weapon') {
    if (isTwoHanded(d)) return ['weapon'];
    const main = h.equip.weapon && itemDef(h.equip.weapon);
    const dual = (handsOf(h.cls).dual || []).includes(d.wtype) && !(main && isTwoHanded(main));
    return dual ? ['weapon', 'left'] : ['weapon'];
  }
  return [];
}
function stash(it) { if (!it) return; if (hero().inv.length < invCap()) hero().inv.push(it); else S().meta.storage.push(it); }
// arruma as mãos depois de trocar arma ou classe (arma de 2 mãos, escudo proibido, segunda arma inválida)
export function validateHands(h = hero()) {
  const main = h.equip.weapon && itemDef(h.equip.weapon), left = h.equip.left && itemDef(h.equip.left);
  if (!left) return;
  const hs = handsOf(h.cls);
  const bad = (main && isTwoHanded(main)) || (left.kind === 'shield' && hs.noShield) || (left.kind === 'weapon' && !(hs.dual || []).includes(left.wtype));
  if (bad) { const it = h.equip.left; h.equip.left = null; stash(it); log(`${itemName(it)} voltou para a mochila.`, '#ffd86b'); }
}
export function equipItem(u, slot) {
  const h = hero();
  const it = findInv(u);
  if (!it || !isEquip(it)) return;
  const opts = slotsFor(it, h);
  if (!opts.length) { log('Sua classe não usa este item.', '#ff8a8a'); return; }
  if (!opts.includes(slot)) slot = opts.find((k) => !h.equip[k]) || opts[0];
  const old = h.equip[slot];
  h.inv = h.inv.filter((o) => o !== it);
  h.equip[slot] = it;
  if (old) h.inv.push(old);
  // escudo com arma de 2 mãos: a arma volta para a mochila
  if (slot === 'left' && h.equip.weapon && isTwoHanded(itemDef(h.equip.weapon))) { const w = h.equip.weapon; h.equip.weapon = null; stash(w); }
  validateHands(h);
  recalc();
  log(`Equipou ${itemName(it)}.`, '#9fe08a');
  fx({ type: 'sfx', name: 'equip' });
}
export const slotOf = (it, h = hero()) => SLOTS.find((k) => h.equip[k] === it);

export function unequip(slot) {
  const h = hero();
  const it = h.equip[slot];
  if (!it) return;
  if (h.inv.length >= invCap()) { log('Mochila cheia.', '#ff8a8a'); return; }
  h.equip[slot] = null;
  h.inv.push(it);
  recalc();
}

export function dropItem(u) {
  const it = findInv(u);
  if (!it) return;
  hero().inv = hero().inv.filter((o) => o !== it);
  if (run()) run().items.push({ x: run().px, y: run().py, item: it });
  log(`Largou ${itemName(it)}.`);
}

export function insertCard(cardUid, equipUid) {
  const h = hero();
  const card = findInv(cardUid);
  let eq = findInv(equipUid) || Object.values(h.equip).find((e) => e && e.uid === equipUid);
  if (!card || !eq) return false;
  const cd = itemDef(card), ed = itemDef(eq);
  if (cd.slot !== ed.kind) return false;
  if ((eq.cards || []).length >= eq.slots) return false;
  eq.cards.push(card.mon);
  h.inv = h.inv.filter((o) => o !== card);
  recalc();
  log(`${cd.name} encaixada em ${itemName(eq)}!`, '#ffd86b');
  fx({ type: 'sfx', name: 'card' });
  save();
  return true;
}

// ---------------- Atributos e habilidades ----------------
export function raiseStat(k) {
  const h = hero();
  const c = statCost(h.base[k]);
  if (h.statPts < c || h.base[k] >= 99) return false;
  h.statPts -= c;
  h.base[k]++;
  const oldMax = G.d.maxHp, oldSp = G.d.maxSp;
  recalc();
  h.hp += Math.max(0, G.d.maxHp - oldMax);
  h.sp += Math.max(0, G.d.maxSp - oldSp);
  return true;
}

export function skillAvailable(id) {
  const h = hero();
  return lineage(h.cls).some((c) => CLASSES[c].skills.includes(id));
}

export function learnSkill(id) {
  const h = hero();
  const sk = SKILLS[id];
  if (!skillAvailable(id) || h.skillPts <= 0) return false;
  const cur = h.skills[id] || 0;
  if (cur >= sk.max) return false;
  h.skills[id] = cur + 1;
  h.skillPts--;
  if (cur === 0 && sk.target !== 'passive' && !h.bar.includes(id)) {
    const i = h.bar.indexOf(null);
    if (i >= 0) h.bar[i] = id;
  }
  recalc();
  return true;
}

export function toggleBar(id) {
  const h = hero();
  const i = h.bar.indexOf(id);
  if (i >= 0) { h.bar[i] = null; return; }
  const e = h.bar.indexOf(null);
  if (e >= 0) h.bar[e] = id;
  else { h.bar.shift(); h.bar.push(id); }
}

// Pontos de habilidade que ainda podem ser gastos na classe atual
export function unspentSkillPts() {
  const h = hero();
  if (h.skillPts <= 0) return 0;
  const learnable = lineage(h.cls).flatMap((c) => CLASSES[c].skills).some((id) => (h.skills[id] || 0) < SKILLS[id].max);
  return learnable ? h.skillPts : 0;
}

export function classOptions() {
  const h = hero();
  const prev = h.rebornFrom ? lineage(h.rebornFrom) : null;
  const opts = Object.entries(CLASSES).filter(([id, c]) => c.from === h.cls && (!prev || !c.base || prev.includes(c.base))).map(([id, c]) => ({ id, ...c }));
  const need = opts.length ? CLASS_LV[opts[0].tier] : null;
  const lvOk = need !== null && h.lv >= need;
  const pts = unspentSkillPts();
  return { opts, need, lvOk, pts, ok: lvOk && pts === 0 };
}

export function changeClass(id) {
  const h = hero();
  const c = CLASSES[id];
  if (!c || c.from !== h.cls || h.lv < CLASS_LV[c.tier] || unspentSkillPts() > 0) return false;
  if (h.rebornFrom && c.base && !lineage(h.rebornFrom).includes(c.base)) return false;
  h.cls = id;
  validateHands(h);
  h.clsHistory = h.clsHistory || [{ cls: 'aprendiz', since: 1 }];
  h.clsHistory.push({ cls: id, since: h.lv });
  h.skillPts += 1;
  const starter = CLASS_STARTER[id];
  // Taekwon luta de mãos vazias: guarda a arma que estiver na mão
  if (!starter && ['taekwon', 'mestre_taekwon'].includes(baseCls(id)) && h.equip.weapon && itemDef(h.equip.weapon).wtype !== 'faixa') {
    const w = h.equip.weapon; h.equip.weapon = null;
    if (!addToInv(w)) S().meta.storage.push(w);
    log('Você guarda a arma: o Taekwon luta com os pés e os punhos.', '#ffd86b');
  }
  if (starter) {
    const it = makeItem(starter);
    if (!addToInv(it)) S().meta.storage.push(it);
    log(`O mestre te entrega: ${itemName(it)}.`, '#ffd86b');
  }
  recalc();
  h.hp = G.d.maxHp; h.sp = G.d.maxSp;
  log(`${h.name} agora é ${c.name}!`, '#ffd86b');
  fx({ type: 'sfx', name: 'levelup' });
  save();
  return true;
}

// Teto de nível: só sobe além dele derrotando o próximo chefe
// 0 chefes: 12 · Rei Gelim: 20 · Rainha: 30 · Faraó: 40 · Lorde: 55 · Bafomé: 65 · Drake: 75 · Garm: 90 · Thanatos: livre
export const LEVEL_CAPS = [12, 20, 30, 40, 55, 65, 75, 90, 99];
export const bossesBeaten = (h = hero()) => (h.bosses || []).length;
export const levelCap = (h = hero()) => LEVEL_CAPS[Math.min(LEVEL_CAPS.length - 1, bossesBeaten(h))];

function addXp(n) {
  const h = hero();
  const cap = levelCap(h);
  if (h.lv >= cap) {
    // no teto: a barra fica cheia e o excesso vira um pouco de zeny
    const full = xpToNext(h.lv, h) - 1;
    const over = Math.max(0, h.xp + n - full);
    h.xp = Math.min(full, h.xp + n);
    if (over > 0) {
      h.xpOver = (h.xpOver || 0) + over * 0.02;
      if (h.xpOver >= 1) { const z = Math.floor(h.xpOver); h.xpOver -= z; h.zeny += z; }
    }
    return;
  }
  h.xp += n;
  let leveled = false;
  while (h.xp >= xpToNext(h.lv, h) && h.lv < cap) {
    h.xp -= xpToNext(h.lv, h);
    h.lv++;
    h.statPts += statPtsForLevel(h.lv);
    h.skillPts += 1;
    if (h.reborn && h.lv % 10 === 0) h.skillPts += 1; // renascido: +1 ponto de habilidade a cada 10 níveis
    leveled = true;
    S().meta.bestLevel = Math.max(S().meta.bestLevel || 0, h.lv);
  }
  if (h.lv >= cap) { h.xp = Math.min(h.xp, xpToNext(h.lv, h) - 1); if (leveled) log(`Limite de nível ${cap}! Derrote o próximo chefe para continuar evoluindo.`, '#ffb84a'); }
  if (leveled) {
    recalc();
    h.hp = Math.min(G.d.maxHp, h.hp + Math.floor(G.d.maxHp * 0.3));
    h.sp = Math.min(G.d.maxSp, h.sp + Math.floor(G.d.maxSp * 0.3));
    log(`Nível ${h.lv}! Você tem pontos para distribuir.`, '#ffd86b');
    fx({ type: 'levelup', x: run().px, y: run().py });
    fx({ type: 'sfx', name: 'levelup' });
    const co = classOptions();
    if (co.opts.length && h.lv === co.need) log('Nível de classe atingido! Gaste os pontos de habilidade e visite a Guilda na cidade.', '#ffd86b');
  }
}

// ---------------- Renascimento ----------------
export const REBIRTH_LV = 60;
export function rebirthInfo(h = hero()) {
  const why = [];
  if (h.reborn) return { ok: false, done: true, why: ['Este herói já renasceu.'] };
  if (!(h.bosses || []).includes(FIRST_LIFE_FLOOR)) why.push('Derrote o Bafomé (andar 25).');
  if (h.lv < REBIRTH_LV) why.push(`Chegue ao nível ${REBIRTH_LV} (agora ${h.lv}).`);
  if (CLASSES[h.cls].tier < 2) why.push('Seja de uma classe avançada.');
  return { ok: !why.length, why };
}
export function rebirth() {
  const h = hero();
  const info = rebirthInfo(h);
  if (!info.ok || S().mode !== 'town') return info.why[0] || 'Não é possível renascer agora.';
  h.rebornFrom = h.cls;
  h.reborn = 1;
  h.firstLife = { cls: h.cls, lv: h.lv };
  h.cls = 'aprendiz_alto';
  h.lv = 1; h.xp = 0;
  h.base = { str: 1, agi: 1, vit: 1, int: 1, dex: 1, luk: 1 };
  h.statPts = 10 + REBORN_STAT_BONUS;
  h.skills = {}; h.skillPts = 1; h.bar = Array(BAR_N).fill(null);
  h.buffs = []; h.status = {}; h.cd = {};
  h.clsHistory = [{ cls: 'aprendiz_alto', since: 1 }];
  h.bosses = []; h.bossDown = {}; h.checkpoint = 1; h.deepest = 1;
  recalc();
  h.hp = G.d.maxHp; h.sp = G.d.maxSp;
  S().meta.reborns = (S().meta.reborns || 0) + 1;
  log(`${h.name} renasceu! Nível 1, mas com +25% de HP e SP e ${REBORN_STAT_BONUS} pontos de atributo extras.`, '#ffd86b');
  fx({ type: 'sfx', name: 'levelup' });
  save();
  return null;
}
export const isTrans = (h = hero()) => !!CLASSES[h.cls].trans;

// ---------------- Masmorra ----------------
// Pela cidade dá para entrar em qualquer andar já alcançado (cada entrada gera um andar novo).
// Andares de chefe já vencidos ficam de fora.
export function availableFloors() {
  const h = hero();
  const max = Math.max(1, h.deepest || 1, h.checkpoint || 1);
  const beaten = new Set(h.bosses || []);
  const out = [];
  for (let f = 1; f <= max; f++) out.push(f);
  return out;
}

export function enterDungeon(floor) {
  const h = hero();
  h.buffs = (h.buffs || []).filter((b) => b.aura);
  h.status = {};
  S().run = { floor: 0, log: [], telegraphs: [], items: [], monsters: [], time: 0, turns: 0, energy: 100, px: 0, py: 0, reviveUsed: false };
  S().mode = 'dungeon';
  recalc();
  goToFloor(floor);
}

function goToFloor(floor) {
  const r = run();
  const h = hero();
  r.floor = floor;
  r.map = generateFloor(floor);
  r.monsters = [];
  r.items = [];
  r.telegraphs = [];
  r.guard = false; h.buffs = h.buffs.filter((b) => b.id !== 'guarda');
  r.px = r.map.start.x; r.py = r.map.start.y;
  r.reviveUsed = false;
  r.bossDead = false;
  r.sinceSpawn = 0;
  h.deepest = Math.max(h.deepest || 0, floor);
  S().meta.bestFloor = Math.max(S().meta.bestFloor, floor);
  // chefe ainda morto (reaparece com o tempo): arena vazia, saídas abertas
  if (r.map.isBoss && bossRespawnAt(floor)) {
    r.map.isBoss = false;
    r.bossDead = true;
    openBossExits(r);
    spawnInitial();
    r.monsters = r.monsters.filter((o) => !MONSTERS[o.type].boss);
    const left = Math.ceil((bossRespawnAt(floor) - Date.now()) / 60000);
    log(`${MONSTERS[themeForFloor(floor).boss].name} ainda não voltou (cerca de ${left} min).`, '#9ab');
  } else spawnInitial();
  updateView();
  const th = themeForFloor(floor);
  log(`Andar ${floor} — ${th.name}`, th.accent);
  if (r.map.isBoss) log('Uma presença poderosa domina este andar...', '#ff8a8a');
  fx({ type: 'floor' });
  save();
}

function monsterPoolForFloor(floor) {
  const th = themeForFloor(floor);
  const list = [...th.monsters].sort((a, b) => MONSTERS[a].lv - MONSTERS[b].lv);
  if (floor > LAST_FLOOR) return list;
  const k = (floor - 1) % 5;
  return list.slice(0, Math.min(list.length, k + 2 + (k >= 3 ? 1 : 0)));
}

function makeMonster(type, x, y) {
  const st = monsterStats(type, run().floor);
  const def = MONSTERS[type];
  return {
    uid: uid(), type, x, y, ...st, boss: !!def.boss,
    energy: rnd(0, 90), status: {}, awake: false, asleep: !def.boss && chance(45),
    tx: null, ty: null, stolen: false, cd: { summon: 4, slam: 3, meteor: 5, teleport: 8 }, ai: def.ai || [],
  };
}

const monsterAt = (x, y) => run().monsters.find((m) => m.x === x && m.y === y && m.hp > 0);
export { monsterAt };
const occupied = (x, y) => (x === run().px && y === run().py) || !!monsterAt(x, y);

function spawnInitial() {
  const r = run();
  const m = r.map;
  if (m.isBoss) {
    const th = themeForFloor(r.floor);
    const boss = makeMonster(th.boss, m.bossSpot.x, m.bossSpot.y);
    r.monsters.push(boss);
    const def = MONSTERS[th.boss];
    for (let i = 0; i < 2; i++) {
      const p = freeNear(m.bossSpot.x, m.bossSpot.y, 3);
      if (p) r.monsters.push(makeMonster(def.summon, p.x, p.y));
    }
  } else {
    const n = 9 + Math.floor(r.floor * 0.35);
    for (let i = 0; i < n; i++) spawnRandom(true);
    const ni = rnd(2, 4);
    for (let i = 0; i < ni; i++) {
      const p = randomFloorTile(m, (x, y) => dist(x, y, m.start.x, m.start.y) < 3);
      if (p) r.items.push({ x: p.x, y: p.y, item: randomLoot(r.floor, true) });
    }
  }
}

function spawnRandom(initial) {
  const r = run();
  const pool = monsterPoolForFloor(r.floor);
  const p = randomFloorTile(r.map, (x, y) => occupied(x, y) || dist(x, y, r.px, r.py) < (initial ? 7 : 9) || (G.fov && G.fov[y * r.map.w + x]));
  if (!p) return;
  const type = weighted(pool.map((t, i) => [t, 10 + i * 2]));
  const mon = makeMonster(type, p.x, p.y);
  if (!initial) { mon.asleep = false; mon.awake = false; }
  r.monsters.push(mon);
}

function freeNear(x, y, rad) {
  const r = run();
  for (let k = 0; k < 60; k++) {
    const nx = x + rnd(-rad, rad), ny = y + rnd(-rad, rad);
    if (passable(tileAt(r.map, nx, ny)) && !occupied(nx, ny) && tileAt(r.map, nx, ny) !== T.STAIRS) return { x: nx, y: ny };
  }
  return null;
}

export const tierForFloor = (floor) => clamp(Math.ceil(floor / 5), 1, MAX_TIER);
function randomLoot(floor, ground) {
  const tier = clamp(tierForFloor(floor) + (chance(12) ? 1 : 0), 1, MAX_TIER);
  const kind = weighted([['pot', ground ? 40 : 50], ['equip', ground ? 35 : 28], ['frag', 10], ['wing', 8], ['herb', 4], ['blue', 3]]);
  if (kind === 'pot') return makeItem(POTION_BY_TIER[clamp(tier + (chance(30) ? -1 : 0), 1, MAX_TIER + 1)], { qty: rnd(1, 2) });
  if (kind === 'equip') return randomEquip(tier);
  if (kind === 'frag') return makeItem('fragmento');
  if (kind === 'wing') return makeItem(chance(70) ? 'asa_mosca' : 'asa_borboleta');
  if (kind === 'blue') return makeItem(SP_POTION_BY_TIER[clamp(tier, 1, MAX_TIER + 1)]);
  return makeItem('erva_verde');
}

export function updateView() {
  const r = run();
  const m = r.map;
  G.fov = computeFov(m, r.px, r.py, FOV_R);
  for (let i = 0; i < G.fov.length; i++) if (G.fov[i]) m.seen[i] = 1;
  G.dmap = bfs(m, r.px, r.py);
  G.dirty = true;
}

export const visible = (x, y) => G.fov && inb(run().map, x, y) && G.fov[y * run().map.w + x] === 1;
export const visibleMonsters = () => run().monsters.filter((m) => m.hp > 0 && visible(m.x, m.y));

// ---------------- Turnos ----------------
function endTurn(cost = 100) {
  const r = run();
  if (r.guard === 'new') r.guard = true;
  else if (r.guard) endGuard();
  r.energy -= cost;
  advance();
  G.dirty = true;
}

function advance() {
  const r = run();
  let guard = 0;
  while (S().mode === 'dungeon' && guard++ < 20000) {
    if (r.energy >= 100) {
      const st = hero().status;
      if ((st.stun || 0) > 0 || (st.freeze || 0) > 0) {
        r.energy -= 100;
        if (guard % 7 === 1) log(st.freeze ? 'Você está congelado!' : 'Você está atordoado!', '#9ac8ff');
      } else break;
    }
    r.time++;
    r.energy += G.d.speed / 10;
    for (const m of [...r.monsters]) {
      if (m.hp <= 0) continue;
      m.energy += m.speed / 10 * ((m.status.slow || 0) > 0 ? 0.5 : 1);
      while (m.energy >= 100 && m.hp > 0 && S().mode === 'dungeon') {
        m.energy -= 100;
        monsterAct(m);
      }
    }
    if (S().mode !== 'dungeon' || !run()) break; // o herói caiu neste passo
    resolveTelegraphs();
    if (S().mode !== 'dungeon' || !run()) break;
    if (r.time % 10 === 0) turnEnd();
    if (S().mode !== 'dungeon' || !run()) break;
  }
  if (run()) run().monsters = run().monsters.filter((m) => m.hp > 0);
}

function turnEnd() {
  const r = run();
  const h = hero();
  const d = G.d;
  r.turns++;
  // Regeneração
  r.hpAcc = (r.hpAcc || 0) + d.regenHp * (r.resting ? 2.5 : 1);
  r.spAcc = (r.spAcc || 0) + d.regenSp * (r.resting ? 2.5 : 1);
  if (r.hpAcc >= 1) { const v = Math.floor(r.hpAcc); r.hpAcc -= v; if (!h.status.poison) h.hp = Math.min(d.maxHp, h.hp + v); }
  if (h.status.noSpRegen) r.spAcc = 0; // depois do Asura o SP não volta por um tempo
  if (r.spAcc >= 1) { const v = Math.floor(r.spAcc); r.spAcc -= v; h.sp = Math.min(d.maxSp, h.sp + v); }
  // invisível gasta SP a cada turno (Esconderijo 1% do SP máx, Furtividade 2%); sem SP, a invisibilidade acaba
  const hide = h.buffs.find((b) => b.id === 'oculto');
  if (hide) {
    const cost = Math.max(1, Math.round(d.maxSp * (hide.still ? 0.01 : 0.02)));
    if (h.sp >= cost) h.sp -= cost; else { h.buffs = h.buffs.filter((b) => b !== hide); recalc(); log('Sem SP: você saiu das sombras.', '#c9ccd6'); }
    if (hide.still) { r.hpAcc += d.regenHp; r.spAcc += d.regenSp; }   // Esconderijo: recupera 2× mais rápido
  }
  if (h.cd) for (const k of Object.keys(h.cd)) { h.cd[k]--; if (h.cd[k] <= 0) delete h.cd[k]; }
  // Status do herói
  if (h.status.poison > 0) {
    const v = Math.max(1, Math.floor(d.maxHp * 0.025));
    damageHero(v, { silent: false, color: '#b56bff', noKyrie: true, source: 'veneno' });
  }
  if (h.status.burn > 0 && S().mode === 'dungeon') {
    const v = Math.max(1, Math.floor(d.maxHp * 0.03));
    damageHero(v, { color: '#ff8a3a', noKyrie: true, source: 'queimadura' });
  }
  if (S().mode !== 'dungeon' || !run()) return; // caiu por veneno/queimadura
  for (const k of Object.keys(h.status)) { h.status[k]--; if (h.status[k] <= 0) delete h.status[k]; }
  // Buffs
  let changed = false;
  for (const b of h.buffs) if (!b.aura && !b.keep) b.turns--;
  // Fervor: depois de 8 turnos sem ganhar, perde 1 ponto a cada 2 turnos
  if (fervorOf(h) > 0) { h.fervorIdle = (h.fervorIdle || 0) + 1; if (h.fervorIdle > 8 && h.fervorIdle % 2 === 1) setFervor(h, fervorOf(h) - 1); }
  const expired = h.buffs.filter((b) => b.turns <= 0 && !b.keep);
  if (expired.length) {
    h.buffs = h.buffs.filter((b) => b.turns > 0 || b.keep);
    for (const b of expired) if (b.id === 'oculto') log('Você saiu das sombras.', '#c9ccd6');
    changed = true;
  }
  if (changed) recalc();
  // Campo Gravitacional (Arquimago): dano todo turno ignorando DEFM e deixa lento
  if (r.fields && r.fields.length) {
    for (const fl of r.fields) {
      for (const m of r.monsters) {
        if (m.hp <= 0 || dist(m.x, m.y, fl.x, fl.y) > fl.rad) continue;
        const res = magicHit(heroAttacker({ ignoreMdef: true }), m, fl.mult, 'neutro');
        m.status.slow = Math.max(m.status.slow || 0, 2);
        m.status.gravity = Math.max(m.status.gravity || 0, 2);   // -30% DEFM enquanto estiver no campo
        killSrc = 'magic'; damageMonster(m, res.dmg, { color: '#c9a6ff', dot: true }); killSrc = null;
      }
      fx({ type: 'ring', x: fl.x, y: fl.y, r: fl.rad, color: '#a37bff' });
      fl.turns--;
    }
    r.fields = r.fields.filter((fl) => fl.turns > 0);
  }
  // Calor do Sol (Imperador Estelar): queima quem estiver em volta
  if (d.mods.sunAura) {
    const lv = d.mods.sunAura, rad = lv >= 3 ? 2 : 1;
    for (const m of r.monsters) {
      if (m.hp <= 0 || dist(m.x, m.y, r.px, r.py) > rad) continue;
      const res = physHit(heroAttacker({ el: 'fogo' }), m, 0.2 + lv * 0.04, { el: 'fogo', sure: true });
      damageMonster(m, res.dmg, { color: '#ffb04a', dot: true });
    }
  }
  // Monstros
  for (const m of r.monsters) {
    if (m.hp <= 0) continue;
    if (m.status.poison > 0) damageMonster(m, Math.max(1, Math.floor(Math.min(m.maxHp * 0.03, 40 + m.lv * 6) * (d.mods.deadlyPoison ? 2 : 1))), { color: '#b56bff', dot: true });
    // pedra não queima: enquanto petrificado, a queimadura fica pausada (não tira vida e não acaba)
    const stoned = (m.status.petrify || 0) > 0;
    if (m.status.burn > 0 && m.hp > 0 && !stoned) damageMonster(m, Math.max(1, Math.floor(Math.min(m.maxHp * 0.03, 40 + m.lv * 6))), { color: '#ff8a3a', dot: true });
    for (const k of Object.keys(m.status)) { if (k === 'burn' && stoned) continue; m.status[k]--; if (m.status[k] <= 0) delete m.status[k]; }
    for (const k of Object.keys(m.cd)) if (m.cd[k] > 0) m.cd[k]--;
  }
  // Reaparecimento
  r.sinceSpawn = (r.sinceSpawn || 0) + 1;
  const cap = 9 + Math.floor(r.floor * 0.35);
  if (!r.map.isBoss && r.sinceSpawn >= 45 && r.monsters.length < cap) { r.sinceSpawn = 0; spawnRandom(false); }
  if (r.turns % 25 === 0) save();
}

// ---------------- Dano ----------------
export function damageHero(v, info = {}) {
  const h = hero();
  if (S().mode !== 'dungeon') return;
  const r = run();
  if (!info.noKyrie) {
    const ky = h.buffs.find((b) => b.id === 'kyrie');
    if (ky && ky.hits) { // Kyrie Eleison: reduz o dano de alguns golpes (chefe conta como 2)
      const absorb = Math.floor(v * ky.blockPct / 100); v -= absorb;
      ky.hits -= info.boss ? 2 : 1;
      if (ky.hits <= 0) { removeBuff('kyrie'); log('A Barreira Sagrada se desfez.', '#c9ccd6'); }
      if (absorb) fx({ type: 'text', x: r.px, y: r.py, text: 'bloqueio', color: '#fff2b0' });
    } else if (ky) {
      const absorb = Math.min(ky.shield, v);
      ky.shield -= absorb; v -= absorb;
      if (ky.shield <= 0) { removeBuff('kyrie'); log('A Barreira Sagrada se desfez.', '#c9ccd6'); }
      if (absorb) fx({ type: 'text', x: r.px, y: r.py, text: 'bloqueio', color: '#fff2b0' });
    }
  }
  if (v <= 0) return;
  if (S().settings?.god) v = 0; // modo dev: invencível
  h.hp -= v;
  fx({ type: 'dmg', x: r.px, y: r.py, val: v, color: info.color || '#ff5a5a', crit: info.crit, onHero: true });
  if (!info.dot) fx({ type: 'hurt' });
  r.resting = false;
  r.interrupted = true;
  if (h.hp <= 0) heroDies(info.source);
}

function heroDies(source) {
  const h = hero();
  const r = run();
  const rev = G.d.mods.revive || 0;
  if (rev && !r.reviveUsed) {
    r.reviveUsed = true;
    h.hp = Math.max(1, Math.floor(G.d.maxHp * rev * 0.12));
    log('A Geleia Real te refez!', '#fff2b0');
    fx({ type: 'levelup', x: r.px, y: r.py });
    return;
  }
  h.hp = 0;
  const meta = S().meta;
  if (h.hardcore) {
    // Hardcore: o herói se vai para sempre
    meta.heroesLost++;
    meta.graveyard.unshift({ name: h.name, cls: CLASSES[h.cls].name, lv: h.lv, floor: r.floor, by: source || 'desconhecido', at: Date.now(), hardcore: true });
    meta.graveyard = meta.graveyard.slice(0, 15);
    S().lastDeath = { hardcore: true, name: h.name, cls: CLASSES[h.cls].name, lv: h.lv, floor: r.floor, by: source, zenyLost: h.zeny, kills: h.kills };
    S().roster = (S().roster || []).filter((o) => o !== h);
    S().active = -1;
    S().mode = 'dead';
    fx({ type: 'sfx', name: 'death' });
    save();
    return;
  }
  // Normal: volta para a vila com penalidade pesada
  const xpLoss = Math.floor(xpToNext(h.lv, h) * 0.25);
  h.xp -= xpLoss; // pode ficar negativo: uma dívida de XP a pagar antes de evoluir
  const zenyLost = Math.floor(h.zeny * 0.75);
  h.zeny -= zenyLost;
  h.deaths = (h.deaths || 0) + 1;
  S().lastDeath = { hardcore: false, name: h.name, cls: CLASSES[h.cls].name, lv: h.lv, floor: r.floor, by: source, zenyLost, xpLoss, debt: h.xp < 0 ? -h.xp : 0, kept: h.zeny };
  meta.zeny += h.zeny;
  h.zeny = 0;
  h.buffs = (h.buffs || []).filter((b) => b.aura);
  h.status = {};
  S().run = null;
  S().mode = 'dead';
  recalc();
  h.hp = G.d.maxHp; h.sp = G.d.maxSp;
  fx({ type: 'sfx', name: 'death' });
  save();
}

export function acknowledgeDeath() {
  const ld = S().lastDeath || {};
  S().run = null;
  if (ld.hardcore || !S().hero) {
    S().hero = null; S().active = -1; S().mode = 'title'; G.d = null;
  } else {
    S().mode = 'town';
    S().townLog = [];
    log(`${S().hero.name} acorda na Vila de Runa, ferido mas vivo.`, '#ffe08a');
  }
  save();
}

// ---------------- Personagens ----------------
export function selectHero(i) {
  const h = (S().roster || [])[i];
  if (!h) return;
  S().hero = h; S().active = i; S().run = null; S().mode = 'town'; S().townLog = [];
  recalc();
  h.hp = Math.min(h.hp || G.d.maxHp, G.d.maxHp) || G.d.maxHp;
  log(`${h.name} chega à Vila de Runa.`, '#ffe08a');
  save();
}
export function toCharacterSelect() {
  if (S().mode === 'dungeon') return;
  S().hero = null; S().active = -1; S().mode = 'title'; G.d = null;
  save();
}
export function deleteHero(i) {
  const r = S().roster || [];
  if (!r[i]) return;
  r.splice(i, 1);
  S().roster = r;
  save();
}

function damageMonster(m, v, info = {}) {
  if (m.hp <= 0) return;
  if (castDelay) fx({ type: 'hphold', uid: m.uid, hp: m.hp });   // a barra de vida só cai quando o golpe chega
  m.hp -= v;
  fx({ type: 'dmg', uid: m.uid, x: m.x, y: m.y, val: v, color: info.color || (info.crit ? '#ffd23f' : '#ffffff'), crit: info.crit, delay: info.delay || 0, el: info.el });
  if (!info.dot) fx({ type: 'flash', id: m.uid, delay: info.delay || 0 });
  m.asleep = false;
  if (!hasBuff('oculto')) { m.awake = true; m.tx = run().px; m.ty = run().py; }
  if (m.hp <= 0) killMonster(m);
}

let killSrc = null; // 'magic' enquanto uma magia do herói causa dano (Absorver Alma)
function killMonster(m) {
  const r = run();
  const h = hero();
  const def = MONSTERS[m.type];
  m.hp = 0;
  h.kills++;
  if (castDelay) fx({ type: 'dying', uid: m.uid, mtype: m.type, x: m.x, y: m.y, maxHp: m.maxHp, until: castDelay });   // continua na tela até o golpe chegar
  fx({ type: 'death', x: m.x, y: m.y, color: def.sprite.c[0], boss: m.boss, mtype: m.type, uid: m.uid });
  fx({ type: 'sfx', name: m.boss ? 'bossdie' : 'kill' });
  // XP com penalidade por diferença de nível
  let xp = m.xp * (h.hardcore ? HC.xp : 1) * (h.boosts?.xp > 0 ? 1.5 : 1);
  const diff = h.lv - m.lv;
  if (diff > 8) xp *= Math.max(0.15, 1 - (diff - 8) * 0.08);
  addXp(Math.max(1, Math.round(xp)));
  // Zeny
  const leg = S().meta.legacy;
  const bo = h.boosts || {};
  const plunder = G.d.mods.plunder && chance(G.d.mods.plunder); // carta do Drake
  const zb = (1 + (G.d.mods.zenyPct || 0) / 100) * (h.hardcore ? HC.zeny : 1) * (bo.zeny > 0 ? 1.5 : 1) * (plunder ? 2 : 1);
  if (m.boss || chance(65)) {
    const z = Math.round(m.zeny * (0.6 + Math.random()) * zb);
    h.zeny += z;
    fx({ type: 'text', x: m.x, y: m.y, text: `+${z}z`, color: '#ffd86b', delay: 250 });
  }
  // Itens
  const luck = (h.hardcore ? HC.drop : 1) * (bo.drop > 0 ? 2 : 1);
  const drops = [];
  if (m.boss) {
    // drop de chefe: qualidade acima do bioma, sempre com slots, às vezes já refinado
    const tier = clamp(tierForFloor(r.floor) + 1, 1, MAX_TIER);
    const bossItem = () => { const it = randomEquip(tier, weighted([['weapon', 50], ['armor', 20], ['head', 15], ['shield', 15]])); it.slots = itemDef(it).kind === 'weapon' ? Math.max(it.slots || 0, rnd(1, 3)) : 1; if (chance(50)) it.refine = Math.max(it.refine || 0, rnd(1, 4)); it.bossDrop = MONSTERS[m.type].name; return it; };
    drops.push(bossItem(), makeItem('fragmento', { qty: rnd(1, 3) }), makeItem(POTION_BY_TIER[clamp(Math.ceil(run().floor / 5), 1, 8)], { qty: 3 }));
    if (chance(40 * luck)) drops.push(bossItem());
    if (chance(3 * luck)) drops.push(makeCard(m.type));
  } else {
    if (chance(17 * luck)) drops.push(randomLoot(r.floor));
    if (chance(1.6 * luck)) { drops.push(makeCard(m.type)); }
  }
  if (plunder) { drops.push(randomLoot(r.floor)); fx({ type: 'text', x: m.x, y: m.y, text: 'pilhagem!', color: '#7fe0d0', delay: 350 }); }
  for (const it of drops) {
    r.items.push({ x: m.x, y: m.y, item: it });
    if (it.id === 'card') { log(`Uma ${itemName(it)} caiu!`, '#ffd86b'); fx({ type: 'sfx', name: 'card' }); fx({ type: 'cardDrop', x: m.x, y: m.y }); }
  }
  addFervor(1);
  if (G.d.mods.spOnKill) h.sp = Math.min(G.d.maxSp, h.sp + Math.ceil(G.d.maxSp * G.d.mods.spOnKill / 100));
  if (G.d.mods.soulDrain && killSrc === 'magic') { const v = Math.ceil(G.d.maxSp * G.d.mods.soulDrain / 100); h.sp = Math.min(G.d.maxSp, h.sp + v); fx({ type: 'text', x: m.x, y: m.y, text: `+${v} SP`, color: '#7ab8ff', delay: 300 }); }
  if (m.boss) bossDefeated(m);
  // bênçãos do Santuário: gastam 1 a cada monstro derrotado
  if (h.boosts) for (const k of Object.keys(h.boosts)) { if (h.boosts[k] > 0) { h.boosts[k]--; if (!h.boosts[k]) log(`${BOOSTS[k].name} acabou.`, '#9ab'); } }
}

function openBossExits(r) {
  const spot = r.map.bossSpot;
  const sx = spot.x, sy = spot.y + 1;
  setTile(r.map, sx, sy, T.STAIRS);
  r.map.stairs = { x: sx, y: sy };
  setTile(r.map, sx + 2, sy, T.PORTAL);
  r.map.portal = { x: sx + 2, y: sy };
  r.map.lights.push({ x: sx + 2, y: sy, color: '#7ad0ff', r: 4 });
}
// quando o chefe deste andar volta (0 = já está vivo)
export function bossRespawnAt(floor, h = hero()) { const t = (h.bossDown || {})[floor] || 0; return t > Date.now() ? t : 0; }

function bossDefeated(m) {
  const r = run();
  const h = hero();
  r.bossDead = true;
  openBossExits(r);
  h.bossDown = h.bossDown || {};
  h.bossDown[r.floor] = Date.now() + (BOSS_RESPAWN_MIN[m.type] || 60) * 60000;
  h.checkpoint = Math.max(h.checkpoint, r.floor + 1);
  h.bosses = h.bosses || [];
  h.potTier = Math.max(h.potTier || 0, r.floor);   // poções liberadas no Empório (não volta a trancar ao renascer)
  if (!h.bosses.includes(r.floor)) { h.bosses.push(r.floor); log(`Novo limite de nível: ${levelCap(h)}!`, '#ffd86b'); }
  log(`${MONSTERS[m.type].name} foi derrotado!`, '#ffd86b');
  log('Um portal para a cidade se abriu. A escada leva mais fundo.', '#7ad0ff');
  // Invocados somem
  for (const o of r.monsters) if (o !== m && o.summoned) { o.hp = 0; fx({ type: 'death', x: o.x, y: o.y, color: '#888' }); }
  if (m.type === 'bafome' && r.floor === FIRST_LIFE_FLOOR && !h.victory) {
    S().meta.victories++;
    h.victory = true;
    log('VITÓRIA! Bafomé caiu e o Abismo se cala.', '#ffd86b');
    if (!h.reborn) log(`No nível ${REBIRTH_LV}, a Guilda pode fazer você renascer.`, '#ffd86b');
    fx({ type: 'victory' });
  }
  if (m.type === 'thanatos' && r.floor === LAST_FLOOR && !h.victory2) {
    h.victory2 = true;
    S().meta.victories2 = (S().meta.victories2 || 0) + 1;
    log('VITÓRIA FINAL! Thanatos foi esquecido pela própria torre.', '#ffd86b');
    fx({ type: 'victory' });
  }
  updateView();
  save();
}

// ---------------- IA dos monstros ----------------
function monsterAct(m) {
  const r = run();
  const map = r.map;
  if ((m.status.stun || 0) > 0 || (m.status.freeze || 0) > 0 || (m.status.petrify || 0) > 0) return;
  const px = r.px, py = r.py;
  const d = dist(m.x, m.y, px, py);
  const hidden = hasBuff('oculto');
  const inView = G.fov[m.y * map.w + m.x] === 1;
  let sees = inView && d <= 9 && !hidden;
  if (m.asleep) {
    if (sees && (d <= 2 || chance(25))) { m.asleep = false; m.awake = true; fx({ type: 'text', x: m.x, y: m.y, text: '!', color: '#ffd23f' }); }
    else return;
  }
  if (sees) { m.awake = true; m.tx = px; m.ty = py; }
  if (!m.awake) { if (chance(35)) wander(m); return; }

  // Especiais de chefe
  if (m.boss && sees && bossSpecial(m, d)) return;

  const canMelee = d === 1; // diagonal liberada nas quinas (igual ao herói)
  if (sees && m.range > 1 && d <= m.range && d > 1 && hasLos(map, m.x, m.y, px, py)) {
    if (d <= 2 && chance(35) && stepAway(m)) return;
    rangedAttack(m); return;
  }
  if (sees && canMelee) { meleeAttack(m); return; }
  if (m.ai.includes('erratic') && chance(30)) { wander(m); return; }
  if ((m.status.snare || 0) > 0) return;
  if (sees || (m.tx !== null && G.dmap)) {
    if (sees) stepToward(m);
    else {
      if (m.x === m.tx && m.y === m.ty) { m.tx = null; m.awake = chance(50); return; }
      greedyStep(m, m.tx, m.ty);
    }
  } else wander(m);
}

function canStep(m, nx, ny) {
  const map = run().map;
  if (!passable(tileAt(map, nx, ny)) || occupied(nx, ny)) return false;
  const dx = nx - m.x, dy = ny - m.y;
  return true;
}

function moveMonster(m, nx, ny) {
  fx({ type: 'move', id: m.uid, fx: m.x, fy: m.y });
  m.x = nx; m.y = ny;
}

function stepToward(m) {
  const map = run().map;
  const cur = G.dmap[m.y * map.w + m.x];
  let best = null, bv = cur < 0 ? 9999 : cur;
  for (const [dx, dy] of DIRS8) {
    const nx = m.x + dx, ny = m.y + dy;
    if (!canStep(m, nx, ny)) continue;
    const v = G.dmap[ny * map.w + nx];
    if (v >= 0 && v < bv) { bv = v; best = [nx, ny]; }
  }
  if (best) moveMonster(m, best[0], best[1]);
  else greedyStep(m, run().px, run().py);
}

function stepAway(m) {
  const map = run().map;
  const cur = G.dmap[m.y * map.w + m.x];
  for (const [dx, dy] of DIRS8) {
    const nx = m.x + dx, ny = m.y + dy;
    if (!canStep(m, nx, ny)) continue;
    if (G.dmap[ny * map.w + nx] > cur) { moveMonster(m, nx, ny); return true; }
  }
  return false;
}

function greedyStep(m, tx, ty) {
  let best = null, bd = dist(m.x, m.y, tx, ty);
  for (const [dx, dy] of DIRS8) {
    const nx = m.x + dx, ny = m.y + dy;
    if (!canStep(m, nx, ny)) continue;
    const dd = dist(nx, ny, tx, ty);
    if (dd < bd) { bd = dd; best = [nx, ny]; }
  }
  if (best) moveMonster(m, best[0], best[1]);
}

function wander(m) {
  const opts = DIRS8.filter(([dx, dy]) => canStep(m, m.x + dx, m.y + dy));
  if (opts.length) { const [dx, dy] = pick(opts); moveMonster(m, m.x + dx, m.y + dy); }
}

// Cercado: a partir do 3º monstro acordado a até 2 casas, a esquiva cai 10% por monstro extra (até −80%)
export function crowdPenalty() {
  const r = run(); if (!r) return 0;
  const n = r.monsters.filter((m) => m.hp > 0 && !m.asleep && Math.max(Math.abs(m.x - r.px), Math.abs(m.y - r.py)) <= 2).length;
  return Math.min(0.8, Math.max(0, n - 2) * 0.1);
}
function heroDefense() {
  const d = G.d;
  return { def: d.def, mdef: d.mdef, flee: Math.round(d.flee * (1 - crowdPenalty())), perfectDodge: d.perfectDodge, el: d.armorEl, armorEl: d.armorEl, race: 'humanoide', dmgReduce: d.dmgReduce, redNormal: d.mods.redNormal || 0, redBoss: d.mods.redBoss || 0 };
}

function onHitEffects(m, res) {
  const h = hero();
  const st = h.status;
  // Escudo Petrificante (Mago): quem acerta o mago pode virar pedra

  if (chance(G.d.statusResist)) { if (m.ai.includes('drain')) m.hp = Math.min(m.maxHp, m.hp + Math.floor(res.dmg * 0.5)); return; }
  if (m.ai.includes('poison') && chance(25) && !G.d.mods.poisonImmune && !st.poison) { st.poison = 5; log('Você foi envenenado!', '#b56bff'); }
  if (m.ai.includes('burn') && chance(20) && !st.burn) { st.burn = 3; log('Você está queimando!', '#ff8a3a'); }
  if (m.ai.includes('web') && chance(20)) { st.snare = 2; log('Uma teia te prende!', '#d9c48a'); }
  if (m.ai.includes('stunhit') && chance(15)) { st.stun = 1; log('Você foi atordoado!', '#9ac8ff'); }
  if (m.ai.includes('freezehit') && chance(12) && !G.d.mods.freezeImmune && !st.freeze) { st.freeze = 1; log('Você congelou!', '#9ad8ff'); }
  if (m.ai.includes('drain')) m.hp = Math.min(m.maxHp, m.hp + Math.floor(res.dmg * 0.5));
}

function meleeAttack(m) {
  const r = run();
  fx({ type: 'lunge', id: m.uid, tx: r.px, ty: r.py });
  // Aparar Golpe (Cavaleiro em guarda): o golpe é aparado, o atacante fica aberto e o Cavaleiro ganha Fervor
  if (r.guard) {
    const res = physHit(m, heroDefense(), 1, { sure: true });
    const v = Math.round(res.dmg * (1 - (r.guardPct || 0) / 100));
    fx({ type: 'text', x: r.px, y: r.py, text: 'aparou!', color: '#cfe7ff' });
    fx({ type: 'sfx', name: 'hit' });
    fx({ type: 'burst', x: r.px, y: r.py, color: '#cfe7ff', n: 8 });
    openGuard(m, m.boss ? 4 : 3);
    addFervor(1);
    if (v > 0) damageHero(v, { source: MONSTERS[m.type].name, boss: m.boss });
    return;
  }
  const res = physHit(m, heroDefense());
  const name = MONSTERS[m.type].name;
  // Uivo Gélido (carta do Garm): quem ataca corpo a corpo pode congelar
  if (G.d.mods.frostbite) applyStatus(m, 'freeze', 2, G.d.mods.frostbite);
  if (res.miss) {
    fx({ type: 'text', x: r.px, y: r.py, text: 'errou', color: '#9ab' });
    // Lua Crescente: contra-ataque ao esquivar
    if (G.d.mods.counter && m.hp > 0 && chance(G.d.mods.counter)) {
      const c = physHit(heroAttacker(), m, 0.8, { sure: true });
      fx({ type: 'text', x: r.px, y: r.py, text: 'contra!', color: '#ffd86b', delay: 80 });
      damageMonster(m, c.dmg, { crit: c.crit, delay: 140 });
    }
    return;
  }
  fx({ type: 'sfx', name: 'hurt' });
  damageHero(res.dmg, { crit: res.crit, source: name, boss: m.boss });
  if (hero().hp > 0 && G.d.mods.thorns && m.hp > 0) damageMonster(m, Math.max(1, Math.floor(res.dmg * G.d.mods.thorns / 100)), { color: '#e8a83a', delay: 120 });
  if (hero().hp > 0 && m.hp > 0) onHitEffects(m, res);
}

function rangedAttack(m) {
  const r = run();
  const def = MONSTERS[m.type];
  const name = def.name;
  fx({ type: 'proj', fx: m.x, fy: m.y, tx: r.px, ty: r.py, color: def.proj || '#fff' });
  if (def.magic) {
    const res = magicHit(m, heroDefense(), 1, m.el);
    damageHero(res.dmg, { source: name, delay: 150, boss: m.boss });
  } else {
    const res = physHit(m, heroDefense());
    if (res.miss) { fx({ type: 'text', x: r.px, y: r.py, text: 'errou', color: '#9ab', delay: 150 }); return; }
    damageHero(res.dmg, { crit: res.crit, source: name, boss: m.boss });
    if (hero().hp > 0) onHitEffects(m, res);
  }
}

function bossSpecial(m, d) {
  const r = run();
  const def = MONSTERS[m.type];
  const ai = m.ai;
  if (ai.includes('summon') && m.cd.summon <= 0) {
    const alive = r.monsters.filter((o) => o.summoned && o.hp > 0).length;
    if (alive < 3) {
      m.cd.summon = 14;
      for (let i = 0; i < (def.summonN || 2); i++) {
        const p = freeNear(m.x, m.y, 2);
        if (p) { const s = makeMonster(def.summon, p.x, p.y); s.summoned = true; s.asleep = false; s.awake = true; r.monsters.push(s); fx({ type: 'burst', x: p.x, y: p.y, color: '#c9a6ff', n: 12 }); }
      }
      log(`${def.name} invoca reforços!`, '#ff8a8a');
      return true;
    }
  }
  if (ai.includes('teleport') && m.cd.teleport <= 0 && m.hp < m.maxHp * 0.6 && chance(40)) {
    const p = freeNear(r.px, r.py, 4);
    if (p && dist(p.x, p.y, r.px, r.py) >= 2) {
      m.cd.teleport = 14;
      fx({ type: 'burst', x: m.x, y: m.y, color: '#a37bff', n: 16 });
      m.x = p.x; m.y = p.y;
      fx({ type: 'burst', x: m.x, y: m.y, color: '#a37bff', n: 16 });
      fx({ type: 'move', id: m.uid, fx: m.x, fy: m.y });
      log(`${def.name} se teletransporta!`, '#ff8a8a');
      return true;
    }
  }
  if ((ai.includes('slam') || ai.includes('curse')) && m.cd.slam <= 0 && d <= 2) {
    m.cd.slam = ai.includes('curse') ? 7 : 6;
    const rad = ai.includes('curse') ? 3 : 2;
    const tiles = [];
    for (let y = -rad; y <= rad; y++) for (let x = -rad; x <= rad; x++) if (passable(tileAt(r.map, m.x + x, m.y + y))) tiles.push([m.x + x, m.y + y]);
    r.telegraphs.push({ tiles, at: r.time + 10 * (rad + 1) + 6, from: m.uid, mult: 1.9, kind: 'phys', el: m.el, name: def.name, color: '#ff4a4a' });
    log(`${def.name} se prepara para um golpe devastador! Afaste-se!`, '#ff8a8a');
    fx({ type: 'sfx', name: 'warn' });
    return true;
  }
  if (ai.includes('meteor') && m.cd.meteor <= 0) {
    m.cd.meteor = 8;
    const tiles = [];
    const centers = [[r.px, r.py], [r.px + rnd(-3, 3), r.py + rnd(-3, 3)], [r.px + rnd(-3, 3), r.py + rnd(-3, 3)]];
    for (const [cx, cy] of centers) for (let y = -1; y <= 1; y++) for (let x = -1; x <= 1; x++) {
      if (passable(tileAt(r.map, cx + x, cy + y))) tiles.push([cx + x, cy + y]);
    }
    r.telegraphs.push({ tiles, at: r.time + 14, from: m.uid, mult: 1.6, kind: 'magic', el: m.el, name: def.name, color: '#c43aff', meteor: true });
    log(`${def.name} conjura uma chuva sombria!`, '#ff8a8a');
    fx({ type: 'sfx', name: 'warn' });
    return true;
  }
  return false;
}

function resolveTelegraphs() {
  const r = run();
  if (!r || !r.telegraphs.length) return;
  const now = r.telegraphs.filter((t) => t.at <= r.time);
  if (!now.length) return;
  r.telegraphs = r.telegraphs.filter((t) => t.at > r.time);
  for (const t of now) {
    const src = r.monsters.find((m) => m.uid === t.from && m.hp > 0);
    for (const [x, y] of t.tiles) fx({ type: 'burst', x, y, color: t.color, n: 3 });
    fx({ type: 'shake', power: 8 });
    fx({ type: 'sfx', name: 'boom' });
    if (!src) continue;
    if (t.tiles.some(([x, y]) => x === r.px && y === r.py)) {
      const res = t.kind === 'magic' ? magicHit(src, heroDefense(), t.mult, t.el) : physHit(src, heroDefense(), t.mult, { sure: true });
      // em guarda, o golpe físico do chefe é aparado: menos dano, Abertura longa e 2 de Fervor
      if (r.guard && t.kind !== 'magic') {
        res.dmg = Math.round(res.dmg * (1 - (r.guardPct || 0) * 0.75 / 100));
        fx({ type: 'text', x: r.px, y: r.py, text: 'aparou!', color: '#cfe7ff' });
        openGuard(src, 4);
        addFervor(2);
      }
      damageHero(res.dmg, { source: t.name, crit: true, boss: !!src.boss });
    }
  }
}

// ---------------- Ações do jogador ----------------
function heroAttacker(extra = {}) {
  const d = G.d;
  return { atk: d.atk, matk: d.matk, hit: d.hit, crit: d.crit, critDmg: d.critDmg, el: d.el, raceDmg: d.raceDmg, pierce: d.mods.pierce || 0, execute: d.mods.execute || 0, dmgNormal: d.mods.dmgNormal || 0, dmgBoss: d.mods.dmgBoss || 0, critPierceAll: ['assassino', 'algoz'].includes(hero().cls), ...extra };
}

// ---- Cavaleiro / Lorde: Guarda, Abertura e Fervor ----
// Fervor: recurso do Cavaleiro. Ganha aparando golpes e derrotando monstros; gasta nos golpes fortes.
// Com Fervor de Batalha, cada ponto guardado dá ATQ (Fúria de Batalha no Lorde: mais pontos e mais ATQ).
const KNIGHTS = new Set(['cavaleiro', 'lorde']);
const isKnight = (h = hero()) => KNIGHTS.has(h.cls);
export const fervorMax = () => 5 + (G.d.mods.rageUp ? Math.ceil(G.d.mods.rageUp / 2) : 0);
export function fervorOf(h = hero()) { const b = (h.buffs || []).find((o) => o.id === 'furia'); return b ? b.stacks || 0 : 0; }
function setFervor(h, n) {
  n = Math.max(0, Math.min(fervorMax(), n));
  let b = h.buffs.find((o) => o.id === 'furia');
  if (!n) { if (b) { h.buffs = h.buffs.filter((o) => o !== b); recalc(); } return; }
  const up = G.d.mods.rageUp || 0, per = up ? 5 : G.d.mods.rage ? 2 + G.d.mods.rage * 0.4 : 0;
  if (!b) { b = { id: 'furia', keep: true, turns: 0, stacks: 0, mods: {} }; h.buffs.push(b); }
  b.stacks = n; b.icon = up ? '😡' : '😤'; b.skill = up ? 'furia_batalha' : 'fervor_batalha'; b.name = `${up ? 'Fúria' : 'Fervor'} ×${n}`; b.mods = per ? { atkPct: Math.round(n * per) } : {};
  recalc();
}
function addFervor(n) {
  const h = hero(), r = run();
  if (!isKnight(h) || !r) return;
  const before = fervorOf(h);
  setFervor(h, before + n);
  h.fervorIdle = 0;
  const got = fervorOf(h) - before;
  if (got > 0) {
    if (G.d.mods.rageUp) h.sp = Math.min(G.d.maxSp, h.sp + Math.ceil(G.d.maxSp * 0.005) * got);
  }
}
function spendFervor(n) {
  const h = hero();
  if (!isKnight(h) || fervorOf(h) < n) return false;
  setFervor(h, fervorOf(h) - n);
  h.fervorIdle = 0;
  const r = run();
  fx({ type: 'text', x: r.px, y: r.py, text: `−${n} Fervor`, color: '#ff7a3a' });
  return true;
}
// Abertura: o próximo golpe do herói nesse monstro é crítico garantido
function openGuard(m, turns) {
  if (!m || m.hp <= 0) return;
  const had = (m.status.abertura || 0) > 0;
  m.status.abertura = Math.max(m.status.abertura || 0, turns);
  if (!had) fx({ type: 'text', x: m.x, y: m.y, text: 'abertura!', color: '#ffd23f', delay: 260 });
}
function startGuard(pct) {
  const r = run(), h = hero();
  r.guard = 'new'; r.guardPct = pct;
  h.buffs = h.buffs.filter((b) => b.id !== 'guarda');
  h.buffs.push({ id: 'guarda', keep: true, turns: 1, mods: {}, name: 'Em guarda', skill: 'aparar_golpe', icon: '🛡️' });
  fx({ type: 'text', x: r.px, y: r.py, text: 'em guarda', color: '#cfe7ff', delay: 120 });
  fx({ type: 'ring', x: r.px, y: r.py, r: 1, color: '#cfe7ff' });
}
function endGuard() {
  const r = run(), h = hero();
  r.guard = false;
  h.buffs = h.buffs.filter((b) => b.id !== 'guarda');
}
// turnos de ação do herói até um golpe anunciado cair (1 = cai antes da sua próxima ação)
export function teleTurns(t) { const r = run(); return Math.max(1, Math.ceil((t.at - r.time) * G.d.speed / 1000)); }
function afterHeroHit(m, dmg, magic) {
  // Fúria de Batalha também cresce contra chefes: um acúmulo a cada 3 golpes acertados
  if (G.d.mods.rageUp && m.boss && dmg > 0 && m.hp > 0) { const h = hero(); h.bossHits = (h.bossHits || 0) + 1; if (h.bossHits % 3 === 0) addFervor(1); }
  if (G.d.mods.spOnHit && dmg > 0 && !magic) { const h = hero(); h.sp = Math.min(G.d.maxSp, h.sp + Math.max(1, Math.round(G.d.maxSp * G.d.mods.spOnHit / 100))); }
  if (G.d.lifesteal && dmg > 0) {
    const h = hero();
    h.hp = Math.min(G.d.maxHp, h.hp + Math.max(1, Math.floor(dmg * G.d.lifesteal / 100)));
  }
}

export function canAttack(m) {
  const r = run();
  const d = dist(r.px, r.py, m.x, m.y);
  const range = G.d.range;
  if (d === 0 || d > range) return false;
  if (!visible(m.x, m.y)) return false;
  if (d === 1) return true;
  return hasLos(r.map, r.px, r.py, m.x, m.y);
}

export function attack(m) {
  const r = run();
  const h = hero();
  const d = G.d;
  const ranged = dist(r.px, r.py, m.x, m.y) > 1;
  r.resting = false;
  let bonus = 1;
  if (hasBuff('oculto')) { bonus = 1.5; removeBuff('oculto'); log('Ataque surpresa!', '#c9ccd6'); }
  if (ranged) fx({ type: 'proj', fx: r.px, fy: r.py, tx: m.x, ty: m.y, color: '#f0e2b6', arrow: ['arco', 'besta'].includes(d.wtype) });
  else fx({ type: 'lunge', id: 'hero', tx: m.x, ty: m.y });
  fx({ type: 'face', x: m.x });
  const delay = ranged ? 140 : 60;
  const hits = (d.mods.tripleAtk && chance(d.mods.tripleAtk)) ? 3 : (d.mods.doubleAtk && chance(d.mods.doubleAtk)) ? 2 : 1;
  for (let i = 0; i < hits && m.hp > 0; i++) {
    const open = (m.status.abertura || 0) > 0;
    if (open) { delete m.status.abertura; fx({ type: 'text', x: m.x, y: m.y, text: 'na abertura!', color: '#ffd23f', delay: delay + 60 }); }
    const res = physHit(heroAttacker(), m, bonus * (BASIC_MUL[baseCls(hero().cls)] ?? 1), open ? { critBonus: 100, sure: true } : {});
    if (res.miss) { fx({ type: 'text', x: m.x, y: m.y, text: 'errou', color: '#9ab', delay }); fx({ type: 'sfx', name: 'miss' }); }
    else {
      fx({ type: 'sfx', name: res.crit ? 'crit' : 'hit' });
      if (res.crit) fx({ type: 'shake', power: 3 });
      damageMonster(m, res.dmg, { crit: res.crit, delay: delay + i * 120, el: res.el });
      afterHeroHit(m, res.dmg);
      // Envenenar Arma: dano extra de veneno e chance de envenenar a cada golpe
      if (d.mods.poisonFlat && m.hp > 0) {
        damageMonster(m, d.mods.poisonFlat, { color: '#b56bff', delay: delay + i * 120 + 60, dot: true });
        if (m.hp > 0 && !m.status.poison) applyStatus(m, 'poison', 6, d.mods.poisonChance || 0);
      }
    }
  }
  if (hits > 1) fx({ type: 'text', x: r.px, y: r.py, text: hits === 3 ? 'triplo!' : 'duplo!', color: '#ffd23f' });
  // Combo em Cadeia (Monge/Mestre): emenda um golpe depois dos Punhos Triplos
  if (hits === 3 && d.mods.combo && m.hp > 0 && chance(d.mods.combo)) {
    const lv = oldLv('combo_cadeia', h.skills.combo_cadeia || 1);
    const c = physHit(heroAttacker(), m, 2 + lv * 0.4, { sure: true });
    fx({ type: 'text', x: m.x, y: m.y, text: 'combo!', color: '#ffb84a', delay: 420 });
    damageMonster(m, c.dmg, { crit: c.crit, delay: 480 });
  }
  corrodeWeapon();
  if (d.mods.cleave && !ranged) {
    for (const o of r.monsters) {
      if (o === m || o.hp <= 0 || dist(o.x, o.y, r.px, r.py) !== 1) continue;
      const c = physHit(heroAttacker(), o, d.mods.cleave / 100, { sure: true });
      damageMonster(o, c.dmg, { crit: c.crit, delay: delay + 100 });
    }
  }
  // Falcão
  if (d.mods.falcon && m.hp > 0 && chance(d.mods.falcon * 7)) {
    const s = d.stats;
    const v = Math.round((s.dex + s.int) * 2 * (1 + d.mods.falcon * 0.4) * (0.9 + Math.random() * 0.2));
    fx({ type: 'falcon', fx: r.px, fy: r.py, tx: m.x, ty: m.y });
    damageMonster(m, v, { color: '#ffe8a0', delay: 420 });
    log('Seu falcão ataca!', '#ffe8a0');
  }
  endTurn(100);
}

// Veneno Mortal corrói a arma: 0,5% por golpe de perder 1 de refino
function corrodeWeapon() {
  const h = hero(), w = h.equip.weapon;
  if (!G.d.mods.deadlyPoison || !w || !(w.refine > 0) || !chance(0.5)) return;
  w.refine--;
  recalc();
  log(`As Presas da Víbora corroeram sua arma: ${itemName(w)}.`, '#b56bff');
}

export function move(dx, dy) {
  const r = run();
  if (hero().buffs.some((b) => b.id === 'oculto' && b.still)) { log('Escondido: não dá para andar (ataque, use uma habilidade ou espere).', '#c9ccd6'); return false; }
  const nx = r.px + dx, ny = r.py + dy;
  const map = r.map;
  const m = monsterAt(nx, ny);
  if (m && visible(nx, ny)) {
    if (canAttack(m)) { attack(m); return true; }
    return false;
  }
  if (!passable(tileAt(map, nx, ny))) return false;
  if (m) { // monstro invisível bloqueando
    log('Algo bloqueia o caminho!', '#ff8a8a');
    m.awake = true;
    endTurn(100);
    return false;
  }
  if ((hero().status.snare || 0) > 0) { log('Você está preso!', '#d9c48a'); endTurn(100); return false; }
  fx({ type: 'move', id: 'hero', fx: r.px, fy: r.py, tx: nx, ty: ny });
  if (dx) fx({ type: 'face', x: nx });
  r.px = nx; r.py = ny;
  r.resting = false;
  pickupHere();
  updateView();
  const t = tileAt(map, nx, ny);
  if (t === T.STAIRS) log('Escada para baixo. Toque em "Descer".', '#7ad0ff');
  if (t === T.PORTAL) log('Portal para a cidade. Toque em "Cidade".', '#7ad0ff');
  if (t === T.LIQUID) fx({ type: 'splash', x: nx, y: ny });
  endTurn(100);
  return true;
}

function pickupHere() {
  const r = run();
  const here = r.items.filter((i) => i.x === r.px && i.y === r.py);
  for (const g of here) {
    if (addToInv(g.item)) {
      r.items = r.items.filter((o) => o !== g);
      const q = g.item.qty > 1 ? ` ×${g.item.qty}` : '';
      log(`Pegou ${itemName(g.item)}${q}.`, itemDef(g.item).kind === 'card' ? '#ffd86b' : '#cfe7ff');
      fx({ type: 'sfx', name: 'pickup' });
    } else { log('Mochila cheia!', '#ff8a8a'); break; }
  }
}

export function wait() {
  const r = run();
  r.resting = true;
  endTurn(100);
}

export function rest10() {
  // Descansa até 10 turnos, interrompe se algo acontecer
  const r = run();
  r.interrupted = false;
  for (let i = 0; i < 10; i++) {
    if (visibleMonsters().some((m) => !m.asleep)) { if (i === 0) log('Há inimigos por perto.', '#ff8a8a'); break; }
    wait();
    if (r.interrupted || S().mode !== 'dungeon') break;
    const h = hero();
    if (h.hp >= G.d.maxHp && h.sp >= G.d.maxSp) break;
  }
}

export function descend() {
  const r = run();
  if (tileAt(r.map, r.px, r.py) !== T.STAIRS) return;
  if (r.floor >= FIRST_LIFE_FLOOR && !isTrans()) { log('Uma força impede a passagem. Só os transcendentais descem além do Bafomé.', '#ff8a8a'); return; }
  if (r.floor >= LAST_FLOOR) { log('Não há nada além da Torre do Esquecimento... por enquanto.', '#c9a6ff'); return; }
  goToFloor(r.floor + 1);
  fx({ type: 'sfx', name: 'stairs' });
}

export function usePortal() {
  const r = run();
  if (tileAt(r.map, r.px, r.py) !== T.PORTAL) return;
  returnToTown();
}

// botão Cidade: usa uma Asa de Borboleta se tiver; se não, custa 30% do zeny que está carregando
// em combate = algum monstro acordado com o herói como alvo ou indo atrás dele
export function inCombat() {
  const r = run(); if (!r) return false;
  return r.monsters.some((m) => m.hp > 0 && !m.asleep && m.awake && m.tx !== null && m.tx !== undefined);
}
export function townCost() {
  const h = hero();
  const wing = h.inv.find((i) => i.id === 'asa_borboleta');
  return wing ? { wing: true } : { zeny: Math.floor((h.zeny || 0) * 0.3) };
}
export function recallButton() {
  const h = hero(), c = townCost();
  if (c.wing) { consume(h.inv.find((i) => i.id === 'asa_borboleta')); log('Você usa uma Asa de Borboleta.', '#c9c4b0'); }
  else if (c.zeny > 0) { h.zeny -= c.zeny; log(`Você paga ${c.zeny} zeny para voltar.`, '#ffd86b'); }
  returnToTown();
}

export function returnToTown() {
  const h = hero();
  const meta = S().meta;
  const found = h.zeny;
  meta.zeny += h.zeny;
  h.zeny = 0;
  h.buffs = (h.buffs || []).filter((b) => b.aura);
  h.status = {};
  S().run = null;
  S().mode = 'town';
  recalc();
  h.hp = G.d.maxHp; h.sp = G.d.maxSp;
  S().townLog = [];
  log(`Você volta à cidade em segurança${found ? ` com ${found} zeny` : ''}.`, '#ffe08a');
  fx({ type: 'sfx', name: 'stairs' });
  save();
}

export const POT_CD = 5;   // turnos de recarga das poções
export function useItem(u) {
  const it = findInv(u);
  if (!it) return;
  const d = itemDef(it);
  const h = hero();
  const inTown = S().mode === 'town';
  if (d.kind !== 'use') return;
  if (d.heal && hasBuff('frenesi')) { log('No Frenesi não dá para usar poções!', '#ff8a8a'); return; }
  // recarga das poções na masmorra (HP e SP separadas)
  const pk = d.heal ? 'potHp' : d.sp ? 'potSp' : null;
  if (pk && !inTown && h.cd && h.cd[pk] > 0) { log(`Poção de ${pk === 'potHp' ? 'HP' : 'SP'} em recarga: ${h.cd[pk]} turno${h.cd[pk] > 1 ? 's' : ''}.`, '#ff8a8a'); return; }
  if (pk && !inTown) { h.cd = h.cd || {}; h.cd[pk] = POT_CD; }
  if (d.heal) {
    const v = Math.floor((d.heal + G.d.maxHp * (d.healPct || 0) / 100) * (1 + G.d.stats.vit * 0.01) * (1 + (G.d.mods.healBoost || 0) / 100));
    h.hp = Math.min(G.d.maxHp, h.hp + v);
    if (!inTown) fx({ type: 'heal', x: run().px, y: run().py, val: v });
  }
  if (d.sp) { const v = Math.floor(d.sp + G.d.maxSp * (d.spPct || 0) / 100); h.sp = Math.min(G.d.maxSp, h.sp + v); if (!inTown) fx({ type: 'text', x: run().px, y: run().py, text: `+${v} SP`, color: '#7ab8ff' }); }
  if (d.cure) { delete h.status.poison; delete h.status.burn; log('Você se sente melhor.', '#9fe08a'); }
  if (d.teleport) {
    if (inTown) return;
    const r = run();
    const p = randomFloorTile(r.map, (x, y) => occupied(x, y));
    if (p) {
      fx({ type: 'burst', x: r.px, y: r.py, color: '#c9c4b0', n: 14 });
      r.px = p.x; r.py = p.y;
      fx({ type: 'move', id: 'hero', fx: p.x, fy: p.y, instant: true });
      updateView();
      pickupHere();
      log('Você foi teleportado!', '#c9c4b0');
    }
  }
  if (d.recall) {
    if (inTown) return;
    consume(it);
    returnToTown();
    return;
  }
  fx({ type: 'sfx', name: 'potion' });
  consume(it);
  if (!inTown) endTurn(100);
  else save();
}

export function skillUsable(id) {
  const h = hero();
  const sk = SKILLS[id];
  const l = h.skills[id] || 0;
  if (!l) return { ok: false, why: 'Não aprendida' };
  if (sk.target === 'passive') return { ok: false, why: 'Passiva' };
  if (sk.aura && hasBuff(sk.buffs(l).id)) return { ok: true };
  if (hasBuff('frenesi') && id !== 'frenesi') return { ok: false, why: 'Em Frenesi' };
  if (h.cd && h.cd[id] > 0) return { ok: false, why: `Recarga: ${h.cd[id]} turnos` };
  if (h.sp < (fusionFree(id) ? 0 : sk.sp(l))) return { ok: false, why: 'SP insuficiente' };
  if (sk.needsBow && !['arco', 'besta'].includes(G.d.wtype)) return { ok: false, why: 'Exige arco ou besta' };
  if (sk.zeny && h.zeny < sk.zeny(l)) return { ok: false, why: 'Zeny insuficiente (carregado)' };
  return { ok: true };
}

// Fusão Estelar: os chutes da linhagem Taekwon saem sem SP (custam HP)
const KICKS = new Set(['chute_giratorio', 'chute_machado', 'chute_voador', 'furia_solar']);
function fusionFree(id) { return KICKS.has(id) && hasBuff('fusao'); }

// Ofensiva Furiosa: casa onde o herói aterrissa. Casa livre no alcance; se tocou num monstro, a casa livre ao lado dele mais perto do herói.
export function leapSpot(id, tx, ty) {
  const r = run(), sk = SKILLS[id];
  const ok = (x, y) => (x !== r.px || y !== r.py) && passable(tileAt(r.map, x, y)) && !monsterAt(x, y) && visible(x, y) && dist(r.px, r.py, x, y) <= sk.range && hasLos(r.map, r.px, r.py, x, y);
  if (!monsterAt(tx, ty)) return ok(tx, ty) ? [tx, ty] : null;
  let best = null, bd = 1e9;
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
    const x = tx + dx, y = ty + dy; if ((!dx && !dy) || !ok(x, y)) continue;
    const d = dist(r.px, r.py, x, y) + Math.hypot(dx, dy) * 0.01; if (d < bd) { bd = d; best = [x, y]; }
  }
  return best;
}
export function validSkillTarget(id, tx, ty) {
  const r = run();
  const sk = SKILLS[id];
  if (sk.leap) return !!leapSpot(id, tx, ty);
  const dd = dist(r.px, r.py, tx, ty);
  if (sk.target === 'enemy') {
    const m = monsterAt(tx, ty);
    if (!m || !visible(tx, ty)) return false;
    if (dd > sk.range) return false;
    if (dd > 1 && !hasLos(r.map, r.px, r.py, tx, ty)) return false;
    return true;
  }
  if (sk.target === 'tile') {
    if (!visible(tx, ty) || dd > sk.range) return false;
    return hasLos(r.map, r.px, r.py, tx, ty);
  }
  return true;
}

function areaTargets(cx, cy, rad) {
  const r = run();
  return r.monsters.filter((m) => m.hp > 0 && dist(m.x, m.y, cx, cy) <= rad && (dist(m.x, m.y, cx, cy) === 0 || hasLos(r.map, cx, cy, m.x, m.y)));
}

function knockback(m, n) {
  const r = run();
  if (m.boss) { fx({ type: 'text', x: m.x, y: m.y, text: 'firme', color: '#c8b8a0', delay: 250 }); return; }   // chefes não são empurrados
  const dx = Math.sign(m.x - r.px), dy = Math.sign(m.y - r.py);
  if (!dx && !dy) return;
  for (let i = 0; i < n; i++) {
    const nx = m.x + dx, ny = m.y + dy;
    if (!passable(tileAt(r.map, nx, ny)) || occupied(nx, ny)) break;
    fx({ type: 'move', id: m.uid, fx: m.x, fy: m.y });
    m.x = nx; m.y = ny;
  }
}

function applyStatus(m, key, turns, pctChance) {
  if (m.hp <= 0) return;
  // chefes: o que impede de agir/andar (atordoar, congelar, petrificar, prender) pega com 20% a menos de chance;
  // queimadura é normal; veneno continua difícil (1/3)
  const HOLD = key === 'stun' || key === 'freeze' || key === 'petrify' || key === 'snare';
  const c = !m.boss || key === 'burn' ? pctChance : HOLD ? pctChance * 0.8 : pctChance / 3;
  if (!chance(c)) return;
  m.status[key] = m.boss && key !== 'burn' ? (key === 'freeze' || key === 'petrify' ? turns - 1 : Math.max(1, Math.floor(turns / 2))) : turns; // nos chefes o gelo e a pedra duram o bastante para o combo
  const label = { stun: 'atordoado', freeze: 'congelado', poison: 'envenenado', snare: 'preso', burn: 'queimando', petrify: 'petrificado' }[key];
  fx({ type: 'text', x: m.x, y: m.y, text: label, color: '#9ac8ff', delay: 300 });
}

export function castSkill(id, tx, ty) {
  const r = run();
  const h = hero();
  const sk = SKILLS[id];
  const l = h.skills[id] || 0;
  const u = skillUsable(id);
  if (!u.ok) { log(`${sk.name}: ${u.why}.`, '#ff8a8a'); return false; }
  if (sk.target !== 'self' && !validSkillTarget(id, tx, ty)) { log('Alvo inválido.', '#ff8a8a'); return false; }
  if (sk.leap) [tx, ty] = leapSpot(id, tx, ty);
  // auras: liga/desliga; enquanto ligada, reserva parte do SP máximo
  if (sk.aura) {
    const bid = sk.buffs(l).id;
    if (hasBuff(bid)) { removeBuff(bid); recalc(); log(`${sk.name} desligada.`, '#9ab'); endTurn(100); return true; }
    h.sp -= sk.sp(l);
    const b = sk.buffs(l);
    h.buffs.push({ id: bid, skill: id, turns: 1, aura: sk.aura, mods: b.mods, name: sk.name, icon: sk.icon });
    recalc();
    h.sp = Math.min(h.sp, G.d.maxSp);
    fx({ type: 'cast', x: r.px, y: r.py, color: '#9ac8ff', icon: sk.icon });
    fx({ type: 'skillfx', id, fx: r.px, fy: r.py, tx: r.px, ty: r.py });
    fx({ type: 'sfx', name: 'skill' });
    log(`${sk.name} ligada (reserva ${sk.aura}% do SP).`, '#9ac8ff');
    endTurn(100);
    return true;
  }
  const free = fusionFree(id);
  const spent = free ? 0 : sk.allSp ? Math.max(sk.sp(l), Math.floor(h.sp)) : sk.sp(l);
  h.sp -= spent;
  r.resting = false;
  if (free) { const c = Math.max(1, Math.floor(G.d.maxHp * 0.01)); h.hp = Math.max(1, h.hp - c); fx({ type: 'text', x: r.px, y: r.py, text: `-${c}`, color: '#ff9a3a' }); }
  if (sk.cooldown) { h.cd = h.cd || {}; h.cd[id] = sk.cooldown(l); }
  if (sk.noRegen) h.status.noSpRegen = sk.noRegen;
  // Zen: recupera SP na hora e acende as esferas
  if (sk.restoreSp) {
    const v = Math.floor(G.d.maxSp * sk.restoreSp(l));
    h.sp = Math.min(G.d.maxSp, h.sp + v);
    delete h.status.noSpRegen;
    fx({ type: 'text', x: r.px, y: r.py, text: `+${v} SP`, color: '#7ab8ff' });
    const es = h.skills.esferas_espirituais;
    if (es && !hasBuff('esferas')) { const b = SKILLS.esferas_espirituais.buffs(es); h.buffs.push({ id: b.id, turns: 1, aura: SKILLS.esferas_espirituais.aura, mods: b.mods, name: SKILLS.esferas_espirituais.name, icon: SKILLS.esferas_espirituais.icon }); recalc(); }
    log('Zen: a mente se acalma e o espírito volta.', '#9ac8ff');
  }
  if (sk.zeny) { h.zeny -= sk.zeny(l); fx({ type: 'text', x: r.px, y: r.py, text: `-${sk.zeny(l)}z`, color: '#ffd86b' }); }
  fx({ type: 'cast', x: r.px, y: r.py, color: ELEMENTS[sk.el || 'neutro'].color, icon: sk.icon });
  // magia em área: o efeito cai em cada monstro da área (e em alguns pontos vazios), um pouco desencontrado;
  // cada monstro leva o dano no instante em que o efeito dele acerta
  let spots = null; const spotDelay = new Map();
  if (sk.target === 'tile' && sk.aoe && FX_META[id] && !FX_META[id].self && !ONE_FX.has(id)) {
    const mons = areaTargets(tx, ty, sk.aoe).filter((m) => m.x !== tx || m.y !== ty);
    const free = [];
    for (let y = -sk.aoe; y <= sk.aoe; y++) for (let x = -sk.aoe; x <= sk.aoe; x++) {
      const X = tx + x, Y = ty + y;
      if ((x || y) && passable(tileAt(r.map, X, Y)) && !mons.some((m) => m.x === X && m.y === Y)) free.push([X, Y]);
    }
    for (let i = free.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [free[i], free[j]] = [free[j], free[i]]; }
    const tiles = mons.map((m) => [m.x, m.y]).sort(() => Math.random() - 0.5).concat(free.slice(0, Math.max(0, (AOE_EXTRA[id] ?? 3) - mons.length)));
    spots = tiles.map(([x, y], i) => ({ x, y, d: 60 + i * 75 + Math.floor(Math.random() * 40) }));
    for (const sp of spots) spotDelay.set(sp.x + ',' + sp.y, sp.d);
  }
  fx({ type: 'skillfx', id, fx: r.px, fy: r.py, tx: tx ?? r.px, ty: ty ?? r.py, aoe: sk.target === 'tile' ? sk.aoe || 0 : 0, spots, leap: !!sk.leap });
  // salto: o herói decola, voa e aterrissa na casa escolhida (o jogo já o considera lá; a animação mostra o voo)
  if (sk.leap) {
    const M = FX_META[id], ms = (M && M.ms) || 60;
    fx({ type: 'move', id: 'hero', fx: r.px, fy: r.py, tx, ty, leap: { wait: 3 * ms, dur: ((M && M.hit) || 11) * ms } });
    r.px = tx; r.py = ty; r.resting = false;
    updateView();
  }
  const hitMs = FX_META[id] && FX_META[id].hit ? Math.min(900, FX_META[id].hit * (FX_META[id].ms || 60)) : 0;
  castDelay = hitMs;
  fx({ type: 'sfx', name: sk.kind === 'magic' ? 'magic' : 'skill' });
  if (tx !== undefined && tx !== r.px) fx({ type: 'face', x: tx });

  // Cura
  if (sk.heal) {
    const v = Math.floor(sk.heal(l, h, G.d.stats) * (1 + (G.d.mods.healBoost || 0) / 100));
    h.hp = Math.min(G.d.maxHp, h.hp + v);
    fx({ type: 'heal', x: r.px, y: r.py, val: v });
  }
  // Aparar Golpe: guarda até a próxima ação
  if (sk.guard) { startGuard(sk.guardPct(l)); log('Em guarda!', '#cfe7ff'); }
  // Buffs
  if (sk.buffs) {
    const b = sk.buffs(l);
    const buff = { id: b.id, skill: id, turns: b.turns, mods: b.mods, name: sk.name, icon: sk.icon };
    if (b.shieldPct) buff.shield = Math.floor(G.d.maxHp * b.shieldPct);
    if (b.blockHits) { buff.hits = b.blockHits; buff.blockPct = b.blockPct; }
    h.buffs = h.buffs.filter((o) => o.id !== b.id);
    const oldMax = G.d.maxHp;
    h.buffs.push(buff);
    recalc();
    if (b.id === 'frenesi') h.hp = Math.min(G.d.maxHp, h.hp + Math.max(0, G.d.maxHp - oldMax)); // o HP extra já vem cheio
    log(`${sk.name}!`, '#9ac8ff');
    if (b.id === 'oculto') fx({ type: 'burst', x: r.px, y: r.py, color: '#3a3f4a', n: 14 });
    if (b.still) { buff.still = true; for (const m of r.monsters) if (m.hp > 0 && !m.boss) { m.awake = false; m.tx = null; m.ty = null; } }   // Esconderijo: os monstros te esquecem
  }
  const ambush = sk.ambush && hasBuff('oculto');   // Garra Sombria: golpe surpresa invisível (+50%), depois revela
  if (ambush) log('Ataque surpresa!', '#c9ccd6');
  if (!sk.keepHidden && sk.kind && hasBuff('oculto')) removeBuff('oculto');

  // Campo Gravitacional
  if (sk.kind === 'field') {
    const f = sk.field(l);
    r.fields = r.fields || [];
    r.fields.push({ x: tx, y: ty, rad: sk.aoe, turns: f.turns, mult: f.mult });
    fx({ type: 'ring', x: tx, y: ty, r: sk.aoe, color: '#a37bff' });
    fx({ type: 'shake', power: 4 });
    log(`${sk.name}!`, '#c9a6ff');
  }
  // Ataque do Falcão: ignora esquiva e DEF
  if (sk.kind === 'falcon') {
    const m = monsterAt(tx, ty);
    if (m) {
      const st = G.d.stats;
      const v = Math.round((st.dex * 3 + st.int * 2 + h.lv * 2) * (0.8 + l * 0.4) * (0.9 + Math.random() * 0.2));
      fx({ type: 'falcon', fx: r.px, fy: r.py, tx, ty, big: true });
      damageMonster(m, v, { color: '#ffe8a0', delay: 420 });
    }
  }
  // Ofensivas
  if (sk.kind === 'phys' || sk.kind === 'magic' || sk.kind === 'field') fx({ type: 'vfx', id, fx: r.px, fy: r.py, tx: tx ?? r.px, ty: ty ?? r.py, aoe: sk.aoe || 0, line: !!sk.line, range: sk.range || 0 });
  if (sk.kind === 'phys' || sk.kind === 'magic') {
    let targets = [];
    if (sk.target === 'self') targets = areaTargets(r.px, r.py, sk.aoe);
    else if (sk.line) {
      const pts = lineTiles(r.px, r.py, tx + (tx - r.px) * 3, ty + (ty - r.py) * 3).slice(1, sk.range + 1);
      for (const [x, y] of pts) {
        if (!passable(tileAt(r.map, x, y))) break;
        const m = monsterAt(x, y);
        if (m) targets.push(m);
      }
    } else if (sk.aoe) targets = areaTargets(tx, ty, sk.aoe);
    else { const m = monsterAt(tx, ty); if (m) targets = [m]; }

    if (sk.target === 'tile' || (sk.target === 'enemy' && sk.aoe)) {
      for (let y = -sk.aoe; y <= sk.aoe; y++) for (let x = -sk.aoe; x <= sk.aoe; x++) {
        if (passable(tileAt(r.map, tx + x, ty + y))) fx({ type: 'burst', x: tx + x, y: ty + y, color: ELEMENTS[sk.el || 'neutro'].color, n: 4, delay: 120 });
      }
      fx({ type: 'shake', power: sk.leap ? 8 : 5, delay: 150 });
      if (sk.leap) for (const m of r.monsters) if (m.hp > 0 && dist(m.x, m.y, tx, ty) <= 2) fx({ type: 'quake', id: m.uid, delay: 120 + dist(m.x, m.y, tx, ty) * 50 });
    } else if (sk.target === 'self' && sk.aoe) {
      fx({ type: 'ring', x: r.px, y: r.py, r: sk.aoe, color: ELEMENTS[sk.el || 'neutro'].color });
      fx({ type: 'shake', power: 4 });
    } else if (sk.proj) {
      fx({ type: 'proj', fx: r.px, fy: r.py, tx, ty, color: sk.proj, big: true, skill: id });
    } else if (sk.target === 'enemy') fx({ type: 'lunge', id: 'hero', tx, ty });

    const hits = sk.hits || 1;
    // Fervor (Cavaleiro): o Redemoinho só gasta se pegar 2+ monstros ou um chefe; os outros gastam sempre que der
    const uniq = [...new Set(targets)];
    const fervorUse = sk.fervor && uniq.length && (id !== 'redemoinho' || uniq.length >= 2 || uniq.some((m) => m.boss)) && spendFervor(sk.fervor);
    if (fervorUse && sk.leap) startGuard(h.skills.aparar_golpe ? SKILLS.aparar_golpe.guardPct(h.skills.aparar_golpe) : 40);
    const echo = sk.kind === 'magic' && G.d.mods.echo && chance(G.d.mods.echo);
    if (echo) { targets = targets.concat(targets); fx({ type: 'text', x: r.px, y: r.py, text: 'eco!', color: '#c47aff', delay: 250 }); }
    for (const m of targets) {
      castDelay = hitMs + (spotDelay.get(m.x + ',' + m.y) || 0);
      let res;
      const frozen = (m.status.freeze || 0) > 0;
      const stone = (m.status.petrify || 0) > 0;
      const grav = (m.status.gravity || 0) > 0;   // dentro do Campo Gravitacional os combos pegam mais fácil
      let mult = sk.mult(l, spent);
      if (sk.weightBonus) mult += 0.25 * (h.equip.weapon ? itemDef(h.equip.weapon).tier || 1 : 0);
      if (sk.poisonBonus && (m.status.poison || 0) > 0) mult *= 1 + sk.poisonBonus / 100;
      if (sk.crowdBonus) mult *= 1 + Math.min(sk.crowdBonus * 5, sk.crowdBonus * (new Set(targets).size - 1)) / 100;
      // dano base fixo da habilidade (forte quando é nova, perde peso conforme o herói cresce)
      const baseAdd = sk.base ? sk.base(l) / Math.max(0.01, mult) : 0;
      const atkOver = { atk: (sk.useDex ? G.d.dexAtk : sk.agiBonus ? G.d.atk + G.d.stats.agi * 2 : G.d.atk) + baseAdd };
      const open = sk.kind === 'phys' && (m.status.abertura || 0) > 0;
      if (open) { delete m.status.abertura; fx({ type: 'text', x: m.x, y: m.y, text: 'na abertura!', color: '#ffd23f', delay: 180 }); }
      const pierceAll = sk.ignoreDef || (open && sk.openPierce) || (fervorUse && id === 'perfuracao_espiral');
      if (sk.kind === 'magic') res = magicHit(heroAttacker({ matk: (sk.hybrid ? Math.max(G.d.matk, Math.floor(G.d.atk * 0.6)) : G.d.matk) + baseAdd }), m, mult, sk.el);
      else res = physHit(heroAttacker({ ...(sk.el ? { el: sk.el } : {}), ...atkOver }), m, mult, { el: sk.el, critBonus: (sk.critBonus || 0) + (open ? 100 : 0), sure: open || sk.sureHit || sk.target !== 'enemy' || hits > 2, ignoreDef: pierceAll, defPierce: sk.defPierce });
      if (res.miss) { fx({ type: 'text', x: m.x, y: m.y, text: 'errou', color: '#9ab', delay: 150 }); continue; }
      let dmg = res.dmg + (sk.flat ? sk.flat(l) : 0);
      if (ambush) dmg = Math.round(dmg * 1.5);
      if (open && sk.openMul) dmg *= sk.openMul;
      if (fervorUse && id === 'redemoinho') dmg *= 1.3;
      if (fervorUse && id === 'perfuracao_espiral') dmg *= 2;
      const burning = (m.status.burn || 0) > 0;
      if (frozen && sk.el === 'vento') { dmg *= 6; delete m.status.freeze; fx({ type: 'text', x: m.x, y: m.y, text: 'estilhaçou!', color: '#b9fff0', delay: 200 }); fx({ type: 'burst', x: m.x, y: m.y, color: '#cfefff', n: 14 }); }
      else if (frozen && sk.el === 'fogo') delete m.status.freeze; // o fogo derrete o gelo
      if (stone && sk.el === 'fogo') { dmg *= 10; delete m.status.petrify; fx({ type: 'text', x: m.x, y: m.y, text: 'rachou!', color: '#ffb36b', delay: 200 }); fx({ type: 'burst', x: m.x, y: m.y, color: '#c8a878', n: 14 }); }
      // gelo/água em quem está queimando: choque térmico (vapor)
      else if (burning && sk.el === 'agua' && !frozen) { dmg *= 5.5; delete m.status.burn; fx({ type: 'text', x: m.x, y: m.y, text: 'vapor!', color: '#cfefff', delay: 200 }); fx({ type: 'burst', x: m.x, y: m.y, color: '#e8f4ff', n: 14 }); }
      dmg = Math.round(dmg);
      const parts = [];
      let left = dmg;
      for (let i = 0; i < hits; i++) { const p = i === hits - 1 ? left : Math.floor(dmg / hits); parts.push(p); left -= p; }
      killSrc = sk.kind === 'magic' ? 'magic' : null;
      parts.forEach((p, i) => { if (m.hp > 0) damageMonster(m, p, { crit: res.crit, delay: 150 + i * 70, el: res.el }); });
      killSrc = null;
      afterHeroHit(m, dmg, sk.kind === 'magic');
      if (m.hp > 0) {
        if (sk.stun) applyStatus(m, 'stun', 2, sk.stun(l));
        if (fervorUse && id === 'redemoinho') applyStatus(m, 'stun', 2, 100);
        if (sk.openOnStun && (m.status.stun || 0) > 0) openGuard(m, 3);
        if (sk.freeze) applyStatus(m, 'freeze', 5, burning && sk.el === 'agua' ? (grav ? 95 : 90) : sk.freeze(l));   // gelo em quem queimava: congela quase certo
        if (sk.poison) applyStatus(m, 'poison', 6, sk.poison(l));
        if (sk.burn) applyStatus(m, 'burn', 4, sk.burn(l));
        else if (sk.el === 'fogo') applyStatus(m, 'burn', stone ? 6 : 4, stone ? (grav ? 95 : 85) : 25);   // fogo tem chance de deixar queimando (bem maior e mais longo na pedra rachada)
        if (sk.knock) knockback(m, sk.knock);
      }
    }
    if (!targets.length) log('Nenhum alvo atingido.', '#9ab');
    if (id === 'chute_voador') { h.buffs = h.buffs.filter((b) => b.id !== 'voo'); h.buffs.push({ id: 'voo', turns: 3, mods: { flee: 15 }, name: 'Aterrissagem', icon: '🦵' }); recalc(); } // esquiva ao chegar
    if (sk.kind === 'phys') corrodeWeapon();
  }
  if (sk.kind === 'curse') { // Maldição de Pedra
    const m = monsterAt(tx, ty);
    if (m) {
      fx({ type: 'proj', fx: r.px, fy: r.py, tx, ty, color: sk.proj });
      const before = m.status.petrify || 0;
      applyStatus(m, 'petrify', 4, sk.petrify(l));
      if (!(m.status.petrify > before)) fx({ type: 'text', x: m.x, y: m.y, text: 'resistiu', color: '#9ab', delay: 300 });
      m.awake = true;
    }
  }
  if (sk.kind === 'petrifyArea') {   // Olhar da Medusa
    for (const m of areaTargets(tx, ty, sk.aoe)) {
      const before = m.status.petrify || 0;
      applyStatus(m, 'petrify', 6, (m.status.gravity || 0) > 0 ? Math.max(95, sk.petrify(l)) : sk.petrify(l));
      if (!(m.status.petrify > before)) fx({ type: 'text', x: m.x, y: m.y, text: 'resistiu', color: '#9ab', delay: 300 });
      m.awake = true;
    }
  }
  if (sk.kind === 'status') {
    const m = monsterAt(tx, ty);
    if (m) {
      fx({ type: 'proj', fx: r.px, fy: r.py, tx, ty, color: sk.proj });
      applyStatus(m, 'snare', sk.snare(l), 100);
      m.awake = true;
    }
  }
  if (sk.kind === 'steal') {
    const m = monsterAt(tx, ty);
    fx({ type: 'lunge', id: 'hero', tx, ty });
    if (m.stolen) log('Não há mais nada para roubar.', '#9ab');
    else {
      const c = 15 + l * 7 + (G.d.stats.dex - m.lv) / 2;
      if (chance(c)) {
        m.stolen = true;
        if (chance(55)) {
          const z = Math.round(m.lv * rnd(6, 14) * (1 + (G.d.mods.zenyPct || 0) / 100));
          h.zeny += z;
          fx({ type: 'text', x: m.x, y: m.y, text: `+${z}z`, color: '#ffd86b' });
          log(`Roubou ${z} zeny!`, '#ffd86b');
        } else {
          const it = chance(4) ? makeCard(m.type) : randomLoot(r.floor);
          if (!addToInv(it)) r.items.push({ x: r.px, y: r.py, item: it });
          log(`Roubou ${itemName(it)}!`, '#ffd86b');
        }
        fx({ type: 'sfx', name: 'pickup' });
      } else log('O furto falhou.', '#9ab');
      m.awake = true; m.asleep = false;
    }
  }
  // tempo de conjuração próprio de cada magia (1 = um turno normal)
  // Faraó: encurta só o tempo EXTRA de conjuração (magias de 1 turno não mudam)
  // DES e a carta do Faraó encurtam só o tempo EXTRA de conjuração (magias de 1 turno não mudam)
  const cast = sk.cast || 1;
  const quick = Math.min(60, (G.d.mods.castSpeed || 0) + G.d.stats.dex * 0.35);
  castDelay = 0;
  const cost = Math.round(100 * (Math.min(1, cast) + Math.max(0, cast - 1) * (1 - quick / 100)));
  const wait = animWait && (sk.kind === 'phys' || sk.kind === 'magic') && hitMs ? Math.min(1200, hitMs + Math.max(0, ...[...spotDelay.values()]) + 160) : 0;
  if (wait) {
    lockUntil = Date.now() + wait;
    setTimeout(() => { lockUntil = 0; if (S().mode === 'dungeon' && run()) { endTurn(cost); if (onDeferredTurn) onDeferredTurn(); } }, wait);
  } else endTurn(cost);
  return true;
}

// ---------------- Cidade ----------------
export const potUnlocked = (id, h = hero()) => !ITEMS[id] || !ITEMS[id].unlock || Math.max(h?.potTier || 0, ...(h?.bosses || [])) >= ITEMS[id].unlock;
export function buy(id) {
  const meta = S().meta;
  if (!potUnlocked(id)) return `Liberada depois do chefe do andar ${ITEMS[id].unlock}.`;
  const it = makeItem(id);
  const p = buyPrice(it, G.d);
  if (meta.zeny < p) return 'Zeny insuficiente.';
  if (!addToInv(it)) return 'Mochila cheia.';
  meta.zeny -= p;
  fx({ type: 'sfx', name: 'coin' });
  save();
  return null;
}

export function shopGear() {
  // Estoque de equipamentos muda conforme o progresso do herói
  const h = hero();
  // acompanha o andar mais fundo, mas um tier atrás e sempre o básico: sem slots e sem refino
  const t = clamp(Math.ceil((h.deepest || 1) / 5) - 1, 1, MAX_TIER);
  return SHOP_GEAR.map((id) => ({ id, tier: ITEMS[id].tier })).filter((g) => g.tier <= Math.max(2, t))
    .concat(Object.keys(ITEMS).filter((k) => ['weapon', 'armor', 'head', 'shield'].includes(ITEMS[k].kind) && ITEMS[k].tier === t && t > 1 && !SHOP_GEAR.includes(k)).map((id) => ({ id, tier: t })));
}

export function sell(u) {
  const it = findInv(u);
  if (!it) return;
  const p = sellPrice(it, G.d) * (it.qty || 1);
  hero().inv = hero().inv.filter((o) => o !== it);
  S().meta.zeny += p;
  fx({ type: 'sfx', name: 'coin' });
  save();
  return p;
}

export function deposit(u) {
  const it = findInv(u);
  const st = S().meta.storage;
  if (!it) return;
  if (isStack(it)) {
    const ex = st.find((o) => o.id === it.id);
    if (ex) { ex.qty += it.qty; hero().inv = hero().inv.filter((o) => o !== it); save(); return; }
  }
  if (st.length >= storageCap()) return 'Armazém cheio.';
  hero().inv = hero().inv.filter((o) => o !== it);
  st.push(it);
  save();
}

export function withdraw(u) {
  const st = S().meta.storage;
  const it = st.find((o) => o.uid === u);
  if (!it) return;
  if (!addToInv(it)) return 'Mochila cheia.';
  S().meta.storage = st.filter((o) => o !== it);
  save();
}

export function refineInfo(it) {
  const d = itemDef(it);
  if (!['weapon', 'armor', 'head', 'shield'].includes(d.kind)) return null;
  const r = it.refine || 0;
  if (r >= 10) return { max: true };
  const rate = Math.min(100, REFINE_RATES[r] + (G.d.mods.refineBonus || 0) + (REFINE_RATES[r] < 100 ? G.d.refineLuck : 0));
  const cost = (r + 1) * 120 * (d.tier || 1);
  return { rate, cost, safe: REFINE_RATES[r] >= 100, next: r + 1 };
}

export function refine(u, where, useHammer = false) {
  const h = hero();
  const it = where === 'equip' ? Object.values(h.equip).find((e) => e && e.uid === u) : findInv(u);
  if (!it) return { msg: 'Item não encontrado.' };
  const info = refineInfo(it);
  if (!info || info.max) return { msg: 'Não pode ser refinado.' };
  const frag = h.inv.find((o) => o.id === 'fragmento');
  if (!frag) return { msg: 'Você precisa de um Fragmento Rúnico.' };
  if (S().meta.zeny < info.cost) return { msg: 'Zeny insuficiente.' };
  S().meta.zeny -= info.cost;
  consume(frag);
  // Martelo Abençoado: o jogador escolhe usar; é gasto na tentativa, dando certo ou não (só em refino arriscado)
  const hammer = useHammer && !info.safe && (S().meta.safeRefine || 0) > 0;
  if (hammer) S().meta.safeRefine--;
  if (chance(info.rate)) {
    it.refine = (it.refine || 0) + 1;
    recalc();
    fx({ type: 'sfx', name: 'refineok' });
    save();
    return { ok: true, msg: `Sucesso! ${itemName(it)}` };
  }
  // Falha: o Martelo Abençoado (se foi usado) protege o item
  if (hammer) {
    fx({ type: 'sfx', name: 'refinefail' });
    save();
    return { ok: false, msg: `O refino falhou, mas o Martelo Abençoado protegeu ${itemName(it)}.` };
  }
  // Falha: o item se quebra
  for (const k of Object.keys(h.equip)) if (h.equip[k] === it) h.equip[k] = null;
  h.inv = h.inv.filter((o) => o !== it);
  recalc();
  fx({ type: 'sfx', name: 'refinefail' });
  save();
  return { ok: false, msg: `O refino falhou... ${itemName(it)} se quebrou.` };
}

export function veteranUnlocked() { return (S().roster || []).some((h) => h.lv >= 25) || (S().meta.bestLevel || 0) >= 25; }
export function buyBoost(k) {
  const h = hero(), meta = S().meta, B = BOOSTS[k];
  const p = B.price(h.lv);
  if (meta.zeny < p) return 'Zeny insuficiente.';
  meta.zeny -= p;
  h.boosts = h.boosts || {};
  h.boosts[k] = (h.boosts[k] || 0) + B.kills;
  fx({ type: 'sfx', name: 'levelup' });
  save();
  return null;
}
export const SAFE_REFINE_PRICE = 6000;
export function buySafeRefine() {
  const meta = S().meta;
  if (meta.zeny < SAFE_REFINE_PRICE) return 'Zeny insuficiente.';
  meta.zeny -= SAFE_REFINE_PRICE;
  meta.safeRefine = (meta.safeRefine || 0) + 1;
  save();
  return null;
}
export const resetSkillsCost = () => 800 + hero().lv * 200;
export function resetSkills() {
  const h = hero(), c = resetSkillsCost();
  if (S().meta.zeny < c) return 'Zeny insuficiente.';
  S().meta.zeny -= c;
  let pts = 0;
  for (const l of Object.values(h.skills)) pts += l;
  h.skills = {}; h.bar = Array(BAR_N).fill(null);
  h.buffs = (h.buffs || []).filter((b) => !b.aura);
  h.skillPts += pts;
  recalc();
  save();
  return null;
}
export const RENAME_PRICE = 1000;
export function renameHero(name) {
  name = String(name || '').trim().slice(0, 16);
  if (!name) return 'Nome inválido.';
  if (S().meta.zeny < RENAME_PRICE) return 'Zeny insuficiente.';
  S().meta.zeny -= RENAME_PRICE;
  hero().name = name;
  save();
  return null;
}

export function buyLegacy(key) {
  const meta = S().meta;
  const lv = meta.legacy[key] || 0;
  if (lv >= LEGACY[key].max) return 'Nível máximo.';
  if (key === 'veterano' && !veteranUnlocked()) return 'Exige um personagem nível 25 ou mais.';
  const c = legacyCost(key, lv);
  if (meta.zeny < c) return 'Zeny insuficiente.';
  meta.zeny -= c;
  meta.legacy[key] = lv + 1;
  recalc();
  if (hero()) { hero().hp = G.d.maxHp; hero().sp = G.d.maxSp; }
  fx({ type: 'sfx', name: 'levelup' });
  save();
  return null;
}

export function resetStatsCost() {
  return 500 + hero().lv * 150;
}

export function resetStats() {
  const h = hero();
  const c = resetStatsCost();
  if (S().meta.zeny < c) return 'Zeny insuficiente.';
  S().meta.zeny -= c;
  let pts = 0;
  for (const k of STATS) {
    for (let v = 1; v < h.base[k]; v++) pts += statCost(v);
    h.base[k] = 1;
  }
  h.statPts += pts;
  recalc();
  save();
  return null;
}

// ---------------- Salvamento ----------------
export function save() {
  try {
    const s = { ...G.state, hero: undefined }; // o herói ativo já está dentro de roster
    localStorage.setItem(SAVE_KEY, JSON.stringify(s));
  } catch (e) { console.warn('save falhou', e); }
}

export function load() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return false;
    G.state = JSON.parse(raw);
    // vários personagens: o herói ativo é uma referência dentro de roster
    if (!G.state.roster) {
      G.state.roster = G.state.hero && G.state.mode !== 'dead' ? [G.state.hero] : [];
      G.state.active = G.state.roster.length ? 0 : -1;
      if (G.state.mode === 'dead') { G.state.mode = 'title'; G.state.hero = null; }
    }
    G.state.hero = G.state.active >= 0 ? G.state.roster[G.state.active] || null : (G.state.mode === 'dead' && G.state.lastDeath?.hardcore ? G.state.hero || null : null);
    if (!G.state.hero && (G.state.mode === 'town' || G.state.mode === 'dungeon')) { G.state.mode = 'title'; G.state.run = null; }
    let maxU = 0;
    const scan = (o) => { if (o && typeof o === 'object') { if (typeof o.uid === 'number' && o.uid > maxU) maxU = o.uid; for (const v of Object.values(o)) scan(v); } };
    scan(G.state.roster); scan(G.state.meta); scan(G.state.run?.monsters); scan(G.state.run?.items);
    setUidFloor(maxU + 1);
    const MIG = { sacerdote: 'monge', mercador: 'ninja', ferreiro: 'shinobi' };
    if (G.state.hero && MIG[G.state.hero.cls]) G.state.hero.cls = MIG[G.state.hero.cls];
    if (G.state.hero && !G.state.hero.clsHistory) {
      const lin = lineage(G.state.hero.cls);
      G.state.hero.clsHistory = lin.map((c, i) => ({ cls: c, since: i === 0 ? 1 : CLASS_LV[i] }));
    }
    // Santuário antigo (bênçãos de poder): devolve o zeny gasto
    const lg = G.state.meta.legacy || {};
    if (!G.state.meta.legacyV2) {
      const OLD = { vida: 250, mente: 250, talento: 400, fortuna: 300 };
      let back = 0;
      for (const [k, base] of Object.entries(OLD)) { for (let l = 0; l < (lg[k] || 0); l++) back += Math.floor(base * Math.pow(l + 1, 2)); delete lg[k]; }
      G.state.meta.zeny += back;
      if (back) G.state.meta.legacyRefund = back;
      G.state.meta.legacyV2 = true;
    }
    // habilidades que saíram da árvore da classe: devolve os pontos
    // equipamento antigo -> 6 espaços; cartas que mudaram de espaço voltam para o armazém
    const fixCards = (it) => {
      if (!it || !it.cards || !it.cards.length) return;
      const kind = itemDef(it).kind;
      const keep = [];
      for (const c of it.cards) { if (MONSTERS[c]?.card?.slot === kind) keep.push(c); else G.state.meta.storage.push(makeCard(c)); }
      it.cards = keep;
    };
    for (const hh of G.state.roster || []) {
      const e = hh.equip || {};
      if ('acc' in e) { e.acc1 = e.acc1 || e.acc; delete e.acc; }
      for (const k of SLOTS) if (!(k in e)) e[k] = null;
      hh.equip = e;
      for (const it of [...Object.values(e), ...(hh.inv || [])]) fixCards(it);
    }
    for (const it of G.state.meta.storage || []) fixCards(it);
    for (const hh of G.state.roster || []) {
    if (MIG[hh.cls]) hh.cls = MIG[hh.cls];
    hh.bar = hh.bar || []; while (hh.bar.length < BAR_N) hh.bar.push(null);
    if (!hh.bosses) { hh.bosses = []; for (let f = 5; f < (hh.checkpoint || 1); f += 5) hh.bosses.push(f); }
    if (hh.potTier === undefined) hh.potTier = Math.max(hh.reborn ? 25 : 0, ...hh.bosses);
    // níveis máximos menores: converte o nível antigo e devolve a diferença em pontos
    if (!hh.skillRemap) {
      for (const [id, L] of Object.entries(hh.skills || {})) { if (!SKILL_OLD_MAX[id] || !L) continue; const n = newLvFromOld(id, L); hh.skillPts = (hh.skillPts || 0) + (L - n); hh.skills[id] = n; }
      hh.skillRemap = 1;
    }
    {
      const allowed = new Set(lineage(hh.cls).flatMap((c) => CLASSES[c].skills));
      for (const [id, l] of Object.entries(hh.skills || {})) {
        if (!allowed.has(id)) { hh.skillPts += l; delete hh.skills[id]; hh.bar = hh.bar.map((b) => (b === id ? null : b)); hh.buffs = (hh.buffs || []).filter((b) => b.id !== SKILLS[id]?.buffs?.(1)?.id); }
      }
    }
    }
    recalc();
    if (G.state.mode === 'dungeon' && G.state.run) updateView();
    return true;
  } catch (e) {
    console.warn('load falhou', e);
    return false;
  }
}

export function wipeSave() {
  localStorage.removeItem(SAVE_KEY);
  newState();
}

// ---------------- Menu de desenvolvedor ----------------
export const Dev = {
  goFloor(f) {
    f = Math.max(1, Math.min(99, f | 0));
    hero().checkpoint = Math.max(hero().checkpoint || 1, f);
    if (S().mode === 'dungeon') { hero().status = {}; goToFloor(f); } else enterDungeon(f);
  },
  setLevel(lv) {
    const h = hero();
    lv = Math.max(1, Math.min(99, lv | 0));
    if (S().mode !== 'dungeon') { // addXp mostra efeitos no mapa; na cidade sobe direto
      while (h.lv < lv) { h.lv++; h.statPts += statPtsForLevel(h.lv); h.skillPts += 1; }
    } else while (h.lv < lv) { h.lv++; h.statPts += statPtsForLevel(h.lv); h.skillPts += 1; }
    recalc(); h.hp = G.d.maxHp; h.sp = G.d.maxSp; save();
  },
  town() { if (S().mode === 'dungeon') returnToTown(); },
  heal() { recalc(); const h = hero(); h.hp = G.d.maxHp; h.sp = G.d.maxSp; h.status = {}; save(); },
  zeny(n) { hero().zeny += n; save(); },
  pts(n) { hero().statPts += n; hero().skillPts += n; save(); },
  reveal() { const m = run()?.map; if (!m) return; m.seen.fill(1); G.dirty = true; save(); },
  killAll() { const r = run(); if (!r) return; for (const m of r.monsters) if (m.hp > 0 && !m.boss) { m.hp = 0; } r.monsters = r.monsters.filter((m) => m.hp > 0); G.dirty = true; save(); },
  god(on) { S().settings.god = on; save(); },
  rebirth() { const h = hero(); if (h.reborn) return; h.bosses = Array.from(new Set([...(h.bosses || []), 5, 10, 15, 20, 25])); if (h.lv < REBIRTH_LV) this.setLevel(REBIRTH_LV); if (CLASSES[h.cls].tier < 2) this.setClass(Object.keys(CLASSES).find((k) => CLASSES[k].tier === 2 && !CLASSES[k].reborn)); rebirth(); },
  spawn(type, x, y) { const m = makeMonster(type, x, y); m.asleep = false; m.awake = true; m.energy = 0; run().monsters.push(m); return m; },
  setClass(id) {
    const h = hero();
    if (!CLASSES[id]) return;
    h.cls = id;
    validateHands(h);
    // histórico coerente para os bônus por nível: aprendiz -> 1ª classe -> avançada
    const chain = []; let c = id;
    while (c) { chain.unshift(c); c = CLASSES[c].from; }
    h.clsHistory = chain.map((k, i) => ({ cls: k, since: i === 0 ? 1 : Math.min(h.lv, CLASS_LV[CLASSES[k].tier] || 1) }));
    if (CLASSES[id].reborn) { h.reborn = h.reborn || 1; h.rebornFrom = h.rebornFrom || CLASSES[id].base; }
    const starter = CLASS_STARTER[id];
    if (starter) { const it = makeItem(starter); if (!addToInv(it)) S().meta.storage.push(it); }
    recalc(); h.hp = G.d.maxHp; h.sp = G.d.maxSp;
    log(`[dev] Classe: ${CLASSES[id].name}`, '#9ad8ff');
    save();
  },
};

// ---------------- Mercado ----------------
export function market() {
  const meta = S().meta;
  if (!meta.market) meta.market = Mk.newMarket();
  meta.market.myMax = Mk.MAX_MY_LISTINGS + 2 * (meta.legacy.vagas || 0);
  meta.market.myTax = Mk.TAX - 0.006 * (meta.legacy.taxa || 0);
  return meta.market;
}
// avança o mundo; vendas suas caem no banco. Retorna as vendas novas.
export function marketTick(now = Date.now()) {
  if (!S() || !S().meta) return [];
  const m = market();
  const sold = Mk.tickMarket(m, now, (net) => { S().meta.zeny += net; });
  if (sold.length) save();
  return sold;
}
// itens que podem ir ao mercado: mochila e armazém (equipamentos não equipados e cartas)
export function marketSellables() {
  const out = [];
  const ok = (it) => isEquip(it) || itemDef(it).kind === 'card';
  for (const it of hero()?.inv || []) if (ok(it)) out.push({ it, where: 'inv' });
  for (const it of S().meta.storage) if (ok(it)) out.push({ it, where: 'storage' });
  return out;
}
export function marketList(u, price) {
  const h = hero(), meta = S().meta;
  let it = h.inv.find((o) => o.uid === u), where = 'inv';
  if (!it) { it = meta.storage.find((o) => o.uid === u); where = 'storage'; }
  if (!it) return 'Item não encontrado.';
  const err = Mk.listItem(market(), it, price, (fee) => { if (meta.zeny < fee) return false; meta.zeny -= fee; return true; });
  if (err) return err;
  if (where === 'inv') h.inv = h.inv.filter((o) => o !== it); else meta.storage = meta.storage.filter((o) => o !== it);
  save();
  return null;
}
export function marketCancel(id) {
  const it = Mk.cancelListing(market(), id);
  if (!it) return 'Anúncio não encontrado.';
  if (!addToInv(it)) S().meta.storage.push(it);
  save();
  return null;
}
export function marketBuy(id) {
  const meta = S().meta;
  const r = Mk.buyListing(market(), id, (p) => { if (meta.zeny < p) return false; meta.zeny -= p; return true; });
  if (r.err) return r.err;
  if (!addToInv(r.item)) meta.storage.push(r.item);
  fx({ type: 'sfx', name: 'coin' });
  save();
  return null;
}
