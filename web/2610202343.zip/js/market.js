// Mercado: um "MMO" offline com jogadores simulados.
// - População de jogadores fictícios (nick, classe, nível, equipamento, zeny, personalidade) que evolui em tempo real.
// - Cada item vale o quanto melhora o personagem de cada jogador (com a classe dele), vezes raridade e personalidade.
// - Você anuncia; vende quando aparece alguém que precisa e topa o preço. Os outros também anunciam e compram entre si.
// - O tempo passa de verdade (inclusive com o app fechado), com teto de horas para não virar máquina de dinheiro.
import { CLASSES, ITEMS, MONSTERS, THEMES, WTYPES } from './data.js';
import { itemDef, itemName, makeItem, makeCard, randomEquip, equipValue, weaponAtk, weaponMatk, armorDef, isEquip } from './rules.js';
import { rnd, chance, pick, weighted, clamp } from './util.js';

export const TICK_MS = 10 * 60 * 1000;      // um "passo" do mundo a cada 10 minutos
export const MAX_CATCHUP = 36;              // no máximo 6 horas de mundo ao voltar
export const TAX = 0.05;                    // taxa sobre a venda
export const LIST_FEE = 0.01;               // taxa de anúncio (paga ao anunciar)
export const MAX_MY_LISTINGS = 10;
const POP = 120;
const NPC_LISTING_CAP = 45;
const LISTING_TTL = 48 * 60 * 60 * 1000;

// Força relativa das classes (vinda dos testes do robô). Classe forte = mais jogadores = itens dela valem mais.
const STRENGTH = { espadachim: 1.0, mago: 1.15, arqueiro: 1.1, gatuno: 0.85, novico: 0.95, ninja: 1.0, taekwon: 0.95,
  cavaleiro: 1.0, bruxo: 1.12, cacador: 1.1, assassino: 0.95, monge: 1.08, shinobi: 1.0, mestre_taekwon: 1.05 };

// O que cada classe valoriza
const PROFILE = {
  aprendiz: { wt: ['espada', 'treino', 'adaga'], armor: 'any', st: { str: 1, vit: 0.8, dex: 0.5, agi: 0.5 } },
  espadachim: { wt: ['espada'], armor: 'heavy', st: { str: 1, vit: 0.8, dex: 0.4, agi: 0.3 } },
  cavaleiro: { wt: ['espada'], armor: 'heavy', st: { str: 1, vit: 0.9, dex: 0.4, agi: 0.3 } },
  mago: { wt: ['cajado'], armor: 'robe', magic: true, st: { int: 1, dex: 0.6, vit: 0.3 } },
  bruxo: { wt: ['cajado'], armor: 'robe', magic: true, st: { int: 1, dex: 0.6, vit: 0.3 } },
  arqueiro: { wt: ['arco'], armor: 'light', ranged: true, st: { dex: 1, agi: 0.5, vit: 0.3 } },
  cacador: { wt: ['besta', 'arco'], armor: 'light', ranged: true, st: { dex: 1, agi: 0.5, vit: 0.3, luk: 0.2 } },
  gatuno: { wt: ['adaga'], armor: 'light', st: { agi: 1, str: 0.8, luk: 0.4, dex: 0.3 } },
  assassino: { wt: ['katar', 'adaga'], armor: 'light', st: { agi: 1, str: 0.8, luk: 0.5, dex: 0.3 } },
  novico: { wt: ['maca'], armor: 'robe', magic: true, st: { int: 1, vit: 0.7, str: 0.4, dex: 0.3 } },
  monge: { wt: ['soqueira', 'maca'], armor: 'heavy', hybrid: true, st: { str: 0.9, int: 0.8, vit: 0.7, agi: 0.4 } },
  ninja: { wt: ['kunai'], armor: 'light', st: { str: 0.8, dex: 0.7, agi: 0.7, int: 0.4 } },
  shinobi: { wt: ['fuuma', 'kunai'], armor: 'light', st: { str: 0.8, dex: 0.7, agi: 0.7, int: 0.5 } },
  taekwon: { wt: [], armor: 'light', st: { str: 1, agi: 0.9, vit: 0.5 } },
  mestre_taekwon: { wt: [], armor: 'light', st: { str: 1, agi: 0.9, vit: 0.6 } },
};
const ARMOR_KIND = { roupa_algodao: 'any', tunica_couro: 'any', cota_malha: 'heavy', armadura_placas: 'heavy', armadura_runica: 'heavy',
  manto_aprendiz: 'robe', robe_arcano: 'robe', manto_estelar: 'robe', traje_ladino: 'light', couraca_sombra: 'light' };

// ---------------- Nicks ----------------
const N1 = ['Lorde', 'Dark', 'Sir', 'Mestre', 'Lady', 'Mini', 'Super', 'Rei', 'Anjo', 'Demon', 'Shadow', 'Neo', 'Kira', 'Yuki', 'Hiro', 'Rag', 'Pro', 'Big', 'Ice', 'Fire', 'Blood', 'Holy', 'Cyber', 'Sad', 'Doce', 'Mega', 'Jr', 'Old', 'Lil', 'Mr'];
const N2 = ['Assassino', 'Sacer', 'Poring', 'Knight', 'Wiz', 'Hunter', 'Monk', 'Ninja', 'Lobo', 'Dragao', 'Fenix', 'Gato', 'Corvo', 'Blade', 'Zeny', 'Mvp', 'Kafra', 'Prontera', 'Payon', 'Morroc', 'Geffen', 'Baphomet', 'Osiris', 'Drake', 'Eddga', 'Valk', 'Aldebaran', 'Lutie', 'Juno', 'Rune'];
function makeNick(used) {
  for (let k = 0; k < 50; k++) {
    const style = rnd(0, 5);
    const a = pick(N1), b = pick(N2), n = rnd(1, 99);
    const nick = [`${a}${b}`, `xX_${b}_Xx`, `${b}${n}`, `${a}_${b}`, `${b.toLowerCase()}.${a.toLowerCase()}`, `${a}${b}${n}`][style];
    if (!used.has(nick)) { used.add(nick); return nick; }
  }
  return 'Jogador' + rnd(1000, 9999);
}

// ---------------- População ----------------
const firstFor = (adv) => CLASSES[adv].from;
function pickClassFor(lv) {
  const tier = lv >= 25 ? 2 : lv >= 8 ? 1 : 0;
  const opts = Object.entries(CLASSES).filter(([, c]) => c.tier === tier).map(([k]) => [k, Math.pow(STRENGTH[k] || 1, 3)]);
  return weighted(opts);
}
function zenyPerPower(lv) { return 10 + lv * 2.5; }
function tierForLv(lv) { return clamp(Math.ceil(lv / 11), 1, 5); }

function starterGear(p) {
  const pr = PROFILE[p.cls];
  const t = tierForLv(p.lv);
  const wt = pr.wt[0];
  const wid = wt ? Object.keys(ITEMS).find((k) => ITEMS[k].kind === 'weapon' && ITEMS[k].wtype === wt && ITEMS[k].tier === Math.max(1, t - rnd(0, 1))) : null;
  const armors = Object.keys(ARMOR_KIND).filter((k) => ITEMS[k].tier <= Math.max(1, t - rnd(0, 1)) && (ARMOR_KIND[k] === pr.armor || ARMOR_KIND[k] === 'any'));
  const main = Object.keys(pr.st).sort((a, b) => pr.st[b] - pr.st[a])[0];
  const accId = Object.keys(ITEMS).find((k) => ITEMS[k].kind === 'acc' && ITEMS[k].stat === main);
  return {
    weapon: wid ? makeItem(wid) : null,
    armor: makeItem(armors.sort((a, b) => ITEMS[b].tier - ITEMS[a].tier)[0] || 'roupa_algodao'),
    acc: chance(70) ? makeItem(accId, { tier: Math.max(1, t - rnd(1, 2)) }) : null,
  };
}

function newPlayer(used, lv) {
  const p = { id: Math.random().toString(36).slice(2, 9), nick: makeNick(used), lv, cls: 'aprendiz',
    zeny: Math.round(200 + lv * lv * 25 * (0.5 + Math.random())),
    greed: 0.8 + Math.random() * 0.5, impulse: Math.random(), collector: chance(12) };
  if (lv >= 8) p.cls = pickClassFor(Math.min(lv, 24));
  if (lv >= 25) { const adv = Object.keys(CLASSES).filter((k) => CLASSES[k].from === p.cls); p.cls = adv.length ? pick(adv) : p.cls; }
  p.gear = starterGear(p);
  return p;
}

export function newMarket() {
  const used = new Set();
  const players = [];
  for (let i = 0; i < POP; i++) {
    const lv = weighted([[rnd(1, 14), 25], [rnd(15, 34), 40], [rnd(35, 54), 28], [rnd(55, 70), 7]]);
    players.push(newPlayer(used, lv));
  }
  const m = { v: 1, lastTick: Date.now(), players, mine: [], npc: [], history: [], news: [], events: [], unread: [] };
  for (let i = 0; i < 25; i++) npcDrop(m, Date.now() - rnd(0, 24) * 3600e3);
  news(m, 'O mercado de Runa abriu as portas. Aventureiros de todo canto vêm negociar.', 'info');
  return m;
}

// ---------------- Valor de um item ----------------
const MODW = { atk: 1, matk: 1, atkPct: 5, matkPct: 5, hp: 0.08, hpPct: 3, sp: 0.05, spPct: 1.5, def: 2.5, mdef: 1.5, hit: 0.8, flee: 1.2, crit: 4,
  speed: 2.5, lifesteal: 12, regenHp: 4, dmgReduce: 8, poisonImmune: 15, critDmg: 1.5 };
function modsPower(mods, pr) {
  let v = 0;
  for (const [k, val] of Object.entries(mods || {})) {
    if (pr.st[k] !== undefined || ['str', 'agi', 'vit', 'int', 'dex', 'luk'].includes(k)) v += val * 7 * (pr.st[k] || 0.1);
    else if (k === 'matk' || k === 'matkPct') v += val * MODW[k] * (pr.magic || pr.hybrid ? 1 : 0.1);
    else if (k === 'atk' || k === 'atkPct') v += val * MODW[k] * (pr.magic ? 0.15 : 1);
    else if (k === 'raceDmg') v += Object.values(val).reduce((a, b) => a + b, 0) * 0.6;
    else if (k === 'armorEl' || k === 'weaponEl') v += 22;
    else if (MODW[k]) v += val * MODW[k];
  }
  return v;
}
function weaponPower(it, pr) {
  if (!it) return 0;
  const d = itemDef(it);
  if (!pr.wt.includes(d.wtype)) return 0;
  const main = pr.magic ? weaponMatk(it) + weaponAtk(it) * 0.1 : pr.hybrid ? weaponAtk(it) + weaponMatk(it) * 0.5 : weaponAtk(it);
  return main + modsPower({ ...WTYPES[d.wtype].mods, ...(d.mods || {}) }, pr) + (d.el ? 10 : 0) + cardsPower(it, pr) + (it.slots || 0) * 6;
}
function armorPower(it, pr) {
  if (!it) return 0;
  const d = itemDef(it);
  const kind = ARMOR_KIND[it.id] || 'any';
  const fit = kind === 'any' || kind === pr.armor ? 1 : 0.55;
  return (armorDef(it) * 2.5 + d.mdef * (pr.magic ? 2.5 : 1.2) + modsPower(d.mods, pr) + cardsPower(it, pr) + (it.slots || 0) * 5) * fit;
}
function accPower(it, pr) { return it ? modsPower(itemDef(it).mods, pr) + cardsPower(it, pr) + (it.slots || 0) * 4 : 0; }
function cardsPower(it, pr) { return (it.cards || []).reduce((a, c) => a + modsPower(MONSTERS[c].card.mods, pr), 0); }

// quanto o item melhora o jogador (em "pontos de poder")
function gain(p, it) {
  const pr = PROFILE[p.cls];
  const d = itemDef(it);
  if (d.kind === 'card') {
    const slotItem = p.gear[d.slot];
    if (!slotItem && d.slot !== 'acc') return 0;
    return modsPower(d.mods, pr) * (d.boss ? 1.6 : 1);
  }
  if (d.kind === 'weapon') { const lvReq = (d.tier - 1) * 10; if (p.lv < lvReq) return 0; return Math.max(0, weaponPower(it, pr) - weaponPower(p.gear.weapon, pr)); }
  if (d.kind === 'armor') { const lvReq = (d.tier - 1) * 10; if (p.lv < lvReq) return 0; return Math.max(0, armorPower(it, pr) - armorPower(p.gear.armor, pr)); }
  if (d.kind === 'acc') return Math.max(0, accPower(it, pr) - accPower(p.gear.acc, pr));
  return 0;
}

// raridade: cartas são raras e permanentes; cartas de chefe, mais ainda
function rarity(it) {
  const d = itemDef(it);
  if (d.kind === 'card') return d.boss ? 9 : 3;
  return 1 + (it.slots || 0) * 0.25 + (it.refine || 0) * 0.2;
}

function eventMult(m, p, it, now) {
  let k = 1;
  for (const e of m.events) {
    if (e.until < now) continue;
    if (e.type === 'temporada' && e.cls === p.cls) k *= 1.5;
    if (e.type === 'cartas' && it.id === 'card') k *= 1.35;
    if (e.type === 'crise') k *= 0.75;
    if (e.type === 'bonanca') k *= 1.2;
  }
  return k;
}

// quanto este jogador pagaria
function wtp(m, p, it, now = Date.now()) {
  const g = gain(p, it);
  if (g <= 0) return p.collector && itemDef(it).kind === 'card' ? equipValue(it) * 0.8 : 0;
  let v = g * zenyPerPower(p.lv) * rarity(it) * p.greed * eventMult(m, p, it, now) * (0.85 + p.impulse * 0.3);
  // ninguém paga muito acima do que a loja da cidade cobraria por algo parecido
  const d = itemDef(it);
  v = Math.min(v, equipValue(it) * (d.kind === 'card' ? (d.boss ? 10 : 30) : 1.35));
  return Math.min(v, p.zeny * 0.7);
}

const keyOf = (it) => (it.id === 'card' ? 'card:' + it.mon : it.id);
export function itemKey(it) { return keyOf(it); }

// preço de referência: últimas vendas (corrigidas por refino/slots) ou a demanda atual
export function priceGuide(m, it) {
  const k = keyOf(it);
  const base = equipValue(it);
  const sales = m.history.filter((h) => h.key === k).slice(-12);
  const now = Date.now();
  const w = m.players.map((p) => wtp(m, p, it, now)).filter((v) => v > 0).sort((a, b) => a - b);
  const q = (f) => (w.length ? w[Math.min(w.length - 1, Math.floor(w.length * f))] : 0);
  let median = null;
  if (sales.length >= 2) {
    const adj = sales.map((s) => s.price * base / Math.max(1, s.base || base)).sort((a, b) => a - b);
    median = adj[Math.floor(adj.length / 2)];
  }
  const fast = Math.floor(q(0.3) || base * 0.5);
  const max = Math.floor(q(0.9) || base);
  const sug = Math.floor(median ? Math.min((median + q(0.55)) / 2, q(0.7) || median) : q(0.55) || base * 0.6);
  return { buyers: w.length, fast, max, median: median ? Math.round(median) : null, suggest: Math.max(1, sug), shop: Math.floor(base * 0.4) };
}

// chance de vender em 1 passo, para mostrar ao anunciar
export function saleOdds(m, it, price) {
  const now = Date.now();
  const n = m.players.filter((p) => wtp(m, p, it, now) >= price).length;
  const perTick = 1 - Math.pow(1 - 0.035, n);
  const hours = perTick > 0 ? 1 / perTick / 6 : Infinity;
  return { interested: n, hours };
}

// ---------------- Notícias ----------------
function news(m, text, kind = 'info', at = Date.now()) {
  m.news.unshift({ text, kind, at });
  m.news = m.news.slice(0, 60);
}

// ---------------- Passo do mundo ----------------
function npcDrop(m, at = Date.now()) {
  if (m.npc.length >= NPC_LISTING_CAP) return;
  const p = pick(m.players);
  const t = clamp(tierForLv(p.lv) + rnd(-1, 0), 1, 5);
  let it;
  if (chance(16)) {
    const th = THEMES[clamp(Math.floor(p.lv / 11), 0, 4)];
    const mon = chance(6) ? th.boss : pick(th.monsters);
    it = makeCard(mon);
  } else it = randomEquip(t);
  const g = priceGuide(m, it);
  const price = Math.max(10, Math.round((g.median || g.suggest || equipValue(it) * 0.6) * (0.9 + Math.random() * 0.6) * p.greed));
  m.npc.push({ id: Math.random().toString(36).slice(2, 9), seller: p.nick, sellerId: p.id, item: it, price, at });
}

function equipOn(p, it) {
  const d = itemDef(it);
  if (d.kind === 'card') {
    const s = p.gear[d.slot];
    if (s) { s.cards = s.cards || []; s.slots = Math.max(s.slots || 0, s.cards.length + 1); s.cards.push(it.mon); }
    return;
  }
  p.gear[d.kind] = it;
}

function recordSale(m, it, price, at) {
  m.history.push({ key: keyOf(it), price, base: equipValue(it), at, name: itemName(it) });
  if (m.history.length > 400) m.history = m.history.slice(-400);
}

function tryBuy(m, listing, now, onMine) {
  const cands = m.players.filter((p) => p.id !== listing.sellerId && wtp(m, p, listing.item, now) >= listing.price);
  if (!cands.length) return false;
  if (!chance((1 - Math.pow(1 - 0.035, cands.length)) * 100)) return false;
  const buyer = pick(cands);
  buyer.zeny -= listing.price;
  equipOn(buyer, listing.item);
  recordSale(m, listing.item, listing.price, now);
  if (onMine) onMine(buyer);
  else {
    const seller = m.players.find((p) => p.id === listing.sellerId);
    if (seller) seller.zeny += Math.floor(listing.price * (1 - TAX));
    if (listing.item.id === 'card' && listing.price > 2000) news(m, `${buyer.nick} comprou ${itemName(listing.item)} de ${listing.seller} por ${listing.price.toLocaleString('pt-BR')}z.`, 'trade', now);
  }
  return true;
}

function maybeEvent(m, now) {
  m.events = m.events.filter((e) => e.until > now);
  if (m.events.length >= 2 || !chance(100 / 144)) return; // ~1 por dia
  const type = weighted([['temporada', 45], ['cartas', 20], ['crise', 15], ['bonanca', 20]]);
  const e = { type, until: now + rnd(8, 24) * 3600e3 };
  if (type === 'temporada') {
    e.cls = pick(Object.keys(CLASSES).filter((k) => CLASSES[k].tier >= 1));
    e.text = `Temporada de ${CLASSES[e.cls].name}: muita gente jogando com essa classe. Itens dela estão valorizados.`;
  } else if (type === 'cartas') e.text = 'Febre das cartas: colecionadores pagando mais por cartas.';
  else if (type === 'crise') e.text = 'Crise em Runa: o zeny anda curto e os preços caíram.';
  else e.text = 'Bonança: os aventureiros voltaram ricos das masmorras e estão gastando.';
  m.events.push(e);
  news(m, e.text, 'event', now);
}

function stepPlayers(m, now) {
  for (const p of m.players) {
    const income = p.lv * 5 * (m.events.some((e) => e.type === 'crise' && e.until > now) ? 0.5 : 1);
    p.zeny = p.zeny * 0.995 + income; // gastam com poções, refino etc. (evita inflação)
    if (p.lv < 85 && Math.random() < 0.2 / (p.lv + 5)) {
      p.lv++;
      const want = Object.keys(CLASSES).filter((k) => CLASSES[k].from === p.cls);
      if (want.length && ((p.lv >= 8 && CLASSES[p.cls].tier === 0) || (p.lv >= 25 && CLASSES[p.cls].tier === 1))) {
        p.cls = weighted(want.map((k) => [k, Math.pow(STRENGTH[k] || 1, 3)]));
        if (CLASSES[p.cls].tier === 2 && chance(30)) news(m, `${p.nick} virou ${CLASSES[p.cls].name}!`, 'info', now);
        p.gear = starterGear(p);
      }
    }
    // às vezes acham equipamento sozinhos
    if (chance(0.4)) { const it = randomEquip(clamp(tierForLv(p.lv) + rnd(-1, 0), 1, 5)); if (gain(p, it) > 0) equipOn(p, it); }
  }
  // de tempos em tempos alguém novo começa a jogar (e alguém para)
  if (chance(4)) {
    const used = new Set(m.players.map((p) => p.nick));
    m.players.splice(rnd(0, m.players.length - 1), 1);
    m.players.push(newPlayer(used, rnd(1, 20)));
  }
}

// avança o mundo até agora (no máximo MAX_CATCHUP passos). Retorna as vendas suas que aconteceram.
export function tickMarket(m, now = Date.now(), creditMine) {
  const sold = [];
  let steps = Math.floor((now - m.lastTick) / TICK_MS);
  if (steps <= 0) return sold;
  const skipped = Math.max(0, steps - MAX_CATCHUP);
  steps = Math.min(steps, MAX_CATCHUP);
  let t = m.lastTick + skipped * TICK_MS;
  for (let s = 0; s < steps; s++) {
    t += TICK_MS;
    stepPlayers(m, t);
    maybeEvent(m, t);
    for (let k = 0; k < 2; k++) if (chance(55)) npcDrop(m, t);
    // seus anúncios
    for (const l of [...m.mine]) {
      if (tryBuy(m, { ...l, sellerId: 'me' }, t, (buyer) => {
        const net = Math.floor(l.price * (1 - (m.myTax ?? TAX)));
        m.mine = m.mine.filter((o) => o !== l);
        sold.push({ item: l.item, price: l.price, net, buyer: buyer.nick, at: t });
        news(m, `Você vendeu ${itemName(l.item)} para ${buyer.nick} por ${l.price.toLocaleString('pt-BR')}z.`, 'mine', t);
        if (creditMine) creditMine(net);
      })) continue;
    }
    // anúncios dos outros
    for (const l of [...m.npc]) {
      if (t - l.at > LISTING_TTL) { m.npc = m.npc.filter((o) => o !== l); continue; }
      if (tryBuy(m, l, t)) m.npc = m.npc.filter((o) => o !== l);
    }
  }
  m.lastTick = t;
  if (sold.length) m.unread.push(...sold);
  return sold;
}

// ---------------- Ações do jogador ----------------
export function listItem(m, it, price, payFee) {
  if (m.mine.length >= (m.myMax || MAX_MY_LISTINGS)) return 'Você já tem anúncios demais.';
  if (!isEquip(it) && itemDef(it).kind !== 'card') return 'Só equipamentos e cartas vão ao mercado.';
  price = Math.floor(price);
  if (!(price >= 1)) return 'Preço inválido.';
  const fee = Math.max(1, Math.floor(price * LIST_FEE));
  if (!payFee(fee)) return `Taxa de anúncio: ${fee}z (zeny insuficiente).`;
  m.mine.push({ id: Math.random().toString(36).slice(2, 9), item: it, price, at: Date.now(), fee });
  return null;
}
export function cancelListing(m, id) {
  const l = m.mine.find((o) => o.id === id);
  if (!l) return null;
  m.mine = m.mine.filter((o) => o !== l);
  return l.item;
}
export function buyListing(m, id, pay) {
  const l = m.npc.find((o) => o.id === id);
  if (!l) return { err: 'O anúncio não existe mais.' };
  if (!pay(l.price)) return { err: 'Zeny insuficiente no banco.' };
  m.npc = m.npc.filter((o) => o !== l);
  const seller = m.players.find((p) => p.id === l.sellerId);
  if (seller) seller.zeny += Math.floor(l.price * (1 - TAX));
  recordSale(m, l.item, l.price, Date.now());
  news(m, `Você comprou ${itemName(l.item)} de ${l.seller} por ${l.price.toLocaleString('pt-BR')}z.`, 'mine');
  return { item: l.item };
}

// quem mais quer este item (para mostrar ao anunciar)
export function topBuyers(m, it, n = 3) {
  const now = Date.now();
  return m.players.map((p) => ({ p, v: wtp(m, p, it, now) })).filter((o) => o.v > 0).sort((a, b) => b.v - a.v).slice(0, n)
    .map(({ p, v }) => ({ nick: p.nick, cls: CLASSES[p.cls].name, lv: p.lv, v: Math.round(v) }));
}

export function activeEvents(m, now = Date.now()) { return m.events.filter((e) => e.until > now); }
