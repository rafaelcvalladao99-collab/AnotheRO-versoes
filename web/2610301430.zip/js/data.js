// =============================================================
// Dados do jogo: elementos, raças, classes, habilidades, monstros,
// itens e cartas.
// =============================================================

export const ELEMENTS = {
  neutro: { name: 'Neutro', color: '#c9ccd6' },
  agua: { name: 'Água', color: '#4fb3ff' },
  terra: { name: 'Terra', color: '#c79a5a' },
  fogo: { name: 'Fogo', color: '#ff7a3d' },
  vento: { name: 'Vento', color: '#9cf2c8' },
  sagrado: { name: 'Sagrado', color: '#ffe9a3' },
  sombrio: { name: 'Sombrio', color: '#a37bff' },
  fantasma: { name: 'Fantasma', color: '#cfe7ff' },
  morto: { name: 'Morto-vivo', color: '#9aa88a' },
};

// atacante > defensor = 1.5x
const STRONG = {
  agua: ['fogo'],
  fogo: ['terra', 'morto'],
  terra: ['vento'],
  vento: ['agua'],
  sagrado: ['sombrio', 'morto', 'fantasma'],
  sombrio: ['sagrado'],
  fantasma: ['fantasma'],
};

export function elemMult(atk, def) {
  return 1;   // sem vantagem/desvantagem de elemento: os elementos são só tema (e os combos do mago)
  if (!atk) atk = 'neutro';
  if (!def) def = 'neutro';
  if (def === 'fantasma' && atk === 'neutro') return 0.5;
  if ((STRONG[atk] || []).includes(def)) return 1.5;
  if ((STRONG[def] || []).includes(atk)) return 0.75;
  if (atk === def && atk !== 'neutro' && atk !== 'fantasma') return 0.5;
  return 1;
}

export const RACES = {
  amorfo: 'Amorfo', inseto: 'Inseto', planta: 'Planta', bruto: 'Bruto', peixe: 'Peixe',
  morto: 'Morto-vivo', demonio: 'Demônio', humanoide: 'Humanoide', dragao: 'Dragão',
};

export const STAT_NAMES = { str: 'FOR', agi: 'AGI', vit: 'VIT', int: 'INT', dex: 'DES', luk: 'SOR' };
export const STAT_DESC = {
  str: 'Dano corpo a corpo',
  agi: 'Esquiva e velocidade',
  vit: 'HP máximo e defesa',
  int: 'Dano mágico e SP',
  dex: 'Precisão, conjuração e dano à distância',
  luk: 'Crítico, esquiva perfeita e resistência',
};

// ------------------------------------------------------------------
// Classes
// ------------------------------------------------------------------
export const CLASSES = {
  aprendiz: { name: 'Aprendiz', tier: 0, hpMul: 1, spMul: 1, colors: ['#8a6a4a', '#d8c3a0'], hat: 'none',
    desc: 'Todo aventureiro começa aqui.', skills: ['primeiros_socorros', 'faisca_arcana', 'arremessar_pedra', 'resistencia'] },

  espadachim: { name: 'Espadachim', tier: 1, from: 'aprendiz', hpMul: 1.45, spMul: 1.05, colors: ['#3b6fd1', '#c7d4ef'], hat: 'band',
    desc: 'Guerreiro resistente de corpo a corpo.', skills: ['golpe_fulminante', 'impacto_explosivo', 'vigor', 'maestria_espada'] },
  mago: { name: 'Mago', tier: 1, from: 'aprendiz', hpMul: 1.15, spMul: 1.5, colors: ['#7c3fbf', '#e5d2ff'], hat: 'wizard',
    desc: 'Magias elementais poderosas, mas frágil. Gelo + raio estilhaça.', skills: ['lanca_fogo', 'lanca_gelo', 'relampago', 'congelar', 'meditacao', 'escudo_petrificante'] },
  arqueiro: { name: 'Arqueiro', tier: 1, from: 'aprendiz', hpMul: 1.0, spMul: 1.1, colors: ['#3f9a52', '#d7f0c9'], hat: 'feather',
    desc: 'Ataques à distância com arco.', skills: ['tiro_duplo', 'chuva_flechas', 'olhos_coruja', 'olho_aguia'] },
  gatuno: { name: 'Gatuno', tier: 1, from: 'aprendiz', hpMul: 1.3, spMul: 1.05, colors: ['#3c3f4a', '#b9bdc9'], hat: 'hood',
    desc: 'Ágil, furtivo e venenoso: apunhala pelas costas e some na fumaça.', skills: ['ataque_duplo', 'envenenar_arma', 'esconderijo', 'apunhalar', 'bomba_fumaca', 'explosao_veneno'] },
  novico: { name: 'Clérigo', tier: 1, from: 'aprendiz', hpMul: 1.25, spMul: 1.3, colors: ['#e9e3d3', '#4a5f9e'], hat: 'cap',
    desc: 'Cura, bênçãos, escudo sagrado e luz divina.', skills: ['curar', 'bencao', 'kyrie', 'luz_divina'] },
  ninja: { energy: true, name: 'Ninja', tier: 1, from: 'aprendiz', hpMul: 1.05, spMul: 1.2, colors: ['#2a2f45', '#c43a4a'], hat: 'none',
    desc: 'Ágil e cadenciado: usa Energia em vez de SP, faz os monstros sangrarem e detona o sangue.', skills: ['kunai', 'pulsar_sangue', 'substituicao', 'passos_sombra'] },

  taekwon: { name: 'Taekwon', tier: 1, from: 'aprendiz', hpMul: 1.15, spMul: 1.1, colors: ['#f4f2ec', '#d83a3a'], hat: 'none',
    desc: 'Luta com chutes em sequência: chutes diferentes, um atrás do outro, dão Ritmo até o Golpe Final. Fica mais forte sem arma nas mãos.', skills: ['chute_giratorio', 'chute_machado', 'chute_rasteira', 'postura_taekwon', 'corrida', 'ritmo'] },

  cavaleiro: { name: 'Cavaleiro', tier: 2, from: 'espadachim', hpMul: 1.75, spMul: 1.15, colors: ['#1f4fa8', '#e4ecff'], hat: 'helm',
    desc: 'Luta com duas espadas na linha de frente: apara golpes para abrir a guarda dos monstros e junta Fervor para os golpes fortes.', skills: ['corte_cruzado', 'redemoinho', 'aparar_golpe', 'ambidestria', 'ofensiva_furiosa', 'fervor_batalha'] },
  bruxo: { name: 'Bruxo', tier: 2, from: 'mago', hpMul: 1.15, spMul: 1.8, colors: ['#4a1f8a', '#f0b84a'], hat: 'wizard',
    desc: 'Magias em área devastadoras.', skills: ['meteoro', 'nevasca', 'olhar_medusa', 'vortice_jupiter', 'ira_thor', 'amplificacao'] },
  cacador: { hunter: true, name: 'Caçador', tier: 2, from: 'arqueiro', hpMul: 1.1, spMul: 1.2, colors: ['#2e6e3a', '#e8d9a8'], hat: 'feather',
    desc: 'Caça de longe: quanto mais distante, mais forte o tiro. Marca a presa com a rede e arma o terreno com armadilhas.', skills: ['tiro_certeiro', 'rede', 'armadilha', 'salto_tras', 'virote_impacto', 'falcao', 'instinto'] },
  assassino: { shadow: true, name: 'Assassino', tier: 2, from: 'gatuno', hpMul: 1.4, spMul: 1.15, colors: ['#5a1a2e', '#d6c5cb'], hat: 'mask',
    desc: 'Mestre do katar: sai da sombra matando e volta para ela a cada abate.', skills: ['laminas_sonicas', 'garra_sombria', 'furtividade', 'maestria_katar', 'execucao'] },
  monge: { name: 'Monge', tier: 2, from: 'novico', hpMul: 1.55, spMul: 1.2, colors: ['#d8742a', '#f4e2b8'], hat: 'none',
    desc: 'Lutador de punhos guiado pela energia espiritual. Punhos Sagrados: metade do ATQM vira ATQ, e +3 ATQ por nível.', holyFist: 0.5, skills: ['punhos_triplos', 'esferas_espirituais', 'palma_ferro', 'combo_cadeia'] },
  mestre_taekwon: { name: 'Mestre Taekwon', tier: 2, from: 'taekwon', hpMul: 1.3, spMul: 1.3, colors: ['#1a1a24', '#ffcf4a'], hat: 'none',
    desc: 'Chutes voadores e o poder do sol e das estrelas.', skills: ['chute_voador', 'furia_solar', 'chute_ascendente', 'protecao_estelar', 'unidade_corpo'] },
  shinobi: { energy: true, name: 'Shinobi', tier: 2, from: 'ninja', hpMul: 1.25, spMul: 1.4, colors: ['#1c1830', '#8a4ae8'], hat: 'none',
    desc: 'Mestre ninja: corta, recua e deixa o inimigo sangrar correndo atrás dele.', skills: ['lamina_fantasma', 'chuva_shuriken', 'clones_sombra', 'arte_ninja'] },

  // ---------- Renascimento ----------
  aprendiz_alto: { name: 'Aprendiz Renascido', tier: 0, reborn: true, art: 'aprendiz_alto', hpMul: 1, spMul: 1, colors: ['#8a6a4a', '#ffe08a'], hat: 'none',
    desc: 'Renasceu depois de vencer o Bafomé. Mais forte desde o começo.', skills: ['primeiros_socorros', 'faisca_arcana', 'arremessar_pedra', 'resistencia'] },
  // classes transcendentais: tudo da classe 2 + duas habilidades novas
  lorde: { name: 'Lorde', tier: 2, from: 'espadachim_alto', base: 'cavaleiro', reborn: true, trans: true, art: 'lorde', hpMul: 1.85, spMul: 1.25, colors: ['#1f4fa8', '#ffd86b'], hat: 'helm',
    desc: 'O Cavaleiro transcendido: aposta tudo no Frenesi e derruba chefes com a Perfuração Espiral.', skills: ['corte_cruzado', 'redemoinho', 'aparar_golpe', 'ambidestria', 'ofensiva_furiosa', 'fervor_batalha', 'furia_batalha', 'frenesi', 'perfuracao_espiral'] },
  arquimago: { name: 'Arquimago', tier: 2, from: 'mago_alto', base: 'bruxo', reborn: true, trans: true, art: 'arquimago', hpMul: 1.2, spMul: 1.9, colors: ['#4a1f8a', '#ffd86b'], hat: 'wizard',
    desc: 'O Bruxo transcendido: controla o campo com a gravidade e se alimenta das almas que ceifa.', skills: ['meteoro', 'nevasca', 'olhar_medusa', 'vortice_jupiter', 'ira_thor', 'amplificacao', 'campo_gravitacional', 'absorver_alma'] },
  atirador_elite: { hunter: true, name: 'Atirador de Elite', tier: 2, from: 'arqueiro_alto', base: 'cacador', reborn: true, trans: true, art: 'atirador_elite', hpMul: 1.15, spMul: 1.3, colors: ['#2e6e3a', '#ffd86b'], hat: 'feather',
    desc: 'O Caçador transcendido: tiros que atravessam fileiras e um falcão que nunca erra.', skills: ['tiro_certeiro', 'rede', 'armadilha', 'salto_tras', 'virote_impacto', 'falcao', 'instinto', 'tiro_preciso', 'ataque_falcao'] },
  algoz: { shadow: true, name: 'Algoz', tier: 2, from: 'gatuno_alto', base: 'assassino', reborn: true, trans: true, art: 'algoz', hpMul: 1.45, spMul: 1.25, colors: ['#5a1a2e', '#ffd86b'], hat: 'mask',
    desc: 'O Assassino transcendido: veneno mortal e lâminas que atravessam qualquer armadura.', skills: ['laminas_sonicas', 'garra_sombria', 'furtividade', 'maestria_katar', 'execucao', 'veneno_mortal', 'destruidor_almas'] },
  mestre: { name: 'Mestre', tier: 2, from: 'novico_alto', base: 'monge', reborn: true, trans: true, art: 'mestre', hpMul: 1.6, spMul: 1.3, colors: ['#d8742a', '#ffd86b'], hat: 'none', holyFist: 0.5,
    desc: 'O Monge transcendido: dono do Punho de Asura, o golpe que gasta a alma inteira.', skills: ['punhos_triplos', 'esferas_espirituais', 'palma_ferro', 'combo_cadeia', 'asura', 'zen'] },
  imperador_estelar: { name: 'Imperador Estelar', tier: 2, from: 'taekwon_alto', base: 'mestre_taekwon', reborn: true, trans: true, art: 'imperador_estelar', hpMul: 1.4, spMul: 1.4, colors: ['#1a1a24', '#ff9a3a'], hat: 'none',
    desc: 'O Mestre Taekwon transcendido: funde-se às estrelas e queima tudo em volta com o calor do sol.', skills: ['chute_voador', 'furia_solar', 'chute_ascendente', 'protecao_estelar', 'unidade_corpo', 'fusao_estelar', 'calor_sol'] },
  kagerou: { energy: true, name: 'Kagerou', tier: 2, from: 'ninja_alto', base: 'shinobi', reborn: true, trans: true, art: 'kagerou', hpMul: 1.3, spMul: 1.5, colors: ['#1c1830', '#ff4a6a'], hat: 'none',
    desc: 'O Shinobi transcendido: kunais que sangram fileiras inteiras e a postura da Lua Crescente, que pune quem erra.', skills: ['lamina_fantasma', 'chuva_shuriken', 'clones_sombra', 'arte_ninja', 'kunai_sangrenta', 'lua_crescente'] },
};
// classes 1 "Altas" do renascido: as mesmas da primeira vida, vindas do Aprendiz Renascido
for (const id of ['espadachim', 'mago', 'arqueiro', 'gatuno', 'novico', 'ninja', 'taekwon']) {
  const c = CLASSES[id];
  CLASSES[id + '_alto'] = { ...c, name: c.name + ' Alto', from: 'aprendiz_alto', base: id, reborn: true, art: id + '_alto' };
}
// classe "de origem" (para bônus, sprites e regras que dependem da classe)
export const baseCls = (id) => (CLASSES[id] && CLASSES[id].base) || id;
// força do ataque normal por classe (perfil: Assassino e Monge batem forte no normal; Mago quase não usa)
export const BASIC_MUL = { aprendiz: 1, espadachim: 0.833, cavaleiro: 0.833, lorde: 1, mago: 1, bruxo: 1, arquimago: 1, arqueiro: 1.638, cacador: 1.638, atirador_elite: 1,
  gatuno: 1.437, assassino: 1.437, algoz: 1, novico: 1.446, monge: 1.446, mestre: 1, ninja: 1.959, shinobi: 1.959, kagerou: 1, taekwon: 1.509, mestre_taekwon: 1.509, imperador_estelar: 1 };
// vida dos monstros por faixa de 5 andares (curva suave, sem o degrau do andar 26)
export const MON_HP_BAND = [1.1, 1.44, 1.56, 1.45, 1.96, 0.9, 0.85, 1.27];   // HP dos monstros comuns por faixa de 5 andares
export const artCls = (id) => (CLASSES[id] && CLASSES[id].art) || id;

// Mãos: quem pode usar escudo e quais armas vão na mão esquerda (duas armas)
export const HANDS = {
  espadachim: { dual: ['espada'] }, cavaleiro: { dual: ['espada'] },
  gatuno: { dual: ['adaga'] }, assassino: { dual: ['adaga'], noShield: true },
  ninja: { dual: ['kunai'], noShield: true }, shinobi: { dual: ['kunai'], noShield: true },
  taekwon: { noShield: true }, mestre_taekwon: { noShield: true },
};
export const OFFHAND = 0.4; // arma na mão esquerda: 40% do ATQ e dos bônus do item (as cartas valem inteiras)
export const handsOf = (cls) => HANDS[baseCls(cls)] || {};
export const isTwoHanded = (d) => !!(d && d.kind === 'weapon' && WTYPES[d.wtype] && WTYPES[d.wtype].hands === 2);
// nível de classe: 1 ponto de habilidade por nível de classe; a troca de classe pede o nível de classe máximo
export const CLASS_LV = { 1: 5, 2: 15 };   // nível de classe da classe anterior exigido para a 1ª e a 2ª classe
export const jobMax = (cls) => { const c = CLASSES[cls]; return c.tier === 0 ? 5 : c.trans ? 20 : 15; };

// Bônus de classe: atributos ganhos automaticamente por nível passado na classe
export const JOB_BONUS = {
  espadachim: { str: 0.5, vit: 0.35, dex: 0.15 }, cavaleiro: { str: 0.55, vit: 0.4, dex: 0.15, agi: 0.1 },
  mago: { int: 0.6, dex: 0.3 }, bruxo: { int: 0.7, dex: 0.35 },
  arqueiro: { dex: 0.6, agi: 0.25 }, cacador: { dex: 0.65, agi: 0.25, luk: 0.1 },
  gatuno: { agi: 0.6, str: 0.4, luk: 0.15 }, assassino: { agi: 0.55, str: 0.35, luk: 0.2 },
  novico: { int: 0.4, vit: 0.3, dex: 0.15 }, monge: { str: 0.6, agi: 0.3, vit: 0.3 },
  ninja: { agi: 0.4, dex: 0.3, int: 0.2 }, shinobi: { agi: 0.45, dex: 0.35, int: 0.25 },
  taekwon: { agi: 0.45, str: 0.35 }, mestre_taekwon: { agi: 0.5, str: 0.4, vit: 0.15 },
};

// Arma de assinatura entregue ao mudar de classe
export const CLASS_STARTER = {
  espadachim: 'espada_curta', mago: 'vara', arqueiro: 'arco_curto', gatuno: 'faca', novico: 'clava', ninja: 'kunai', taekwon: null,
  cavaleiro: 'sabre', bruxo: 'cajado_carvalho', cacador: 'besta_caca', assassino: 'katar_serrilhado', monge: 'soqueira_ferro', shinobi: 'fuuma_lamina', mestre_taekwon: null,
}; // nível exigido para cada tier

// ------------------------------------------------------------------
// Habilidades
// target: self | enemy | tile | passive
// ------------------------------------------------------------------
const pct = (n) => Math.round(n * 100) + '%';
export const SKILLS = {
  // Aprendiz
  primeiros_socorros: { name: 'Primeiros Socorros', icon: '🩹', target: 'self', max: 5, sp: (l) => 3,
    heal: (l, h) => 10 + l * 8 + h.lv * 2, desc: (l) => `Recupera ${10 + l * 8} + 2×nível de HP.` },
  faisca_arcana: { name: 'Faísca Arcana', icon: '✨', target: 'enemy', range: 4, max: 5, sp: (l) => 5,
    kind: 'magic', el: 'neutro', base: (l) => 20 + l * 2, mult: (l) => 0.05 + l * 0.006, proj: '#c8b8ff',
    desc: (l) => `Dispara uma faísca mágica: ${Math.round(20 + l * 2)} + ${pct(0.05 + l * 0.006)} do ATQM. Um truque de aprendiz: fraco, mas barato.` },
  arremessar_pedra: { name: 'Arremessar Pedra', icon: '🥌', target: 'enemy', range: 4, max: 5, sp: (l) => 3,
    kind: 'phys', useDex: true, base: (l) => 10 + l * 3, mult: (l) => 0.5 + l * 0.06, proj: '#b8a890',
    desc: (l) => `Arremessa uma pedra: ${Math.round(10 + l * 3)} + ${pct(0.5 + l * 0.06)} do ataque à distância. Um truque de aprendiz: ajuda no começo e perde força depois.` },
  resistencia: { name: 'Resistência', icon: '🫀', target: 'passive', max: 5,
    mods: (l) => ({ hpPct: l * 3, regenHp: l * 0.5 }), desc: (l) => `+${l * 3}% HP máximo e regeneração.` },

  // Espadachim
  golpe_fulminante: { name: 'Golpe Fulminante', icon: '🗡️', target: 'enemy', range: 1, max: 5, sp: (l) => 4 + l,
    kind: 'phys', base: (l) => 19.87 + l * 4.92, mult: (l) => 0.5125 + l * 0.1281, stun: (l) => l * 6,
    desc: (l) => `Golpe de ${Math.round(19.87 + l * 4.92)} + ${pct(0.5125 + l * 0.1281)} do ATQ. ${l * 6}% de atordoar.` },
  impacto_explosivo: { name: 'Impacto Explosivo', icon: '💥', target: 'self', aoe: 1, max: 5, sp: (l) => 10 + l, cooldown: (l) => 3,
    kind: 'phys', el: 'fogo', base: (l) => 10.21 + l * 2.17, mult: (l) => 0.2679 + l * 0.0558, knock: 1,
    desc: (l) => `Explosão de fogo ao redor: ${Math.round(10.21 + l * 2.17)} + ${pct(0.2679 + l * 0.0558)} do ATQ e empurra.` },
  vigor: { name: 'Vigor', icon: '❤️‍🩹', target: 'passive', max: 5,
    mods: (l) => ({ regenHp: l * 1.5, regenHpPct: l * 0.02 }), desc: (l) => `Regenera HP mais rápido: +${l * 1.5} e +${(l * 0.02).toFixed(2).replace('.', ',')}% do HP máximo por turno.` },
  maestria_espada: { name: 'Maestria com Armas', icon: '⚒️', target: 'passive', max: 5,
    mods: (l) => ({ atk: l * 4, hit: l * 2, pierce: l * 6 }), desc: (l) => `+${l * 4} ATQ, +${l * 2} precisão e seus golpes atravessam ${l * 6}% da DEF.` },

  // Cavaleiro

  // Cavaleiro (duas espadas)
  corte_cruzado: { name: 'Corte Cruzado', icon: '⚔️', target: 'enemy', range: 1, max: 5, sp: (l) => 7 + l,
    kind: 'phys', base: (l) => 101.47 + l * 25.37, mult: (l) => 0.8456 + l * 0.2114, hits: 2, openMul: 2,
    desc: (l) => `Duas lâminas em X: ${Math.round(101.47 + l * 25.37)} + ${pct(0.8456 + l * 0.2114)} do ATQ. Num monstro com Abertura: crítico garantido e o dobro do dano.` },
  redemoinho: { name: 'Redemoinho de Lâminas', icon: '🔄', target: 'self', aoe: 2, max: 5, sp: (l) => 12 + l * 2, cooldown: (l) => 3,
    kind: 'phys', base: (l) => 57.61 + l * 13.62, mult: (l) => 0.4788 + l * 0.1138, hits: 2, knock: 1, crowdBonus: 10, fervor: 3,
    desc: (l) => `Gira com as duas espadas atingindo tudo a até 2 casas: ${Math.round(57.61 + l * 13.62)} + ${pct(0.4788 + l * 0.1138)} do ATQ, +10% por inimigo extra atingido (até +50%). Consome a Abertura de todos que atingir. Com 3 de Fervor (e 2 ou mais alvos, ou um chefe), gasta o Fervor: +30% de dano e atordoa todos.` },
  aparar_golpe: { name: 'Aparar Golpe', icon: '🛡️', target: 'self', guard: true, max: 5, sp: (l) => 4,
    guardPct: (l) => 40 + l * 8,
    desc: (l) => `Fica em guarda até sua próxima ação. Cada golpe corpo a corpo que você levar é aparado: o dano cai ${40 + l * 8}%, quem bateu fica com Abertura (seu próximo golpe nele é crítico garantido) e você ganha 1 de Fervor. O golpe devastador de um chefe também é aparado (${Math.round((40 + l * 8) * 0.75)}% a menos), deixa uma Abertura mais longa e dá 2 de Fervor. Não apara flechas nem magias.` },
  ambidestria: { name: 'Ambidestria', icon: '🤺', target: 'passive', max: 5,
    mods: (l) => ({ doubleAtk: l * 10, atk: l * 8 }), desc: (l) => `${l * 10}% de chance de golpear com as duas espadas e +${l * 8} ATQ.` },

  // Monge
  punhos_triplos: { name: 'Punhos Triplos', icon: '👊', target: 'passive', max: 5,
    mods: (l) => ({ tripleAtk: l * 10, atk: l * 4 }), desc: (l) => `${l * 10}% de chance de uma sequência de 3 socos e +${l * 4} ATQ.` },
  esferas_espirituais: { name: 'Esferas Espirituais', icon: '🔮', target: 'self', buff: true, aura: 20, max: 5, sp: (l) => 8 + l * 2,
    buffs: (l) => ({ id: 'esferas', turns: 30 + l * 6, mods: { atk: l * 12, hit: l * 3, pierce: l * 6 } }),
    desc: (l) => `Invoca ${l} esferas: +${l * 12} ATQ, +${l * 3} precisão e seus golpes atravessam ${l * 6}% da DEF. Aura: fica ligada e reserva 20% do SP.` },
  palma_ferro: { name: 'Palma de Ferro', icon: '🖐️', target: 'enemy', range: 1, max: 5, sp: (l) => 9 + l, cooldown: (l) => 3,
    kind: 'phys', base: (l) => 103.84 + l * 25.99, mult: (l) => 0.8664 + l * 0.2168, stun: (l) => 15 + l * 6, knock: 1,
    desc: (l) => `Golpe concentrado: ${Math.round(103.84 + l * 25.99)} + ${pct(0.8664 + l * 0.2168)} do ATQ, ${15 + l * 6}% de atordoar e empurra.` },
  combo_cadeia: { name: 'Combo em Cadeia', icon: '⛓️', target: 'passive', max: 5,
    mods: (l) => ({ combo: l * 12, atk: l * 3 }), desc: (l) => `Depois dos Punhos Triplos, ${l * 12}% de chance de emendar um golpe de ${pct(2 + l * 0.4)} do ATQ. +${l * 3} ATQ.` },
  asura: { name: 'Punho de Asura', icon: '🌋', target: 'enemy', range: 1, max: 5, sp: (l) => 20, allSp: true, noRegen: 10,
    kind: 'phys', base: (l) => 300 + l * 80, mult: (l, spent = 20) => 6 + l * 1.2 + spent / 25, sureHit: true, defPierce: 60,
    desc: (l) => `Ultimato: gasta TODO o SP num golpe de ${Math.round(300 + l * 80)} + ${pct(6 + l * 1.2)} do ATQ, e mais 4% do ATQ por ponto de SP gasto. Nunca erra e ignora 60% da DEF. Depois, o SP não se recupera por 10 turnos.` },
  zen: { name: 'Zen', icon: '🧘', target: 'self', max: 5, sp: (l) => 0, cooldown: (l) => 40 - l * 2,
    restoreSp: (l) => 0.15 + l * 0.05,
    desc: (l) => `Medita por um turno: recupera ${Math.round((0.15 + l * 0.05) * 100)}% do SP na hora (inclusive logo depois do Asura) e acende as esferas. Recarga: ${40 - l * 2} turnos.` },

  // Ninja
  kunai: { name: 'Arremesso de Kunai', icon: '📍', target: 'enemy', range: 5, max: 5, sp: (l) => 15,
    kind: 'phys', base: (l) => 27.72 + l * 13.86, mult: (l) => 0.4158 + l * 0.1386, proj: '#d8dce8', bleed: 1,
    desc: (l) => `Arremessa uma kunai a distância: ${Math.round(27.72 + l * 13.86)} + ${pct(0.4158 + l * 0.1386)} do ATQ e 1 de Sangria. Uma técnica básica: ajuda muito no começo e perde força depois.` },
  pulsar_sangue: { name: 'Pulsar Sangue', icon: '🩸', target: 'self', aoe: 1, max: 5, sp: (l) => 15,
    kind: 'blood', base: (l) => 40 + l * 10, mult: (l) => 0.35 + l * 0.07, lost: (l) => 2 + l * 0.4,
    desc: (l) => `O sangue dos monstros em volta (3×3) explode e a Sangria acaba. Cada acúmulo de Sangria causa ${40 + l * 10} + ${pct(0.35 + l * 0.07)} do ATQ e mais ${(2 + l * 0.4).toFixed(1).replace('.', ',')}% da vida que o monstro já perdeu (nos chefes essa parte tem limite). Ignora a DEF. Só atinge quem está sangrando.` },
  substituicao: { name: 'Substituição', icon: '🪵', target: 'self', buff: true, max: 5, sp: (l) => 30,
    buffs: (l) => ({ id: 'substituicao', turns: 30, mods: { flee: 10 + l * 5 } }),
    desc: (l) => `Troca de lugar com um tronco ao ser atacado: +${10 + l * 5} esquiva por 30 turnos.` },
  passos_sombra: { name: 'Passos da Sombra', icon: '👣', target: 'passive', max: 5,
    mods: (l) => ({ agi: l, speed: l * 3, crit: l }), desc: (l) => `+${l} AGI, +${l * 3} velocidade e +${l}% crítico.` },

  // Shinobi
  lamina_fantasma: { name: 'Lâmina Fantasma', icon: '🌫️', target: 'enemy', range: 3, max: 5, sp: (l) => 30,
    kind: 'phys', base: (l) => 151.5 + l * 37.8, mult: (l) => 1.26 + l * 0.315, critBonus: 20, sureHit: true, bleed: 2,
    desc: (l) => `Avança como um borrão e corta: ${Math.round(151.5 + l * 37.8)} + ${pct(1.26 + l * 0.315)} do ATQ, +20% crítico, alcance 3, e 2 de Sangria.` },
  chuva_shuriken: { name: 'Chuva de Shurikens', icon: '💫', target: 'self', aoe: 2, max: 5, sp: (l) => 35,
    kind: 'phys', base: (l) => 83.8 + l * 20.9, mult: (l) => 0.696 + l * 0.173, hits: 3, bleed: 1,
    desc: (l) => `Shurikens em todas as direções, raio 2: ${Math.round(83.8 + l * 20.9)} + ${pct(0.696 + l * 0.173)} do ATQ e 1 de Sangria em cada um.` },
  clones_sombra: { name: 'Clones de Sombra', icon: '👥', target: 'self', buff: true, max: 5, sp: (l) => 40,
    buffs: (l) => ({ id: 'clones', turns: 15 + l * 3, mods: { flee: 15 + l * 3, crit: 10 } }),
    desc: (l) => `Clones confundem os inimigos: +${15 + l * 3} esquiva e +10% crítico por ${15 + l * 3} turnos.` },
  arte_ninja: { name: 'Arte Ninja', icon: '🥷', target: 'passive', max: 5,
    mods: (l) => ({ atk: l * 8, bleedHit: l * 20 }), desc: (l) => `+${l * 8} ATQ e o ataque básico tem ${l * 20}% de chance de aplicar 1 de Sangria.` },

  // Taekwon
  chute_giratorio: { name: 'Chute Giratório', icon: '🌀', target: 'self', aoe: 1, max: 5, sp: (l) => 10 + l, cooldown: (l) => 3,
    kind: 'phys', base: (l) => 24 + l * 4.86, mult: (l) => 0.63 + l * 0.126, knock: 1,
    desc: (l) => `Gira chutando tudo em volta: ${Math.round(24 + l * 4.86)} + ${pct(0.63 + l * 0.126)} do ATQ e empurra.` },
  chute_machado: { name: 'Chute Machado', icon: '🦶', target: 'enemy', range: 1, max: 5, sp: (l) => 8 + l,
    kind: 'phys', base: (l) => 22.56 + l * 5.4, mult: (l) => 0.5882 + l * 0.1393, stun: (l) => 10 + l * 5,
    desc: (l) => `Calcanhar descendo como um machado: ${Math.round(22.56 + l * 5.4)} + ${pct(0.5882 + l * 0.1393)} do ATQ, ${10 + l * 5}% de atordoar. Com Ritmo 3 ou mais, atordoa sempre (o chefe fica lento).` },
  chute_rasteira: { name: 'Chute Rasteira', icon: '🦿', target: 'enemy', range: 1, max: 5, sp: (l) => 7,
    kind: 'phys', base: (l) => 19 + l * 4.6, mult: (l) => 0.5 + l * 0.118, slow: 3,
    desc: (l) => `Chute baixo e rápido nas pernas: ${Math.round(19 + l * 4.6)} + ${pct(0.5 + l * 0.118)} do ATQ e deixa o alvo lento por 3 turnos.` },
  ritmo: { name: 'Ritmo', icon: '🥁', target: 'passive', max: 1,
    mods: (l) => ({ ritmo: 1 }),
    desc: (l) => `Cada chute diferente do anterior dá 1 de Ritmo (até 5); repetir o mesmo chute zera. Cada ponto dá +8% de dano nos chutes. Com 5, o próximo chute é o Golpe Final: dobro do dano, e o Ritmo recomeça. Andar e o ataque básico não quebram a sequência; ficar 3 turnos sem chutar, ser atordoado ou congelado, sim.` },
  postura_taekwon: { name: 'Postura de Combate', icon: '🥋', target: 'self', buff: true, aura: 15, max: 5, sp: (l) => 12,
    buffs: (l) => ({ id: 'postura', turns: 25 + l * 5, mods: { agi: l + 1, flee: l * 3, atk: l * 5 } }),
    desc: (l) => `+${l + 1} AGI, +${l * 3} esquiva e +${l * 5} ATQ. Aura: fica ligada e reserva 15% do SP.` },
  corrida: { name: 'Corrida', icon: '🏃', target: 'passive', max: 5,
    mods: (l) => ({ speed: l * 5, agi: l, unarmedAtk: l * 8 }), desc: (l) => `+${l * 5} velocidade, +${l} AGI e +${l * 8} ATQ lutando sem arma.` },

  // Mestre Taekwon
  chute_voador: { name: 'Chute Voador', icon: '🦵', target: 'enemy', range: 4, max: 5, sp: (l) => 14 + l * 2, cooldown: (l) => 3,
    kind: 'phys', base: (l) => 119.59 + l * 34.17, mult: (l) => 0.8542 + l * 0.2733, sureHit: true, knock: 1,
    desc: (l) => `Salta até o alvo com um chute: ${Math.round(119.59 + l * 34.17)} + ${pct(0.8542 + l * 0.2733)} do ATQ, alcance 4, nunca erra. Ao aterrissar: +15 de esquiva por 3 turnos.` },
  chute_ascendente: { name: 'Chute Ascendente', icon: '🦵', target: 'enemy', range: 1, max: 5, sp: (l) => 15,
    kind: 'phys', base: (l) => 100 + l * 28, mult: (l) => 0.75 + l * 0.22, critBonus: 35,
    desc: (l) => `Chute de baixo para cima: ${Math.round(100 + l * 28)} + ${pct(0.75 + l * 0.22)} do ATQ e +35% de chance de crítico. Ótimo para o Golpe Final num alvo só.` },
  furia_solar: { name: 'Fúria do Sol', icon: '🌞', target: 'self', aoe: 2, max: 5, sp: (l) => 20 + l * 3,
    kind: 'phys', el: 'fogo', base: (l) => 66.65 + l * 16.68, mult: (l) => 0.5562 + l * 0.1394, burn: (l) => 50,
    desc: (l) => `Chute flamejante em raio 2: ${Math.round(66.65 + l * 16.68)} + ${pct(0.5562 + l * 0.1394)} do ATQ de fogo e 50% de chance de deixar queimando.` },
  protecao_estelar: { name: 'Escudo Estelar', icon: '⭐', target: 'self', buff: true, max: 5, sp: (l) => 24,
    buffs: (l) => ({ id: 'kyrie', turns: 25, mods: { def: l * 3 }, shieldPct: 0.06 + l * 0.03 }),
    desc: (l) => `Escudo de estrelas que absorve ${Math.round((0.06 + l * 0.03) * 100)}% do HP máximo em dano, +${l * 3} DEF.` },
  unidade_corpo: { name: 'Unidade do Corpo', icon: '☯️', target: 'passive', max: 5,
    mods: (l) => ({ hpPct: l * 4, atk: l * 5, crit: l, unarmedAtk: l * 12 }), desc: (l) => `+${l * 4}% HP, +${l * 5} ATQ, +${l}% crítico e +${l * 12} ATQ lutando sem arma.` },

  // Mago
  lanca_fogo: { name: 'Leão de Fogo', icon: '🔥', target: 'enemy', range: 5, max: 5, sp: (l) => 10,
    kind: 'magic', el: 'fogo', base: (l) => 18 + l * 7.5, mult: (l) => 0.076 + l * 0.042, cast: 1, proj: '#ff7a3d',
    desc: (l) => `Fogo: ${Math.round(18 + l * 7.5)} + ${pct(0.076 + l * 0.042)} do ATQM. Chance de deixar queimando. Contra um alvo petrificado: racha a pedra com 10× o dano e 85% de chance de queimar (95% dentro do Campo Gravitacional).` },
  lanca_gelo: { name: 'Presas de Gelo', icon: '🧊', target: 'enemy', range: 5, max: 5, sp: (l) => 10,
    kind: 'magic', el: 'agua', base: (l) => 34.79 + l * 14.49, mult: (l) => 0.1469 + l * 0.0812, cast: 1, freeze: (l) => 20 + l * 8, proj: '#7fd3ff',
    desc: (l) => `Água: ${Math.round(34.79 + l * 14.49)} + ${pct(0.1469 + l * 0.0812)} do ATQM e ${20 + l * 8}% de congelar. Prepara o combo com vento. Em quem está queimando: vapor (5,5× o dano) e 90% de congelar (95% no Campo Gravitacional).` },
  relampago: { name: 'Garra Relâmpago', icon: '⚡', target: 'enemy', range: 5, max: 5, sp: (l) => 10,
    kind: 'magic', el: 'vento', base: (l) => 17.06 + l * 7.11, mult: (l) => 0.072 + l * 0.0398, cast: 1, proj: '#d8fff0',
    desc: (l) => `Vento: ${Math.round(17.06 + l * 7.11)} + ${pct(0.072 + l * 0.0398)} do ATQM. Contra um alvo congelado: estilhaça o gelo com 6× o dano.` },
  congelar: { name: 'Prisão de Gelo', icon: '❄️', target: 'self', aoe: 2, max: 5, sp: (l) => 22,
    kind: 'magic', el: 'agua', base: (l) => 30.55 + l * 12.21, mult: (l) => 0.1667 + l * 0.0538, freeze: (l) => 30 + l * 8, cast: 1.4,
    desc: (l) => `Onda de gelo à sua volta: ${Math.round(30.55 + l * 12.21)} + ${pct(0.1667 + l * 0.0538)} do ATQM e ${30 + l * 8}% de congelar. Raios estilhaçam o gelo. Quem está queimando leva vapor (5,5×) e 90% de congelar (95% no Campo Gravitacional).` },
  escudo_petrificante: { name: 'Proteção Arcana', icon: '🛡️', target: 'self', buff: true, aura: 20, max: 5, sp: (l) => 10 + l * 2,
    buffs: (l) => ({ id: 'escudo_petrificante', turns: 999, mods: { dmgReduce: 6 + l * 4 } }),
    desc: (l) => `Um escudo arcano envolve o mago e reduz em ${6 + l * 4}% todo dano recebido. Aura: reserva parte do SP enquanto ligada.` },
  meditacao: { name: 'Meditação', icon: '📿', target: 'passive', max: 5,
    mods: (l) => ({ spPct: l * 6, regenSp: l * 0.6 }), desc: (l) => `+${l * 6}% SP e regeneração de SP.` },

  // Bruxo
  olhar_medusa: { name: 'Olhar da Medusa', icon: '🐍', target: 'tile', range: 5, aoe: 2, max: 5, sp: (l) => 26, cast: 1.4,
    kind: 'petrifyArea', petrify: (l) => 48 + l * 8,
    desc: (l) => `Um olhar de pedra varre a área (raio 2): sem dano, mas ${48 + l * 8}% de chance de petrificar cada monstro por 6 turnos (5 em chefes); dentro do Campo Gravitacional, 95%. Petrificados não agem e o fogo os racha.` },
  meteoro: { name: 'Chuva de Meteoros', icon: '☄️', target: 'tile', range: 4, aoe: 2, max: 5, sp: (l) => 38,
    kind: 'magic', el: 'fogo', base: (l) => 17.86 + l * 7.14, mult: (l) => 0.0723 + l * 0.0284, stun: (l) => 10, cast: 2,
    desc: (l) => `Meteoros: ${Math.round(17.86 + l * 7.14)} + ${pct(0.0723 + l * 0.0284)} do ATQM, pode atordoar e tem chance de deixar queimando. Monstros petrificados na área racham com 10× o dano e têm 85% de chance de queimar (95% no Campo Gravitacional).` },
  nevasca: { name: 'Nevasca', icon: '🌨️', target: 'tile', range: 4, aoe: 2, max: 5, sp: (l) => 34,
    kind: 'magic', el: 'agua', base: (l) => 40.31 + l * 16.25, mult: (l) => 0.1604 + l * 0.0657, freeze: (l) => 40 + l * 8, cast: 1.8,
    desc: (l) => `Tempestade de gelo: ${Math.round(40.31 + l * 16.25)} + ${pct(0.1604 + l * 0.0657)} do ATQM e ${40 + l * 8}% de congelar. Prepara a Ira de Thor. Quem está queimando leva vapor (5,5×) e 90% de congelar (95% no Campo Gravitacional).` },
  vortice_jupiter: { name: 'Trovão de Júpiter', icon: '🌩️', target: 'enemy', range: 5, max: 5, sp: (l) => 22, cooldown: (l) => 4,
    kind: 'magic', el: 'vento', base: (l) => 21.54 + l * 7.64, mult: (l) => 0.0868 + l * 0.0315, cast: 1, knock: 2, proj: '#b9fff0',
    desc: (l) => `Esfera elétrica: ${Math.round(21.54 + l * 7.64)} + ${pct(0.0868 + l * 0.0315)} do ATQM e empurra. Contra um alvo congelado: estilhaça com 6× o dano.` },
  ira_thor: { name: 'Ira de Thor', icon: '⛈️', target: 'tile', range: 4, aoe: 2, max: 5, sp: (l) => 32,
    kind: 'magic', el: 'vento', base: (l) => 13.25 + l * 5.3, mult: (l) => 0.0537 + l * 0.0211, cast: 1.2,
    desc: (l) => `Raios caem do céu em toda a área: ${Math.round(13.25 + l * 5.3)} + ${pct(0.0537 + l * 0.0211)} do ATQM. Monstros congelados na área estilhaçam com 6× o dano.` },
  amplificacao: { name: 'Amplificação', icon: '📖', target: 'passive', max: 5,
    mods: (l) => ({ matkPct: l * 5, int: l }), desc: (l) => `+${l * 5}% ATQM e +${l} INT.` },

  // Arqueiro
  tiro_duplo: { name: 'Tiro Duplo', icon: '🏹', target: 'enemy', range: 6, needsBow: true, max: 5, sp: (l) => 8,
    kind: 'phys', base: (l) => 31.33 + l * 6.44, mult: (l) => 0.8062 + l * 0.166, hits: 2, proj: '#f0e2b6',
    desc: (l) => `Dois disparos: ${Math.round(31.33 + l * 6.44)} + ${pct(0.8062 + l * 0.166)} do ATQ. Exige arco ou besta.` },
  chuva_flechas: { name: 'Chuva de Flechas', icon: '🌧️', target: 'tile', range: 5, aoe: 1, needsBow: true, max: 5, sp: (l) => 12, cooldown: (l) => 3,
    kind: 'phys', base: (l) => 14.4 + l * 3.24, mult: (l) => 0.37 + l * 0.084, knock: 1,
    desc: (l) => `Disparos em raio 1: ${Math.round(14.4 + l * 3.24)} + ${pct(0.37 + l * 0.084)} do ATQ. Exige arco ou besta.` },
  olhos_coruja: { name: 'Olhos de Coruja', icon: '🦉', target: 'passive', max: 5,
    mods: (l) => ({ dex: l * 2, regenSp: l * 0.2 }), desc: (l) => `+${l * 2} DES e +${(l * 0.2).toFixed(1).replace('.', ',')} SP por turno.` },
  olho_aguia: { name: 'Olho de Águia', icon: '👁️', target: 'passive', max: 5,
    mods: (l) => ({ hit: l * 3, crit: l }), desc: (l) => `+${l * 3} precisão e +${l}% crítico.` },

  // Caçador
  tiro_certeiro: { name: 'Virote Perfurante', icon: '🔩', target: 'enemy', range: 7, needsBow: true, line: true, max: 5, sp: (l) => 26,
    kind: 'phys', base: (l) => 101.34 + l * 25.34, mult: (l) => 0.8436 + l * 0.2109, critBonus: 25, proj: '#ffe8a0',
    desc: (l) => `Disparo que atravessa a linha: ${Math.round(101.34 + l * 25.34)} + ${pct(0.8436 + l * 0.2109)} do ATQ, +25% crítico. Exige arco ou besta.` },
  rede: { name: 'Rede de Caça', icon: '🕸️', target: 'enemy', range: 5, max: 5, sp: (l) => 10,
    kind: 'status', snare: (l) => 2 + l, proj: '#d9c48a', prey: true,
    desc: (l) => `Prende o alvo por ${2 + l} turnos (o chefe só fica lento) e marca como Presa por 10 turnos, mesmo que a rede se solte: o falcão ataca a Presa e seus tiros nela têm +25% de crítico.` },
  armadilha: { name: 'Armadilha', icon: '🪤', target: 'tile', range: 3, max: 5, sp: (l) => 10,
    kind: 'trap', snare: (l) => 2 + l, base: (l) => 30 + l * 10, mult: (l) => 0.3 + l * 0.06,
    desc: (l) => `Arma uma armadilha numa casa livre a até 3 de distância (até 2 armadas de cada vez). O primeiro monstro que pisar leva ${30 + l * 10} + ${pct(0.3 + l * 0.06)} do ATQ, fica preso por ${2 + l} turnos (o chefe só fica lento) e vira Presa.` },
  salto_tras: { name: 'Salto para Trás', icon: '🦘', target: 'enemy', range: 5, needsBow: true, max: 5, sp: (l) => 14, cooldown: (l) => 4,
    kind: 'phys', leapBack: 2, base: (l) => 60 + l * 15, mult: (l) => 0.6 + l * 0.12, proj: '#f0e2b6',
    desc: (l) => `Salta até 2 casas para longe do alvo e atira no ar: ${60 + l * 15} + ${pct(0.6 + l * 0.12)} do ATQ. Recarga de 4 turnos. Exige arco ou besta.` },
  virote_impacto: { name: 'Virote de Impacto', icon: '🔨', target: 'enemy', range: 5, needsBow: true, max: 5, sp: (l) => 12, cooldown: (l) => 4,
    kind: 'phys', knock: 2, base: (l) => 70 + l * 17, mult: (l) => 0.7 + l * 0.14, proj: '#c8a060',
    desc: (l) => `Virote pesado que empurra o alvo 2 casas: ${70 + l * 17} + ${pct(0.7 + l * 0.14)} do ATQ. Chefes não são empurrados. Recarga de 4 turnos. Exige arco ou besta.` },
  falcao: { name: 'Falcão de Caça', icon: '🦅', target: 'passive', max: 5,
    mods: (l) => ({ falcon: l }), desc: (l) => `${l * 7}% de chance do falcão atacar junto (ignora esquiva).` },
  instinto: { name: 'Instinto', icon: '🍀', target: 'passive', max: 5,
    mods: (l) => ({ agi: l, flee: l * 3 }), desc: (l) => `+${l} AGI e +${l * 3} esquiva.` },

  // Gatuno
  ataque_duplo: { name: 'Ataque Duplo', icon: '✌️', target: 'passive', max: 5,
    mods: (l) => ({ doubleAtk: l * 12 }), desc: (l) => `${l * 12}% de chance de golpear duas vezes.` },
  envenenar_arma: { name: 'Envenenar Arma', icon: '🐍', target: 'self', aura: 15, max: 5, sp: (l) => 12,
    buffs: (l) => ({ id: 'veneno_arma', mods: { poisonFlat: 6 + l * 6, poisonChance: 10 + l * 6 } }),
    desc: (l) => `Aura (reserva 15% do SP): cada ataque básico causa +${6 + l * 6} de dano de veneno e tem ${10 + l * 6}% de envenenar.` },
  esconderijo: { name: 'Esconderijo', icon: '🫥', target: 'self', buff: true, max: 5, sp: (l) => 10,
    buffs: (l) => ({ id: 'oculto', still: true, turns: 4 + l * 2, mods: {} }),
    desc: (l) => `Esconde-se no chão por até ${4 + l * 2} turnos: não dá para andar, os monstros te esquecem e você recupera HP e SP 2× mais rápido. Gasta 1% do SP por turno.` },
  apunhalar: { name: 'Apunhalar', icon: '🗡️', target: 'enemy', range: 2, max: 5, sp: (l) => 10, cooldown: (l) => 3,
    kind: 'phys', behind: true, base: (l) => 40 + l * 10, mult: (l) => 0.9 + l * 0.18, sureHit: true,
    desc: (l) => `Aparece atrás do alvo (a até 2 casas) e crava a lâmina: ${40 + l * 10} + ${pct(0.9 + l * 0.18)} do ATQ. Saindo da sombra, é Emboscada (crítico garantido e +50%). Recarga de 3 turnos.` },
  bomba_fumaca: { name: 'Bomba de Fumaça', icon: '💨', target: 'self', max: 5, sp: (l) => 14, cooldown: (l) => 14,
    kind: 'smoke', smoke: (l) => 2 + l,
    desc: (l) => `Fumaça em volta de você (3×3) por ${2 + l} turnos. Dentro dela os monstros não te enxergam: você fica na sombra e volta para ela a cada turno, mesmo depois de atacar. Recarga de 14 turnos.` },
  explosao_veneno: { name: 'Explosão de Veneno', icon: '🧪', target: 'enemy', range: 1, aoe: 1, max: 5, sp: (l) => 12, needsPoison: true,
    kind: 'phys', base: (l) => 30 + l * 8, mult: (l) => 0.5 + l * 0.1, poison: (l) => 40 + l * 10,
    desc: (l) => `Só com Envenenar Arma ligada: golpeia o alvo e o veneno da lâmina explode em volta dele (3×3): ${30 + l * 8} + ${pct(0.5 + l * 0.1)} do ATQ em cada um e ${40 + l * 10}% de envenenar.` },

  // Assassino
  laminas_sonicas: { name: 'Lâminas do Vento', icon: '💨', target: 'enemy', range: 1, max: 5, sp: (l) => 16 + l * 2,
    kind: 'phys', base: (l) => 198.98 + l * 53.06, mult: (l) => 1.6582 + l * 0.4422, hits: 8, stun: (l) => 10 + l * 2,
    desc: (l) => `8 golpes rápidos: ${Math.round(198.98 + l * 53.06)} + ${pct(1.6582 + l * 0.4422)} do ATQ, pode atordoar.` },
  garra_sombria: { name: 'Garra Sombria', icon: '🐾', target: 'tile', range: 3, aoe: 1, max: 5, sp: (l) => 8 + l,
    kind: 'phys', el: 'sombrio', base: (l) => 75 + l * 25, mult: (l) => 0.64 + l * 0.212, ambush: true,
    desc: (l) => `Ataque sombrio em raio 1 a distância: ${Math.round(75 + l * 25)} + ${pct(0.64 + l * 0.212)} do ATQ. Usada invisível: ataque surpresa (+50%), mas revela você.` },
  furtividade: { name: 'Furtividade', icon: '🌑', target: 'self', buff: true, max: 5, sp: (l) => 14,
    buffs: (l) => ({ id: 'oculto', turns: 8 + l * 3, mods: { crit: 30 } }),
    desc: (l) => `Anda invisível por até ${8 + l * 3} turnos com +30% de crítico; o primeiro ataque é surpresa (+50%). Gasta 2% do SP por turno.` },
  maestria_katar: { name: 'Maestria com Katar', icon: '🔪', target: 'passive', max: 5,
    mods: (l) => ({ crit: l * 2, atk: l * 4, critDmg: l * 6 }), desc: (l) => `+${l * 2}% crítico, +${l * 4} ATQ e +${l * 6}% de dano crítico. Dobra com katar.` },
  execucao: { name: 'Execução', icon: '⚰️', target: 'enemy', range: 1, max: 5, sp: (l) => 18,
    kind: 'phys', base: (l) => 120 + l * 30, mult: (l) => 1 + l * 0.25, execute3: true,
    desc: (l) => `Golpe finalizador: ${120 + l * 30} + ${pct(1 + l * 0.25)} do ATQ. Em monstro com menos de 30% de vida causa o triplo (em vez do dobro da Execução comum). Não vale em chefes.` },

  // Noviço
  curar: { name: 'Curar', icon: '💚', target: 'self', max: 5, sp: (l) => 8 + l * 3,
    heal: (l, h, d) => 100 + l * 10 + d.int * 2 + h.lv * 2,
    desc: (l) => `Cura ${100 + l * 10} + 2×INT + 2×nível de HP.` },
  bencao: { name: 'Bênção', icon: '🙏', target: 'self', buff: true, aura: 20, max: 5, sp: (l) => 12 + l * 2,
    buffs: (l) => ({ id: 'bencao', turns: 30 + l * 10, mods: { str: l + 1, int: l + 1, dex: l + 1, agi: l + 1, speed: l * 3 } }),
    desc: (l) => `+${l + 1} FOR, AGI, INT e DES e +${l * 3} velocidade. Aura: fica ligada e reserva 20% do SP.` },
  luz_divina: { name: 'Luz Divina', icon: '🔆', target: 'enemy', range: 5, max: 5, sp: (l) => 12,
    kind: 'magic', el: 'sagrado', base: (l) => 95.03 + l * 15.54, mult: (l) => 0.0864 + l * 0.0104, cast: 1, proj: '#fff2b0',
    desc: (l) => `Raio sagrado: ${Math.round(95.03 + l * 15.54)} + ${pct(0.0864 + l * 0.0104)} do ATQM. Forte contra mortos-vivos. Dano base alto, mas cresce pouco com o ATQM.` },

  // Sacerdote
  kyrie: { name: 'Barreira Sagrada', icon: '🫧', target: 'self', buff: true, max: 5, sp: (l) => 20,
    buffs: (l) => ({ id: 'kyrie', turns: 25, mods: {}, blockHits: 1 + l, blockPct: 30 + l * 4 }),
    desc: (l) => `Escudo sagrado: reduz em ${30 + l * 4}% o dano dos próximos ${1 + l} golpes (golpes de chefe contam como 2). Dura 25 turnos.` },

  // Mercador

  // Ferreiro

  // ---------- Transcendentais ----------
  ofensiva_furiosa: { name: 'Ofensiva Furiosa', icon: '💥', target: 'tile', range: 4, aoe: 1, max: 5, sp: (l) => 14 + l * 2, cooldown: (l) => 3,
    kind: 'phys', leap: true, sureHit: true, base: (l) => 40 + l * 10, mult: (l) => 0.35 + l * 0.08, stun: (l) => 15 + l * 5, openOnStun: true, fervor: 1,
    desc: (l) => `Salta até uma casa a até 4 de distância (ou para perto do monstro escolhido) e cai com as duas espadas: ${40 + l * 10} + ${pct(0.35 + l * 0.08)} do ATQ em quem estiver em volta (3×3) e ${15 + l * 5}% de atordoar. Quem fica atordoado ganha Abertura. Com 1 de Fervor, gasta e você já aterrissa em guarda. Recarga de 3 turnos.` },
  fervor_batalha: { name: 'Fervor de Batalha', icon: '😤', target: 'passive', max: 5,
    mods: (l) => ({ rage: l }), desc: (l) => `Cada ponto de Fervor guardado dá +${(2 + l * 0.4).toFixed(1).replace('.', ',')}% de ATQ (até +${Math.round((2 + l * 0.4) * 5)}% com 5). Guardar aumenta o dano; gastar libera os golpes fortes. Como Lorde, vira a Fúria de Batalha.` },
  furia_batalha: { name: 'Fúria de Batalha', icon: '😡', target: 'passive', max: 5,
    mods: (l) => ({ rageUp: l }), desc: (l) => `Aprimora o Fervor de Batalha: o Fervor guarda até ${5 + Math.ceil(l / 2)} pontos, cada ponto dá +5% de ATQ, cada 3 golpes num chefe também dão 1 ponto e cada ponto ganho recupera 0,5% do SP.` },
  frenesi: { name: 'Frenesi', icon: '🩸', target: 'self', buff: true, max: 5, sp: (l) => 30,
    buffs: (l) => ({ id: 'frenesi', turns: 10 + l * 2, mods: { atkPct: 40 + l * 12, speed: 30, crit: 10 + l * 4, lifesteal: 2 + l } }),
    desc: (l) => `+${40 + l * 12}% ATQ, +30 velocidade, +${10 + l * 4}% de crítico (o crítico ignora a DEF) e ${2 + l}% de roubo de vida por ${10 + l * 2} turnos. Durante o Frenesi: sem poções e sem outras habilidades.` },
  perfuracao_espiral: { name: 'Perfuração Espiral', icon: '🌪️', target: 'enemy', range: 2, max: 5, sp: (l) => 22,
    kind: 'phys', base: (l) => 278.24 + l * 69.56, mult: (l) => 0.9988 + l * 0.2497, weightBonus: true, sureHit: true, defPierce: 50, openPierce: true, fervor: 5,
    desc: (l) => `Investida giratória a até 2 casas: ${Math.round(278.24 + l * 69.56)} + ${pct(0.9988 + l * 0.2497)} do ATQ, +25% por nível da arma. Nunca erra e atravessa 50% da DEF (toda a DEF num alvo com Abertura). Com 5 de Fervor, gasta tudo: atravessa toda a DEF e causa o dobro do dano.` },
  campo_gravitacional: { name: 'Campo Gravitacional', icon: '🕳️', target: 'tile', range: 5, aoe: 2, max: 5, sp: (l) => 30,
    kind: 'field', field: (l) => ({ turns: 4 + l, mult: 0.03 + l * 0.01 }),
    desc: (l) => `Suporte instantâneo: cria um campo de gravidade em raio 2 por ${4 + l} turnos. Quem está dentro fica lento (age na metade da velocidade) e perde 30% da DEFM; ali os combos pegam mais fácil (petrificar, queimar a pedra e congelar quem queima chegam a 95%), o que dá tempo para conjurar as magias grandes, e sofre ${pct(0.03 + l * 0.01)} do ATQM por turno, ignorando DEFM.` },
  absorver_alma: { name: 'Absorver Alma', icon: '👻', target: 'passive', max: 5,
    mods: (l) => ({ soulDrain: l * 2 }), desc: (l) => `Cada monstro morto por magia devolve ${l * 2}% do SP máximo.` },
  tiro_preciso: { name: 'Tiro Preciso', icon: '🎯', target: 'enemy', range: 7, needsBow: true, line: true, max: 5, sp: (l) => 32,
    kind: 'phys', base: (l) => 284.2 + l * 65.52, mult: (l) => 1.0192 + l * 0.2352, critBonus: 100, proj: '#fff2b0',
    desc: (l) => `Flecha que atravessa todos em linha: ${Math.round(284.2 + l * 65.52)} + ${pct(1.0192 + l * 0.2352)} do ATQ, sempre crítico. Exige arco ou besta.` },
  ataque_falcao: { name: 'Ataque do Falcão', icon: '🪶', target: 'enemy', range: 7, max: 5, sp: (l) => 22,
    kind: 'falcon', proj: '#ffe8a0',
    desc: (l) => `O falcão mergulha no alvo: (3×DES + 2×INT + 2×nível) × ${(0.8 + l * 0.4).toFixed(1)}. Ignora esquiva e DEF.` },
  veneno_mortal: { name: 'Presas da Víbora', icon: '☠️', target: 'self', aura: 25, max: 5, sp: (l) => 40,
    buffs: (l) => ({ id: 'veneno_mortal', mods: { atkPct: 20 + l * 8, deadlyPoison: 1 } }),
    desc: (l) => `Aura (reserva 25% do SP): +${20 + l * 8}% ATQ e o veneno nos inimigos causa o dobro. Corrói a arma: cada golpe tem 0,5% de chance de perder 1 de refino.` },
  destruidor_almas: { name: 'Destruidor de Almas', icon: '💀', target: 'enemy', range: 3, max: 5, sp: (l) => 26,
    kind: 'phys', base: (l) => 168.1 + l * 38.51, mult: (l) => 0.6034 + l * 0.1383, ignoreDef: true, agiBonus: true, poisonBonus: 50, sureHit: true, proj: '#c47aff',
    desc: (l) => `Golpe à distância (até 3 casas): ${Math.round(168.1 + l * 38.51)} + ${pct(0.6034 + l * 0.1383)} do ATQ + 2×AGI, ignora a DEF. +50% em alvos envenenados.` },
  fusao_estelar: { name: 'Fusão Estelar', icon: '🌠', target: 'self', buff: true, max: 5, sp: (l) => 35, cooldown: (l) => 30,
    buffs: (l) => ({ id: 'fusao', turns: 5, mods: { atkPct: 25 + l * 5 } }),
    desc: (l) => `Explosão estelar por 5 turnos: os chutes não gastam SP, o ATQ sobe ${25 + l * 5}% e o Ritmo não cai por tempo. Cada chute custa 1% do HP. Recarga de 30 turnos.` },
  calor_sol: { name: 'Calor do Sol', icon: '♨️', target: 'self', aura: 20, max: 5, sp: (l) => 30,
    buffs: (l) => ({ id: 'calor_sol', mods: { sunAura: l } }),
    desc: (l) => `Aura (reserva 20% do SP): todo turno queima os inimigos em volta (raio ${l >= 3 ? 2 : 1}) com ${pct(0.2 + l * 0.04)} do ATQ de fogo.` },
  kunai_sangrenta: { name: 'Kunai Sangrenta', icon: '🗡️', target: 'enemy', range: 5, line: true, max: 5, sp: (l) => 35,
    kind: 'phys', base: (l) => 246.5 + l * 58.5, mult: (l) => 0.887 + l * 0.21, bleed: 2, proj: '#c0182a',
    desc: (l) => `Kunai que atravessa todos em linha: ${Math.round(246.5 + l * 58.5)} + ${pct(0.887 + l * 0.21)} do ATQ e 2 de Sangria em cada um.` },
  lua_crescente: { name: 'Lua Crescente', icon: '🌙', target: 'self', buff: true, max: 5, sp: (l) => 40,
    buffs: (l) => ({ id: 'lua', turns: 15 + l * 3, mods: { flee: 10 + l * 4, counter: 10 + l * 5 } }),
    desc: (l) => `+${10 + l * 4} esquiva por ${15 + l * 3} turnos. Ao esquivar de um golpe corpo a corpo, ${10 + l * 5}% de chance de contra-atacar (80% do ATQ) e aplicar 1 de Sangria.` },
};

// O custo de SP não cresce com o nível da habilidade: fica fixo no valor do nível 1
for (const sk of Object.values(SKILLS)) {
  if (typeof sk.sp === 'function') { const c = sk.sp(1); sk.sp = () => c; }
}

// ------------------------------------------------------------------
// Poucos níveis, mesmo efeito final: o último nível novo rende o que o nível 5 rendia.
// Truques do Aprendiz: 1 nível. Dano: 3 níveis (1, 3 e 5 de antes). Suporte, buffs e passivas: 2 níveis (3 e 5 de antes).
// ------------------------------------------------------------------
const SHORT_MAX = { faisca_arcana: 1, arremessar_pedra: 1, protecao_estelar: 3, fusao_estelar: 3, furtividade: 3 };
const DAMAGE_KINDS = new Set(['phys', 'magic', 'falcon', 'blood']);
const isDamageSkill = (sk) => sk.target !== 'passive' && DAMAGE_KINDS.has(sk.kind);
for (const [id, sk] of Object.entries(SKILLS)) {
  if (SHORT_MAX[id] || (sk.max || 1) !== 5) continue;
  SHORT_MAX[id] = isDamageSkill(sk) ? 3 : 2;
}
const OLD_OF = { 1: [5], 2: [3, 5], 3: [1, 3, 5] };
// nível novo -> nível antigo (o que de fato entra nas fórmulas)
export const oldLv = (id, l) => { const n = SHORT_MAX[id]; if (!n || !l) return l; return OLD_OF[n][Math.min(n, l) - 1]; };
// como era antes desta mudança (truques 1; dano 5 sem conversão; o resto 3 = níveis 1, 3, 5): para converter personagens salvos
export const prevOldLv = (id, l) => { const n = SHORT_MAX[id]; if (!n || !l) return l; if (n === 1) return 5; return isDamageSkill(SKILLS[id]) ? l : 1 + (l - 1) * 2; };
export const SKILL_OLD_MAX = {};
for (const [id, n] of Object.entries(SHORT_MAX)) {
  const sk = SKILLS[id]; SKILL_OLD_MAX[id] = sk.max; sk.max = n;
  for (const k of Object.keys(sk)) if (typeof sk[k] === 'function') { const f = sk[k]; sk[k] = (l, ...rest) => f(oldLv(id, l), ...rest); }
}
// nível novo equivalente a um nível antigo (para devolver pontos de quem já tinha): o maior nível novo que não passa do antigo
export const newLvFromOld = (id, L) => { const n = SHORT_MAX[id]; if (!n || !L) return L; let best = 1; for (let l = 1; l <= n; l++) if (oldLv(id, l) <= L) best = l; return n === 1 ? 1 : best; };

// ------------------------------------------------------------------
// Temas / biomas
// ------------------------------------------------------------------
export const THEMES = [
  { name: 'Campos de Prado', floors: [1, 5], lv: [1, 6], floor: ['#3e5f36', '#456b3b'], wall: ['#5a7a4a', '#2f4426', '#3a5530'], accent: '#ffe08a',
    decor: ['grass', 'flower', 'rock', 'grass', 'crate'], liquid: 'agua', ambient: 'rgba(255,240,200,0.05)', light: '#ffd890',
    monsters: ['gelim', 'larvinha', 'cogumelo', 'coelho', 'abelha', 'lobo'], boss: 'rei_gelim' },
  { name: 'Cemitério Assombrado', floors: [6, 10], lv: [7, 14], floor: ['#3a4146', '#40484e'], wall: ['#5d666c', '#2a3034', '#373e43'], accent: '#7fe0a8',
    decor: ['bones', 'skull', 'candle', 'puddle', 'rock'], liquid: 'lodo', ambient: 'rgba(120,255,160,0.04)', light: '#a6ffcf',
    monsters: ['rato', 'morcego', 'sapo', 'barata', 'lodo', 'crocodilo'], boss: 'rainha_barata' },
  { name: 'Dunas de Sombra', floors: [11, 15], lv: [15, 22], floor: ['#8f7448', '#9a7d4e'], wall: ['#b8955e', '#6e5530', '#86683c'], accent: '#ffcf6b',
    decor: ['sand', 'skull', 'cactus', 'barrel'], liquid: 'areia', ambient: 'rgba(255,200,120,0.05)', light: '#ffc874',
    monsters: ['escorpiao', 'serpente', 'mumia', 'aranha', 'golem_areia', 'dancarina'], boss: 'farao' },
  { name: 'Castelo Sombrio', floors: [16, 20], lv: [23, 32], floor: ['#34303f', '#3a3547'], wall: ['#5b5470', '#221f2b', '#2d2939'], accent: '#c9a6ff',
    decor: ['carpet', 'bones', 'candle', 'crystal', 'barrel'], liquid: 'agua', ambient: 'rgba(170,140,255,0.05)', light: '#d8b8ff',
    monsters: ['esqueleto', 'arq_esqueleto', 'fantasma', 'vampiro', 'gargula', 'cavaleiro_fantasma'], boss: 'lorde_sombrio', built: true },
  { name: 'Abismo Ígneo', floors: [21, 25], lv: [33, 42], floor: ['#3b2420', '#432923'], wall: ['#6e3a2c', '#24120e', '#3a1d16'], accent: '#ff8a4a',
    decor: ['ember', 'rock', 'bones', 'crystal'], liquid: 'lava', ambient: 'rgba(255,110,60,0.06)', light: '#ff9a5a',
    monsters: ['diabrete', 'salamandra', 'golem_magma', 'bruxa', 'dragao', 'pesadelo'], boss: 'bafome' },
  // mundos dos transcendentais
  { name: 'Navio Fantasma', floors: [26, 30], lv: [52, 60], floor: ['#5a3e28', '#634430'], wall: ['#6e4a2e', '#2a1a10', '#3a2616'], accent: '#7fe0d0',
    decor: ['barrel', 'crate', 'bones', 'skull', 'barrel'], liquid: 'agua', ambient: 'rgba(120,220,210,0.05)', light: '#9affe8', built: true, trans: true,
    monsters: ['marujo_afogado', 'caranguejo_morto', 'pirata_esqueleto', 'sereia', 'tubarao', 'polvo_abissal'], boss: 'drake' },
  { name: 'Pico Congelado', floors: [31, 35], lv: [62, 70], floor: ['#c8d8e8', '#d4e2ee'], wall: ['#a8c0d8', '#4a5a70', '#6a7a90'], accent: '#bfe8ff',
    decor: ['rock', 'crystal', 'bones', 'rock'], liquid: 'gelo', ambient: 'rgba(200,230,255,0.06)', light: '#cfeaff', trans: true,
    monsters: ['lobo_gelo', 'urso_polar', 'golem_cristal', 'gigante_gelo', 'demonio_nevasca', 'dragao_gelo'], boss: 'garm' },
  { name: 'Torre do Esquecimento', floors: [36, 40], lv: [72, 83], floor: ['#3a2a48', '#40304e'], wall: ['#5a4470', '#1e1428', '#2a1e38'], accent: '#e0a6ff',
    decor: ['candle', 'bones', 'skull', 'crystal', 'carpet'], liquid: 'vazio', ambient: 'rgba(200,140,255,0.06)', light: '#e0b8ff', built: true, trans: true,
    monsters: ['alma_perdida', 'espectro_sombrio', 'carrasco', 'cavaleiro_infernal', 'lich', 'ceifador'], boss: 'thanatos' },
];
export const LAST_FLOOR = 40;
export const FIRST_LIFE_FLOOR = 25; // além daqui, só transcendentais

// monstros dos mundos transcendentais são mais duros que o nível sugere
export const TRANS_MONSTERS = new Set(THEMES.filter((t) => t.trans).flatMap((t) => [...t.monsters, t.boss]));
export const TRANS_HARD = { hp: 1.8, atk: 1.5, def: 1.2 };
export function themeForFloor(f) {
  return THEMES[Math.max(0, Math.min(THEMES.length - 1, Math.floor((f - 1) / 5)))];
}

// ------------------------------------------------------------------
// Monstros
// sprite: forma procedural + cores
// ai: lista de comportamentos
// ------------------------------------------------------------------
export const MONSTERS = {
  // Campos
  gelim: { name: 'Gelim', lv: 1, el: 'agua', race: 'amorfo', speed: 85, hpMul: 0.9, atkMul: 0.8, ai: ['erratic'],
    sprite: { shape: 'blob', c: ['#ff9cc0', '#e0507f'] }, card: { slot: 'armor', mods: { flee: 16, mdef: 13 } } },
  larvinha: { name: 'Larvinha', lv: 2, el: 'terra', race: 'inseto', speed: 80, hpMul: 1.1, ai: [],
    sprite: { shape: 'bug', c: ['#9be36a', '#4f9a2c'] }, card: { slot: 'head', mods: { def: 5, hpPct: 5 } } },
  cogumelo: { name: 'Cogumelo Esporento', lv: 3, el: 'agua', race: 'planta', speed: 90, ai: [],
    sprite: { shape: 'mushroom', c: ['#e8584a', '#f4e3c8'] }, card: { slot: 'head', mods: { spPct: 13, regenSp: 2 } } },
  coelho: { name: 'Coelho Chifrudo', lv: 2, el: 'neutro', race: 'bruto', speed: 115, ai: ['erratic'],
    sprite: { shape: 'beast', c: ['#f2f2f2', '#c9c9c9'], ears: 'long', horn: true }, card: { slot: 'acc', mods: { crit: 5, luk: 2 } } },
  abelha: { name: 'Vespa Dourada', lv: 4, el: 'vento', race: 'inseto', speed: 125, atkMul: 1.1, hpMul: 0.8, ai: [],
    sprite: { shape: 'bug', c: ['#ffd23f', '#4a3a10'], wings: true, stripes: true }, card: { slot: 'weapon', mods: { atkPct: 6, crit: 3 } } },
  lobo: { name: 'Lobo Cinzento', lv: 6, el: 'terra', race: 'bruto', speed: 115, atkMul: 1.15, ai: [],
    sprite: { shape: 'beast', c: ['#8d939e', '#5b616b'], ears: 'pointy' }, card: { slot: 'weapon', mods: { atkPct: 10 } } },
  rei_gelim: { name: 'Rei Gelim', lv: 11, el: 'agua', race: 'amorfo', speed: 95, boss: true, hpMul: 0.8, atkMul: 0.85, ai: ['summon', 'slam'], summon: 'gelim',
    sprite: { shape: 'blob', c: ['#ffd36b', '#d99a1c'], crown: true, scale: 1.5 }, card: { slot: 'armor', mods: { hpPct: 28, vit: 7, regenHp: 6, healBoost: 60 }, power: 'Recuperação Real: poções e habilidades de cura recuperam 60% a mais.' } },

  // Cemitério
  rato: { name: 'Ratazana', lv: 7, el: 'neutro', race: 'bruto', speed: 120, hpMul: 0.9, ai: [],
    sprite: { shape: 'beast', c: ['#8a6a52', '#5e4535'], ears: 'round', tail: true, small: true }, card: { slot: 'acc', mods: { agi: 3, speed: 6 } } },
  morcego: { name: 'Morcego', lv: 8, el: 'sombrio', race: 'bruto', speed: 130, hpMul: 0.75, ai: ['erratic', 'drain'],
    sprite: { shape: 'bat', c: ['#7d5ab8', '#3d2a63'] }, card: { slot: 'weapon', mods: { lifesteal: 3, spOnHit: 2 } } },
  sapo: { name: 'Carniçal', lv: 9, el: 'agua', race: 'peixe', speed: 95, ai: ['poison'],
    sprite: { shape: 'frog', c: ['#5fd16a', '#e8f06a'] }, card: { slot: 'shield', mods: { def: 6, mdef: 6 } } },
  barata: { name: 'Besouro Carniceiro', lv: 10, el: 'terra', race: 'inseto', speed: 130, fleeMul: 1.3, ai: [],
    sprite: { shape: 'bug', c: ['#8b5a2b', '#3e2612'], flat: true }, card: { slot: 'armor', mods: { flee: 10, hpPct: 5 } } },
  lodo: { name: 'Lodo Tóxico', lv: 12, el: 'terra', race: 'amorfo', speed: 80, hpMul: 1.6, ai: ['poison'],
    sprite: { shape: 'blob', c: ['#a6e34a', '#4d7a17'], drip: true }, card: { slot: 'armor', mods: { regenHp: 5, hpPct: 10 } } },
  crocodilo: { name: 'Espantalho', lv: 14, el: 'agua', race: 'bruto', speed: 90, hpMul: 1.5, defMul: 1.5, atkMul: 1.15, ai: [],
    sprite: { shape: 'beast', c: ['#4f7a3a', '#2c4a1e'], long: true }, card: { slot: 'weapon', mods: { dmgNormal: 16 } } },
  rainha_barata: { name: 'Rei Abóbora', lv: 19, el: 'fogo', race: 'inseto', speed: 110, boss: true, mdefMul: 1.4, defMul: 1.2, atkMul: 0.85, ai: ['summon', 'slam'], summon: 'barata', summonN: 1,
    sprite: { shape: 'bug', c: ['#e8a83a', '#6a3a10'], flat: true, wings: true, crown: true, scale: 1.6 }, card: { slot: 'shield', mods: { def: 17, mdef: 28, thorns: 25 }, power: 'Casca de Abóbora: devolve 25% do dano corpo a corpo que você recebe.' } },

  // Dunas
  escorpiao: { name: 'Escaravelho', lv: 15, el: 'fogo', race: 'inseto', speed: 105, ai: ['poison'],
    sprite: { shape: 'scorpion', c: ['#e08a3a', '#7a3d12'] }, card: { slot: 'weapon', mods: { atkPct: 11, dex: 3 } } },
  serpente: { name: 'Serpente das Dunas', lv: 16, el: 'terra', race: 'bruto', speed: 110, ai: ['poison'],
    sprite: { shape: 'snake', c: ['#d8b65a', '#7a5a22'] }, card: { slot: 'head', mods: { hit: 16, dex: 3 } } },
  mumia: { name: 'Múmia', lv: 18, el: 'morto', race: 'morto', speed: 85, hpMul: 1.6, ai: [],
    sprite: { shape: 'humanoid', c: ['#d9cfb2', '#9a8f72'], wrap: true }, card: { slot: 'shield', mods: { redNormal: 8, def: 6 } } },
  aranha: { name: 'Aranha da Areia', lv: 19, el: 'terra', race: 'inseto', speed: 110, ai: ['web'],
    sprite: { shape: 'spider', c: ['#5a4a3a', '#d84a3a'] }, card: { slot: 'acc', mods: { speed: 10, flee: 6 } } },
  golem_areia: { name: 'Golem de Areia', lv: 21, el: 'terra', race: 'amorfo', speed: 75, hpMul: 1.8, atkMul: 1.4, defMul: 2, ai: [],
    sprite: { shape: 'golem', c: ['#c9a66a', '#8a6a3a'] }, card: { slot: 'shield', mods: { def: 16 } } },
  dancarina: { name: 'Dançarina Serpente', lv: 22, el: 'sombrio', race: 'demonio', speed: 120, fleeMul: 1.5, ai: [],
    sprite: { shape: 'humanoid', c: ['#7a3fa8', '#3fbf9a'], snakeHair: true }, card: { slot: 'acc', mods: { agi: 3, spOnKill: 5 } } },
  farao: { name: 'Faraó Esquecido', lv: 29, el: 'morto', race: 'morto', speed: 100, boss: true, ai: ['summon', 'slam', 'curse'], summon: 'mumia', summonN: 1,
    sprite: { shape: 'humanoid', c: ['#e8c34a', '#2a4ab8'], pharaoh: true, scale: 1.5 }, card: { slot: 'acc', mods: { spPct: 35, int: 8, dex: 6, castSpeed: 60 }, power: 'Sabedoria do Faraó: o tempo extra de conjuração das magias lentas cai 60%.' } },

  // Castelo
  esqueleto: { name: 'Esqueleto', lv: 23, el: 'morto', race: 'morto', speed: 100, ai: [],
    sprite: { shape: 'skeleton', c: ['#ece6d6', '#8a8474'] }, card: { slot: 'weapon', mods: { atkPct: 14 } } },
  arq_esqueleto: { name: 'Arqueiro Esqueleto', lv: 24, el: 'morto', race: 'morto', speed: 100, range: 5, ai: ['ranged'], proj: '#e8e0c8',
    sprite: { shape: 'skeleton', c: ['#e2dccb', '#7a7464'], bow: true }, card: { slot: 'head', mods: { dex: 6, hit: 13 } } },
  fantasma: { name: 'Espectro', lv: 26, el: 'fantasma', race: 'demonio', speed: 105, fleeMul: 1.8, hpMul: 0.8, ai: ['erratic'],
    sprite: { shape: 'ghost', c: ['#d8ecff', '#7aa8e8'] }, card: { slot: 'armor', mods: { armorEl: 'fantasma' } } },
  vampiro: { name: 'Morcego Vampiro', lv: 27, el: 'sombrio', race: 'bruto', speed: 135, ai: ['erratic', 'drain'],
    sprite: { shape: 'bat', c: ['#c43a4a', '#4a1018'] }, card: { slot: 'weapon', mods: { lifesteal: 5, spOnHit: 2.4 } } },
  gargula: { name: 'Gárgula', lv: 29, el: 'vento', race: 'demonio', speed: 110, range: 4, ai: ['ranged'], proj: '#b8f0d8',
    sprite: { shape: 'humanoid', c: ['#8a8f99', '#4a4f59'], wings: true, horns: true }, card: { slot: 'shield', mods: { def: 13, mdef: 13, dmgReduce: 6 } } },
  cavaleiro_fantasma: { name: 'Cavaleiro Negro', lv: 32, el: 'sombrio', race: 'humanoide', speed: 100, hpMul: 1.6, defMul: 1.8, atkMul: 1.3, ai: [],
    sprite: { shape: 'humanoid', c: ['#2a2a35', '#8a1a2a'], armored: true }, card: { slot: 'shield', mods: { redBoss: 16 } } },
  lorde_sombrio: { name: 'Lorde Sombrio', lv: 39, el: 'sombrio', race: 'demonio', speed: 110, boss: true, hpMul: 1.3, atkMul: 1.2, ai: ['summon', 'meteor', 'teleport'], summon: 'esqueleto',
    sprite: { shape: 'humanoid', c: ['#1a1424', '#c43aff'], cape: true, horns: true, scale: 1.55 }, card: { slot: 'weapon', mods: { matkPct: 35, int: 8, echo: 20 }, power: 'Eco Sombrio: 20% de chance de uma magia ofensiva se repetir de graça (sem SP e sem turno).' } },

  // Abismo
  diabrete: { name: 'Diabrete', lv: 33, el: 'fogo', race: 'demonio', speed: 130, hpMul: 0.85, ai: ['erratic'],
    sprite: { shape: 'humanoid', c: ['#e0433a', '#3a1010'], horns: true, small: true, tail: true }, card: { slot: 'acc', mods: { str: 5, spOnKill: 6 } } },
  salamandra: { name: 'Salamandra', lv: 35, el: 'fogo', race: 'bruto', speed: 110, atkMul: 1.2, ai: ['burn'],
    sprite: { shape: 'beast', c: ['#ff6a2a', '#8a1a0a'], long: true, flameTail: true }, card: { slot: 'weapon', mods: { dmgBoss: 24 } } },
  golem_magma: { name: 'Golem de Magma', lv: 37, el: 'fogo', race: 'amorfo', speed: 75, hpMul: 1.9, defMul: 2, atkMul: 1.4, ai: ['burn'],
    sprite: { shape: 'golem', c: ['#4a2a22', '#ff7a2a'], lava: true }, card: { slot: 'armor', mods: { hpPct: 16, def: 13 } } },
  bruxa: { name: 'Bruxa do Abismo', lv: 39, el: 'sombrio', race: 'humanoide', speed: 105, range: 5, magic: true, ai: ['ranged'], proj: '#c47aff',
    sprite: { shape: 'humanoid', c: ['#3a1a5a', '#9affb0'], witch: true }, card: { slot: 'weapon', mods: { matkPct: 19 } } },
  dragao: { name: 'Draconiano', lv: 41, el: 'fogo', race: 'dragao', speed: 105, hpMul: 1.4, atkMul: 1.2, range: 4, ai: ['ranged', 'burn'], proj: '#ff8a3a',
    sprite: { shape: 'dragon', c: ['#c4302a', '#ffc04a'] }, card: { slot: 'head', mods: { crit: 8, critDmg: 16 } } },
  pesadelo: { name: 'Olho do Pesadelo', lv: 42, el: 'fantasma', race: 'demonio', speed: 135, ai: ['stunhit'],
    sprite: { shape: 'beast', c: ['#1a1a24', '#8a4aff'], ears: 'pointy', mane: true, ghostly: true }, card: { slot: 'acc', mods: { speed: 16, agi: 3 } } },
  bafome: { name: 'Bafomé', lv: 55, el: 'sombrio', race: 'demonio', speed: 115, boss: true, hpMul: 1.3, atkMul: 1.15, ai: ['summon', 'slam', 'meteor', 'teleport'], summon: 'diabrete',
    sprite: { shape: 'humanoid', c: ['#3a2a3a', '#c4302a'], goat: true, scythe: true, scale: 1.7 }, card: { slot: 'weapon', mods: { atkPct: 35, crit: 17, cleave: 40 }, power: 'Foice do Bafomé: seu ataque básico também atinge os inimigos ao lado com 40% do dano.' } },

  // Navio Fantasma
  marujo_afogado: { name: 'Marujo Afogado', lv: 52, el: 'agua', race: 'morto', speed: 90, hpMul: 1.4, ai: [],
    sprite: { shape: 'humanoid', c: ['#4a6a4a', '#2a3a2a'] }, card: { slot: 'armor', mods: { hpPct: 22 } } },
  caranguejo_morto: { name: 'Caranguejo Morto', lv: 53, el: 'agua', race: 'peixe', speed: 85, hpMul: 1.3, defMul: 2.2, ai: [],
    sprite: { shape: 'bug', c: ['#8a5a4a', '#4a2a20'], flat: true }, card: { slot: 'shield', mods: { def: 26, mdef: 10 } } },
  pirata_esqueleto: { name: 'Pirata Esqueleto', lv: 55, el: 'morto', race: 'morto', speed: 110, atkMul: 1.2, ai: [],
    sprite: { shape: 'skeleton', c: ['#ece6d6', '#8a8474'] }, card: { slot: 'weapon', mods: { dmgNormal: 29 } } },
  sereia: { name: 'Sereia', lv: 56, el: 'agua', race: 'peixe', speed: 105, range: 5, magic: true, ai: ['ranged'], proj: '#9affe8',
    sprite: { shape: 'humanoid', c: ['#3fbf9a', '#1a5a6a'] }, card: { slot: 'head', mods: { matkPct: 16, spPct: 16 } } },
  tubarao: { name: 'Tubarão Fantasma', lv: 58, el: 'agua', race: 'peixe', speed: 140, hpMul: 0.9, atkMul: 1.3, ai: [],
    sprite: { shape: 'beast', c: ['#7a9ab8', '#3a4a5a'], long: true }, card: { slot: 'weapon', mods: { atkPct: 16, speed: 8 } } },
  polvo_abissal: { name: 'Tentáculo Abissal', lv: 60, el: 'agua', race: 'peixe', speed: 95, hpMul: 1.6, ai: ['web', 'poison'],
    sprite: { shape: 'blob', c: ['#6a3a7a', '#2a1030'] }, card: { slot: 'armor', mods: { regenHpPct: 0.5, regenSp: 5 } } },
  drake: { name: 'Capitão Drake', lv: 64, el: 'agua', race: 'morto', speed: 115, boss: true, hpMul: 1.3, atkMul: 1.2, ai: ['summon', 'slam', 'teleport'], summon: 'pirata_esqueleto', summonN: 2,
    sprite: { shape: 'humanoid', c: ['#3fbf9a', '#1a3a3a'], cape: true, scale: 1.55 }, card: { slot: 'acc', mods: { luk: 8, crit: 8, plunder: 15 }, power: 'Pilhagem do Capitão: 15% de chance de cada abate render um drop extra e o dobro de zeny.' } },

  // Pico Congelado
  lobo_gelo: { name: 'Lobo do Gelo', lv: 62, el: 'agua', race: 'bruto', speed: 125, atkMul: 1.15, ai: ['freezehit'],
    sprite: { shape: 'beast', c: ['#cfe7ff', '#7aa8e8'], ears: 'pointy' }, card: { slot: 'weapon', mods: { atkPct: 21 } } },
  urso_polar: { name: 'Urso Polar', lv: 64, el: 'agua', race: 'bruto', speed: 95, hpMul: 1.7, atkMul: 1.35, ai: [],
    sprite: { shape: 'beast', c: ['#f4f4f4', '#c9c9c9'], ears: 'round' }, card: { slot: 'armor', mods: { hpPct: 19, vit: 6 } } },
  golem_cristal: { name: 'Golem de Cristal', lv: 66, el: 'agua', race: 'amorfo', speed: 75, hpMul: 1.9, defMul: 2.2, mdefMul: 1.6, atkMul: 1.4, ai: [],
    sprite: { shape: 'golem', c: ['#9ad8ff', '#4a8ab8'] }, card: { slot: 'shield', mods: { redNormal: 19 } } },
  gigante_gelo: { name: 'Gigante de Gelo', lv: 67, el: 'agua', race: 'humanoide', speed: 90, hpMul: 2, atkMul: 1.5, ai: ['stunhit'],
    sprite: { shape: 'golem', c: ['#bfe8ff', '#5a7a9a'] }, card: { slot: 'acc', mods: { str: 6, spOnHit: 3 } } },
  demonio_nevasca: { name: 'Demônio da Nevasca', lv: 68, el: 'agua', race: 'demonio', speed: 115, range: 5, magic: true, ai: ['ranged', 'freezehit'], proj: '#cfeaff',
    sprite: { shape: 'humanoid', c: ['#4a6ae8', '#1a2a6a'], horns: true }, card: { slot: 'weapon', mods: { matkPct: 26 } } },
  dragao_gelo: { name: 'Dragão de Gelo', lv: 70, el: 'agua', race: 'dragao', speed: 105, hpMul: 1.5, atkMul: 1.25, range: 4, ai: ['ranged', 'freezehit'], proj: '#bfe8ff',
    sprite: { shape: 'dragon', c: ['#bfe8ff', '#4a8ab8'] }, card: { slot: 'head', mods: { mdef: 22, def: 13 } } },
  garm: { name: 'Garm', lv: 74, el: 'agua', race: 'bruto', speed: 125, boss: true, hpMul: 1.35, atkMul: 1.2, ai: ['summon', 'slam', 'meteor', 'freezehit'], summon: 'lobo_gelo', summonN: 2,
    sprite: { shape: 'beast', c: ['#e8f4ff', '#7aa8e8'], ears: 'pointy', mane: true, scale: 1.6 }, card: { slot: 'head', mods: { hpPct: 17, freezeImmune: 1, frostbite: 25 }, power: 'Uivo Gélido: quem te ataca corpo a corpo tem 25% de chance de congelar. Você não congela.' } },

  // Torre do Esquecimento
  alma_perdida: { name: 'Alma Perdida', lv: 72, el: 'fantasma', race: 'demonio', speed: 120, fleeMul: 1.6, hpMul: 0.85, ai: ['erratic', 'drain'],
    sprite: { shape: 'ghost', c: ['#9aff9a', '#3a8a5a'] }, card: { slot: 'acc', mods: { agi: 6, spOnKill: 10 } } },
  espectro_sombrio: { name: 'Espectro Sombrio', lv: 74, el: 'sombrio', race: 'demonio', speed: 115, range: 4, magic: true, ai: ['ranged'], proj: '#8a5aff',
    sprite: { shape: 'ghost', c: ['#4a3aff', '#1a1060'] }, card: { slot: 'head', mods: { int: 8, matkPct: 13 } } },
  carrasco: { name: 'Carrasco', lv: 76, el: 'sombrio', race: 'demonio', speed: 95, hpMul: 1.6, atkMul: 1.5, ai: ['stunhit'],
    sprite: { shape: 'humanoid', c: ['#5a4a4a', '#2a1a1a'] }, card: { slot: 'weapon', mods: { dmgBoss: 35 } } },
  cavaleiro_infernal: { name: 'Cavaleiro Infernal', lv: 78, el: 'fogo', race: 'humanoide', speed: 105, hpMul: 1.8, defMul: 2, atkMul: 1.35, ai: ['burn'],
    sprite: { shape: 'humanoid', c: ['#c4302a', '#3a1010'], armored: true }, card: { slot: 'shield', mods: { redBoss: 24 } } },
  lich: { name: 'Lich Ancião', lv: 80, el: 'morto', race: 'morto', speed: 100, hpMul: 1.2, range: 5, magic: true, ai: ['ranged', 'poison'], proj: '#9aff9a',
    sprite: { shape: 'skeleton', c: ['#d8d0b8', '#3a2a4a'] }, card: { slot: 'acc', mods: { int: 10, spPct: 19 } } },
  ceifador: { name: 'Ceifador', lv: 83, el: 'sombrio', race: 'demonio', speed: 125, atkMul: 1.4, ai: ['drain', 'stunhit'],
    sprite: { shape: 'humanoid', c: ['#2a2a35', '#c4302a'], scythe: true }, card: { slot: 'weapon', mods: { lifesteal: 8, atkPct: 13 } } },
  thanatos: { name: 'Thanatos', lv: 88, el: 'sombrio', race: 'demonio', speed: 120, boss: true, hpMul: 1.4, atkMul: 1.25, ai: ['summon', 'slam', 'curse', 'meteor', 'teleport'], summon: 'alma_perdida', summonN: 2,
    sprite: { shape: 'humanoid', c: ['#4a1a6a', '#c47aff'], wings: true, scale: 1.7 }, card: { slot: 'weapon', mods: { atkPct: 28, matkPct: 28, pierce: 35, execute: 15 }, power: 'Ceifador: ataques e magias ignoram 40% da DEF e da DEFM, e golpes em inimigos com menos de 15% do HP causam o dobro.' } },
};

// ------------------------------------------------------------------
// Itens
// ------------------------------------------------------------------
export const WTYPES = {
  varinha: { name: 'Varinha', range: 1, mods: { hit: 4 } },
  adaga: { name: 'Adaga', range: 1, mods: { crit: 8, speed: 10 } },
  espada: { name: 'Espada', range: 1, mods: {} },
  lanca: { name: 'Lança', hands: 2, range: 2, mods: {} },
  cajado: { name: 'Cajado', hands: 2, range: 1, mods: {} },
  arco: { name: 'Arco', hands: 2, range: 5, ranged: true, mods: {} },
  maca: { name: 'Maça', range: 1, mods: { hit: 5 } },
  machado: { name: 'Machado', range: 1, mods: { speed: -10, crit: 2 } },
  kunai: { name: 'Kunai', range: 1, mods: { crit: 6, speed: 6 } },
  fuuma: { name: 'Fuuma Shuriken', hands: 2, range: 2, mods: { speed: -6, crit: 3 } },
  treino: { name: 'Espada de Treino', range: 1, mods: { hit: 6 } },
  besta: { name: 'Besta', hands: 2, range: 5, ranged: true, mods: { crit: 3, speed: -4 } },
  katar: { name: 'Katar', hands: 2, range: 1, mods: { crit: 12 } },
  soqueira: { name: 'Soqueira', hands: 2, range: 1, mods: { speed: 10, hit: 4 } },
  faixa: { name: 'Faixas de Luta', hands: 2, range: 1, unarmed: true, mods: { speed: 4 } },
};

export const ITEMS = {
  // Armas [tipo, tier, atk, matk, extras]
  faca: { kind: 'weapon', name: 'Faca', wtype: 'adaga', tier: 1, atk: 10 },
  adaga: { kind: 'weapon', name: 'Adaga', wtype: 'adaga', tier: 2, atk: 26 },
  estilete: { kind: 'weapon', name: 'Estilete', wtype: 'adaga', tier: 3, atk: 48 },
  gladius: { kind: 'weapon', name: 'Lâmina Gladius', wtype: 'adaga', tier: 4, atk: 80 },
  punhal_sombrio: { kind: 'weapon', name: 'Punhal Sombrio', wtype: 'adaga', tier: 5, atk: 120, el: 'sombrio' },

  espada_curta: { kind: 'weapon', name: 'Espada Curta', wtype: 'espada', tier: 1, atk: 14 },
  sabre: { kind: 'weapon', name: 'Sabre', wtype: 'espada', tier: 2, atk: 33 },
  espada_bastarda: { kind: 'weapon', name: 'Espada Bastarda', wtype: 'espada', tier: 3, atk: 60 },
  montante: { kind: 'weapon', name: 'Montante Rúnico', wtype: 'espada', tier: 4, atk: 96 },
  lamina_celeste: { kind: 'weapon', name: 'Lâmina Celeste', wtype: 'espada', tier: 5, atk: 145, el: 'sagrado' },

  lanca_simples: { kind: 'weapon', name: 'Lança Simples', wtype: 'lanca', tier: 1, atk: 13 },
  pique: { kind: 'weapon', name: 'Pique', wtype: 'lanca', tier: 2, atk: 31 },
  glaive: { kind: 'weapon', name: 'Glaive', wtype: 'lanca', tier: 3, atk: 57 },
  lanca_cavaleiro: { kind: 'weapon', name: 'Lança de Cavaleiro', wtype: 'lanca', tier: 4, atk: 92 },
  lanca_trovao: { kind: 'weapon', name: 'Lança Trovejante', wtype: 'lanca', tier: 5, atk: 140, el: 'vento' },

  vara: { kind: 'weapon', name: 'Vara de Aprendiz', wtype: 'cajado', tier: 1, atk: 6, matk: 15 },
  cajado_carvalho: { kind: 'weapon', name: 'Cajado de Carvalho', wtype: 'cajado', tier: 2, atk: 10, matk: 36, mods: { int: 1 } },
  cetro_arcano: { kind: 'weapon', name: 'Cetro Arcano', wtype: 'cajado', tier: 3, atk: 14, matk: 66, mods: { int: 2 } },
  cajado_sabio: { kind: 'weapon', name: 'Cajado do Sábio', wtype: 'cajado', tier: 4, atk: 18, matk: 102, mods: { int: 3 } },
  baculo_celestial: { kind: 'weapon', name: 'Báculo Celestial', wtype: 'cajado', tier: 5, atk: 24, matk: 150, mods: { int: 4, spPct: 10 } },

  arco_curto: { kind: 'weapon', name: 'Arco Curto', wtype: 'arco', tier: 1, atk: 12 },
  arco_composto: { kind: 'weapon', name: 'Arco Composto', wtype: 'arco', tier: 2, atk: 29 },
  arco_longo: { kind: 'weapon', name: 'Arco Longo', wtype: 'arco', tier: 3, atk: 53 },
  arco_caca: { kind: 'weapon', name: 'Arco de Caça', wtype: 'arco', tier: 4, atk: 85 },
  arco_elfico: { kind: 'weapon', name: 'Arco Élfico', wtype: 'arco', tier: 5, atk: 130, mods: { dex: 4 } },

  clava: { kind: 'weapon', name: 'Clava', wtype: 'maca', tier: 1, atk: 15 },
  maca: { kind: 'weapon', name: 'Maça', wtype: 'maca', tier: 2, atk: 35 },
  maca_estrela: { kind: 'weapon', name: 'Maça Estrela', wtype: 'maca', tier: 3, atk: 62 },
  martelo_sagrado: { kind: 'weapon', name: 'Martelo Sagrado', wtype: 'maca', tier: 4, atk: 97, el: 'sagrado' },
  maca_divina: { kind: 'weapon', name: 'Maça Divina', wtype: 'maca', tier: 5, atk: 146, mods: { int: 3 } },

  machadinha: { kind: 'weapon', name: 'Machadinha', wtype: 'machado', tier: 1, atk: 19 },
  machado: { kind: 'weapon', name: 'Machado', wtype: 'machado', tier: 2, atk: 42 },
  machado_duplo: { kind: 'weapon', name: 'Machado Duplo', wtype: 'machado', tier: 3, atk: 74 },
  machado_barbaro: { kind: 'weapon', name: 'Machado Bárbaro', wtype: 'machado', tier: 4, atk: 112 },
  machado_tita: { kind: 'weapon', name: 'Machado Titânico', wtype: 'machado', tier: 5, atk: 168 },

  espada_treino: { kind: 'weapon', name: 'Espada de Treino', wtype: 'treino', tier: 1, atk: 9 },

  kunai: { kind: 'weapon', name: 'Kunai', wtype: 'kunai', tier: 1, atk: 11 },
  kunai_aco: { kind: 'weapon', name: 'Kunai de Aço', wtype: 'kunai', tier: 2, atk: 27 },
  kunai_serpente: { kind: 'weapon', name: 'Kunai Serpente', wtype: 'kunai', tier: 3, atk: 50 },
  kunai_sombria: { kind: 'weapon', name: 'Kunai Sombria', wtype: 'kunai', tier: 4, atk: 82, el: 'sombrio' },
  kunai_celestial: { kind: 'weapon', name: 'Kunai Celestial', wtype: 'kunai', tier: 5, atk: 124 },

  fuuma_ferro: { kind: 'weapon', name: 'Fuuma de Ferro', wtype: 'fuuma', tier: 1, atk: 17 },
  fuuma_lamina: { kind: 'weapon', name: 'Fuuma de Lâminas', wtype: 'fuuma', tier: 2, atk: 39 },
  fuuma_dentada: { kind: 'weapon', name: 'Fuuma Dentada', wtype: 'fuuma', tier: 3, atk: 68 },
  fuuma_sombria: { kind: 'weapon', name: 'Fuuma Sombria', wtype: 'fuuma', tier: 4, atk: 104, el: 'sombrio' },
  fuuma_celestial: { kind: 'weapon', name: 'Fuuma Celestial', wtype: 'fuuma', tier: 5, atk: 150 },

  besta_leve: { kind: 'weapon', name: 'Besta Leve', wtype: 'besta', tier: 1, atk: 14 },
  besta_caca: { kind: 'weapon', name: 'Besta de Caça', wtype: 'besta', tier: 2, atk: 32 },
  besta_pesada: { kind: 'weapon', name: 'Besta Pesada', wtype: 'besta', tier: 3, atk: 58 },
  besta_repeticao: { kind: 'weapon', name: 'Besta de Repetição', wtype: 'besta', tier: 4, atk: 90 },
  besta_tempestade: { kind: 'weapon', name: 'Besta Tempestade', wtype: 'besta', tier: 5, atk: 136, el: 'vento' },

  katar_ferro: { kind: 'weapon', name: 'Katar de Ferro', wtype: 'katar', tier: 1, atk: 13 },
  katar_serrilhado: { kind: 'weapon', name: 'Katar Serrilhado', wtype: 'katar', tier: 2, atk: 30 },
  katar_gemeo: { kind: 'weapon', name: 'Katar Gêmeo', wtype: 'katar', tier: 3, atk: 55 },
  katar_sombrio: { kind: 'weapon', name: 'Katar Sombrio', wtype: 'katar', tier: 4, atk: 88, el: 'sombrio' },
  katar_abismo: { kind: 'weapon', name: 'Katar do Abismo', wtype: 'katar', tier: 5, atk: 132 },

  soqueira_couro: { kind: 'weapon', name: 'Soqueira de Couro', wtype: 'soqueira', tier: 1, atk: 12 },
  soqueira_ferro: { kind: 'weapon', name: 'Soqueira de Ferro', wtype: 'soqueira', tier: 2, atk: 29 },
  garras_tigre: { kind: 'weapon', name: 'Garras de Tigre', wtype: 'soqueira', tier: 3, atk: 54 },
  punho_aco: { kind: 'weapon', name: 'Punho de Aço', wtype: 'soqueira', tier: 4, atk: 86 },
  punho_celestial: { kind: 'weapon', name: 'Punho Celestial', wtype: 'soqueira', tier: 5, atk: 130, el: 'sagrado' },
  // faixas: contam como mãos vazias (o Taekwon mantém o bônus), mas aceitam cartas e refino
  faixa_algodao: { kind: 'weapon', name: 'Faixas de Algodão', wtype: 'faixa', tier: 1, atk: 4, mods: { agi: 1 } },
  faixa_couro: { kind: 'weapon', name: 'Faixas de Couro', wtype: 'faixa', tier: 2, atk: 9, mods: { agi: 2, crit: 2 } },
  faixa_tigre: { kind: 'weapon', name: 'Faixas do Tigre', wtype: 'faixa', tier: 3, atk: 15, mods: { str: 3, agi: 3 } },
  faixa_estelar: { kind: 'weapon', name: 'Faixas Estelares', wtype: 'faixa', tier: 4, atk: 22, mods: { agi: 4, crit: 4, speed: 6 } },
  faixa_solar: { kind: 'weapon', name: 'Faixas do Sol', wtype: 'faixa', tier: 5, atk: 30, el: 'fogo', mods: { str: 5, agi: 5 } },

  // Armas dos mundos transcendentais
  lamina_corsario: { kind: 'weapon', name: 'Lâmina do Corsário', wtype: 'adaga', tier: 6, atk: 168 },
  adaga_morte: { kind: 'weapon', name: 'Adaga da Morte', wtype: 'adaga', tier: 7, atk: 228, el: 'sombrio' },
  sabre_almirante: { kind: 'weapon', name: 'Sabre do Almirante', wtype: 'espada', tier: 6, atk: 203 },
  espada_glacial: { kind: 'weapon', name: 'Espada Glacial', wtype: 'espada', tier: 7, atk: 275, el: 'agua' },
  tridente_mares: { kind: 'weapon', name: 'Tridente das Marés', wtype: 'lanca', tier: 6, atk: 196, el: 'agua' },
  gungnir: { kind: 'weapon', name: 'Gungnir', wtype: 'lanca', tier: 7, atk: 266 },
  arco_vigia: { kind: 'weapon', name: 'Arco do Vigia', wtype: 'arco', tier: 6, atk: 182, mods: { dex: 5 } },
  arco_boreal: { kind: 'weapon', name: 'Arco Boreal', wtype: 'arco', tier: 7, atk: 247, el: 'agua', mods: { dex: 6 } },
  ancora_guerra: { kind: 'weapon', name: 'Âncora de Guerra', wtype: 'maca', tier: 6, atk: 204 },
  martelo_glacial: { kind: 'weapon', name: 'Martelo Glacial', wtype: 'maca', tier: 7, atk: 277, el: 'agua', mods: { int: 4 } },
  machado_berserker: { kind: 'weapon', name: 'Machado do Berserker', wtype: 'machado', tier: 6, atk: 235 },
  machado_juizo: { kind: 'weapon', name: 'Machado do Juízo', wtype: 'machado', tier: 7, atk: 319 },
  kunai_nevoeiro: { kind: 'weapon', name: 'Kunai do Nevoeiro', wtype: 'kunai', tier: 6, atk: 174 },
  kunai_lunar: { kind: 'weapon', name: 'Kunai Lunar', wtype: 'kunai', tier: 7, atk: 236, el: 'sombrio' },
  fuuma_tempestade: { kind: 'weapon', name: 'Fuuma Tempestuosa', wtype: 'fuuma', tier: 6, atk: 210, el: 'vento' },
  fuuma_eclipse: { kind: 'weapon', name: 'Fuuma do Eclipse', wtype: 'fuuma', tier: 7, atk: 285 },
  besta_arpoador: { kind: 'weapon', name: 'Besta do Arpoador', wtype: 'besta', tier: 6, atk: 190 },
  besta_gelida: { kind: 'weapon', name: 'Besta Gélida', wtype: 'besta', tier: 7, atk: 258, el: 'agua' },
  katar_kraken: { kind: 'weapon', name: 'Katar do Kraken', wtype: 'katar', tier: 6, atk: 185 },
  katar_ceifador: { kind: 'weapon', name: 'Katar do Ceifador', wtype: 'katar', tier: 7, atk: 251, el: 'sombrio' },
  punho_tufao: { kind: 'weapon', name: 'Punho do Tufão', wtype: 'soqueira', tier: 6, atk: 182, el: 'vento' },
  punho_asura: { kind: 'weapon', name: 'Punho do Asura', wtype: 'soqueira', tier: 7, atk: 247 },
  cajado_mares: { kind: 'weapon', name: 'Cajado das Marés', wtype: 'cajado', tier: 6, atk: 32, matk: 210, mods: { int: 5 } },
  cetro_thanatos: { kind: 'weapon', name: 'Cetro do Esquecimento', wtype: 'cajado', tier: 7, atk: 40, matk: 285, mods: { int: 7, spPct: 10 } },
  faixa_aurora: { kind: 'weapon', name: 'Faixas da Aurora', wtype: 'faixa', tier: 6, atk: 42, mods: { agi: 6, crit: 6 } },
  faixa_celeste: { kind: 'weapon', name: 'Faixas Celestes', wtype: 'faixa', tier: 7, atk: 58, mods: { str: 7, agi: 7, speed: 8 } },

  // Armaduras
  roupa_algodao: { kind: 'armor', name: 'Roupa de Algodão', tier: 1, def: 4, mdef: 2 },
  tunica_couro: { kind: 'armor', name: 'Túnica de Couro', tier: 2, def: 10, mdef: 3 },
  cota_malha: { kind: 'armor', name: 'Cota de Malha', tier: 3, def: 22, mdef: 4 },
  armadura_placas: { kind: 'armor', name: 'Armadura de Placas', tier: 4, def: 36, mdef: 5 },
  armadura_runica: { kind: 'armor', name: 'Armadura Rúnica', tier: 5, def: 52, mdef: 16, mods: { hpPct: 5 } },
  manto_aprendiz: { kind: 'armor', name: 'Manto de Estudante', tier: 2, def: 6, mdef: 10, mods: { int: 1 } },
  robe_arcano: { kind: 'armor', name: 'Robe Arcano', tier: 3, def: 10, mdef: 18, mods: { int: 3 } },
  traje_ladino: { kind: 'armor', name: 'Traje de Ladino', tier: 3, def: 13, mdef: 5, mods: { agi: 3, flee: 5 } },
  manto_estelar: { kind: 'armor', name: 'Manto Estelar', tier: 5, def: 22, mdef: 30, mods: { int: 5, spPct: 10 } },
  couraca_sombra: { kind: 'armor', name: 'Couraça das Sombras', tier: 5, def: 30, mdef: 12, mods: { agi: 5, crit: 5 } },
  couraca_almirante: { kind: 'armor', name: 'Couraça do Almirante', tier: 6, def: 70, mdef: 24, mods: { hpPct: 6 } },
  manto_mares: { kind: 'armor', name: 'Manto das Marés', tier: 6, def: 30, mdef: 42, mods: { int: 6, spPct: 12 } },
  traje_corsario: { kind: 'armor', name: 'Traje do Corsário', tier: 6, def: 40, mdef: 16, mods: { agi: 6, crit: 6 } },
  armadura_glacial: { kind: 'armor', name: 'Armadura Glacial', tier: 7, def: 92, mdef: 32, mods: { hpPct: 8 } },
  veste_vazio: { kind: 'armor', name: 'Veste do Vazio', tier: 7, def: 38, mdef: 56, mods: { int: 8, spPct: 15 } },
  couraca_noturna: { kind: 'armor', name: 'Couraça Noturna', tier: 7, def: 52, mdef: 20, mods: { agi: 8, crit: 8 } },

  // Acessórios (valor = tier + 1)
  anel_forca: { kind: 'acc', name: 'Anel de Força', stat: 'str' },
  brinco_sabio: { kind: 'acc', name: 'Brinco do Sábio', stat: 'int' },
  luvas_precisas: { kind: 'acc', name: 'Luvas Precisas', stat: 'dex' },
  botas_leves: { kind: 'acc', name: 'Botas Leves', stat: 'agi' },
  colar_vida: { kind: 'acc', name: 'Colar da Vida', stat: 'vit' },
  trevo: { kind: 'acc', name: 'Trevo de Quatro Folhas', stat: 'luk' },

  // Varinhas (mago, 1 mão: deixa a outra mão para escudo ou grimório)
  varinha_aprendiz: { kind: 'weapon', name: 'Varinha de Aprendiz', wtype: 'varinha', tier: 1, atk: 5, matk: 15 },
  varinha_salgueiro: { kind: 'weapon', name: 'Varinha de Salgueiro', wtype: 'varinha', tier: 2, atk: 8, matk: 36, mods: { int: 1 } },
  varinha_cristal: { kind: 'weapon', name: 'Varinha de Cristal', wtype: 'varinha', tier: 3, atk: 11, matk: 66, mods: { int: 2 } },
  varinha_runica: { kind: 'weapon', name: 'Varinha Rúnica', wtype: 'varinha', tier: 4, atk: 14, matk: 102, mods: { int: 3 } },
  varinha_estelar: { kind: 'weapon', name: 'Varinha Estelar', wtype: 'varinha', tier: 5, atk: 18, matk: 150, mods: { int: 4 } },
  varinha_coral: { kind: 'weapon', name: 'Varinha de Coral', wtype: 'varinha', tier: 6, atk: 24, matk: 210, mods: { int: 5 } },
  varinha_vazio: { kind: 'weapon', name: 'Varinha do Vazio', wtype: 'varinha', tier: 7, atk: 30, matk: 285, mods: { int: 6 } },

  // Cabeça: elmos (pesado), chapéus (mago) e capuzes (leve)
  bandana_couro: { kind: 'head', cat: 'heavy', name: 'Bandana de Couro', tier: 1, def: 2, mdef: 0 },
  elmo_ferro: { kind: 'head', cat: 'heavy', name: 'Elmo de Ferro', tier: 2, def: 5, mdef: 1 },
  elmo_aco: { kind: 'head', cat: 'heavy', name: 'Elmo de Aço', tier: 3, def: 9, mdef: 2 },
  elmo_cavaleiro: { kind: 'head', cat: 'heavy', name: 'Elmo do Cavaleiro', tier: 4, def: 14, mdef: 3 },
  elmo_runico: { kind: 'head', cat: 'heavy', name: 'Elmo Rúnico', tier: 5, def: 20, mdef: 6, mods: { hpPct: 3 } },
  elmo_almirante: { kind: 'head', cat: 'heavy', name: 'Elmo do Almirante', tier: 6, def: 26, mdef: 8, mods: { hpPct: 4 } },
  elmo_glacial: { kind: 'head', cat: 'heavy', name: 'Elmo Glacial', tier: 7, def: 33, mdef: 10, mods: { hpPct: 5 } },
  chapeu_palha: { kind: 'head', cat: 'robe', name: 'Chapéu de Palha', tier: 1, def: 1, mdef: 3 },
  chapeu_estudante: { kind: 'head', cat: 'robe', name: 'Chapéu de Estudante', tier: 2, def: 2, mdef: 6, mods: { int: 1 } },
  chapeu_mago: { kind: 'head', cat: 'robe', name: 'Chapéu de Mago', tier: 3, def: 3, mdef: 10, mods: { int: 2 } },
  chapeu_arcano: { kind: 'head', cat: 'robe', name: 'Chapéu Arcano', tier: 4, def: 5, mdef: 14, mods: { int: 3 } },
  diadema_estelar: { kind: 'head', cat: 'robe', name: 'Diadema Estelar', tier: 5, def: 7, mdef: 18, mods: { int: 4, spPct: 4 } },
  coroa_mares: { kind: 'head', cat: 'robe', name: 'Coroa das Marés', tier: 6, def: 9, mdef: 23, mods: { int: 5, spPct: 5 } },
  coroa_vazio: { kind: 'head', cat: 'robe', name: 'Coroa do Vazio', tier: 7, def: 11, mdef: 28, mods: { int: 6, spPct: 6 } },
  bandana: { kind: 'head', cat: 'light', name: 'Bandana', tier: 1, def: 1, mdef: 1, mods: { agi: 1 } },
  capuz_couro: { kind: 'head', cat: 'light', name: 'Capuz de Couro', tier: 2, def: 3, mdef: 2, mods: { agi: 1 } },
  capuz_ladino: { kind: 'head', cat: 'light', name: 'Capuz de Ladino', tier: 3, def: 5, mdef: 3, mods: { agi: 2, crit: 1 } },
  mascara_cacador: { kind: 'head', cat: 'light', name: 'Máscara de Caçador', tier: 4, def: 8, mdef: 4, mods: { agi: 3, crit: 2 } },
  capuz_sombras: { kind: 'head', cat: 'light', name: 'Capuz das Sombras', tier: 5, def: 11, mdef: 6, mods: { agi: 4, crit: 3 } },
  lenco_corsario: { kind: 'head', cat: 'light', name: 'Lenço do Corsário', tier: 6, def: 14, mdef: 8, mods: { agi: 5, crit: 3 } },
  capuz_noturno: { kind: 'head', cat: 'light', name: 'Capuz Noturno', tier: 7, def: 17, mdef: 10, mods: { agi: 6, crit: 4 } },

  // Mão esquerda: escudos e grimórios
  broquel: { kind: 'shield', cat: 'escudo', name: 'Broquel', tier: 1, def: 3, mdef: 1 },
  escudo_madeira: { kind: 'shield', cat: 'escudo', name: 'Escudo de Madeira', tier: 2, def: 7, mdef: 2 },
  escudo_ferro: { kind: 'shield', cat: 'escudo', name: 'Escudo de Ferro', tier: 3, def: 12, mdef: 4 },
  escudo_torre: { kind: 'shield', cat: 'escudo', name: 'Escudo de Torre', tier: 4, def: 18, mdef: 6 },
  escudo_runico: { kind: 'shield', cat: 'escudo', name: 'Escudo Rúnico', tier: 5, def: 25, mdef: 10, mods: { dmgReduce: 2 } },
  escudo_almirante: { kind: 'shield', cat: 'escudo', name: 'Escudo do Almirante', tier: 6, def: 32, mdef: 12, mods: { dmgReduce: 3 } },
  escudo_glacial: { kind: 'shield', cat: 'escudo', name: 'Escudo Glacial', tier: 7, def: 40, mdef: 15, mods: { dmgReduce: 4 } },
  tomo_gasto: { kind: 'shield', cat: 'grimorio', name: 'Tomo Gasto', tier: 1, def: 1, mdef: 4, matk: 5 },
  grimorio_estudante: { kind: 'shield', cat: 'grimorio', name: 'Grimório de Estudante', tier: 2, def: 2, mdef: 7, matk: 12 },
  grimorio_arcano: { kind: 'shield', cat: 'grimorio', name: 'Grimório Arcano', tier: 3, def: 4, mdef: 11, matk: 22 },
  livro_estrelas: { kind: 'shield', cat: 'grimorio', name: 'Livro das Estrelas', tier: 4, def: 6, mdef: 15, matk: 34 },
  codice_estelar: { kind: 'shield', cat: 'grimorio', name: 'Códice Estelar', tier: 5, def: 8, mdef: 20, matk: 48 },
  grimorio_mares: { kind: 'shield', cat: 'grimorio', name: 'Grimório das Marés', tier: 6, def: 10, mdef: 25, matk: 64 },
  livro_vazio: { kind: 'shield', cat: 'grimorio', name: 'Livro do Vazio', tier: 7, def: 12, mdef: 30, matk: 82 },

  // Consumíveis
  // poções: parte fixa + porcentagem do máximo; liberadas no Empório depois de derrotar o chefe do andar `unlock`
  pocao_vermelha: { kind: 'use', name: 'Poção Vermelha', heal: 25, healPct: 10, unlock: 0, price: 20, icon: '#e8434a' },
  pocao_laranja: { kind: 'use', name: 'Poção Laranja', heal: 60, healPct: 12, unlock: 5, price: 70, icon: '#ff9a3a' },
  pocao_amarela: { kind: 'use', name: 'Poção Amarela', heal: 120, healPct: 15, unlock: 10, price: 140, icon: '#ffd23f' },
  pocao_branca: { kind: 'use', name: 'Poção Branca', heal: 200, healPct: 18, unlock: 15, price: 220, icon: '#f4f4f4' },
  pocao_real: { kind: 'use', name: 'Poção Real', heal: 300, healPct: 20, unlock: 20, price: 300, icon: '#ff6ad8' },
  pocao_imperial: { kind: 'use', name: 'Poção Imperial', heal: 450, healPct: 22, unlock: 25, price: 450, icon: '#c43aff' },
  elixir_vital: { kind: 'use', name: 'Elixir Vital', heal: 600, healPct: 25, unlock: 35, price: 650, icon: '#ff3a6a' },
  pocao_azul_clara: { kind: 'use', name: 'Poção Azul Clara', sp: 15, spPct: 8, unlock: 5, price: 60, icon: '#8ac8ff' },
  pocao_azul: { kind: 'use', name: 'Poção Azul', sp: 30, spPct: 10, unlock: 15, price: 180, icon: '#4a8aff' },
  pocao_azul_profunda: { kind: 'use', name: 'Poção Azul Profunda', sp: 60, spPct: 12, unlock: 25, price: 400, icon: '#2a4adf' },
  elixir_arcano: { kind: 'use', name: 'Elixir Arcano', sp: 100, spPct: 14, unlock: 35, price: 600, icon: '#7a3aff' },
  erva_verde: { kind: 'use', name: 'Erva Verde', cure: true, price: 20, icon: '#5fd16a' },
  asa_mosca: { kind: 'use', name: 'Asa de Mosca', teleport: true, price: 45, icon: '#c9c4b0' },
  asa_borboleta: { kind: 'use', name: 'Asa de Borboleta', recall: true, price: 160, icon: '#7ad0ff' },
  fragmento: { kind: 'mat', name: 'Fragmento Rúnico', price: 450, icon: '#9affe8' },
};

export const POTION_BY_TIER = ['pocao_vermelha', 'pocao_vermelha', 'pocao_laranja', 'pocao_amarela', 'pocao_branca', 'pocao_real', 'pocao_imperial', 'pocao_imperial', 'elixir_vital'];
export const SP_POTION_BY_TIER = ['pocao_azul_clara', 'pocao_azul_clara', 'pocao_azul_clara', 'pocao_azul_clara', 'pocao_azul', 'pocao_azul', 'pocao_azul_profunda', 'pocao_azul_profunda', 'elixir_arcano'];
export const MAX_TIER = 7;

export const SHOP_ITEMS = ['pocao_vermelha', 'pocao_laranja', 'pocao_amarela', 'pocao_branca', 'pocao_real', 'pocao_imperial', 'elixir_vital', 'pocao_azul_clara', 'pocao_azul', 'pocao_azul_profunda', 'elixir_arcano', 'erva_verde', 'asa_mosca', 'asa_borboleta', 'fragmento'];

// Equipamentos básicos à venda na cidade (tier 1 e 2)
export const SHOP_GEAR = ['faca', 'espada_curta', 'lanca_simples', 'vara', 'arco_curto', 'besta_leve', 'katar_ferro', 'soqueira_couro', 'faixa_algodao', 'kunai', 'fuuma_ferro', 'clava', 'machadinha', 'roupa_algodao', 'tunica_couro', 'manto_aprendiz', 'varinha_aprendiz', 'bandana_couro', 'chapeu_palha', 'bandana', 'broquel', 'tomo_gasto'];

// Melhorias permanentes do Santuário
// Santuário: melhorias de conforto da conta (custam zeny). costs = preço de cada nível
export const LEGACY = {
  mochila: { name: 'Mochila Maior', desc: '+5 espaços na mochila de todos os personagens.', max: 4, costs: [3000, 8000, 18000, 40000] },
  armazem: { name: 'Armazém Maior', desc: '+40 espaços no armazém da conta.', max: 4, costs: [2500, 7000, 16000, 35000] },
  vagas: { name: 'Banca no Mercado', desc: '+2 anúncios ao mesmo tempo no Mercado.', max: 5, costs: [2000, 5000, 10000, 20000, 40000] },
  taxa: { name: 'Sócio do Mercado', desc: 'Taxa de venda do Mercado 0,6% menor (5% → 2%).', max: 5, costs: [5000, 12000, 25000, 50000, 90000] },
  kit: { name: 'Kit do Aventureiro', desc: 'Novos personagens começam com poções e asas.', max: 5, costs: [800, 2000, 4500, 8000, 13000] },
  veterano: { name: 'Aprendiz Veterano', desc: 'Novos personagens começam no nível 8, prontos para escolher a classe. Exige um personagem nível 25+.', max: 1, costs: [15000] },
};

// Bênçãos temporárias: valem para os próximos N monstros derrotados pelo personagem atual
// Reaparecimento dos chefes (minutos reais), por personagem
export const BOSS_RESPAWN_MIN = { rei_gelim: 10, rainha_barata: 10, farao: 10, lorde_sombrio: 15, bafome: 15, drake: 15, garm: 20, thanatos: 20 };

export const BOOSTS = {
  xp: { name: 'Manual de Batalha', icon: '📘', desc: '+50% de XP', kills: 200, price: (lv) => 400 + lv * 120 },
  drop: { name: 'Chiclete da Sorte', icon: '🍬', desc: 'drops ×2 (inclusive cartas e chefes)', kills: 80, price: (lv) => 500 + lv * 150 },
  zeny: { name: 'Bolsa da Fortuna', icon: '💰', desc: '+50% de zeny', kills: 200, price: (lv) => 300 + lv * 80 },
};

// Refino: chance de sucesso por nível alvo (+1 ... +10)
export const REFINE_RATES = [100, 100, 100, 100, 70, 60, 50, 40, 25, 15];
