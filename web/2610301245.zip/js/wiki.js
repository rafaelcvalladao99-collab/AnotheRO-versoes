import { aoeText, aoeGrid } from './rules.js';
// Wiki do jogo: gerada a partir dos dados, para nunca ficar desatualizada
import { CLASSES, SKILLS, THEMES, MONSTERS, ELEMENTS, RACES, JOB_BONUS, CLASS_LV, CLASS_STARTER, STAT_NAMES, WTYPES, ITEMS, elemMult } from './data.js';
import { openSheet } from './ui.js';
import { monsterSprite, spriteURL } from './sprites.js';
import { LEVEL_CAPS } from './game.js';

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pct = (n) => Math.round(n * 100) + '%';
const num = (n) => String(Math.round(n * 100) / 100).replace('.', ',');

const TABS = [['attr', 'Atributos'], ['cls', 'Classes'], ['skills', 'Habilidades'], ['mech', 'Mecânicas'], ['el', 'Elementos'], ['mon', 'Monstros']];
let state = { tab: 'attr', q: '', cls: 'todas', open: null };

export function wikiSheet(tab) {
  if (tab) state.tab = tab;
  openSheet({
    title: 'Wiki',
    html: `<div class="tabs wiki-tabs">${TABS.map(([k, n]) => `<button class="tab ${k === state.tab ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div id="wiki-body" class="wiki"></div>`,
    mount(b) {
      b.querySelectorAll('[data-t]').forEach((t) => t.onclick = () => { state.tab = t.dataset.t; state.open = null; wikiSheet(); });
      render(b.querySelector('#wiki-body'));
      const on = b.querySelector('.tab.on'); if (on) on.scrollIntoView({ inline: 'center', block: 'nearest' });
    },
  });
}

function render(el) {
  if (state.tab === 'attr') el.innerHTML = attrHTML();
  if (state.tab === 'cls') { el.innerHTML = classesHTML(); bindSkillLinks(el); }
  if (state.tab === 'skills') renderSkills(el);
  if (state.tab === 'mech') el.innerHTML = mechHTML();
  if (state.tab === 'el') el.innerHTML = elementsHTML();
  if (state.tab === 'mon') el.innerHTML = monstersHTML();
}

// ---------------- Atributos ----------------
function attrHTML() {
  const A = [
    ['str', 'FOR', 'Força', [
      'ATQ corpo a corpo: +2 por ponto, mais um bônus que cresce a cada 10 pontos (10 FOR = +1, 20 = +4, 30 = +9...).',
      'Com arco ou besta: cada 5 FOR dão +1 de ATQ.',
      'Pedras e kunais arremessadas: cada 5 FOR dão +1.']],
    ['agi', 'AGI', 'Agilidade', [
      'Esquiva: +1,3 por ponto.',
      'Velocidade: +1,2 por ponto (mais velocidade = mais ações antes dos monstros agirem).']],
    ['vit', 'VIT', 'Vitalidade', [
      'HP máximo: +8 por ponto, mais 0,35 × seu nível por ponto (rende mais quanto maior o nível). Multiplicado pelo HP da classe.',
      'DEF: +1 a cada 2 pontos. DEFM: +1 a cada 3 pontos.',
      'Regeneração de HP: +0,08 por turno por ponto (e todos recuperam 0,2% do HP máximo por turno).',
      'Resistência a veneno, queimadura, atordoar etc.: +0,3% por ponto.']],
    ['int', 'INT', 'Inteligência', [
      'ATQM: +2 por ponto, mais um bônus a cada 10 pontos (10 = +1, 20 = +4, 30 = +9...).',
      'SP máximo: +3 por ponto (multiplicado pelo SP da classe).',
      'DEFM: +1 a cada 2 pontos. Regeneração de SP: +0,05 por ponto.',
      'Cura do Clérigo: +2 de cura base por ponto. Monge: metade do ATQM vira ATQ (Punhos Sagrados).']],
    ['dex', 'DES', 'Destreza', [
      'Precisão: +1 por ponto.',
      'Com arco ou besta: ATQ +1,45 por ponto, mais o bônus a cada 10 pontos.',
      'Corpo a corpo: cada 5 DES dão +1 de ATQ.',
      'Pedras e kunais arremessadas usam DES como atributo principal.',
      'Velocidade: +0,3 por ponto.']],
    ['luk', 'SOR', 'Sorte', [
      'Crítico: +0,4% por ponto. Crítico causa 40% a mais e ignora a DEF do alvo.',
      'Esquiva perfeita: 1% a cada 8 pontos (desvia de qualquer golpe).',
      'Esquiva: +1 a cada 5 pontos. ATQ e ATQM: +1 a cada 4 pontos.',
      'Resistência a status: +0,6% por ponto. Refino: +1% de sucesso a cada 10 pontos.',
      'SOR não aumenta zeny nem drops.']],
  ];
  return `<div class="wiki-sec">Como funcionam os pontos</div>
    <ul class="wiki-list">
      <li>Cada nível dá <b>3 pontos</b> de atributo (4 a partir do nível 15, 5 a partir do 30...).</li>
      <li>Custo de 1 ponto até 10, 2 pontos de 11 a 20, 3 de 21 a 30, e assim por diante.</li>
      <li>Cada classe também dá atributos automáticos por nível (veja em Classes).</li>
    </ul>
    ${A.map(([k, s, n, l]) => `<div class="wiki-card"><div class="wiki-h"><span class="wiki-tag">${s}</span>${n}</div><ul class="wiki-list">${l.map((x) => `<li>${x}</li>`).join('')}</ul></div>`).join('')}
    <div class="wiki-sec">Fórmulas base</div>
    <ul class="wiki-list">
      <li><b>HP</b> = (50 + 12×nível + 8×VIT + 0,35×nível×VIT) × HP da classe.</li>
      <li><b>SP</b> = (8 + 2×nível + 3×INT) × SP da classe. Auras ligadas reservam parte do SP máximo.</li>
      <li><b>Chance de acerto</b> = 80% + sua precisão − esquiva do alvo (entre 5% e 100%). Magia nunca erra.</li>
      <li><b>Cercado</b>: a partir do 3º monstro acordado a até 2 casas, sua esquiva cai 10% por monstro extra (até −80%). Chefes miram 30% melhor.</li>
      <li><b>Dano físico</b> é reduzido pela DEF do alvo: dano × 60 / (60 + DEF). Crítico ignora a DEF. Algumas habilidades atravessam parte da DEF.</li>
      <li><b>Dano mágico</b> é reduzido pela DEFM do alvo do mesmo jeito.</li>
    </ul>`;
}

// ---------------- Classes ----------------
const lineage = (id) => { const out = []; let c = id; while (c) { out.unshift(c); c = CLASSES[c].from; } return out; };
function classesHTML() {
  const tiers = [0, 1, 2, 3];
  return tiers.map((t) => `<div class="wiki-sec">${['Inicial', `Primeira classe (nível ${CLASS_LV[1]})`, `Classe avançada (nível ${CLASS_LV[2]})`, `Transcendental (renascido, nível ${CLASS_LV[2]})`][t]}</div>` +
    Object.entries(CLASSES).filter(([, c]) => (t === 3 ? c.trans : c.tier === t && !c.reborn)).map(([id, c]) => {
      const jb = Object.entries(JOB_BONUS[id] || JOB_BONUS[c.base] || {}).map(([k, v]) => [k, c.trans ? v * 1.15 : v]).map(([k, v]) => `${STAT_NAMES[k]} +${num(v)}`).join(', ');
      const st = CLASS_STARTER[id] ? ITEMS[CLASS_STARTER[id]].name : c.trans ? 'a que já tiver' : (t ? 'luta sem arma' : '—');
      return `<div class="wiki-card"><div class="wiki-h">${esc(c.name)}${c.trans ? `<small> · renascimento de ${esc(CLASSES[c.base].name)}</small>` : c.from ? `<small> · vem de ${esc(CLASSES[c.from].name)}</small>` : ''}</div>
        <p class="wiki-p">${esc(c.desc)}</p>
        <div class="wiki-kv"><span>HP da classe</span><b>×${num(c.hpMul)}</b><span>SP da classe</span><b>×${num(c.spMul)}</b>
        ${jb ? `<span>Por nível na classe</span><b>${jb}</b>` : ''}<span>Arma inicial</span><b>${esc(st)}</b></div>
        <div class="wiki-skills">${c.skills.map((s) => `<button class="wiki-chip" data-sk="${s}"><img class="wsk" src="assets/icons/sk/${s}.svg" alt=""> ${esc(SKILLS[s].name)}</button>`).join('')}</div></div>`;
    }).join('')).join('');
}
function bindSkillLinks(el) {
  el.querySelectorAll('[data-sk]').forEach((b) => b.onclick = () => { state.tab = 'skills'; state.open = b.dataset.sk; state.q = ''; state.cls = 'todas'; wikiSheet(); });
}

// ---------------- Habilidades ----------------
const ownerOf = (id) => Object.entries(CLASSES).filter(([, c]) => c.skills.includes(id) && (!c.reborn || c.trans)).map(([k]) => k);
function skillKind(sk) {
  if (sk.target === 'passive') return 'Passiva';
  if (sk.aura) return 'Aura';
  if (sk.heal) return 'Cura';
  if (sk.buffs) return 'Buff';
  if (sk.kind === 'magic') return 'Mágica';
  if (sk.kind === 'phys') return 'Física';
  if (sk.kind === 'status') return 'Controle';
  if (sk.kind === 'steal') return 'Utilidade';
  if (sk.kind === 'field') return 'Mágica (campo)';
  if (sk.kind === 'falcon') return 'Física (falcão)';
  if (sk.restoreSp) return 'Recuperação';
  return 'Ativa';
}
function skillRows(id) {
  const sk = SKILLS[id];
  const rows = [];
  rows.push(['Tipo', skillKind(sk)]);
  if (sk.kind === 'magic') rows.push(['Dano baseado em', 'ATQM (INT)']);
  else if (sk.kind === 'phys') rows.push(['Dano baseado em', sk.useDex ? 'ATQ à distância (DES)' : 'ATQ (FOR, ou DES com arco/besta)']);
  if (sk.heal) rows.push(['Cura baseada em', id === 'curar' ? 'INT e nível' : 'nível']);
  if (sk.target !== 'passive') {
    rows.push(['Custo', `${sk.sp(1)} SP${sk.allSp ? ' (gasta todo o SP)' : ''}`]);
    rows.push(['Conjuração', sk.aura ? '1 turno para ligar/desligar' : `${num(sk.cast || 1)} turno${(sk.cast || 1) > 1 ? 's' : ''}`]);
    const alvo = { self: sk.aoe ? 'em volta de você' : 'você mesmo', enemy: 'um inimigo', tile: 'uma área' }[sk.target];
    rows.push(['Alvo', alvo + (sk.line ? ' (atravessa a linha)' : '')]);
    if (sk.range) rows.push(['Alcance', `${sk.range} casa${sk.range > 1 ? 's' : ''}`]);
    if (sk.aoe) rows.push(['Área', `${aoeText(sk)} ${aoeGrid(sk)}`]);
  }
  if (sk.el && sk.el !== 'neutro') rows.push(['Elemento', ELEMENTS[sk.el].name]);
  if (sk.aura) rows.push(['Reserva de SP', `${sk.aura}% do SP máximo enquanto ligada`]);
  if (sk.hits > 1) rows.push(['Golpes', `${sk.hits} (o dano total é dividido)`]);
  if (sk.sureHit) rows.push(['Precisão', 'nunca erra']);
  if (sk.critBonus) rows.push(['Crítico', `+${sk.critBonus}%`]);
  if (sk.cooldown) rows.push(['Recarga', `${sk.cooldown(sk.max)}–${sk.cooldown(1)} turnos`]);
  if (sk.knock) rows.push(['Empurra', `${sk.knock} casa${sk.knock > 1 ? 's' : ''}`]);
  if (sk.needsBow) rows.push(['Exige', 'arco ou besta']);
  if (sk.buffs && !sk.aura) { const b = sk.buffs(1); if (b.turns) rows.push(['Duração', `${b.turns} turnos no nível 1`]); }
  return rows;
}
function levelLines(id) {
  const sk = SKILLS[id];
  const out = [];
  for (let l = 1; l <= sk.max; l++) {
    const bits = [];
    if (sk.mult) bits.push(`<b>${pct(sk.mult(l))}</b>`);
    if (sk.stun) bits.push(`${sk.stun(l)}% atordoar`);
    if (sk.freeze) bits.push(`${sk.freeze(l)}% congelar`);
    if (sk.poison) bits.push(`${sk.poison(l)}% envenenar`);
    if (sk.snare) bits.push(`prende ${sk.snare(l)} turnos`);
    out.push(`<tr><td>Nv ${l}</td><td>${bits.length ? bits.join(' · ') : esc(sk.desc(l))}</td></tr>`);
  }
  return out.join('');
}
function renderSkills(el) {
  const classes = ['todas', ...Object.keys(CLASSES).filter((c) => !CLASSES[c].reborn || CLASSES[c].trans)];
  const q = state.q.trim().toLowerCase();
  const ids = Object.keys(SKILLS).filter((id) => ownerOf(id).length && (state.cls === 'todas' || CLASSES[state.cls].skills.includes(id)))
    .filter((id) => !q || (SKILLS[id].name + ' ' + SKILLS[id].desc(1) + ' ' + skillKind(SKILLS[id])).toLowerCase().includes(q));
  el.innerHTML = `<input class="dv-in wiki-search" placeholder="Buscar habilidade (ex.: gelo, cura, aura)" value="${esc(state.q)}">
    <div class="wiki-filter">${classes.map((c) => `<button class="wiki-chip ${state.cls === c ? 'on' : ''}" data-c="${c}">${c === 'todas' ? 'Todas' : esc(CLASSES[c].name)}</button>`).join('')}</div>
    <div class="wiki-list2">${ids.map((id) => {
      const sk = SKILLS[id];
      const open = state.open === id;
      return `<div class="wiki-card wiki-skill ${open ? 'open' : ''}" data-id="${id}">
        <div class="wiki-h"><span class="wiki-ic"><img src="assets/icons/sk/${id}.svg" alt=""></span>${esc(sk.name)}<small> · ${skillKind(sk)} · ${ownerOf(id).map((c) => esc(CLASSES[c].name)).join(', ')}</small><span class="wiki-arrow">${open ? '▾' : '▸'}</span></div>
        <p class="wiki-p">${esc(sk.desc(sk.max))}</p>
        ${open ? `<div class="wiki-kv">${skillRows(id).map(([k, v]) => `<span>${k}</span><b>${v}</b>`).join('')}</div>
        <table class="wiki-t"><tbody>${levelLines(id)}</tbody></table>` : ''}
      </div>`;
    }).join('') || '<p class="wiki-p">Nada encontrado.</p>'}</div>`;
  const inp = el.querySelector('.wiki-search');
  inp.oninput = () => { state.q = inp.value; const pos = inp.selectionStart; renderSkills(el); const n = el.querySelector('.wiki-search'); n.focus(); n.setSelectionRange(pos, pos); };
  el.querySelectorAll('[data-c]').forEach((b) => b.onclick = () => { state.cls = b.dataset.c; renderSkills(el); });
  el.querySelectorAll('.wiki-skill').forEach((c) => c.onclick = () => { state.open = state.open === c.dataset.id ? null : c.dataset.id; renderSkills(el); });
  if (state.open) { const o = el.querySelector('.wiki-skill.open'); if (o) o.scrollIntoView({ block: 'center' }); }
}

// ---------------- Mecânicas ----------------
function mechHTML() {
  const caps = LEVEL_CAPS.slice(0, -1);
  const bosses = THEMES.map((t) => MONSTERS[t.boss].name);
  const S = (t, items) => `<div class="wiki-sec">${t}</div><ul class="wiki-list">${items.map((x) => `<li>${x}</li>`).join('')}</ul>`;
  return S('Turnos e velocidade', [
      'O jogo é em turnos: os monstros só agem quando você age.',
      'Velocidade 100 = uma ação por turno. Com mais velocidade você age mais vezes que os monstros lentos.',
      'Algumas magias levam mais de um turno para conjurar (veja em Habilidades → Conjuração).',
    ]) +
    S('Equipamento', [
      'Seis espaços: <b>cabeça</b>, <b>armadura</b>, <b>mão direita</b>, <b>mão esquerda</b> e <b>dois acessórios</b>.',
      'Armas de <b>uma mão</b> deixam a mão esquerda livre para um <b>escudo</b> (ou grimório, para magos). Armas de <b>duas mãos</b> (arco, besta, katar, lança, cajado, soqueira, fuuma, faixas) rendem mais, mas ocupam as duas mãos.',
      '<b>Duas armas</b>: Espadachim/Cavaleiro (espadas), Gatuno/Assassino (adagas) e Ninja/Shinobi (kunais) podem pôr uma segunda arma na mão esquerda. Ela rende <b>40%</b> do ATQ e dos bônus dela, mas as <b>cartas valem inteiras</b>.',
      'Assassinos, ninjas e taekwons não usam escudo.',
      'Slots de carta: a arma pode ter até 3; cabeça, armadura, escudo e acessórios, até 1.',
    ]) +
    S('Limite de nível', [
      `Você só sobe até o nível <b>${caps.join(', ')}</b> enquanto não derrotar o próximo chefe (${bosses.slice(0, caps.length).join(', ')}). Depois do ${bosses[bosses.length - 1]} não há limite.`,
      'A partir do nível 30 cada nível pede um pouco mais de experiência (até +25% no nível 40).',
      'No limite, a barra de XP fica dourada e o XP extra vira um pouco de zeny (2%).',
      'Pelo Portão da Masmorra você entra em qualquer andar já visitado. Cada entrada gera um andar novo, e os monstros continuam aparecendo: farme o quanto quiser.',
    ]) +
    S('Renascimento', [
      'Depois de derrotar o Bafomé, no nível 60, a Guilda das Classes pode fazer seu herói renascer.',
      'Ele volta ao nível 1 como Aprendiz Renascido com +25% de HP e SP, +40 pontos de atributo e +1 ponto de habilidade a cada 10 níveis. Equipamentos, banco e armazém continuam.',
      'O renascido segue o mesmo caminho da primeira vida (Espadachim Alto → Lorde, por exemplo) e precisa de 50% mais experiência por nível.',
      'As classes transcendentais têm tudo da classe avançada e duas habilidades novas. Só elas descem além do andar 25: Navio Fantasma (26–30), Pico Congelado (31–35) e Torre do Esquecimento (36–40).',
    ]) +
    S('Auras', [
      'Bênção, Esferas Espirituais, Postura de Combate, Substituição e Envenenar Arma são auras: ligue uma vez e elas ficam ativas, mesmo trocando de andar.',
      'Enquanto ligada, a aura reserva uma parte do seu SP máximo. Toque de novo para desligar.',
    ]) +
    S('Combos do Bruxo', [
      'Cada combo <b>consome</b> o estado do alvo e causa muito mais dano:',
      '<b>Raio em congelado</b>: estilhaça o gelo com 6× o dano.',
      '<b>Fogo em petrificado</b>: racha a pedra com 10× o dano e tem 85% de chance de deixar queimando.',
      '<b>Gelo em quem está queimando</b>: vapor, 5,5× o dano e 90% de chance de congelar.',
      'Fogo comum tem 25% de chance de deixar queimando. Fogo também derrete o gelo (sem bônus).',
      'Pedra não queima: enquanto o monstro está petrificado, a queimadura fica pausada e volta quando a pedra sai.',
      '<b>Campo Gravitacional</b>: dentro dele os monstros ficam lentos, perdem 30% da DEFM e os combos pegam mais fácil (petrificar, queimar a pedra e congelar quem queima chegam a 95%).',
      'Uma corrente completa: Campo → Olhar da Medusa → fogo → gelo → raio.',
    ]) +
    S('Caçada do Caçador', [
      '<b>Distância</b>: os tiros do Caçador ficam mais fortes de longe. Ao lado do alvo −30%, a 2–3 casas normal, a 4–5 casas +25% e a 6 casas ou mais +50%.',
      '<b>Presa</b> (selo verde com mira): a Rede de Caça e a Armadilha marcam o monstro por 10 turnos, mesmo que ele se solte. O falcão ataca a Presa (com o dobro de frequência) e seus tiros nela têm +25% de crítico. Uma Presa por vez.',
      '<b>Armadilha</b>: até 2 armadas no chão (marca dourada). O primeiro monstro que pisar leva dano, fica preso e vira Presa.',
      '<b>Salto para Trás</b>: recua até 2 casas e atira. <b>Virote de Impacto</b>: empurra o alvo 2 casas. Os dois têm recarga.',
      'Virote Perfurante e Tiro Preciso atravessam a fila inteira: vale deixar os monstros enfileirados.',
    ]) +
    S('Sangria do Ninja', [
      'Ninja, Shinobi e Kagerou usam <b>Energia</b> (barra amarela) em vez de SP: sempre 100, volta 8 por turno (mais rápido descansando). Dá para usar poucas habilidades seguidas; depois é recuar, usar o ataque básico e voltar. Poção de SP não serve para eles.',
      '<b>Sangria</b> (selo vermelho com gota; o número é a quantidade de acúmulos): até 5 por monstro, dura 5 turnos e renova a cada acúmulo. Sangra um pouco a cada turno e <b>bem mais a cada casa que o monstro anda</b>. Quem corre atrás do ninja se machuca.',
      'Aplicam Sangria: Arremesso de Kunai (1), Lâmina Fantasma (2), Chuva de Shurikens (1 em cada), Kunai Sangrenta (2 em cada da linha), ataque básico com Arte Ninja e o contra-ataque da Lua Crescente (1).',
      '<b>Pulsar Sangue</b>: explode o sangue de todos em volta (3×3) e acaba com a Sangria. Quanto mais acúmulos e mais vida o monstro já perdeu, maior o dano. Ignora a DEF.',
      'Nos chefes, cada sangrada e a parte de vida perdida do Pulsar têm limite.',
    ]) +
    S('Guarda do Cavaleiro', [
      '<b>Aparar Golpe</b> deixa o Cavaleiro em guarda até a próxima ação. Cada golpe corpo a corpo levado é aparado: bem menos dano, o atacante fica com <b>Abertura</b> e você ganha 1 de <b>Fervor</b>.',
      '<b>Abertura</b> (selo amarelo com "!" sobre o monstro): o próximo golpe seu nele é crítico garantido. O Corte Cruzado causa o dobro e a Perfuração Espiral atravessa toda a DEF. Some em cerca de 2 turnos.',
      '<b>Golpe anunciado do chefe</b>: o número em cima dele mostra quantas ações suas faltam. No 1 (vermelho), ficar em guarda apara o golpe: menos dano, Abertura longa e 2 de Fervor. Magias e flechas não são aparadas.',
      '<b>Fervor</b> (até 5): ganha aparando e derrotando monstros. Com Fervor de Batalha, cada ponto guardado dá ATQ. Sem ganhar Fervor por 8 turnos, ele vai caindo.',
      'Gastos de Fervor: <b>Redemoinho</b> com 3 (2+ alvos ou chefe) dá +30% e atordoa todos; <b>Ofensiva Furiosa</b> com 1 faz você aterrissar em guarda; <b>Perfuração Espiral</b> com 5 atravessa toda a DEF e dobra o dano.',
      'A Ofensiva Furiosa também deixa Abertura em quem ficar atordoado: serve para abrir monstros que não atacam.',
    ]) +
    S('Combate', [
      'Crítico causa 40% a mais e ignora metade da DEF do alvo (Assassino e Algoz ignoram toda).',
      'Ataque Duplo / Punhos Triplos: chance de golpear 2 ou 3 vezes num ataque básico.',
      'Envenenar Arma: cada ataque básico causa dano de veneno extra e pode envenenar.',
      'Andar na diagonal é permitido sempre que a casa de destino estiver livre (para você e para os monstros).',
    ]) +
    S('Chefes', [
      'Um chefe a cada 5 andares. Derrotá-lo abre um portal para a cidade, um atalho e libera o próximo limite de nível.',
      'Quadrados vermelhos no chão avisam um golpe forte: saia de cima antes que ele caia.',
      'Chefes nunca ficam presos nem são empurrados: congelar, petrificar, atordoar ou prender um chefe o deixa <b>lento</b> (age na metade da velocidade), e os combos continuam funcionando.',
      'Toda habilidade que empurra tem recarga, para não segurar o monstro longe para sempre.',
      'Alguns chefes chamam ajudantes; outros se teletransportam ou fazem chover meteoros.',
      'Chefes resistem um pouco: atordoar, congelar, petrificar e prender pegam com a chance normal, mas duram menos e só deixam o chefe lento. Queimadura pega normal; veneno é difícil.',
      'Chefes reaparecem com o tempo real (por personagem): Rei Gelim, Rei Abóbora e Faraó 10 min; Lorde Sombrio, Bafomé e Capitão Drake 15 min; Garm e Thanatos 20 min. Enquanto isso, o andar fica com as saídas abertas.',
      'Drop de chefe: um equipamento acima do bioma garantido (sempre com slots, às vezes refinado) e chance de um segundo. Cartas de chefe caem só 3% das vezes e têm um poder único.',
    ]) +
    S('Equipamento, cartas e refino', [
      'Cartas caem raramente e encaixam nos slots [ ] das armas, armaduras e acessórios.',
      'Refino no Ferreiro com Fragmentos Rúnicos. Acima de +4, uma falha quebra o item.',
      'Tipos de arma: ' + Object.values(WTYPES).map((w) => `${w.name}${w.range > 1 ? ` (alcance ${w.range})` : ''}`).join(', ') + '.',
    ]) +
    S('Mercado', [
      'Cerca de 120 aventureiros (simulados) jogam em Runa: sobem de nível, trocam de classe, ganham e gastam zeny.',
      'Um item vale o quanto ele melhora o personagem de cada um, com a classe dele. Classes fortes têm mais jogadores, então os itens delas valem mais. Cartas são raras e valem mais.',
      'Você anuncia pela aba Vender. Vende quando aparece alguém que precisa e topa o preço, mesmo com o jogo fechado (até 6 horas de mundo por vez). Taxa de anúncio de 1% e de venda de 5%.',
      'O mundo anda a cada 10 minutos reais. Eventos mudam os preços por algumas horas: temporada de uma classe, febre das cartas, crise e bonança.',
    ]) +
    S('Santuário', [
      'Melhorias da conta (para sempre): mochila maior, armazém maior, mais vagas e taxa menor no Mercado, kit para novos personagens e Aprendiz Veterano (novos personagens começam no nível 8).',
      'Bênçãos do herói, contadas por monstros derrotados: Manual de Batalha (+50% XP, 200 monstros), Chiclete da Sorte (drops ×2, 80 monstros), Bolsa da Fortuna (+50% zeny, 200 monstros). Comprar de novo soma.',
      'Martelo Abençoado: um refino que falhar não quebra o item. Serviços: redistribuir atributos ou habilidades e trocar o nome.',
    ]) +
    S('Morte e personagens', [
      'Até 8 personagens por conta. Banco, armazém, mercado e bênçãos do Santuário são de todos; a mochila e o equipamento vestido são de cada um.',
      'Normal: ao cair, volta para a vila. Perde 25% do XP do nível (pode ficar com uma dívida de XP, que precisa ser paga antes de evoluir) e 75% do zeny ganho na viagem. Mochila e equipamento ficam.',
      'Hardcore: ao cair, o herói se vai para sempre. Em troca ganha +30% de XP, +30% de zeny e 50% mais chance de drop (inclusive cartas).',
      'O zeny ganho na masmorra vai para o banco quando você volta à vila; só o da viagem atual está em risco.',
    ]);
}

// ---------------- Elementos ----------------
function elementsHTML() {
  return `<p class="wiki-p">Não existe vantagem de elemento: nenhum elemento causa mais ou menos dano contra outro.</p>
    <ul class="wiki-list"><li>Arma com elemento (ou carta que dá elemento à arma): +8% de ATQ.</li><li>Armadura com elemento (carta): -5% de dano recebido.</li>
    <li>O que importa são os combos de estado do Bruxo (veja em Mecânicas).</li></ul>`;
}

// ---------------- Monstros ----------------
const AI_TXT = { erratic: 'anda de forma errática', drain: 'rouba vida', poison: 'envenena', burn: 'queima', web: 'prende com teia', stunhit: 'atordoa', ranged: 'ataca à distância', summon: 'chama ajudantes', slam: 'golpe em área (fuja dos quadrados)', curse: 'maldição em área', meteor: 'chuva de meteoros', teleport: 'teletransporta' };
function monstersHTML() {
  return THEMES.map((t, i) => {
    const list = [...t.monsters, t.boss];
    return `<div class="wiki-sec" style="color:${t.accent}">${t.name} <small>· andares ${i * 5 + 1}–${i * 5 + 5}</small></div>` + list.map((k) => {
      const m = MONSTERS[k];
      const sp = spriteURL(monsterSprite(k), 'm:' + k);
      const ai = (m.ai || []).map((a) => AI_TXT[a]).filter(Boolean).join(', ');
      return `<div class="wiki-mon ${m.boss ? 'boss' : ''}"><img src="${sp}" alt=""><div><b>${m.boss ? '♛ ' : ''}${esc(m.name)}</b> <small>nv ${m.lv}</small>
        <div class="wiki-small">${ELEMENTS[m.el].name} · ${RACES[m.race]}${m.range > 1 ? ` · alcance ${m.range}` : ''}${ai ? ` · ${ai}` : ''}</div>
        ${m.card.power ? `<div class="wiki-small" style="color:#ffb84a">★ Carta: ${esc(m.card.power)}</div>` : ''}</div></div>`;
    }).join('');
  }).join('');
}
