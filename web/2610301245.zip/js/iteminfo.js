// Ficha do item com destaque no que importa: números principais grandes, bônus em verde, poderes em dourado.
import { itemDef, itemDesc, isEquip, modsText } from './rules.js';
import { WTYPES, ELEMENTS } from './data.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const chips = (txt) => txt.split(', ').map((p) => {
  const neg = /-\d|^Esquiva -|^Velocidade -/.test(p) && !/Dano recebido/.test(p);
  return `<span class="ii-chip ${neg ? 'neg' : ''}">${esc(p)}</span>`;
}).join('');

export function itemInfoHTML(it) {
  const d = itemDef(it);
  const lines = itemDesc(it);
  const mods = new Set([modsText(d.mods), d.kind === 'weapon' && WTYPES[d.wtype] ? modsText({ ...WTYPES[d.wtype].mods, ...(d.mods || {}) }) : null].filter(Boolean));
  const out = [];
  lines.forEach((l, i) => {
    if (/^(ATQ|DEF) \d/.test(l)) {
      out.push(`<div class="ii-main">${l.split(' · ').map((p) => { const m = p.match(/^(\S+) \+?(\d.*)$/); return m ? `<span><small>${esc(m[1])}</small><b>${esc(m[2])}</b></span>` : `<span><b>${esc(p)}</b></span>`; }).join('')}</div>`);
    } else if (i === 0 && isEquip(it) && !l.startsWith('Acessório')) {
      out.push(`<div class="ii-type">${esc(l)}</div>`);
    } else if (l.startsWith('Acessório · ') && mods.has(l.slice(12))) {
      out.push(`<div class="ii-type">Acessório</div><div class="ii-mods">${chips(l.slice(12))}</div>`);
    } else if (mods.has(l)) {
      out.push(`<div class="ii-mods">${chips(l)}</div>`);
    } else if (l.startsWith('★')) {
      out.push(`<div class="ii-power">${esc(l)}</div>`);
    } else if (l.startsWith('Elemento: ')) {
      const el = Object.values(ELEMENTS).find((e) => e.name === l.slice(10));
      out.push(`<div class="ii-el" style="color:${el ? el.color : '#fff'}">◆ ${esc(l)}</div>`);
    } else if (l.startsWith('Slots: ')) {
      // cartas encaixadas: nome + o que cada uma dá
      const cards = it.cards || [];
      out.push(`<div class="ii-slots">${Array.from({ length: it.slots }, (_, k) => {
        if (!cards[k]) return '<span class="empty">slot vazio</span>';
        const cd = itemDef({ id: 'card', mon: cards[k] });
        const cm = modsText(cd.mods);
        return `<span>${esc(cd.name)}${cm ? `<em>${esc(cm)}</em>` : ''}${cd.power ? `<em class="pw">★ ${esc(cd.power)}</em>` : ''}</span>`;
      }).join('')}</div>`);
    } else if (/^Recupera /.test(l)) {
      out.push(`<div class="ii-main">${(() => { const m = l.match(/^Recupera (\d+) (HP|SP)/); return m ? `<span><small>${m[2]}</small><b>+${m[1]}</b></span>` : esc(l); })()}</div>`);
    } else out.push(`<div class="ii-text">${esc(l)}</div>`);
  });
  return `<div class="ii">${out.join('')}</div>`;
}

// linha curta para as listas: o que o item dá (ATQ/DEF e bônus), com os números em destaque; o tipo fica para a ficha
export function itemSummaryHTML(it) {
  const d = itemDef(it);
  const lines = itemDesc(it);
  let pick;
  if (isEquip(it)) {
    const main = lines.find((l) => /^(ATQ|DEF) \d/.test(l));
    const m = d.kind === 'acc' ? (lines[0] || '').replace(/^Acessório · /, '') : lines.find((l, i) => i > 0 && l !== main && !l.startsWith('Slots') && !l.startsWith('★') && !l.startsWith('Conta como') && !l.startsWith('Elemento'));
    pick = [main, m].filter(Boolean).join(' · ');
    if (!pick) pick = lines[0] || '';
  } else if (d.kind === 'card') pick = lines[1] || lines[0] || '';
  else pick = lines[0] || '';
  return esc(pick).replace(/(&#?\w+;)|([+-]?\d[\d.,]*%?)/g, (m, ent, n) => ent || `<b class="hn">${n}</b>`);
}

// ---------------- Grade de itens agrupada por tipo (mochila, armazém, mercado) ----------------
export const GROUPS = [
  ['use', 'Consumíveis'], ['weapon', 'Armas'], ['shield', 'Mão esquerda'], ['head', 'Cabeça'], ['armor', 'Armaduras'],
  ['acc', 'Acessórios'], ['card', 'Cartas'], ['mat', 'Materiais'],
];
// valor simples para comparar com o equipado (seta verde quando é melhor)
export function quickScore(it) {
  const d = itemDef(it); const t = itemDesc(it).find((l) => /^(ATQ|DEF) \d/.test(l)) || '';
  const n = (re) => { const m = t.match(re); return m ? +m[1] : 0; };
  return n(/ATQ (\d+)/) + n(/ATQM (\d+)/) + n(/DEF (\d+)/) * 2 + n(/DEFM (\d+)/) + (it.slots || 0) * 3 + (it.cards || []).length * 6 + Object.values(d.mods || {}).reduce((a, v) => a + (typeof v === 'number' ? Math.abs(v) : 2), 0);
}
/**
 * opts: { icon(it), name(it), color(it), key(it) -> data attr value, attr: 'u'|'l', sub(it) -> texto abaixo do nome,
 *         better(it) -> true se melhor que o equipado, item(x) -> item quando a lista não é de itens }
 */
export function itemGridHTML(list, opts) {
  const item = opts.item || ((x) => x);
  const groups = new Map(GROUPS.map(([k, n]) => [k, { n, xs: [] }]));
  for (const x of list) { const k = itemDef(item(x)).kind; (groups.get(k) || groups.get('mat')).xs.push(x); }
  let html = '';
  for (const [, g] of groups) {
    if (!g.xs.length) continue;
    html += `<div class="ig-sec"><span>${g.n}</span><small>${g.xs.length}</small></div><div class="ig">`;
    for (const x of g.xs) {
      const it = item(x), q = it.qty > 1 ? `<span class="ig-q">×${it.qty}</span>` : '';
      const rf = it.refine ? `<span class="ig-r">+${it.refine}</span>` : '';
      const sl = it.slots ? `<span class="ig-s">${'<i class="on"></i>'.repeat((it.cards || []).length)}${'<i></i>'.repeat(it.slots - (it.cards || []).length)}</span>` : '';
      const up = opts.better && opts.better(it) ? '<span class="ig-up">▲</span>' : '';
      html += `<button class="ig-t" data-${opts.attr || 'u'}="${opts.key ? opts.key(x) : it.uid}" style="--rc:${opts.color(it)}">
        <span class="ig-ic"><img src="${opts.icon(it)}" alt="">${q}${rf}${up}${sl}</span>
        <span class="ig-n">${esc(opts.name(it))}</span>${opts.sub ? `<span class="ig-sub">${opts.sub(x)}</span>` : ''}</button>`;
    }
    html += '</div>';
  }
  return html;
}
