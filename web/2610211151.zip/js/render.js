// Renderização em canvas: masmorra, iluminação suave, entidades e efeitos
import { G, visible, monsterAt } from './game.js';
import { THEMES, MONSTERS, ELEMENTS, artCls } from './data.js';
import { T, tileAt } from './map.js';
import { monsterSprite, heroSprite, itemSprite, shade, SPR } from './sprites.js';
import { itemDef } from './rules.js';
import { heroFrame, frameCount, CELL, FEET } from './lpc.js';
import { terrainTiles } from './terrain.js';
import { HERO_META } from './hero_meta.js';
import { Audio } from './audio.js';

const R = {
  cv: null, ctx: null, dpr: 1, W: 0, H: 0, TS: 44, baseTS: 44, zoom: 1, follow: true,
  camX: 0, camY: 0, topPad: 96, botPad: 170,
  anims: new Map(), parts: [], texts: [], projs: [], rings: [], corpses: [], pending: [],
  shake: 0, hurt: 0, flashFloor: 0, tiles: null, tilesKey: '', lc: null, lctx: null,
  targeting: null, marker: null, face: 1, hdir: 2, hanim: null, hmove: -1e9, last: 0, time: 0, victory: 0,
};
export { R };

export function initRender(canvas) {
  R.cv = canvas;
  R.ctx = canvas.getContext('2d');
  resize();
  window.addEventListener('resize', resize);
  requestAnimationFrame(loop);
}

export function resize() {
  R.dpr = Math.min(window.devicePixelRatio || 1, 3);
  R.W = window.innerWidth; R.H = window.innerHeight;
  R.cv.width = Math.round(R.W * R.dpr); R.cv.height = Math.round(R.H * R.dpr);
  R.cv.style.width = R.W + 'px'; R.cv.style.height = R.H + 'px';
  R.baseTS = Math.max(38, Math.min(64, Math.floor(R.W / 9)));
  applyZoom();
  R.tilesKey = '';
}

export function setPads(top, bot) { R.topPad = top; R.botPad = bot; }

// ---------------- Conversões ----------------
const viewCY = () => R.topPad + (R.H - R.topPad - R.botPad) / 2;
export function screenToTile(px, py) {
  const x = Math.floor((px - R.W / 2) / R.TS + R.camX + 0.5);
  const y = Math.floor((py - viewCY()) / R.TS + R.camY + 0.5);
  return { x, y };
}
const sx = (tx) => (tx - R.camX) * R.TS + R.W / 2 - R.TS / 2;
const sy = (ty) => (ty - R.camY) * R.TS + viewCY() - R.TS / 2;

// ---------------- Tiles pré-renderizados ----------------
function hash(x, y) { let h = (x * 374761393 + y * 668265263) | 0; h = (h ^ (h >>> 13)) * 1274126177; return (h ^ (h >>> 16)) >>> 0; }

function chamfer(x, a, b, w, h, k) {
  x.beginPath(); x.moveTo(a + k, b); x.lineTo(a + w - k, b); x.lineTo(a + w, b + k); x.lineTo(a + w, b + h - k);
  x.lineTo(a + w - k, b + h); x.lineTo(a + k, b + h); x.lineTo(a, b + h - k); x.lineTo(a, b + k); x.closePath();
}
// Placa de pedra chanfrada com luz no canto superior esquerdo
function slab(x, a, b, w, h, base, d) {
  const k = Math.min(w, h) * 0.16;
  chamfer(x, a, b, w, h, k);
  const g = x.createLinearGradient(a, b, a + w * 0.7, b + h);
  g.addColorStop(0, shade(base, 0.07)); g.addColorStop(0.6, base); g.addColorStop(1, shade(base, -0.1));
  x.fillStyle = g; x.fill();
  x.lineWidth = 1 * d; x.strokeStyle = 'rgba(0,0,0,0.25)'; x.stroke();
  // reflexo nas bordas de cima e esquerda
  x.beginPath(); x.moveTo(a + 1.5 * d, b + h - k); x.lineTo(a + 1.5 * d, b + k); x.lineTo(a + k, b + 1.5 * d); x.lineTo(a + w - k, b + 1.5 * d);
  x.lineWidth = 1 * d; x.strokeStyle = 'rgba(255,255,255,0.07)'; x.stroke();
}

function buildTiles(theme) {
  const s = Math.round(R.TS * R.dpr);
  const d = R.dpr;
  const th = THEMES[theme];
  const mkc = () => { const c = document.createElement('canvas'); c.width = s; c.height = s; return c; };
  const floors = [];
  const gap = 1.5 * d;
  for (let v = 0; v < 4; v++) {
    const c = mkc(), x = c.getContext('2d');
    x.fillStyle = shade(th.floor[0], -0.3); x.fillRect(0, 0, s, s); // rejunte
    const c0 = th.floor[0], c1 = th.floor[1];
    if (v === 0) slab(x, gap, gap, s - gap * 2, s - gap * 2, c0, d);
    else if (v === 1) { slab(x, gap, gap, s * 0.5 - gap * 1.5, s - gap * 2, c0, d); slab(x, s * 0.5 + gap * 0.5, gap, s * 0.5 - gap * 1.5, s * 0.55, c1, d); slab(x, s * 0.5 + gap * 0.5, s * 0.55 + gap * 2, s * 0.5 - gap * 1.5, s * 0.45 - gap * 3, c0, d); }
    else if (v === 2) { slab(x, gap, gap, s - gap * 2, s * 0.45, c1, d); slab(x, gap, s * 0.45 + gap * 2, s * 0.62, s * 0.55 - gap * 3, c0, d); slab(x, s * 0.62 + gap * 2, s * 0.45 + gap * 2, s * 0.38 - gap * 3, s * 0.55 - gap * 3, c1, d); }
    else { for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) slab(x, gap + i * s / 2, gap + j * s / 2, s / 2 - gap * 2, s / 2 - gap * 2, (i + j) % 2 ? c0 : c1, d); }
    // pequenas rachaduras e pontos
    x.strokeStyle = 'rgba(0,0,0,0.22)'; x.lineWidth = 1 * d;
    if (hash(v, 9) % 2) { x.beginPath(); x.moveTo(s * 0.3, s * 0.35); x.lineTo(s * 0.42, s * 0.48); x.lineTo(s * 0.38, s * 0.6); x.stroke(); }
    for (let i = 0; i < 4; i++) { x.fillStyle = i % 2 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.12)'; x.fillRect((hash(v, i) % 90) / 100 * s, (hash(i, v + 7) % 90) / 100 * s, 1.5 * d, 1.5 * d); }
    floors.push(c);
  }
  // topo da parede: placa escura chanfrada
  const wallTop = mkc(), wt = wallTop.getContext('2d');
  wt.fillStyle = shade(th.wall[1], -0.55); wt.fillRect(0, 0, s, s);
  slab(wt, 1 * d, 1 * d, s - 2 * d, s - 2 * d, shade(th.wall[2], -0.15), d);

  // face da parede: blocos chanfrados com reflexo
  const wallFace = mkc(), wf = wallFace.getContext('2d');
  wf.drawImage(wallTop, 0, 0);
  const fh = s * 0.58, top = s - fh;
  wf.fillStyle = shade(th.wall[0], -0.55); wf.fillRect(0, top, s, fh);
  const rows = 3, bh = fh / rows;
  for (let r = 0; r < rows; r++) {
    const off = r % 2 ? -s / 4 : 0;
    for (let cx = off; cx < s; cx += s / 2) {
      const bw = s / 2;
      slab(wf, Math.max(0, cx) + gap / 2, top + r * bh + gap / 2, Math.min(bw, s - Math.max(0, cx), cx + bw) - gap, bh - gap, shade(th.wall[0], 0.08 - 0.08 * r), d);
    }
  }
  // borda superior iluminada
  wf.fillStyle = 'rgba(255,255,255,0.22)'; wf.fillRect(0, top, s, 1.5 * d);
  // sombra na base
  const sg = wf.createLinearGradient(0, s - fh * 0.35, 0, s);
  sg.addColorStop(0, 'rgba(0,0,0,0)'); sg.addColorStop(1, 'rgba(0,0,0,0.35)');
  wf.fillStyle = sg; wf.fillRect(0, s - fh * 0.35, s, fh * 0.35);
  R.tiles = { floors, wallTop, wallFace, s, dc: terrainTiles(theme, s) };
}

// ---------------- Processamento de efeitos ----------------
function animOf(id) {
  if (!R.anims.has(id)) R.anims.set(id, {});
  return R.anims.get(id);
}

function renderPos(id, x, y, now) {
  const a = R.anims.get(id);
  if (!a || !a.move) return { x, y };
  const t = Math.min(1, (now - a.move.t0) / a.move.dur);
  if (t >= 1) { a.move = null; return { x, y }; }
  const e = 1 - Math.pow(1 - t, 2);
  return { x: a.move.fx + (x - a.move.fx) * e, y: a.move.fy + (y - a.move.fy) * e };
}

function entityPos(id) {
  const r = G.state.run;
  if (id === 'hero') return { x: r.px, y: r.py };
  const m = r.monsters.find((o) => o.uid === id);
  return m ? { x: m.x, y: m.y } : null;
}

// variação de piso/parede: as primeiras são as mais comuns (as últimas, como flores, aparecem pouco)
const TEXTURE_DECOR = new Set(['grass', 'flower', 'sand', 'carpet', 'puddle']);
function pickVar(x, y, n) {
  const h = Math.abs(hash(x, y)) % 100;
  if (n <= 3) return h % n;
  return h < 80 ? h % 3 : 3 + (h % (n - 3));
}

function heroDir(dx, dy) {
  if (!dx && !dy) return;
  R.hdir = Math.abs(dx) >= Math.abs(dy) ? (dx > 0 ? 3 : 1) : (dy > 0 ? 2 : 0);
  if (dx) R.face = dx > 0 ? 1 : -1;
}

// quadro atual do herói LPC (andar / atacar / magia)
const FRAME_MS = { slash: 55, thrust: 55, shoot: 38, spellcast: 65 };
function heroFrameNow(cls, now) {
  const ha = R.hanim;
  if (ha) {
    const n = frameCount(cls, ha.anim);
    const ms = ha.anim === 'cast' ? 65 : (FRAME_MS[HERO_META[artCls(cls)]?.atkType] || 55);
    const col = Math.floor((now - ha.t0) / ms);
    if (col < n) return heroFrame(cls, ha.anim, R.hdir, col);
    R.hanim = null;
  }
  const walking = now - R.hmove < 190;
  return heroFrame(cls, 'walk', R.hdir, walking ? 1 + Math.floor(now / 75) % 8 : 0);
}

function burst(x, y, color, n = 10, speed = 2.5, life = 600, size = 3) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, v = (0.3 + Math.random()) * speed;
    R.parts.push({ x: x + 0.5, y: y + 0.5, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 1, g: 3, life, t0: R.time, color, size: size * (0.6 + Math.random() * 0.8) });
  }
}

function handleFx(e) {
  const now = R.time;
  switch (e.type) {
    case 'sfx': Audio.play(e.name); break;
    case 'dmg':
      R.texts.push({ x: e.x + 0.5 + (Math.random() - 0.5) * 0.3, y: e.y + 0.1, text: String(e.val), color: e.color, crit: e.crit, t0: now, big: e.crit || e.val > 999 });
      burst(e.x, e.y, e.onHero ? '#ff6a6a' : (e.el && e.el !== 'neutro' ? ELEMENTS[e.el].color : '#fff3d0'), e.crit ? 14 : 6, 2.2, 450, 2.5);
      break;
    case 'text': R.texts.push({ x: e.x + 0.5, y: e.y, text: e.text, color: e.color, t0: now, small: true }); break;
    case 'heal':
      R.texts.push({ x: e.x + 0.5, y: e.y, text: '+' + e.val, color: '#7af08a', t0: now });
      for (let i = 0; i < 12; i++) R.parts.push({ x: e.x + 0.2 + Math.random() * 0.6, y: e.y + 0.9, vx: 0, vy: -1.2 - Math.random(), g: 0, life: 800, t0: now, color: '#9affb0', size: 2.5, glow: true });
      break;
    case 'flash': animOf(e.id).flash = now; break;
    case 'move': {
      const a = animOf(e.id);
      let fx = e.fx, fy = e.fy;
      if (a.move) {
        // continua da posição visual atual (movimento anterior ainda em curso)
        const q = Math.min(1, (now - a.move.t0) / a.move.dur), k = 1 - Math.pow(1 - q, 2);
        fx = a.move.fx + (e.fx - a.move.fx) * k; fy = a.move.fy + (e.fy - a.move.fy) * k;
      }
      if (e.id === 'hero' && e.tx !== undefined) { heroDir(e.tx - e.fx, e.ty - e.fy); R.hmove = now; }
      if (e.instant) { a.move = null; break; }
      a.move = { fx, fy, t0: now, dur: e.id === 'hero' ? 115 : 130 };
      break;
    }
    case 'lunge': {
      const a = animOf(e.id); a.lunge = { tx: e.tx, ty: e.ty, t0: now };
      if (e.id === 'hero' && G.state.run) { heroDir(e.tx - G.state.run.px, e.ty - G.state.run.py); R.hanim = { anim: 'atk', t0: now }; }
      break;
    }
    case 'face': if (G.state.run) R.face = e.x < G.state.run.px ? -1 : e.x > G.state.run.px ? 1 : R.face; break;
    case 'proj':
      if (G.state.run && e.fx === G.state.run.px && e.fy === G.state.run.py) {
        heroDir(e.tx - e.fx, e.ty - e.fy);
        if (!(R.hanim && R.hanim.anim === 'cast' && now - R.hanim.t0 < 40)) R.hanim = { anim: 'atk', t0: now };
      }
      R.projs.push({ ...e, t0: now, dur: 140 + Math.hypot(e.tx - e.fx, e.ty - e.fy) * 20 }); break;
    case 'burst': burst(e.x, e.y, e.color, e.n || 8, 2, 550, 3); break;
    case 'ring': R.rings.push({ x: e.x + 0.5, y: e.y + 0.5, r: e.r + 0.5, color: e.color, t0: now, dur: 380 }); break;
    case 'shake': R.shake = Math.max(R.shake, e.power || 4); break;
    case 'death': {
      burst(e.x, e.y, e.color, e.boss ? 60 : 18, e.boss ? 5 : 3, e.boss ? 1400 : 700, 3.5);
      if (e.mtype) R.corpses.push({ x: e.x, y: e.y, mtype: e.mtype, t0: now, face: 1 });
      if (e.boss) R.shake = 14;
      break;
    }
    case 'levelup':
      R.texts.push({ x: e.x + 0.5, y: e.y - 0.4, text: 'NÍVEL!', color: '#ffd86b', t0: now, big: true });
      R.rings.push({ x: e.x + 0.5, y: e.y + 0.5, r: 2.5, color: '#ffd86b', t0: now, dur: 700 });
      for (let i = 0; i < 26; i++) R.parts.push({ x: e.x + 0.5 + Math.cos(i) * 0.5, y: e.y + 0.8, vx: Math.cos(i) * 0.4, vy: -2 - Math.random() * 1.5, g: 0, life: 1100, t0: now, color: '#ffe8a0', size: 3, glow: true });
      break;
    case 'cast':
      if (G.state.run && e.x === G.state.run.px && e.y === G.state.run.py) R.hanim = { anim: 'cast', t0: now };
      R.rings.push({ x: e.x + 0.5, y: e.y + 0.5, r: 0.9, color: e.color, t0: now, dur: 450, circle: true }); break;
    case 'meteor': R.projs.push({ fx: e.x - 2, fy: e.y - 6, tx: e.x, ty: e.y, color: '#ff8a3a', big: true, t0: now, dur: 260, meteor: true }); break;
    case 'cardDrop': for (let i = 0; i < 20; i++) R.parts.push({ x: e.x + Math.random(), y: e.y + Math.random(), vx: 0, vy: -0.8, g: 0, life: 1500, t0: now + i * 40, color: '#ffd86b', size: 2.5, glow: true }); break;
    case 'splash': burst(e.x, e.y, '#9ad8ff', 6, 1.5, 400, 2); break;
    case 'hurt': R.hurt = now; if (G.state.settings?.vibrate && navigator.vibrate) try { navigator.vibrate(25); } catch (_) {} break;
    case 'floor': R.flashFloor = now; R.anims.clear(); R.parts = []; R.texts = []; R.projs = []; R.corpses = []; snapCamera(); break;
    case 'victory': R.victory = now; break;
  }
}

function pumpFx() {
  const now = R.time;
  while (G.fx.length) {
    const e = G.fx.shift();
    if (e.delay) R.pending.push({ at: now + e.delay, e: { ...e, delay: 0 } });
    else handleFx(e);
  }
  if (R.pending.length) {
    const due = R.pending.filter((p) => p.at <= now);
    R.pending = R.pending.filter((p) => p.at > now);
    due.forEach((p) => handleFx(p.e));
  }
}

function applyZoom() {
  const minZ = Math.max(0.2, (R.W / 42) / R.baseTS);
  R.zoom = Math.max(minZ, Math.min(1.6, R.zoom));
  R.TS = Math.max(8, Math.round(R.baseTS * R.zoom));
}

// Câmera livre: arrastar e pinçar, como no Shattered Pixel Dungeon
export function panCamera(dxPx, dyPx) {
  R.follow = false;
  R.camX -= dxPx / R.TS; R.camY -= dyPx / R.TS;
  const m = G.state?.run?.map;
  if (m) { R.camX = Math.max(0, Math.min(m.w - 1, R.camX)); R.camY = Math.max(0, Math.min(m.h - 1, R.camY)); }
}
export function zoomCamera(factor, cxPx, cyPx) {
  const before = screenToTileF(cxPx, cyPx);
  R.zoom *= factor;
  applyZoom();
  const after = screenToTileF(cxPx, cyPx);
  R.camX += before.x - after.x; R.camY += before.y - after.y;
  if (factor !== 1) R.follow = false;
}
function screenToTileF(px, py) { return { x: (px - R.W / 2) / R.TS + R.camX, y: (py - viewCY()) / R.TS + R.camY }; }
export function followHero() { R.follow = true; }
export function resetZoom() { R.zoom = 1; applyZoom(); R.follow = true; }
export const cameraFree = () => !R.follow || Math.abs(R.zoom - 1) > 0.01;

export function snapCamera() {
  const r = G.state?.run;
  if (r) { R.camX = r.px; R.camY = r.py; }
}

// ---------------- Laço principal ----------------
function loop(ts) {
  const dt = Math.min(50, ts - (R.last || ts));
  R.last = ts; R.time = ts;
  pumpFx();
  const ctx = R.ctx;
  ctx.setTransform(R.dpr, 0, 0, R.dpr, 0, 0);
  const st = G.state;
  if (st && st.mode === 'dungeon' && st.run) drawDungeon(ctx, dt);
  else drawBackdrop(ctx, st?.mode);
  requestAnimationFrame(loop);
}

// Fundo da cidade / título: aurora suave
const stars = Array.from({ length: 80 }, () => ({ x: Math.random(), y: Math.random() * 0.7, r: Math.random() * 1.4 + 0.3, p: Math.random() * 6 }));
function drawBackdrop(ctx, mode) {
  const W = R.W, H = R.H, t = R.time / 1000;
  ctx.fillStyle = mode === 'dead' ? '#0c0610' : '#07081a';
  ctx.fillRect(0, 0, W, H);
  const blobs = mode === 'dead'
    ? [['255,60,90', 0.5, 0.3, 0.6]]
    : [['167,123,255', 0.25, 0.22, 0.75], ['94,225,255', 0.8, 0.35, 0.65], ['255,110,200', 0.55, 0.75, 0.6]];
  ctx.globalCompositeOperation = 'lighter';
  blobs.forEach(([c, bx, by, r], i) => {
    const x = (bx + Math.sin(t * 0.13 + i * 2) * 0.08) * W, y = (by + Math.cos(t * 0.11 + i) * 0.06) * H, rad = r * Math.max(W, H) * 0.6;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, `rgba(${c},0.32)`); g.addColorStop(1, `rgba(${c},0)`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  });
  ctx.globalCompositeOperation = 'source-over';
  for (const s of stars) { ctx.globalAlpha = 0.25 + 0.35 * Math.sin(t * 1.4 + s.p); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(s.x * W, s.y * H, s.r, 0, 7); ctx.fill(); }
  ctx.globalAlpha = 1;
  if (mode === 'dead') return;
  // silhueta do castelo com janelas acesas
  const base = H * 0.86, cx = W * 0.5;
  ctx.fillStyle = 'rgba(6,6,20,0.9)';
  ctx.beginPath(); ctx.moveTo(0, base + 20);
  for (let i = 0; i <= 12; i++) ctx.lineTo(i * W / 12, base - 10 - Math.sin(i * 1.3) * 14);
  ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
  ctx.fillRect(cx - 60, base - 70, 120, 90);
  for (const [dx, h, w] of [[-62, 120, 22], [40, 132, 22], [-11, 170, 24]]) {
    ctx.fillRect(cx + dx, base - h, w, h);
    ctx.beginPath(); ctx.moveTo(cx + dx - 5, base - h); ctx.lineTo(cx + dx + w / 2, base - h - 30); ctx.lineTo(cx + dx + w + 5, base - h); ctx.fill();
  }
  ctx.save(); ctx.shadowColor = '#5ee1ff'; ctx.shadowBlur = 12;
  for (const [dx, dy] of [[-54, 90], [48, 104], [-3, 140], [-30, 40], [22, 50]]) { ctx.fillStyle = `rgba(160,235,255,${0.6 + 0.3 * Math.sin(t * 2 + dx)})`; ctx.fillRect(cx + dx, base - dy, 5, 8); }
  ctx.restore();
  // partículas subindo
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 22; i++) {
    const x = ((i * 0.137 + Math.sin(t * 0.2 + i) * 0.04) % 1) * W, y = H - ((t * 18 + i * 61) % (H * 0.9));
    const g = ctx.createRadialGradient(x, y, 0, x, y, 6); g.addColorStop(0, 'rgba(160,220,255,0.6)'); g.addColorStop(1, 'rgba(160,220,255,0)');
    ctx.fillStyle = g; ctx.fillRect(x - 6, y - 6, 12, 12);
  }
  ctx.globalCompositeOperation = 'source-over';
}

// ---------------- Masmorra ----------------
function drawDungeon(ctx, dt) {
  const r = G.state.run, m = r.map, now = R.time;
  const th = THEMES[m.theme];
  const key = `${m.theme}:${R.TS}:${R.dpr}`;
  if (R.tilesKey !== key) { buildTiles(m.theme); R.tilesKey = key; }
  const TS = R.TS;

  // câmera suave
  const hp = renderPos('hero', r.px, r.py, now);
  if (R.follow) {
    const k = 1 - Math.pow(0.0005, dt / 1000);
    R.camX += (hp.x - R.camX) * k; R.camY += (hp.y - R.camY) * k;
  }
  let shx = 0, shy = 0;
  if (R.shake > 0.2) { shx = (Math.random() - 0.5) * R.shake; shy = (Math.random() - 0.5) * R.shake; R.shake *= Math.pow(0.002, dt / 1000); } else R.shake = 0;

  ctx.fillStyle = '#07080c'; ctx.fillRect(0, 0, R.W, R.H);
  ctx.save(); ctx.translate(shx, shy);

  const x0 = Math.max(0, Math.floor(R.camX - R.W / 2 / TS) - 1), x1 = Math.min(m.w - 1, Math.ceil(R.camX + R.W / 2 / TS) + 1);
  const y0 = Math.max(0, Math.floor(R.camY - viewCY() / TS) - 1), y1 = Math.min(m.h - 1, Math.ceil(R.camY + (R.H - viewCY()) / TS) + 1);
  const t = now / 1000;
  const tl = R.tiles;

  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
    const i = y * m.w + x;
    if (!m.seen[i]) continue;
    const tt = m.t[i], X = sx(x), Y = sy(y);
    if (tt === T.WALL) {
      const below = tileAt(m, x, y + 1);
      if (tl.dc) {
        const v = Math.abs(hash(x, y)) % 2;
        if (tl.dc.natural) ctx.drawImage(tl.dc.base, X, Y, TS, TS); // rocha/terra; a floresta dos Campos vem por cima
        else ctx.drawImage(below === T.WALL ? tl.dc.tops[v] : tl.dc.faces[v], X, Y, TS, TS);
      } else ctx.drawImage(below === T.WALL ? tl.wallTop : tl.wallFace, X, Y, TS, TS);
      if (m.decor[i] === 'torch' && below !== T.WALL && !(tl.dc && tl.dc.trees)) drawTorch(ctx, X, Y, TS, t, th);
      continue;
    }
    if (tl.dc) {
      const open = (dx, dy) => tileAt(m, x + dx, y + dy) !== T.WALL;
      let edge = false;
      if (tl.dc.floorAuto) for (const [dx, dy] of [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]]) if (!open(dx, dy)) { edge = true; break; }
      if (edge) { ctx.drawImage(tl.dc.base, X, Y, TS, TS); ctx.drawImage(tl.dc.floorAuto(open), X, Y, TS, TS); }
      else ctx.drawImage(tl.dc.floors[pickVar(x, y, 4)], X, Y, TS, TS);
    }
    else { const hv = hash(x, y) % 10; ctx.drawImage(tl.floors[hv < 5 ? 0 : hv < 7 ? 3 : hv < 9 ? 1 : 2], X, Y, TS, TS); }
    // sombra de parede acima
    if (tileAt(m, x, y - 1) === T.WALL && !(tl.dc && tl.dc.natural)) { const g = ctx.createLinearGradient(0, Y, 0, Y + TS * 0.45); g.addColorStop(0, 'rgba(0,0,0,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(X, Y, TS, TS * 0.45); }
    if (tt === T.LIQUID || tt === T.CHASM) {
      // líquido e buraco com bordas contínuas (autotile); lava funda também é lava
      const lava = th.liquid === 'lava';
      const auto = tt === T.LIQUID || lava ? tl.dc && tl.dc.liquid : tl.dc && tl.dc.hole;
      if (auto) {
        const isMe = (k) => k === tt || (lava && (k === T.LIQUID || k === T.CHASM));
        ctx.drawImage(auto((dx, dy) => isMe(tileAt(m, x + dx, y + dy))), X, Y, TS, TS);
      } else drawLiquid(ctx, X, Y, TS, t, th, x, y, tt === T.CHASM);
    }
    else if (tt === T.STAIRS) {
      if (tl.dc && tl.dc.stairs) {
        ctx.drawImage(tl.dc.stairs, X, Y, TS, TS);
        const g = ctx.createLinearGradient(0, Y, 0, Y + TS); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.55)');
        ctx.fillStyle = g; ctx.fillRect(X, Y, TS, TS);
      } else drawStairs(ctx, X, Y, TS, t);
    }
    else if (tt === T.PORTAL) drawPortal(ctx, X, Y, TS, t);
    if (m.decor[i] && m.decor[i] !== 'torch' && !(tl.dc && TEXTURE_DECOR.has(m.decor[i]))) drawDecor(ctx, m.decor[i], X, Y, TS, hash(x, y), t, th);
  }

  // floresta dos Campos: copas de árvore sobre as paredes, de cima para baixo para se sobreporem
  if (tl.dc && tl.dc.trees) {
    ctx.imageSmoothingEnabled = false;
    for (let y = y0; y <= y1 + 1; y++) for (let x = x0; x <= x1; x++) {
      const i = y * m.w + x;
      if (y >= m.h || m.t[i] !== T.WALL || !m.seen[i]) continue;
      const h = Math.abs(hash(x, y)), n = tl.dc.trees.length;
      const tr = tl.dc.trees[(h % 5 === 0 ? 2 + ((h >>> 3) % 2) : (h >>> 3) % 2) % n];
      const w = TS * 1.55, hh = w * tr.height / tr.width;
      ctx.drawImage(tr, sx(x) + TS / 2 - w / 2, sy(y) + TS * 1.25 - hh, w, hh);
    }
    ctx.imageSmoothingEnabled = true;
  }

  // telegrafias
  for (const tg of r.telegraphs) {
    const left = Math.max(0, tg.at - r.time) / 14;
    const pulse = 0.35 + 0.25 * Math.sin(now / 90);
    ctx.fillStyle = tg.color; ctx.globalAlpha = pulse * (1.2 - left * 0.5);
    for (const [x, y] of tg.tiles) if (m.seen[y * m.w + x]) { ctx.beginPath(); ctx.roundRect(sx(x) + 2, sy(y) + 2, TS - 4, TS - 4, 6); ctx.fill(); }
    ctx.globalAlpha = 1;
  }

  // alcance da habilidade
  if (R.targeting) {
    const tgt = R.targeting;
    ctx.fillStyle = 'rgba(122,208,255,0.10)';
    for (let y = r.py - tgt.range; y <= r.py + tgt.range; y++) for (let x = r.px - tgt.range; x <= r.px + tgt.range; x++) {
      if (visible(x, y) && tileAt(m, x, y) !== T.WALL) ctx.fillRect(sx(x) + 1, sy(y) + 1, TS - 2, TS - 2);
    }
  }

  // itens no chão
  for (const g of r.items) {
    if (!m.seen[g.y * m.w + g.x]) continue;
    const X = sx(g.x), Y = sy(g.y) + Math.sin(t * 3 + g.x) * 2;
    const d = itemDef(g.item);
    if (d.kind === 'card') { ctx.save(); ctx.shadowColor = '#ffd86b'; ctx.shadowBlur = 16; }
    ctx.drawImage(itemSprite(g.item), X + TS * 0.18, Y + TS * 0.15, TS * 0.64, TS * 0.64);
    if (d.kind === 'card') ctx.restore();
  }

  // cadáveres desaparecendo
  R.corpses = R.corpses.filter((c) => now - c.t0 < 450);
  for (const c of R.corpses) {
    const p = (now - c.t0) / 450;
    const spr = monsterSprite(c.mtype);
    const sc = (MONSTERS[c.mtype].sprite.scale || 1) * TS * 1.35;
    ctx.globalAlpha = 1 - p;
    ctx.imageSmoothingEnabled = !spr.pixel;
    ctx.drawImage(spr, sx(c.x) + TS / 2 - sc / 2, sy(c.y) + TS * 0.95 - sc * 0.92 + p * 8, sc, sc * (1 - p * 0.5));
    ctx.globalAlpha = 1; ctx.imageSmoothingEnabled = true;
  }

  // entidades ordenadas por y
  const ents = [];
  for (const mo of r.monsters) if (mo.hp > 0 && visible(mo.x, mo.y)) ents.push({ kind: 'm', o: mo, ...renderPos(mo.uid, mo.x, mo.y, now) });
  ents.push({ kind: 'h', ...hp });
  ents.sort((a, b) => a.y - b.y);
  for (const e of ents) drawEntity(ctx, e, now, t);

  // projéteis
  R.projs = R.projs.filter((p) => now - p.t0 < p.dur);
  for (const p of R.projs) {
    const q = (now - p.t0) / p.dur;
    const x = sx(p.fx + (p.tx - p.fx) * q) + TS / 2, y = sy(p.fy + (p.ty - p.fy) * q) + TS / 2 - (p.meteor ? 0 : TS * 0.25);
    ctx.save(); ctx.shadowColor = p.color; ctx.shadowBlur = p.big ? 18 : 8; ctx.fillStyle = p.color;
    if (p.arrow) {
      const a = Math.atan2(p.ty - p.fy, p.tx - p.fx);
      ctx.translate(x, y); ctx.rotate(a); ctx.fillRect(-TS * 0.3, -1.5, TS * 0.5, 3); ctx.beginPath(); ctx.moveTo(TS * 0.25, -5); ctx.lineTo(TS * 0.38, 0); ctx.lineTo(TS * 0.25, 5); ctx.fill();
    } else { ctx.beginPath(); ctx.arc(x, y, p.big ? TS * 0.16 : TS * 0.08, 0, 7); ctx.fill(); if (p.big) R.parts.push({ x: x / TS, y: 0, sx: x, sy: y, screen: true, vx: 0, vy: 0, g: 0, life: 250, t0: now, color: p.color, size: 4, glow: true }); }
    ctx.restore();
  }

  // anéis
  R.rings = R.rings.filter((g) => now - g.t0 < g.dur);
  for (const g of R.rings) {
    const q = (now - g.t0) / g.dur;
    ctx.save(); ctx.globalAlpha = 1 - q; ctx.strokeStyle = g.color; ctx.lineWidth = 3; ctx.shadowColor = g.color; ctx.shadowBlur = 12;
    ctx.beginPath(); ctx.ellipse(sx(g.x - 0.5) + TS / 2, sy(g.y - 0.5) + TS / 2 + TS * 0.25, g.r * TS * (g.circle ? 1 : q), g.r * TS * 0.55 * (g.circle ? 1 : q), 0, 0, 7); ctx.stroke();
    if (g.circle) { ctx.setLineDash([6, 6]); ctx.lineDashOffset = -now / 20; ctx.beginPath(); ctx.ellipse(sx(g.x - 0.5) + TS / 2, sy(g.y - 0.5) + TS / 2 + TS * 0.25, g.r * TS * 0.7, g.r * TS * 0.38, 0, 0, 7); ctx.stroke(); }
    ctx.restore();
  }

  // partículas (coordenadas de tile)
  R.parts = R.parts.filter((p) => now - p.t0 < p.life);
  for (const p of R.parts) {
    if (now < p.t0) continue;
    const a = (now - p.t0) / 1000;
    const q = (now - p.t0) / p.life;
    let X, Y;
    if (p.screen) { X = p.sx; Y = p.sy; }
    else { X = sx(p.x + p.vx * a - 0.5) + TS / 2; Y = sy(p.y + p.vy * a + p.g * a * a * 0.5 - 0.5) + TS / 2; }
    ctx.globalAlpha = 1 - q;
    if (p.glow) { ctx.save(); ctx.shadowColor = p.color; ctx.shadowBlur = 8; }
    ctx.fillStyle = p.color; ctx.fillRect(X - p.size / 2, Y - p.size / 2, p.size, p.size);
    if (p.glow) ctx.restore();
  }
  ctx.globalAlpha = 1;

  // iluminação
  drawLighting(ctx, r, m, th, t, x0, x1, y0, y1);

  // números flutuantes
  R.texts = R.texts.filter((tx) => now - tx.t0 < 950);
  for (const tx of R.texts) {
    const q = (now - tx.t0) / 950;
    const X = sx(tx.x - 0.5) + TS / 2, Y = sy(tx.y - 0.5) + TS * 0.1 - q * TS * 0.9 - (q < 0.15 ? 0 : 0);
    const size = tx.big ? 22 : tx.small ? 13 : 17;
    const pop = q < 0.12 ? 1 + (0.12 - q) * 4 : 1;
    ctx.save();
    ctx.globalAlpha = q > 0.7 ? (1 - q) / 0.3 : 1;
    ctx.font = `800 ${Math.round(size * pop)}px system-ui, -apple-system, Roboto, sans-serif`;
    ctx.textAlign = 'center';
    ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,6,16,0.9)'; ctx.strokeText(tx.text, X, Y);
    ctx.fillStyle = tx.color; ctx.fillText(tx.text, X, Y);
    ctx.restore();
  }

  // marcador de destino / alvo
  if (R.marker && now - R.marker.t0 < 600) {
    const q = (now - R.marker.t0) / 600;
    ctx.save(); ctx.globalAlpha = 1 - q; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(sx(R.marker.x) + TS / 2, sy(R.marker.y) + TS * 0.7, TS * 0.35 * (0.6 + q * 0.5), TS * 0.16 * (0.6 + q * 0.5), 0, 0, 7); ctx.stroke(); ctx.restore();
  }
  ctx.restore();

  // dano no herói: vinheta vermelha
  if (now - R.hurt < 300) {
    const q = 1 - (now - R.hurt) / 300;
    const g = ctx.createRadialGradient(R.W / 2, R.H / 2, R.W * 0.3, R.W / 2, R.H / 2, R.H * 0.7);
    g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(200,0,20,${0.45 * q})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, R.W, R.H);
  }
  // HP baixo: pulsação
  const h = G.state.hero;
  if (h && G.d && h.hp < G.d.maxHp * 0.25) {
    const g = ctx.createRadialGradient(R.W / 2, R.H / 2, R.W * 0.35, R.W / 2, R.H / 2, R.H * 0.75);
    g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(160,0,20,${0.18 + 0.12 * Math.sin(now / 200)})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, R.W, R.H);
  }
  // transição de andar
  if (now - R.flashFloor < 600) { ctx.fillStyle = `rgba(0,0,0,${1 - (now - R.flashFloor) / 600})`; ctx.fillRect(0, 0, R.W, R.H); }
}

function drawEntity(ctx, e, now, t) {
  const TS = R.TS;
  const isHero = e.kind === 'h';
  const id = isHero ? 'hero' : e.o.uid;
  const a = R.anims.get(id) || {};
  let ox = 0, oy = 0;
  if (a.lunge) {
    const q = (now - a.lunge.t0) / 180;
    if (q >= 1) a.lunge = null;
    else {
      const dx = a.lunge.tx - e.x, dy = a.lunge.ty - e.y, len = Math.hypot(dx, dy) || 1;
      const amt = Math.sin(q * Math.PI) * 0.3;
      ox = dx / len * amt; oy = dy / len * amt;
    }
  }
  const X = sx(e.x + ox), Y = sy(e.y + oy);
  let spr, scale = 1, face = 1;
  if (isHero) {
    const h = G.state.hero;
    spr = heroSprite(h.cls, G.d.wtype);
    face = R.face;
  } else {
    spr = monsterSprite(e.o.type);
    scale = MONSTERS[e.o.type].sprite.scale || 1;
    face = e.x > G.state.run.px ? -1 : 1;
  }
  const size = TS * 1.35 * scale;
  const phase = isHero ? 0 : (e.o.uid % 10);
  const moving = a.move ? 1 : 0;
  const bob = Math.sin(t * (isHero ? 3 : 4) + phase) * 0.025 * TS + (moving ? -Math.abs(Math.sin(t * 25)) * TS * 0.08 : 0);
  const squash = !isHero && MONSTERS[e.o.type].sprite.shape === 'blob' ? 1 + Math.sin(t * 5 + phase) * 0.05 : 1;
  const fly = !isHero && ['bat', 'ghost'].includes(MONSTERS[e.o.type].sprite.shape) ? -TS * 0.25 + Math.sin(t * 6 + phase) * TS * 0.06 : 0;

  // sombra
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath(); ctx.ellipse(X + TS / 2, Y + TS * 0.88, TS * 0.32 * scale, TS * 0.11 * scale, 0, 0, 7); ctx.fill();

  // oculto
  const hidden = isHero && G.state.hero.buffs.some((b) => b.id === 'oculto');
  const frozen = !isHero && (e.o.status.freeze || 0) > 0;
  const sleeping = !isHero && e.o.asleep;
  ctx.save();
  if (hidden) ctx.globalAlpha = 0.4;
  const w = size / squash, hgt = size * squash;
  const fr = isHero ? heroFrameNow(G.state.hero.cls, now) : null;
  if (fr) {
    // sprite LPC: 64px do personagem = 1.3 casa
    const k = TS * 1.3 / 64;
    ctx.translate(X + TS / 2, Y + TS * 0.97);
    ctx.imageSmoothingEnabled = false;
    const dw = CELL * k;
    ctx.drawImage(fr.img, fr.sx, fr.sy, CELL, CELL, -dw / 2, -FEET * k, dw, dw);
    if (a.flash && now - a.flash < 140) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.7 * (1 - (now - a.flash) / 140);
      ctx.drawImage(fr.img, fr.sx, fr.sy, CELL, CELL, -dw / 2, -FEET * k, dw, dw);
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.restore();
    return;
  }
  ctx.translate(X + TS / 2, Y + TS * 0.95 + bob + fly);
  if (spr.pixel) { ctx.imageSmoothingEnabled = false; face = 1; }
  ctx.scale(face, 1);
  ctx.drawImage(spr, -w / 2, -hgt * 0.92, w, hgt);
  // flash de dano
  if (a.flash && now - a.flash < 140) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.7 * (1 - (now - a.flash) / 140);
    ctx.drawImage(spr, -w / 2, -hgt * 0.92, w, hgt);
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();
  if (frozen) { ctx.save(); ctx.globalAlpha = 0.45; ctx.fillStyle = '#9ad8ff'; ctx.beginPath(); ctx.roundRect(X + TS * 0.12, Y - TS * 0.15, TS * 0.76, TS * 1.05, 8); ctx.fill(); ctx.restore(); }
  if (sleeping) { ctx.font = `700 ${Math.round(TS * 0.3)}px system-ui`; ctx.fillStyle = '#cfe7ff'; ctx.globalAlpha = 0.6 + 0.4 * Math.sin(t * 2 + phase); ctx.fillText('z', X + TS * 0.75, Y - TS * 0.05 - (t * 8 % 8)); ctx.globalAlpha = 1; }
  if (!isHero) {
    const st = e.o.status;
    if (st.stun) { for (let i = 0; i < 3; i++) { const an = t * 4 + i * 2.1; ctx.fillStyle = '#ffe04a'; ctx.fillRect(X + TS / 2 + Math.cos(an) * TS * 0.25 - 2, Y - TS * 0.2 + Math.sin(an) * 4, 4, 4); } }
    if (st.poison) { ctx.fillStyle = '#b56bff'; ctx.globalAlpha = 0.7; ctx.fillRect(X + TS * 0.15, Y + TS * 0.05 + (t * 20 % 10), 3, 3); ctx.globalAlpha = 1; }
    // barra de HP
    if (e.o.hp < e.o.maxHp && !e.o.boss) {
      const bw = TS * 0.7, bx = X + TS * 0.15, by = Y - TS * 0.32 * scale;
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.beginPath(); ctx.roundRect(bx - 1, by - 1, bw + 2, 6, 3); ctx.fill();
      const p = Math.max(0, e.o.hp / e.o.maxHp);
      ctx.fillStyle = p > 0.5 ? '#6ae07a' : p > 0.25 ? '#ffc23a' : '#ff4a4a';
      ctx.beginPath(); ctx.roundRect(bx, by, bw * p, 4, 2); ctx.fill();
    }
  }
}

function drawTorch(ctx, X, Y, TS, t, th) {
  const fx = X + TS / 2, fy = Y + TS * 0.38;
  ctx.fillStyle = '#4a3020'; ctx.fillRect(fx - 2, fy, 4, TS * 0.2);
  ctx.save(); ctx.shadowColor = th.light; ctx.shadowBlur = 16;
  const f = 1 + Math.sin(t * 13 + X) * 0.15;
  ctx.fillStyle = '#ffb04a'; ctx.beginPath(); ctx.ellipse(fx, fy - 4, 5 * f, 9 * f, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#fff3c0'; ctx.beginPath(); ctx.ellipse(fx, fy - 2, 2.5, 5, 0, 0, 7); ctx.fill();
  ctx.restore();
}

function drawLiquid(ctx, X, Y, TS, t, th, x, y, deep) {
  const kind = th.liquid;
  let base, hi;
  if (deep) {
    if (kind === 'lava') { base = '#c4401a'; hi = '#ffb04a'; }
    else { ctx.fillStyle = '#05060a'; ctx.fillRect(X, Y, TS, TS); ctx.fillStyle = 'rgba(255,255,255,0.03)'; ctx.fillRect(X, Y, TS, 3); return; }
  } else if (kind === 'lodo') { base = '#3f6a3a'; hi = '#9be36a'; }
  else if (kind === 'gelo') { base = '#8ab8d8'; hi = '#ffffff'; }
  else if (kind === 'vazio') { base = '#2a1440'; hi = '#c47aff'; }
  else if (kind === 'areia') { base = '#b8955e'; hi = '#e8cd96'; }
  else if (kind === 'lava') { base = '#5a2a1a'; hi = '#ff8a4a'; }
  else { base = '#2a5a8a'; hi = '#9ad8ff'; }
  ctx.fillStyle = base; ctx.globalAlpha = deep ? 1 : 0.85; ctx.fillRect(X, Y, TS, TS); ctx.globalAlpha = 1;
  ctx.strokeStyle = hi; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.5;
  for (let i = 0; i < 2; i++) {
    const yy = Y + TS * (0.3 + i * 0.4) + Math.sin(t * 2 + x + i) * 2;
    ctx.beginPath(); ctx.moveTo(X + TS * 0.1, yy); ctx.quadraticCurveTo(X + TS * 0.5, yy - 4, X + TS * 0.9, yy); ctx.stroke();
  }
  ctx.globalAlpha = 1;
  if (deep && kind === 'lava' && Math.random() < 0.01) R.parts.push({ x: x + Math.random(), y: y + 0.5, vx: 0, vy: -1, g: 0, life: 800, t0: R.time, color: '#ffb04a', size: 3, glow: true });
}

function drawStairs(ctx, X, Y, TS, t) {
  ctx.fillStyle = '#0a0a12';
  ctx.beginPath(); ctx.roundRect(X + TS * 0.12, Y + TS * 0.12, TS * 0.76, TS * 0.76, 6); ctx.fill();
  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = `rgba(200,210,230,${0.55 - i * 0.12})`;
    ctx.fillRect(X + TS * (0.18 + i * 0.04), Y + TS * (0.2 + i * 0.16), TS * (0.64 - i * 0.08), TS * 0.07);
  }
  ctx.save(); ctx.strokeStyle = '#7ad0ff'; ctx.globalAlpha = 0.4 + 0.3 * Math.sin(t * 3); ctx.lineWidth = 2; ctx.shadowColor = '#7ad0ff'; ctx.shadowBlur = 10;
  ctx.beginPath(); ctx.roundRect(X + TS * 0.1, Y + TS * 0.1, TS * 0.8, TS * 0.8, 7); ctx.stroke(); ctx.restore();
}

function drawPortal(ctx, X, Y, TS, t) {
  ctx.save();
  ctx.translate(X + TS / 2, Y + TS / 2);
  ctx.shadowColor = '#7ad0ff'; ctx.shadowBlur = 20;
  for (let i = 0; i < 3; i++) {
    ctx.rotate(t * (1 + i * 0.5));
    ctx.strokeStyle = ['#7ad0ff', '#c9a6ff', '#ffffff'][i]; ctx.lineWidth = 3 - i;
    ctx.beginPath(); ctx.ellipse(0, 0, TS * (0.4 - i * 0.08), TS * (0.4 - i * 0.08), 0, 0, Math.PI * 1.4); ctx.stroke();
  }
  ctx.restore();
}

function drawDecor(ctx, d, X, Y, TS, h, t, th) {
  const px = X + TS * (0.25 + (h % 50) / 100), py = Y + TS * (0.3 + ((h >> 8) % 40) / 100);
  ctx.save();
  switch (d) {
    case 'grass': ctx.strokeStyle = '#7ab85a'; ctx.lineWidth = 2; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(px + i * 4, py + 8); ctx.quadraticCurveTo(px + i * 4 + Math.sin(t * 2 + i) * 2, py, px + i * 4 + 2, py - 4); ctx.stroke(); } break;
    case 'flower': ctx.fillStyle = ['#ff8ab0', '#ffe04a', '#9ad8ff'][h % 3]; for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(px + Math.cos(i * 1.256) * 3, py + Math.sin(i * 1.256) * 3, 2.2, 0, 7); ctx.fill(); } ctx.fillStyle = '#fff3c0'; ctx.beginPath(); ctx.arc(px, py, 1.6, 0, 7); ctx.fill(); break;
    case 'rock': ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(px + 4, py + 6, 7, 3, 0, 0, 7); ctx.fill(); ctx.fillStyle = shade(th.wall[0], 0.1); ctx.beginPath(); ctx.ellipse(px + 3, py + 2, 6, 5, 0, 0, 7); ctx.fill(); break;
    case 'puddle': ctx.fillStyle = 'rgba(120,200,160,0.25)'; ctx.beginPath(); ctx.ellipse(px + 4, py + 4, 10, 5, 0, 0, 7); ctx.fill(); break;
    case 'pipe': ctx.fillStyle = '#5a6a6a'; ctx.fillRect(px - 2, py, 14, 5); ctx.fillStyle = '#3a4a4a'; ctx.fillRect(px + 10, py - 1, 4, 7); break;
    case 'bones': ctx.strokeStyle = '#d8d0b8'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(px - 4, py + 4); ctx.lineTo(px + 8, py); ctx.moveTo(px, py - 2); ctx.lineTo(px + 4, py + 6); ctx.stroke(); break;
    case 'sand': ctx.strokeStyle = 'rgba(255,240,200,0.25)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(px - 6, py); ctx.quadraticCurveTo(px, py - 3, px + 8, py); ctx.stroke(); break;
    case 'skull': ctx.fillStyle = '#e8e0c8'; ctx.beginPath(); ctx.arc(px + 3, py + 2, 5, 0, 7); ctx.fill(); ctx.fillStyle = '#2a2018'; ctx.fillRect(px + 0.5, py + 1, 2, 2); ctx.fillRect(px + 3.5, py + 1, 2, 2); break;
    case 'cactus': ctx.fillStyle = '#5a9a4a'; ctx.beginPath(); ctx.roundRect(px, py - 6, 5, 14, 2); ctx.fill(); ctx.beginPath(); ctx.roundRect(px - 4, py - 2, 4, 6, 2); ctx.fill(); break;
    case 'carpet': ctx.fillStyle = 'rgba(140,30,50,0.35)'; ctx.fillRect(X + 2, Y + 2, TS - 4, TS - 4); break;
    case 'candle': ctx.fillStyle = '#e8e0d0'; ctx.fillRect(px, py, 4, 8); ctx.shadowColor = '#ffd890'; ctx.shadowBlur = 10; ctx.fillStyle = '#ffd890'; ctx.beginPath(); ctx.ellipse(px + 2, py - 3, 2, 4 + Math.sin(t * 10 + h) * 0.8, 0, 0, 7); ctx.fill(); break;
    case 'barrel': {
      const bx = X + TS * 0.3, by = Y + TS * 0.25, bw = TS * 0.4, bh = TS * 0.5;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(bx + 2, by + bh - 2, bw, 4);
      ctx.beginPath(); ctx.moveTo(bx + bw * 0.12, by); ctx.lineTo(bx + bw * 0.88, by); ctx.lineTo(bx + bw, by + bh * 0.5); ctx.lineTo(bx + bw * 0.88, by + bh); ctx.lineTo(bx + bw * 0.12, by + bh); ctx.lineTo(bx, by + bh * 0.5); ctx.closePath();
      const g = ctx.createLinearGradient(bx, 0, bx + bw, 0); g.addColorStop(0, '#b07a44'); g.addColorStop(1, '#6a4422'); ctx.fillStyle = g; ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = '#2a1a0e'; ctx.stroke();
      ctx.fillStyle = '#5a5e6a'; ctx.fillRect(bx + 1, by + bh * 0.22, bw - 2, 2.5); ctx.fillRect(bx + 1, by + bh * 0.72, bw - 2, 2.5);
      break;
    }
    case 'crate': {
      const bx = X + TS * 0.28, by = Y + TS * 0.3, bw = TS * 0.44;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(bx + 2, by + bw - 2, bw, 4);
      const g = ctx.createLinearGradient(bx, by, bx + bw, by + bw); g.addColorStop(0, '#c4945a'); g.addColorStop(1, '#7a5230');
      ctx.fillStyle = g; ctx.fillRect(bx, by, bw, bw); ctx.lineWidth = 1.5; ctx.strokeStyle = '#2a1a0e'; ctx.strokeRect(bx, by, bw, bw);
      ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + bw, by + bw); ctx.moveTo(bx + bw, by); ctx.lineTo(bx, by + bw); ctx.strokeStyle = 'rgba(42,26,14,0.6)'; ctx.stroke();
      break;
    }
    case 'crystal': {
      const cx = X + TS * 0.5, cy = Y + TS * 0.62, c = th.accent;
      ctx.shadowColor = c; ctx.shadowBlur = 12;
      for (const [dx, hh, w] of [[-5, 16, 5], [2, 22, 6], [8, 12, 4]]) {
        ctx.beginPath(); ctx.moveTo(cx + dx - w, cy); ctx.lineTo(cx + dx, cy - hh); ctx.lineTo(cx + dx + w, cy); ctx.closePath();
        ctx.fillStyle = c; ctx.globalAlpha = 0.85; ctx.fill(); ctx.globalAlpha = 1; ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.stroke();
      }
      break;
    }
    case 'ember': ctx.shadowColor = '#ff7a2a'; ctx.shadowBlur = 8; ctx.fillStyle = '#ff7a2a'; ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 3 + h); ctx.fillRect(px, py, 3, 3); ctx.fillRect(px + 6, py + 4, 2, 2); break;
  }
  ctx.restore();
}

function drawLighting(ctx, r, m, th, t, x0, x1, y0, y1) {
  if (!R.lc || R.lc.width !== m.w || R.lc.height !== m.h) {
    R.lc = document.createElement('canvas'); R.lc.width = m.w; R.lc.height = m.h; R.lctx = R.lc.getContext('2d');
    R.limg = R.lctx.createImageData(m.w, m.h);
  }
  const data = R.limg.data;
  const lights = m.lights.filter((l) => Math.abs(l.x - r.px) < 14 && Math.abs(l.y - r.py) < 14);
  const flick = 0.03 * Math.sin(t * 9);
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const i = y * m.w + x;
    let a;
    if (!m.seen[i]) a = 1;
    else if (!G.fov[i]) a = 0.8;
    else {
      const d = Math.hypot(x - r.px, y - r.py);
      a = 0.05 + 0.62 * Math.pow(Math.min(1, d / 7.5), 2) + flick; // névoa até 7 casas
      for (const l of lights) {
        const dl = Math.hypot(x - l.x, y - l.y), lr = l.r || 3.5;
        if (dl < lr) a -= 0.32 * (1 - dl / lr);
      }
      a = Math.max(0, Math.min(0.85, a));
    }
    data[i * 4] = 6; data[i * 4 + 1] = 5; data[i * 4 + 2] = 14; data[i * 4 + 3] = a * 255;
  }
  R.lctx.putImageData(R.limg, 0, 0);
  const TS = R.TS;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(R.lc, sx(0), sy(0), m.w * TS, m.h * TS);
  // brilhos coloridos
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (const l of lights) {
    if (!m.seen[l.y * m.w + l.x]) continue;
    const X = sx(l.x) + TS / 2, Y = sy(l.y) + TS / 2, rad = (l.r || 3.5) * TS * (1 + 0.04 * Math.sin(t * 8 + l.x));
    const g = ctx.createRadialGradient(X, Y, 0, X, Y, rad);
    g.addColorStop(0, hexA(l.color || th.light, 0.22)); g.addColorStop(1, hexA(l.color || th.light, 0));
    ctx.fillStyle = g; ctx.fillRect(X - rad, Y - rad, rad * 2, rad * 2);
  }
  const hp = renderPos('hero', r.px, r.py, R.time);
  const X = sx(hp.x) + TS / 2, Y = sy(hp.y) + TS / 2, rad = TS * 4;
  const g = ctx.createRadialGradient(X, Y, 0, X, Y, rad);
  g.addColorStop(0, hexA(th.light, 0.10)); g.addColorStop(1, hexA(th.light, 0));
  ctx.fillStyle = g; ctx.fillRect(X - rad, Y - rad, rad * 2, rad * 2);
  ctx.restore();
}

function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

export function setTargeting(t) { R.targeting = t; }
export function setMarker(x, y) { R.marker = { x, y, t0: R.time }; }
