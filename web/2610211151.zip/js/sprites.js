// Sprites procedurais (desenhados em canvas) — visual moderno
// sem depender de arquivos de imagem.
import { MONSTERS, CLASSES, ITEMS, WTYPES, artCls } from './data.js';
import { itemDef } from './rules.js';
import { drawHero } from './heroes.js';
import { heroPortrait } from './lpc.js';
import { dcssMonster } from './dcss.js';

export const SPR = 96; // tamanho lógico dos sprites
const RES = 2;         // renderizados em 2x para telas de alta densidade
const cache = new Map();

function mk(size = SPR) {
  const c = document.createElement('canvas');
  c.width = size * RES; c.height = size * RES;
  c.getContext('2d').scale(RES, RES);
  return c;
}

function shade(hex, amt) {
  // amt: -1..1
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map((x) => x + x).join('');
  const n = parseInt(c, 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (amt >= 0) { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; }
  else { r *= 1 + amt; g *= 1 + amt; b *= 1 + amt; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}
export { shade };

const OUT = 'rgba(16,10,24,0.9)';

// Converte curvas e elipses em facetas retas, mantendo o mesmo desenho.
// Assim os monstros seguem o estilo anguloso dos heróis.
export function angularize(ctx, facets = 8) {
  let cx = 0, cy = 0, sx = 0, sy = 0;
  const lineTo = ctx.lineTo.bind(ctx), moveTo = ctx.moveTo.bind(ctx), closePath = ctx.closePath.bind(ctx);
  ctx.moveTo = (x, y) => { cx = sx = x; cy = sy = y; moveTo(x, y); };
  ctx.lineTo = (x, y) => { cx = x; cy = y; lineTo(x, y); };
  ctx.closePath = () => { cx = sx; cy = sy; closePath(); };
  ctx.quadraticCurveTo = (qx, qy, x, y) => {
    const t = 0.5, u = 0.5;
    ctx.lineTo(u * u * cx + 2 * u * t * qx + t * t * x, u * u * cy + 2 * u * t * qy + t * t * y);
    ctx.lineTo(x, y);
  };
  ctx.bezierCurveTo = (ax, ay, bx, by, x, y) => {
    const x0 = cx, y0 = cy;
    for (const t of [0.34, 0.67]) { const u = 1 - t; ctx.lineTo(u * u * u * x0 + 3 * u * u * t * ax + 3 * u * t * t * bx + t * t * t * x, u * u * u * y0 + 3 * u * u * t * ay + 3 * u * t * t * by + t * t * t * y); }
    ctx.lineTo(x, y);
  };
  ctx.ellipse = (x, y, rx, ry, rot, a0, a1, ccw) => {
    let span = a1 - a0;
    if (ccw) span = -((a0 - a1) % (Math.PI * 2) || Math.PI * 2);
    const full = Math.abs(span) >= Math.PI * 2 - 1e-3;
    const n = Math.max(3, Math.round(Math.abs(span) / (Math.PI * 2) * facets));
    const cr = Math.cos(rot || 0), sr = Math.sin(rot || 0);
    const off = full ? Math.PI / n : 0;
    for (let i = 0; i <= n; i++) {
      const a = a0 + off + span * (i / n);
      const ex = Math.cos(a) * rx, ey = Math.sin(a) * ry;
      const px = x + ex * cr - ey * sr, py = y + ex * sr + ey * cr;
      if (i === 0 && (full || cx === undefined)) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    if (full) ctx.closePath();
  };
  ctx.arc = (x, y, r, a0, a1, ccw) => ctx.ellipse(x, y, r, r, 0, a0, a1, ccw);
  ctx.roundRect = (x, y, w, h) => { const k = Math.min(w, h) * 0.18; ctx.moveTo(x + k, y); ctx.lineTo(x + w - k, y); ctx.lineTo(x + w, y + k); ctx.lineTo(x + w, y + h - k); ctx.lineTo(x + w - k, y + h); ctx.lineTo(x + k, y + h); ctx.lineTo(x, y + h - k); ctx.lineTo(x, y + k); ctx.closePath(); };
  ctx.lineJoin = 'miter'; ctx.miterLimit = 2.5;
  return ctx;
}

function ell(ctx, x, y, rx, ry, fill, stroke = OUT, lw = 3) {
  ctx.beginPath();
  ctx.ellipse(x, y, Math.max(0.5, rx), Math.max(0.5, ry), 0, 0, Math.PI * 2);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.stroke(); }
}

function rr(ctx, x, y, w, h, r, fill, stroke = OUT, lw = 3) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.stroke(); }
}

function grad(ctx, x, y, r, c0, c1) {
  const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.45, r * 0.1, x, y, r * 1.1);
  g.addColorStop(0, shade(c0, 0.35));
  g.addColorStop(0.55, c0);
  g.addColorStop(1, c1);
  return g;
}

function lin(ctx, x0, y0, x1, y1, stops) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  stops.forEach((c, i) => g.addColorStop(i / (stops.length - 1), c));
  return g;
}

function eyes(ctx, x, y, gap, r = 5, angry = false, color = '#141018') {
  for (const sgn of [-1, 1]) {
    const ex = x + sgn * gap;
    ctx.beginPath(); ctx.moveTo(ex - r, y - r * 0.5); ctx.lineTo(ex + r, y - r * 0.9); ctx.lineTo(ex + r * 0.85, y + r * 0.8); ctx.lineTo(ex - r * 0.85, y + r * 0.9); ctx.closePath();
    ctx.fillStyle = '#fbfaff'; ctx.fill(); ctx.lineWidth = 1.8; ctx.strokeStyle = OUT; ctx.stroke();
    ctx.fillStyle = color; ctx.fillRect(ex - r * 0.1, y - r * 0.45, r * 0.75, r * 1.1);
    ctx.fillStyle = '#fff'; ctx.fillRect(ex - r * 0.05, y - r * 0.45, r * 0.3, r * 0.3);
    if (angry) {
      ctx.beginPath();
      ctx.moveTo(ex - r * 1.2 * sgn, y - r * 1.5);
      ctx.lineTo(ex + r * 1.2 * sgn, y - r * 0.8);
      ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
    }
  }
}

function glowEyes(ctx, x, y, gap, color = '#ff3a3a', r = 3.5) {
  ctx.save();
  ctx.shadowColor = color; ctx.shadowBlur = 10;
  for (const s of [-1, 1]) ell(ctx, x + s * gap, y, r, r * 0.8, color, null);
  ctx.restore();
}

function crown(ctx, x, y, w) {
  ctx.beginPath();
  ctx.moveTo(x - w, y);
  ctx.lineTo(x - w, y - w * 0.7);
  ctx.lineTo(x - w * 0.5, y - w * 0.3);
  ctx.lineTo(x, y - w * 0.9);
  ctx.lineTo(x + w * 0.5, y - w * 0.3);
  ctx.lineTo(x + w, y - w * 0.7);
  ctx.lineTo(x + w, y);
  ctx.closePath();
  ctx.fillStyle = lin(ctx, 0, y - w, 0, y, ['#fff3a0', '#ffc21a', '#c47a0a']);
  ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
  ell(ctx, x, y - w * 0.35, w * 0.16, w * 0.16, '#ff3a5a', OUT, 1.5);
}

function horns(ctx, x, y, size, color = '#e8dcc0', curl = false) {
  for (const s of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(x + s * size * 0.35, y);
    if (curl) ctx.bezierCurveTo(x + s * size * 1.4, y - size * 0.3, x + s * size * 1.5, y - size * 1.3, x + s * size * 0.7, y - size * 1.2);
    else ctx.quadraticCurveTo(x + s * size * 0.9, y - size * 0.4, x + s * size * 0.75, y - size * 1.1);
    ctx.lineTo(x + s * size * 0.1, y - size * 0.1);
    ctx.closePath();
    ctx.fillStyle = color; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
  }
}

// ---------------- Formas de monstros ----------------
const SHAPES = {
  blob(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.86, w = s * 0.36, h = s * 0.5;
    ctx.beginPath();
    ctx.moveTo(cx - w, by);
    ctx.bezierCurveTo(cx - w * 1.15, by - h * 0.6, cx - w * 0.6, by - h * 1.05, cx, by - h);
    ctx.bezierCurveTo(cx + w * 0.6, by - h * 1.05, cx + w * 1.15, by - h * 0.6, cx + w, by);
    ctx.quadraticCurveTo(cx, by + 6, cx - w, by);
    ctx.fillStyle = grad(ctx, cx, by - h * 0.5, w, c0, c1);
    ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    ell(ctx, cx - w * 0.45, by - h * 0.72, w * 0.16, h * 0.12, 'rgba(255,255,255,0.7)', null);
    eyes(ctx, cx + 3, by - h * 0.42, w * 0.32, 5);
    ctx.beginPath(); ctx.arc(cx + 3, by - h * 0.22, 5, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
    if (sp.drip) for (const dx of [-0.6, 0.2, 0.7]) ell(ctx, cx + w * dx, by - 2, 3, 6, c1, null);
    if (sp.crown) crown(ctx, cx, by - h * 0.92, w * 0.42);
  },
  bug(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.78;
    ctx.strokeStyle = OUT; ctx.lineWidth = 3;
    for (let i = 0; i < 3; i++) for (const k of [-1, 1]) {
      ctx.beginPath(); ctx.moveTo(cx - 14 + i * 12, by); ctx.lineTo(cx - 18 + i * 12 + k * 3, by + 12); ctx.stroke();
    }
    if (sp.wings) for (const k of [-1, 1]) {
      ctx.save(); ctx.globalAlpha = 0.55;
      ell(ctx, cx - 4 + k * 6, by - 26, 12, 18, '#e8f6ff', 'rgba(16,10,24,0.5)', 2);
      ctx.restore();
    }
    if (sp.flat) {
      ell(ctx, cx, by - 6, s * 0.33, s * 0.17, grad(ctx, cx, by - 6, s * 0.33, c0, c1));
      ctx.beginPath(); ctx.moveTo(cx - 10, by - 18); ctx.lineTo(cx - 10, by + 6); ctx.lineWidth = 2; ctx.strokeStyle = shade(c1, -0.3); ctx.stroke();
      ell(ctx, cx + s * 0.3, by - 8, 9, 8, shade(c1, -0.2));
      ctx.beginPath(); ctx.moveTo(cx + s * 0.35, by - 14); ctx.quadraticCurveTo(cx + s * 0.5, by - 34, cx + s * 0.44, by - 40);
      ctx.moveTo(cx + s * 0.33, by - 14); ctx.quadraticCurveTo(cx + s * 0.4, by - 34, cx + s * 0.3, by - 42);
      ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke();
      glowEyes(ctx, cx + s * 0.32, by - 10, 3, '#ffe0a0', 2);
    } else {
      for (let i = 0; i < 3; i++) {
        const r = 13 - i * 1.5;
        ell(ctx, cx - 16 + i * 14, by - 10 - (i === 2 ? 6 : 0), r, r * 0.95, grad(ctx, cx - 16 + i * 14, by - 10, r, c0, c1));
        if (sp.stripes && i < 2) { ctx.fillStyle = c1; ctx.fillRect(cx - 18 + i * 14, by - 22, 4, 22); }
      }
      eyes(ctx, cx + 14, by - 18, 5, 4);
      ctx.beginPath(); ctx.moveTo(cx + 12, by - 28); ctx.lineTo(cx + 8, by - 40); ctx.moveTo(cx + 18, by - 28); ctx.lineTo(cx + 22, by - 40);
      ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke();
      ell(ctx, cx + 8, by - 41, 3, 3, c0, OUT, 1.5); ell(ctx, cx + 22, by - 41, 3, 3, c0, OUT, 1.5);
    }
    if (sp.crown) crown(ctx, cx + 14, by - 30, 10);
  },
  mushroom(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.86;
    rr(ctx, cx - 13, by - 32, 26, 32, 10, lin(ctx, cx - 13, 0, cx + 13, 0, [shade(c1, -0.1), c1, shade(c1, -0.25)]));
    eyes(ctx, cx + 1, by - 18, 6, 4);
    ctx.beginPath(); ctx.ellipse(cx, by - 34, 30, 22, 0, Math.PI, 0); ctx.closePath();
    ctx.fillStyle = grad(ctx, cx, by - 44, 30, c0, shade(c0, -0.35)); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    for (const [dx, dy, r] of [[-14, -42, 5], [6, -50, 6], [18, -38, 4], [-2, -38, 3]]) ell(ctx, cx + dx, by + dy, r, r * 0.8, '#fff3e6', null);
  },
  beast(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const k = sp.small ? 0.8 : 1;
    const cx = s / 2 - 4, by = s * 0.84;
    ctx.save();
    if (sp.ghostly) ctx.globalAlpha = 0.85;
    // pernas
    for (const dx of [-18, -8, 8, 16]) rr(ctx, cx + dx * k, by - 14 * k, 7 * k, 15 * k, 3, shade(c1, -0.1), OUT, 2.5);
    // cauda
    if (sp.tail) { ctx.beginPath(); ctx.moveTo(cx - 22 * k, by - 18 * k); ctx.quadraticCurveTo(cx - 40 * k, by - 30 * k, cx - 36 * k, by - 6); ctx.lineWidth = 3; ctx.strokeStyle = '#d89a9a'; ctx.stroke(); }
    else if (sp.flameTail) {
      ctx.save(); ctx.shadowColor = '#ffb04a'; ctx.shadowBlur = 12;
      ell(ctx, cx - 30 * k, by - 26 * k, 7, 11, '#ffd23f', null); ell(ctx, cx - 30 * k, by - 22 * k, 4, 6, '#fff3a0', null); ctx.restore();
    } else if (!sp.long) ell(ctx, cx - 24 * k, by - 24 * k, 7 * k, 5 * k, c0);
    // corpo
    const bw = (sp.long ? 30 : 24) * k, bh = 15 * k;
    ell(ctx, cx, by - 22 * k, bw, bh, grad(ctx, cx, by - 24 * k, bw, c0, c1));
    if (sp.mane) for (let i = 0; i < 5; i++) ell(ctx, cx + 8 + i * 3, by - 34 * k + i * 2, 5, 7, sp.c[1], null);
    // cabeça
    const hx = cx + (sp.long ? 30 : 24) * k, hy = by - 32 * k;
    if (sp.ears === 'long') for (const dx of [-5, 3]) ell(ctx, hx + dx, hy - 18 * k, 4.5 * k, 13 * k, c0, OUT, 2.5);
    if (sp.ears === 'pointy') for (const dx of [-7, 5]) { ctx.beginPath(); ctx.moveTo(hx + dx - 5, hy - 6); ctx.lineTo(hx + dx, hy - 20 * k); ctx.lineTo(hx + dx + 5, hy - 6); ctx.closePath(); ctx.fillStyle = c1; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); }
    if (sp.ears === 'round') for (const dx of [-6, 6]) ell(ctx, hx + dx, hy - 10 * k, 6 * k, 6 * k, '#e8a0a0');
    if (sp.long) {
      rr(ctx, hx - 4, hy - 4, 26 * k, 12 * k, 5, c0);
      ctx.fillStyle = '#fff'; for (let i = 0; i < 4; i++) ctx.fillRect(hx + 2 + i * 5, hy + 6 * k, 2.5, 3);
      eyes(ctx, hx + 2, hy - 6, 0.01, 4, true);
    } else {
      ell(ctx, hx, hy, 13 * k, 12 * k, grad(ctx, hx, hy, 13 * k, c0, c1));
      ell(ctx, hx + 9 * k, hy + 3 * k, 6 * k, 5 * k, shade(c0, 0.2), OUT, 2);
      ell(ctx, hx + 13 * k, hy + 1 * k, 2.2, 2, '#2a1a1a', null);
      if (sp.ghostly) glowEyes(ctx, hx + 1, hy - 3, 4, '#c47aff');
      else eyes(ctx, hx + 1, hy - 3, 4.5, 3.5);
    }
    if (sp.horn) { ctx.beginPath(); ctx.moveTo(hx - 2, hy - 10); ctx.lineTo(hx + 4, hy - 26); ctx.lineTo(hx + 6, hy - 10); ctx.closePath(); ctx.fillStyle = '#ffe8a0'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); }
    ctx.restore();
  },
  bat(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, cy = s * 0.5;
    for (const k of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(cx + k * 6, cy - 4);
      ctx.quadraticCurveTo(cx + k * 30, cy - 26, cx + k * 42, cy - 8);
      ctx.quadraticCurveTo(cx + k * 34, cy - 4, cx + k * 34, cy + 6);
      ctx.quadraticCurveTo(cx + k * 26, cy, cx + k * 22, cy + 10);
      ctx.quadraticCurveTo(cx + k * 14, cy + 2, cx + k * 6, cy + 8);
      ctx.closePath();
      ctx.fillStyle = lin(ctx, cx, cy - 20, cx, cy + 10, [c0, c1]); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
    }
    for (const k of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx + k * 3, cy - 10); ctx.lineTo(cx + k * 9, cy - 24); ctx.lineTo(cx + k * 11, cy - 8); ctx.closePath(); ctx.fillStyle = c1; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); }
    ell(ctx, cx, cy, 13, 14, grad(ctx, cx, cy, 13, c0, c1));
    glowEyes(ctx, cx, cy - 3, 5, '#ffe04a', 3);
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(cx - 4, cy + 6); ctx.lineTo(cx - 2, cy + 11); ctx.lineTo(cx, cy + 6); ctx.moveTo(cx + 1, cy + 6); ctx.lineTo(cx + 3, cy + 11); ctx.lineTo(cx + 5, cy + 6); ctx.fill();
  },
  frog(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.84;
    for (const k of [-1, 1]) ell(ctx, cx + k * 22, by - 6, 11, 6, shade(c0, -0.2));
    ell(ctx, cx, by - 18, 28, 19, grad(ctx, cx, by - 20, 28, c0, shade(c0, -0.4)));
    ell(ctx, cx, by - 12, 17, 10, c1, null);
    for (const k of [-1, 1]) { ell(ctx, cx + k * 13, by - 36, 9, 9, c0); }
    eyes(ctx, cx, by - 37, 13, 5);
    ctx.beginPath(); ctx.moveTo(cx - 14, by - 24); ctx.quadraticCurveTo(cx, by - 18, cx + 14, by - 24); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
    for (const [dx, dy] of [[-16, -16], [12, -20], [4, -28]]) ell(ctx, cx + dx, by + dy, 3, 2.5, shade(c0, -0.45), null);
  },
  scorpion(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.84;
    ctx.strokeStyle = OUT; ctx.lineWidth = 3;
    for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(cx - 10 + i * 7, by - 10); ctx.lineTo(cx - 16 + i * 7, by); ctx.stroke(); }
    // cauda
    ctx.beginPath(); ctx.moveTo(cx - 16, by - 14);
    ctx.bezierCurveTo(cx - 40, by - 20, cx - 34, by - 62, cx - 6, by - 56);
    ctx.lineWidth = 11; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 7; ctx.strokeStyle = c0; ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx - 8, by - 58); ctx.lineTo(cx + 6, by - 50); ctx.lineTo(cx - 6, by - 50); ctx.closePath(); ctx.fillStyle = '#2a1a10'; ctx.fill();
    ell(ctx, cx, by - 14, 20, 11, grad(ctx, cx, by - 14, 20, c0, c1));
    for (const k of [-1, 1]) { ell(ctx, cx + 26, by - 14 + k * 9, 8, 5, c0); }
    eyes(ctx, cx + 14, by - 18, 4, 3);
  },
  snake(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.86;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx - 30, by - 6); ctx.bezierCurveTo(cx - 10, by + 4, cx + 10, by - 18, cx - 6, by - 26); ctx.bezierCurveTo(cx - 20, by - 34, cx + 2, by - 50, cx + 16, by - 46);
    ctx.lineWidth = 16; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 11; ctx.strokeStyle = c0; ctx.stroke();
    ctx.setLineDash([4, 6]); ctx.lineWidth = 4; ctx.strokeStyle = c1; ctx.stroke(); ctx.setLineDash([]);
    ell(ctx, cx + 20, by - 48, 12, 9, grad(ctx, cx + 20, by - 48, 12, c0, c1));
    eyes(ctx, cx + 22, by - 52, 4, 3, true);
    ctx.beginPath(); ctx.moveTo(cx + 31, by - 46); ctx.lineTo(cx + 40, by - 44); ctx.lineTo(cx + 43, by - 47); ctx.moveTo(cx + 40, by - 44); ctx.lineTo(cx + 43, by - 41);
    ctx.lineWidth = 2; ctx.strokeStyle = '#ff3a5a'; ctx.stroke();
    ctx.lineCap = 'butt';
  },
  spider(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.8;
    ctx.lineWidth = 3.5; ctx.strokeStyle = OUT;
    for (let i = 0; i < 4; i++) for (const k of [-1, 1]) {
      ctx.beginPath(); ctx.moveTo(cx + k * 6, by - 14);
      ctx.quadraticCurveTo(cx + k * (22 + i * 4), by - 34 + i * 6, cx + k * (26 + i * 5), by + 2 - i * 2);
      ctx.stroke();
    }
    ell(ctx, cx - 12, by - 18, 18, 15, grad(ctx, cx - 12, by - 18, 18, c0, shade(c0, -0.5)));
    ctx.fillStyle = c1; ctx.beginPath(); ctx.moveTo(cx - 12, by - 26); ctx.lineTo(cx - 6, by - 18); ctx.lineTo(cx - 12, by - 10); ctx.lineTo(cx - 18, by - 18); ctx.fill();
    ell(ctx, cx + 10, by - 14, 11, 10, grad(ctx, cx + 10, by - 14, 11, c0, shade(c0, -0.4)));
    glowEyes(ctx, cx + 13, by - 17, 3, '#ff3a3a', 2.2); glowEyes(ctx, cx + 13, by - 11, 2, '#ff3a3a', 1.6);
  },
  golem(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.88;
    rr(ctx, cx - 18, by - 16, 13, 16, 3, shade(c0, -0.15)); rr(ctx, cx + 5, by - 16, 13, 16, 3, shade(c0, -0.15));
    rr(ctx, cx - 26, by - 52, 52, 38, 8, lin(ctx, 0, by - 52, 0, by - 14, [shade(c0, 0.25), c0, shade(c0, -0.3)]));
    rr(ctx, cx - 38, by - 50, 14, 32, 6, c0); rr(ctx, cx + 24, by - 50, 14, 32, 6, c0);
    rr(ctx, cx - 13, by - 70, 26, 20, 6, lin(ctx, 0, by - 70, 0, by - 50, [shade(c0, 0.3), c0]));
    if (sp.lava) {
      ctx.save(); ctx.shadowColor = c1; ctx.shadowBlur = 10; ctx.strokeStyle = c1; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(cx - 18, by - 44); ctx.lineTo(cx - 6, by - 34); ctx.lineTo(cx - 10, by - 22); ctx.moveTo(cx + 12, by - 48); ctx.lineTo(cx + 4, by - 36); ctx.lineTo(cx + 14, by - 26); ctx.stroke(); ctx.restore();
      glowEyes(ctx, cx, by - 61, 6, c1, 3);
    } else {
      ctx.strokeStyle = shade(c0, -0.4); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx - 14, by - 40); ctx.lineTo(cx - 4, by - 30); ctx.moveTo(cx + 10, by - 44); ctx.lineTo(cx + 16, by - 30); ctx.stroke();
      glowEyes(ctx, cx, by - 61, 6, '#7af0ff', 3);
    }
  },
  ghost(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.84;
    ctx.save();
    ctx.globalAlpha = 0.82;
    ctx.shadowColor = c1; ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.moveTo(cx - 22, by - 6);
    ctx.bezierCurveTo(cx - 28, by - 46, cx - 10, by - 66, cx + 4, by - 64);
    ctx.bezierCurveTo(cx + 26, by - 62, cx + 28, by - 36, cx + 24, by - 6);
    for (let i = 0; i < 4; i++) ctx.quadraticCurveTo(cx + 18 - i * 12, by + (i % 2 ? -10 : 6), cx + 12 - i * 12, by - 4);
    ctx.closePath();
    ctx.fillStyle = lin(ctx, 0, by - 64, 0, by, [shade(c0, 0.3), c0, 'rgba(120,160,230,0.2)']);
    ctx.fill();
    ctx.restore();
    ell(ctx, cx - 4, by - 42, 5, 8, '#1a2040', null); ell(ctx, cx + 10, by - 42, 5, 8, '#1a2040', null);
    ell(ctx, cx + 3, by - 26, 5, 6, '#1a2040', null);
  },
  dragon(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2 - 4, by = s * 0.86;
    // asa
    ctx.beginPath(); ctx.moveTo(cx - 4, by - 36); ctx.lineTo(cx - 34, by - 70); ctx.lineTo(cx - 30, by - 46); ctx.lineTo(cx - 42, by - 48); ctx.lineTo(cx - 24, by - 30); ctx.closePath();
    ctx.fillStyle = lin(ctx, 0, by - 70, 0, by - 30, [shade(c0, -0.2), c1]); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
    // cauda
    ctx.beginPath(); ctx.moveTo(cx - 18, by - 18); ctx.quadraticCurveTo(cx - 44, by - 10, cx - 42, by - 30); ctx.lineWidth = 9; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 6; ctx.strokeStyle = c0; ctx.stroke();
    for (const dx of [-14, 8]) rr(ctx, cx + dx, by - 14, 9, 14, 3, shade(c0, -0.2));
    ell(ctx, cx, by - 24, 24, 15, grad(ctx, cx, by - 24, 24, c0, shade(c0, -0.4)));
    ell(ctx, cx + 2, by - 18, 15, 7, c1, null);
    // pescoço e cabeça
    ctx.beginPath(); ctx.moveTo(cx + 14, by - 30); ctx.quadraticCurveTo(cx + 22, by - 50, cx + 26, by - 54); ctx.lineWidth = 13; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 9; ctx.strokeStyle = c0; ctx.stroke();
    horns(ctx, cx + 24, by - 62, 9, '#f0e0c0');
    rr(ctx, cx + 16, by - 66, 26, 15, 6, grad(ctx, cx + 26, by - 60, 16, c0, shade(c0, -0.3)));
    glowEyes(ctx, cx + 28, by - 61, 0.01, '#ffe04a', 3);
    ctx.save(); ctx.shadowColor = '#ff8a3a'; ctx.shadowBlur = 8; ell(ctx, cx + 44, by - 56, 3, 2, '#ffb04a', null); ctx.restore();
  },
  skeleton(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const cx = s / 2, by = s * 0.88;
    ctx.lineCap = 'round';
    const bone = (x0, y0, x1, y1, w = 5) => { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.lineWidth = w + 3; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = w; ctx.strokeStyle = c0; ctx.stroke(); };
    bone(cx - 6, by - 26, cx - 9, by - 2); bone(cx + 6, by - 26, cx + 9, by - 2);
    bone(cx, by - 54, cx, by - 26, 6);
    for (let i = 0; i < 3; i++) bone(cx - 10, by - 48 + i * 7, cx + 10, by - 48 + i * 7, 3);
    bone(cx - 10, by - 52, cx - 18, by - 32); bone(cx + 10, by - 52, cx + 20, by - 34);
    ell(ctx, cx, by - 66, 12, 12, grad(ctx, cx, by - 66, 12, c0, c1));
    rr(ctx, cx - 7, by - 58, 14, 7, 2, c0, OUT, 2);
    glowEyes(ctx, cx, by - 67, 5, '#7ad0ff', 3);
    if (sp.bow) { ctx.beginPath(); ctx.arc(cx + 22, by - 36, 16, -1.2, 1.2); ctx.lineWidth = 4; ctx.strokeStyle = '#8a5a2a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx + 28, by - 51); ctx.lineTo(cx + 28, by - 21); ctx.lineWidth = 1; ctx.strokeStyle = '#ddd'; ctx.stroke(); }
    else { ctx.beginPath(); ctx.moveTo(cx + 20, by - 30); ctx.lineTo(cx + 34, by - 64); ctx.lineWidth = 5; ctx.strokeStyle = '#c9ccd6'; ctx.stroke(); ctx.lineWidth = 1.5; ctx.strokeStyle = OUT; ctx.stroke(); }
    ctx.lineCap = 'butt';
  },
  humanoid(ctx, s, sp) {
    const [c0, c1] = sp.c;
    const k = sp.small ? 0.8 : 1;
    const cx = s / 2, by = s * 0.9;
    const skin = sp.wrap ? c0 : sp.armored ? c0 : sp.goat ? '#5a4a4a' : shade(c0, 0.15);
    if (sp.cape) { ctx.beginPath(); ctx.moveTo(cx - 14, by - 58); ctx.lineTo(cx - 28, by - 2); ctx.lineTo(cx + 24, by - 2); ctx.lineTo(cx + 14, by - 58); ctx.closePath(); ctx.fillStyle = lin(ctx, 0, by - 60, 0, by, [c1, shade(c1, -0.6)]); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); }
    if (sp.wings) for (const sgn of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx + sgn * 8, by - 50 * k); ctx.lineTo(cx + sgn * 38, by - 70 * k); ctx.lineTo(cx + sgn * 30, by - 40 * k); ctx.lineTo(cx + sgn * 12, by - 36 * k); ctx.closePath(); ctx.fillStyle = shade(c1, -0.1); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); }
    if (sp.tail) { ctx.beginPath(); ctx.moveTo(cx - 6, by - 20); ctx.quadraticCurveTo(cx - 30, by - 14, cx - 26, by - 36); ctx.lineWidth = 3; ctx.strokeStyle = c1; ctx.stroke(); }
    // pernas
    rr(ctx, cx - 11 * k, by - 22 * k, 9 * k, 22 * k, 3, shade(c1, -0.25), OUT, 2.5);
    rr(ctx, cx + 2 * k, by - 22 * k, 9 * k, 22 * k, 3, shade(c1, -0.25), OUT, 2.5);
    // tronco
    const tw = sp.witch ? 34 : 26;
    if (sp.witch) { ctx.beginPath(); ctx.moveTo(cx - 10, by - 50); ctx.lineTo(cx - tw / 2 - 4, by - 4); ctx.lineTo(cx + tw / 2 + 4, by - 4); ctx.lineTo(cx + 10, by - 50); ctx.closePath(); ctx.fillStyle = lin(ctx, 0, by - 50, 0, by, [c0, shade(c0, -0.4)]); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke(); }
    else rr(ctx, cx - 13 * k, by - 50 * k, 26 * k, 30 * k, 8, lin(ctx, 0, by - 50 * k, 0, by - 20 * k, [shade(c0, 0.2), c0, shade(c0, -0.3)]));
    if (sp.wrap) { ctx.strokeStyle = shade(c0, -0.35); ctx.lineWidth = 1.5; for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.moveTo(cx - 13, by - 46 + i * 6); ctx.lineTo(cx + 13, by - 43 + i * 6); ctx.stroke(); } }
    if (sp.armored) { rr(ctx, cx - 16, by - 52, 32, 10, 4, shade(c0, 0.3)); ell(ctx, cx, by - 36, 5, 5, c1, OUT, 2); }
    // braços
    ell(ctx, cx - 15 * k, by - 36 * k, 5 * k, 11 * k, sp.armored ? shade(c0, 0.2) : c0, OUT, 2.5);
    ell(ctx, cx + 15 * k, by - 36 * k, 5 * k, 11 * k, sp.armored ? shade(c0, 0.2) : c0, OUT, 2.5);
    // cabeça
    const hy = by - 62 * k;
    if (sp.snakeHair) for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.moveTo(cx - 10 + i * 4, hy - 4); ctx.quadraticCurveTo(cx - 20 + i * 8, hy - 22, cx - 14 + i * 7, hy - 24); ctx.lineWidth = 4; ctx.strokeStyle = c1; ctx.stroke(); }
    if (sp.pharaoh) { ctx.beginPath(); ctx.moveTo(cx - 14, hy - 10); ctx.lineTo(cx - 18, hy + 16); ctx.lineTo(cx + 18, hy + 16); ctx.lineTo(cx + 14, hy - 10); ctx.closePath(); ctx.fillStyle = c0; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); ctx.strokeStyle = c1; ctx.lineWidth = 3; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(cx - 16, hy - 4 + i * 6); ctx.lineTo(cx + 16, hy - 4 + i * 6); ctx.stroke(); } }
    ell(ctx, cx, hy, 13 * k, 13 * k, sp.armored ? lin(ctx, 0, hy - 13, 0, hy + 13, [shade(c0, 0.4), c0]) : grad(ctx, cx, hy, 13 * k, skin, shade(skin, -0.3)));
    if (sp.armored) { ctx.fillStyle = '#0a0a10'; ctx.fillRect(cx - 8, hy - 3, 16, 5); glowEyes(ctx, cx, hy - 1, 4, '#ff3a3a', 2); }
    else if (sp.wrap || sp.goat || sp.horns || sp.pharaoh) glowEyes(ctx, cx + 1, hy - 1, 4.5, sp.wrap ? '#ffe04a' : '#ff3a3a', 2.5);
    else eyes(ctx, cx + 1, hy - 1, 4.5, 3.5, sp.snakeHair);
    if (sp.horns) horns(ctx, cx, hy - 9 * k, 9 * k, '#3a2a2a');
    if (sp.goat) { horns(ctx, cx, hy - 8, 16, '#d8c8a8', true); ell(ctx, cx + 2, hy + 10, 6, 7, '#5a4a4a', OUT, 2); }
    if (sp.witch) { ctx.beginPath(); ctx.moveTo(cx - 22, hy - 6); ctx.lineTo(cx + 22, hy - 6); ctx.lineTo(cx + 4, hy - 40); ctx.lineTo(cx - 8, hy - 30); ctx.closePath(); ctx.fillStyle = c0; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); ctx.fillStyle = c1; ctx.fillRect(cx - 12, hy - 12, 24, 4); }
    if (sp.scythe) { ctx.beginPath(); ctx.moveTo(cx + 22, by); ctx.lineTo(cx + 26, by - 80); ctx.lineWidth = 4; ctx.strokeStyle = '#3a2a1a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx + 26, by - 80); ctx.quadraticCurveTo(cx - 10, by - 92, cx - 24, by - 66); ctx.quadraticCurveTo(cx - 4, by - 80, cx + 25, by - 72); ctx.closePath(); ctx.fillStyle = lin(ctx, cx - 20, 0, cx + 20, 0, ['#e8eaf2', '#8a8f99']); ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); }
    if (sp.witch) { ctx.beginPath(); ctx.moveTo(cx + 18, by - 2); ctx.lineTo(cx + 22, by - 56); ctx.lineWidth = 3; ctx.strokeStyle = '#4a2a1a'; ctx.stroke(); ctx.save(); ctx.shadowColor = c1; ctx.shadowBlur = 10; ell(ctx, cx + 22, by - 58, 4, 4, c1, null); ctx.restore(); }
  },
};

export function monsterSprite(type) {
  const dc = dcssMonster(type);
  if (dc) return dc;
  const key = 'm:' + type;
  if (cache.has(key)) return cache.get(key);
  const def = MONSTERS[type];
  const c = mk();
  const ctx = angularize(c.getContext('2d'));
  SHAPES[def.sprite.shape](ctx, SPR, def.sprite);
  cache.set(key, c);
  return c;
}

// ---------------- Herói ----------------
const HATS = {
  none() {},
  band(ctx, cx, hy, c) { rr(ctx, cx - 13, hy - 8, 26, 5, 2, c[0], OUT, 2); },
  wizard(ctx, cx, hy, c) { ctx.beginPath(); ctx.moveTo(cx - 19, hy - 6); ctx.lineTo(cx + 17, hy - 6); ctx.lineTo(cx + 10, hy - 22); ctx.lineTo(cx - 6, hy - 38); ctx.lineTo(cx - 8, hy - 20); ctx.closePath(); ctx.fillStyle = lin(ctx, 0, hy - 38, 0, hy, [shade(c[0], 0.2), c[0]]); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); ctx.fillStyle = c[1]; ctx.fillRect(cx - 12, hy - 11, 24, 3); },
  feather(ctx, cx, hy, c) { ell(ctx, cx, hy - 9, 15, 6, c[0]); ctx.beginPath(); ctx.moveTo(cx - 6, hy - 12); ctx.quadraticCurveTo(cx - 22, hy - 30, cx - 12, hy - 34); ctx.quadraticCurveTo(cx - 10, hy - 22, cx - 2, hy - 12); ctx.fillStyle = '#e84a4a'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); },
  hood(ctx, cx, hy, c) { ctx.beginPath(); ctx.arc(cx, hy - 1, 15, Math.PI * 1.05, Math.PI * 1.95); ctx.lineTo(cx + 16, hy + 6); ctx.lineTo(cx - 16, hy + 6); ctx.closePath(); ctx.fillStyle = c[0]; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); },
  cap(ctx, cx, hy, c) { ctx.beginPath(); ctx.arc(cx, hy - 3, 14, Math.PI, 0); ctx.closePath(); ctx.fillStyle = c[1]; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); },
  beret(ctx, cx, hy, c) { ell(ctx, cx - 2, hy - 11, 16, 7, c[0]); ell(ctx, cx - 2, hy - 18, 3, 3, c[1], OUT, 1.5); },
  helm(ctx, cx, hy, c) { ctx.beginPath(); ctx.arc(cx, hy - 3, 15, Math.PI, 0); ctx.lineTo(cx + 15, hy - 2); ctx.lineTo(cx - 15, hy - 2); ctx.closePath(); ctx.fillStyle = lin(ctx, 0, hy - 16, 0, hy + 4, ['#e8eef8', '#8a95a8']); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx, hy - 18); ctx.quadraticCurveTo(cx - 14, hy - 32, cx - 22, hy - 24); ctx.lineWidth = 4; ctx.strokeStyle = '#d83a3a'; ctx.stroke(); },
  mask(ctx, cx, hy, c) { rr(ctx, cx - 13, hy + 1, 26, 8, 3, c[0], OUT, 2); ctx.beginPath(); ctx.arc(cx, hy - 2, 14, Math.PI * 1.05, Math.PI * 1.95); ctx.fillStyle = shade(c[0], -0.3); ctx.fill(); },
  mitre(ctx, cx, hy, c) { ctx.beginPath(); ctx.moveTo(cx - 12, hy - 6); ctx.lineTo(cx - 9, hy - 28); ctx.lineTo(cx, hy - 34); ctx.lineTo(cx + 9, hy - 28); ctx.lineTo(cx + 12, hy - 6); ctx.closePath(); ctx.fillStyle = c[0]; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); ctx.fillStyle = c[1]; ctx.fillRect(cx - 1.5, hy - 28, 3, 20); ctx.fillRect(cx - 6, hy - 22, 12, 3); },
  goggles(ctx, cx, hy, c) { rr(ctx, cx - 14, hy - 10, 28, 4, 2, '#3a2a1a', OUT, 1.5); ell(ctx, cx - 6, hy - 10, 5, 4, '#7ad0ff', OUT, 2); ell(ctx, cx + 6, hy - 10, 5, 4, '#7ad0ff', OUT, 2); },
};

function drawWeapon(ctx, wtype, x, y, scale = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.lineCap = 'round';
  const steel = (len, w) => { ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -len); ctx.lineWidth = w + 3; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = w; ctx.strokeStyle = '#dfe6f0'; ctx.stroke(); };
  switch (wtype) {
    case 'adaga': ctx.rotate(0.5); steel(16, 4); rr(ctx, -5, -2, 10, 3, 1, '#c9a24a', OUT, 1.5); break;
    case 'espada': ctx.rotate(0.35); steel(30, 5); rr(ctx, -7, -3, 14, 4, 1, '#c9a24a', OUT, 1.5); break;
    case 'lanca': ctx.rotate(0.15); ctx.beginPath(); ctx.moveTo(0, 14); ctx.lineTo(0, -38); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#8a5a2a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(-5, -36); ctx.lineTo(0, -52); ctx.lineTo(5, -36); ctx.closePath(); ctx.fillStyle = '#e8eef8'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); break;
    case 'cajado': ctx.rotate(0.12); ctx.beginPath(); ctx.moveTo(0, 14); ctx.lineTo(0, -36); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#7a4a2a'; ctx.stroke(); ctx.save(); ctx.shadowColor = '#9ad8ff'; ctx.shadowBlur = 12; ell(ctx, 0, -40, 6, 6, '#9ad8ff', OUT, 2); ctx.restore(); break;
    case 'kunai': ctx.rotate(0.5); ctx.beginPath(); ctx.moveTo(-5, -4); ctx.lineTo(0, -34); ctx.lineTo(5, -4); ctx.closePath(); ctx.fillStyle = lin(ctx, -5, 0, 5, 0, ['#ffffff', '#9aa8bc']); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); rr(ctx, -2.5, -4, 5, 14, 1, '#2a2f45', OUT, 2); ctx.beginPath(); ctx.arc(0, 14, 5, 0, 7); ctx.lineWidth = 3; ctx.strokeStyle = '#c9d2e0'; ctx.stroke(); break;
    case 'fuuma': ctx.translate(4, -20); for (let i = 0; i < 4; i++) { ctx.save(); ctx.rotate(i * Math.PI / 2); ctx.beginPath(); ctx.moveTo(0, -5); ctx.lineTo(8, -8); ctx.lineTo(4, -28); ctx.lineTo(-2, -10); ctx.closePath(); ctx.fillStyle = lin(ctx, 0, -28, 0, 0, ['#ffffff', '#9aa8bc']); ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); ctx.restore(); } ell(ctx, 0, 0, 7, 7, '#3a3048', OUT, 2.5); break;
    case 'treino': ctx.rotate(0.35); ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(-4, -34); ctx.lineTo(0, -40); ctx.lineTo(4, -34); ctx.lineTo(4, 0); ctx.closePath(); ctx.fillStyle = lin(ctx, -4, 0, 4, 0, ['#e0b880', '#a87a48']); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); rr(ctx, -9, -2, 18, 5, 1, '#7a5230', OUT, 2); rr(ctx, -2.5, 3, 5, 10, 1, '#5a3a20', OUT, 2); break;
    case 'besta': ctx.rotate(-0.7); rr(ctx, -16, -4, 30, 7, 2, '#6a4a2a', OUT, 2.5); rr(ctx, 8, -20, 5, 40, 2, '#9aa8bc', OUT, 2.5); ctx.beginPath(); ctx.moveTo(10, -18); ctx.lineTo(-10, 0); ctx.lineTo(10, 18); ctx.lineWidth = 1.2; ctx.strokeStyle = '#eee'; ctx.stroke(); break;
    case 'katar': ctx.rotate(0.3); rr(ctx, -8, -4, 16, 10, 2, '#5a3a2a', OUT, 2.5); ctx.beginPath(); ctx.moveTo(-6, -4); ctx.lineTo(0, -42); ctx.lineTo(6, -4); ctx.closePath(); ctx.fillStyle = lin(ctx, -6, 0, 6, 0, ['#ffffff', '#b8c2d4']); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); break;
    case 'faixa': for (const [dy, c] of [[-14, '#f4efe2'], [-6, '#d83a3a'], [2, '#f4efe2']]) rr(ctx, -15, dy, 30, 8, 3, c, OUT, 2.5); break;
    case 'soqueira': rr(ctx, -16, -10, 32, 18, 5, lin(ctx, 0, -10, 0, 8, ['#e8eef8', '#7a88a0']), OUT, 3); for (const dx of [-10, -3, 4, 11]) { ctx.beginPath(); ctx.moveTo(dx - 3, -10); ctx.lineTo(dx, -17); ctx.lineTo(dx + 3, -10); ctx.closePath(); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); } break;
    case 'arco': ctx.beginPath(); ctx.arc(-6, -10, 20, -1.15, 1.15); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#a86a2a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(2, -28); ctx.lineTo(2, 8); ctx.lineWidth = 1; ctx.strokeStyle = '#eee'; ctx.stroke(); break;
    case 'maca': ctx.rotate(0.35); ctx.beginPath(); ctx.moveTo(0, 6); ctx.lineTo(0, -22); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#7a4a2a'; ctx.stroke(); ell(ctx, 0, -26, 7, 7, '#b8c0cc', OUT, 2); break;
    case 'machado': ctx.rotate(0.3); ctx.beginPath(); ctx.moveTo(0, 8); ctx.lineTo(0, -30); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#7a4a2a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, -28); ctx.quadraticCurveTo(16, -32, 14, -16); ctx.lineTo(0, -20); ctx.closePath(); ctx.fillStyle = '#dfe6f0'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); break;
  }
  ctx.restore();
}

export function heroSprite(cls, wtype) {
  cls = artCls(cls);
  const lpc = heroPortrait(cls);
  if (lpc) return lpc;
  const key = `h:${cls}:${wtype}`;
  if (cache.has(key)) return cache.get(key);
  const c = mk();
  drawHero(c.getContext('2d'), cls, wtype);
  cache.set(key, c);
  return c;
}

// ---------------- Ícones de itens ----------------
function drawItemIcon(ctx, s, it) {
  const d = itemDef(it);
  const cx = s / 2, cy = s / 2;
  ctx.lineJoin = 'round';
  if (d.kind === 'use' && d.id !== undefined) {}
  if (d.kind === 'use') {
    if (d.teleport || d.recall) {
      const col = d.recall ? '#7ad0ff' : '#d8d2bc';
      for (const k of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx, cy + 6); ctx.quadraticCurveTo(cx + k * 34, cy - 30, cx + k * 30, cy + 2); ctx.quadraticCurveTo(cx + k * 20, cy + 14, cx, cy + 6); ctx.fillStyle = lin(ctx, 0, cy - 20, 0, cy + 10, [shade(col, 0.4), col]); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke(); }
      return;
    }
    if (d.cure) { for (const [dx, a] of [[-8, -0.4], [0, 0], [8, 0.4]]) { ctx.save(); ctx.translate(cx + dx, cy + 14); ctx.rotate(a); ell(ctx, 0, -16, 7, 16, '#5fd16a'); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -30); ctx.lineWidth = 1.5; ctx.strokeStyle = '#2a7a2a'; ctx.stroke(); ctx.restore(); } return; }
    const col = d.icon;
    rr(ctx, cx - 6, cy - 26, 12, 10, 3, '#b88a5a');
    ctx.beginPath(); ctx.moveTo(cx - 6, cy - 16); ctx.lineTo(cx - 6, cy - 10); ctx.bezierCurveTo(cx - 24, cy - 4, cx - 22, cy + 26, cx, cy + 26); ctx.bezierCurveTo(cx + 22, cy + 26, cx + 24, cy - 4, cx + 6, cy - 10); ctx.lineTo(cx + 6, cy - 16); ctx.closePath();
    ctx.fillStyle = grad(ctx, cx, cy + 8, 20, col, shade(col, -0.5)); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    ell(ctx, cx - 7, cy + 2, 4, 7, 'rgba(255,255,255,0.6)', null);
    return;
  }
  if (d.kind === 'mat') {
    ctx.save(); ctx.shadowColor = '#7affe0'; ctx.shadowBlur = 14;
    ctx.beginPath(); ctx.moveTo(cx, cy - 28); ctx.lineTo(cx + 16, cy - 4); ctx.lineTo(cx + 6, cy + 26); ctx.lineTo(cx - 10, cy + 22); ctx.lineTo(cx - 16, cy - 6); ctx.closePath();
    ctx.fillStyle = lin(ctx, cx - 16, cy - 28, cx + 16, cy + 26, ['#e0fff8', '#7affe0', '#2a8a9a']); ctx.fill(); ctx.restore();
    ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, cy - 28); ctx.lineTo(cx - 2, cy + 24); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.stroke();
    return;
  }
  if (d.kind === 'card') {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.08);
    rr(ctx, -22, -30, 44, 60, 5, lin(ctx, 0, -30, 0, 30, d.boss ? ['#fff0c0', '#ffb84a'] : ['#fffbe8', '#e8dcb0']));
    rr(ctx, -17, -24, 34, 34, 3, '#2a2438', null);
    const spr = monsterSprite(d.mon);
    ctx.drawImage(spr, -17, -24, 34, 34);
    ctx.fillStyle = 'rgba(60,40,20,0.7)'; ctx.fillRect(-15, 15, 30, 3); ctx.fillRect(-15, 21, 20, 3);
    ctx.restore();
    return;
  }
  if (d.kind === 'weapon') { drawWeapon(ctx, d.wtype, cx - 4, cy + 22, 1.15); return; }
  if (d.kind === 'armor') {
    const col = d.mdef >= 10 && d.def < 15 ? '#6a4ab8' : d.tier >= 3 ? '#9aa8bc' : '#a8784a';
    ctx.beginPath(); ctx.moveTo(cx - 12, cy - 24); ctx.lineTo(cx - 26, cy - 16); ctx.lineTo(cx - 22, cy - 2); ctx.lineTo(cx - 16, cy - 4); ctx.lineTo(cx - 16, cy + 24); ctx.lineTo(cx + 16, cy + 24); ctx.lineTo(cx + 16, cy - 4); ctx.lineTo(cx + 22, cy - 2); ctx.lineTo(cx + 26, cy - 16); ctx.lineTo(cx + 12, cy - 24); ctx.quadraticCurveTo(cx, cy - 14, cx - 12, cy - 24);
    ctx.fillStyle = lin(ctx, 0, cy - 24, 0, cy + 24, [shade(col, 0.35), col, shade(col, -0.35)]); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    return;
  }
  if (d.kind === 'acc') {
    const gems = { str: '#ff4a4a', int: '#7a5aff', dex: '#4ad86a', agi: '#4ad8ff', vit: '#ff9a3a', luk: '#ffd23f' };
    ctx.beginPath(); ctx.ellipse(cx, cy + 6, 18, 18, 0, 0, Math.PI * 2); ctx.lineWidth = 9; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 6; ctx.strokeStyle = '#e8c34a'; ctx.stroke();
    ctx.save(); ctx.shadowColor = gems[d.stat]; ctx.shadowBlur = 10;
    ctx.beginPath(); ctx.moveTo(cx, cy - 24); ctx.lineTo(cx + 10, cy - 12); ctx.lineTo(cx, cy - 4); ctx.lineTo(cx - 10, cy - 12); ctx.closePath(); ctx.fillStyle = gems[d.stat]; ctx.fill(); ctx.restore();
    ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
  }
}

export function itemSprite(it) {
  const d = itemDef(it);
  const key = 'i:' + (d.kind === 'card' ? 'card:' + it.mon : it.id);
  if (cache.has(key)) return cache.get(key);
  const c = mk(72);
  drawItemIcon(c.getContext('2d'), 72, it);
  cache.set(key, c);
  return c;
}

const urlCache = new Map();
export function itemIconURL(it) {
  const d = itemDef(it);
  const key = d.kind === 'card' ? 'card:' + it.mon : it.id;
  if (!urlCache.has(key)) urlCache.set(key, itemSprite(it).toDataURL());
  return urlCache.get(key);
}

export function spriteURL(canvas, key) {
  if (!urlCache.has(key)) {
    let c = canvas;
    if (canvas.pixel) { // pixel art: amplia sem borrar antes de virar imagem
      c = document.createElement('canvas'); c.width = c.height = canvas.width * 4;
      const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(canvas, 0, 0, c.width, c.height);
    }
    urlCache.set(key, c.toDataURL());
  }
  return urlCache.get(key);
}
