// Interface (HTML sobre o canvas): HUD, cidade, folhas de menu
import * as Game from './game.js';
import { G } from './game.js';
import { CLASSES, SKILLS, ITEMS, THEMES, LEGACY, SHOP_ITEMS, STAT_NAMES, STAT_DESC, MONSTERS, CLASS_LV, themeForFloor, ELEMENTS } from './data.js';
import { itemDef, itemName, itemDesc, itemColor, isEquip, isStack, sellPrice, buyPrice, makeItem, statCost, xpToNext, STATS, legacyCost, jobBonus } from './rules.js';
import { JOB_BONUS } from './data.js';
import { heroSprite, monsterSprite, itemIconURL, spriteURL } from './sprites.js';
import { Audio } from './audio.js';
import { ICON } from './icons.js';
import { sceneURL } from './town.js';
import { CLASS_WEAPON } from './heroes.js';
import { fmt } from './util.js';
import { LPC_CREDITS } from './credits.js';
import { wikiSheet } from './wiki.js';
import { marketSheet } from './marketui.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let handlers = {};
export function setHandlers(h) { handlers = h; }

const heroURL = (cls, wt) => spriteURL(heroSprite(cls, wt), `h:${cls}:${wt}`);
const ic = (n) => `<i>${ICON[n]}</i>`;
const purse = () => `<span class="purse price">${ic('coin')}${fmt(G.state.meta.zeny)}</span>`;
export function hydrateIcons(root = document) { root.querySelectorAll('[data-ic]').forEach((e) => { e.innerHTML = ICON[e.dataset.ic]; }); }
const monURL = (t) => spriteURL(monsterSprite(t), 'm:' + t);

// ---------------- Toast ----------------
let toastT = 0;
export function toast(msg, ms = 1800) {
  const t = $('toast');
  t.innerHTML = msg;
  t.classList.remove('hidden');
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.add('hidden'), ms);
}

// ---------------- Folhas ----------------
let sheetStack = [];
export function openSheet({ title, html, mount, center = false, onClose }) {
  closeSheet(true);
  const root = $('sheet-root');
  root.innerHTML = `<div class="sheet-back"></div><div class="sheet ${center ? 'center' : ''}">${center ? '' : '<div class="grab"></div>'}
    <h3>${title}<button class="x" aria-label="Fechar">${ICON.close}</button></h3><div class="body">${html}</div></div>`;
  const close = () => { closeSheet(); };
  root.querySelector('.sheet-back').onclick = close;
  root.querySelector('.x').onclick = close;
  sheetStack = [{ onClose }];
  if (mount) mount(root.querySelector('.body'), root.querySelector('.sheet'));
  return root.querySelector('.body');
}
export function closeSheet(silent) {
  const root = $('sheet-root');
  if (!root.innerHTML) return false;
  const top = sheetStack.pop();
  root.innerHTML = '';
  if (!silent && top && top.onClose) top.onClose();
  if (!silent) refresh(true);
  return true;
}
export const sheetOpen = () => !!$('sheet-root').innerHTML;

// ---------------- HUD ----------------
let lastMode = null;
let lastHudAt = 0;
export function refresh(force) {
  const st = G.state;
  if (!st) return;
  if (st.mode !== lastMode || force === 'screen') {
    lastMode = st.mode;
    renderMode();
  }
  if (st.mode === 'dungeon') updateHUD(force);
  else if (st.mode === 'town' && force) renderTown();
}

function renderMode() {
  const st = G.state;
  const dungeon = st.mode === 'dungeon';
  for (const id of ['hud', 'bottom']) $(id).classList.toggle('hidden', !dungeon);
  $('ctx-btns').classList.toggle('hidden', !dungeon);
  if (!dungeon) $('target-banner').classList.add('hidden');
  $('screen').classList.toggle('hidden', dungeon);
  if (st.mode === 'title') renderTitle();
  else if (st.mode === 'town') renderTown();
  else if (st.mode === 'dead') renderDeath();
  else if (dungeon) { closeSheet(true); updateHUD(true); }
  const bot = $('bottom').getBoundingClientRect().height || 170;
  const top = $('hud').getBoundingClientRect().height || 100;
  handlers.onLayout && handlers.onLayout(Math.min(top, 140), bot);
}

export function updateHUD(force) {
  const now = performance.now();
  if (!force && !G.dirty && now - lastHudAt < 300) return;
  lastHudAt = now;
  G.dirty = false;
  const h = G.state.hero, r = G.state.run, d = G.d;
  if (!h || !r || !d) return;
  $('portrait-img').src = heroURL(h.cls, d.wtype);
  $('hud-lv').textContent = h.lv;
  const pts = h.statPts > 0 || h.skillPts > 0;
  $('pts-dot').classList.toggle('hidden', !pts);
  $('pts-dot2').classList.toggle('hidden', !pts);
  $('hp-fill').style.width = Math.max(0, h.hp / d.maxHp * 100) + '%';
  $('hp-txt').textContent = `${Math.max(0, Math.ceil(h.hp))} / ${d.maxHp}`;
  $('sp-fill').style.width = (h.sp / d.maxSp * 100) + '%';
  $('sp-txt').textContent = `${Math.floor(h.sp)} / ${d.maxSp}`;
  const capped = h.lv >= Game.levelCap();
  $('xp-fill').style.width = (capped ? 100 : Math.min(100, h.xp / xpToNext(h.lv) * 100)) + '%';
  $('xp-fill').classList.toggle('capped', capped);
  $('hud-floor').textContent = `Andar ${r.floor}`;
  $('hud-floor').style.color = themeForFloor(r.floor).accent;
  $('hud-zeny').innerHTML = `${ic('coin')}${fmt(h.zeny)}`;
  // buffs e status
  const bf = [];
  for (const b of h.buffs) bf.push(`<span class="buff">${b.icon || "✦"} ${b.aura ? "∞" : b.turns}</span>`);
  const stn = { poison: '☠ Veneno', burn: '🔥 Queimando', stun: '✶ Atordoado', freeze: '❄ Congelado', snare: '# Preso' };
  for (const [k, v] of Object.entries(h.status)) bf.push(`<span class="buff bad">${stn[k] || k} ${v}</span>`);
  $('buffs').innerHTML = bf.join('');
  // chefe
  const boss = r.monsters.find((m) => m.boss && m.hp > 0 && Game.visible(m.x, m.y));
  $('bossbar').classList.toggle('hidden', !boss);
  if (boss) { $('boss-name').textContent = MONSTERS[boss.type].name; $('boss-fill').style.width = (boss.hp / boss.maxHp * 100) + '%'; }
  // log
  const lg = r.log.slice(-4);
  $('log').innerHTML = lg.map((l) => {
    const age = (now - l.at) / 1000;
    const op = age > 6 ? 0 : age > 4 ? 0.35 : 1;
    return `<div style="color:${l.color};opacity:${op}">${esc(l.text)}</div>`;
  }).join('');
  // botões contextuais
  const t = Game.G.state.run.map.t[r.py * r.map.w + r.px];
  const cb = [];
  if (t === 3) cb.push(`<button class="ctx-btn" data-a="descend">${ic('stairs')}Descer</button>`);
  if (t === 6) cb.push(`<button class="ctx-btn gold" data-a="portal">${ic('portal')}Cidade</button>`);
  const ctx = $('ctx-btns');
  ctx.innerHTML = cb.join('');
  ctx.style.bottom = ($('bottom').getBoundingClientRect().height + 10) + 'px';
  ctx.querySelectorAll('button').forEach((b) => b.onclick = () => handlers.onContext(b.dataset.a));
  renderSkillbar();
}

function bestPotion() {
  const h = G.state.hero;
  const order = ['pocao_branca', 'pocao_amarela', 'pocao_laranja', 'pocao_vermelha'];
  const missing = G.d.maxHp - h.hp;
  const have = order.map((id) => h.inv.find((i) => i.id === id)).filter(Boolean);
  if (!have.length) return null;
  // usa a menor poção que cura o que falta; senão a maior
  const fit = [...have].reverse().find((i) => ITEMS[i.id].heal >= missing * 0.8);
  return fit || have[0];
}
export { bestPotion };

function renderSkillbar() {
  const h = G.state.hero;
  const bar = $('skillbar');
  const sel = handlers.selectedSkill && handlers.selectedSkill();
  const html = h.bar.map((id, i) => {
    if (!id) return `<button class="skill empty" data-i="${i}" aria-label="Escolher habilidade">${ic('plus')}</button>`;
    const sk = SKILLS[id];
    const u = Game.skillUsable(id);
    const auraOn = sk.aura && Game.hasBuff(sk.buffs(1).id);
    return `<button class="skill ${u.ok ? '' : 'off'} ${sel === id ? 'active' : ''} ${auraOn ? 'aura' : ''}" data-id="${id}"><span class="cost">${sk.sp(h.skills[id] || 1)}</span><b>${sk.icon}</b><small>${esc(sk.name)}</small></button>`;
  });
  const pot = bestPotion();
  html.push(pot
    ? `<button class="skill potion" data-pot="${pot.uid}"><img src="${itemIconURL(pot)}"><span class="qty">${h.inv.filter((i) => i.id.startsWith('pocao') && i.id !== 'pocao_azul').reduce((a, b) => a + b.qty, 0)}</span></button>`
    : `<button class="skill potion empty" aria-label="Sem poções">${ic('potion')}</button>`);
  bar.innerHTML = html.join('');
  bar.querySelectorAll('button').forEach((b) => {
    b.onclick = () => {
      Audio.play('click');
      if (b.dataset.id) handlers.onSkill(b.dataset.id);
      else if (b.dataset.pot) handlers.onPotion(Number(b.dataset.pot));
      else if (b.dataset.i !== undefined) heroSheet('skills');
    };
  });
}

// ---------------- Título ----------------
function renderTitle() {
  const st = G.state;
  const meta = st.meta;
  const veteran = meta.heroesLost || meta.zeny || meta.bestFloor;
  $('screen').innerHTML = `
    <div class="logo">AnotheRO</div>
    <div class="tagline">Desça. Evolua. Não olhe para trás.</div>
    <div class="title-box">
      <div class="title-hero"><img src="${heroURL('mago', 'cajado')}" alt=""><img src="${heroURL('aprendiz', 'adaga')}" alt=""><img src="${heroURL('arqueiro', 'arco')}" alt=""></div>
      <input class="name" id="hero-name" maxlength="16" placeholder="Nome do seu herói" value="${esc(meta.lastName || '')}">
      <button class="btn primary" id="btn-new">Começar jornada</button>
      ${veteran ? `<div class="records"><div><b>${fmt(meta.zeny)}</b><small>zeny no banco</small></div><div><b>${meta.bestFloor}</b><small>andar recorde</small></div><div><b>${meta.victories}</b><small>vitórias</small></div></div>` : ''}
      ${meta.graveyard?.length ? `<button class="btn" id="btn-grave">${ic('skull')}Memorial dos heróis</button>` : ''}
      <div class="foot">Se o herói cair, ele se vai. O banco, o armazém e as bênçãos do Santuário ficam para o próximo.</div>
    </div>`;
  $('btn-new').onclick = () => {
    Audio.unlock();
    const name = $('hero-name').value.trim() || 'Aventureiro';
    meta.lastName = name;
    Game.createHero(name);
    refresh('screen');
    setTimeout(() => heroSheet('stats', true), 250);
  };
  const g = $('btn-grave');
  if (g) g.onclick = graveSheet;
}

function graveSheet() {
  const gy = G.state.meta.graveyard || [];
  openSheet({ title: '🪦 Memorial', html: `<div class="list">${gy.map((g) => `<div class="row"><div class="info"><strong>${esc(g.name)}, ${esc(g.cls)} nível ${g.lv}</strong><small>Caiu no andar ${g.floor}, derrotado por ${esc(g.by || '?')}, em ${new Date(g.at).toLocaleDateString('pt-BR')}</small></div></div>`).join('')}</div>` });
}

// ---------------- Morte ----------------
function renderDeath() {
  const d = G.state.lastDeath || {};
  $('screen').innerHTML = `<div class="death">
    <div class="stone">R.I.P.</div>
    <h1>${esc(d.name || 'Herói')} caiu</h1>
    <p>${esc(d.cls || '')}, nível ${d.lv}, no andar ${d.floor}</p>
    <p>Derrotado por <b>${esc(d.by || 'algo nas sombras')}</b></p>
    <p style="color:var(--parch-dim)">${d.kills || 0} monstros derrotados e ${fmt(d.zenyLost || 0)} zeny perdidos.</p>
    <p style="color:var(--brass-hi);margin-top:18px">O banco, o armazém e as bênçãos do Santuário continuam.</p>
    <div class="title-box" style="margin-top:22px"><button class="btn primary" id="btn-ack">Criar novo herói</button></div></div>`;
  $('btn-ack').onclick = () => { Game.acknowledgeDeath(); refresh('screen'); };
}

// ---------------- Cidade ----------------
export function renderTown() {
  const h = G.state.hero, meta = G.state.meta, d = G.d;
  if (!h) return;
  const co = Game.classOptions();
  const pts = h.statPts > 0 || h.skillPts > 0;
  const tl = (G.state.townLog || []).slice(-1)[0];
  const place = (go, scene, name, sub, extra = '', dot = false) =>
    `<button class="place frame ${extra}" data-go="${go}"><img src="${sceneURL(scene)}" alt="">${dot ? '<i class="dot"></i>' : ''}<div class="cap"><strong>${name}</strong><small>${sub}</small></div></button>`;
  $('screen').innerHTML = `
    <div class="plaque frame">
      <button class="pic" data-go="hero" aria-label="Herói"><img src="${heroURL(h.cls, d.wtype)}" alt="">${pts ? '<i class="dot"></i>' : ''}</button>
      <button class="who" data-go="hero"><h2>${esc(h.name)}</h2><p>${CLASSES[h.cls].name}, nível ${h.lv}</p></button>
      <div class="purse"><b>${ic('coin')}${fmt(meta.zeny)}</b><button data-go="bag" aria-label="Mochila">${ICON.bag}</button> <button data-go="menu" aria-label="Opções">${ICON.gear}</button></div>
    </div>
    <div class="town-name">Vila de Runa</div>
    <div class="town-sub">As tochas estão acesas. A masmorra espera.</div>
    <div class="places">
      ${place('dungeon', 'gate', 'Portão da Masmorra', h.deepest ? `Seu recorde: andar ${h.deepest}. Atalhos a cada chefe derrotado.` : 'O primeiro andar fica logo depois do arco.', 'wide')}
      ${place('shop', 'shop', 'Empório', 'Poções, asas e fragmentos')}
      ${place('smith', 'smith', 'Forja', 'Refino, armas e vendas')}
      ${place('storage', 'storage', 'Armazém', `${meta.storage.length} itens guardados`)}
      ${place('class', 'guild', 'Guilda das Classes', co.opts.length ? (co.ok ? 'Seu novo caminho está pronto' : co.lvOk ? 'Gaste os pontos de habilidade para mudar' : `Mudança de classe no nível ${co.need}`) : 'Você já domina sua classe', '', co.ok)}
      ${place('market', 'market', 'Mercado', (() => { const m = Game.market(); return m.mine.length ? `${m.mine.length} anúncio${m.mine.length > 1 ? 's' : ''} seu${m.mine.length > 1 ? 's' : ''} à venda` : 'Negocie com outros aventureiros'; })(), 'wide')}
      ${place('legacy', 'temple', 'Santuário', 'Bênçãos que valem para todos os heróis', 'wide')}
    </div>
    <div class="town-log">${tl ? esc(tl.text) : ''}</div>`;
  $('screen').querySelectorAll('[data-go]').forEach((b) => b.onclick = () => {
    Audio.play('click');
    const go = b.dataset.go;
    if (go === 'dungeon') dungeonSheet();
    if (go === 'hero') heroSheet();
    if (go === 'bag') bagSheet();
    if (go === 'shop') shopSheet();
    if (go === 'smith') smithSheet();
    if (go === 'storage') storageSheet();
    if (go === 'class') classSheet();
    if (go === 'legacy') legacySheet();
    if (go === 'market') marketSheet();
    if (go === 'menu') menuSheet();
  });
}

function dungeonSheet() {
  const floors = Game.availableFloors();
  const h = G.state.hero;
  const cap = Game.levelCap();
  const groups = [];
  for (const f of floors) { const th = themeForFloor(f); let g = groups.find((x) => x.th === th); if (!g) groups.push(g = { th, fl: [] }); g.fl.push(f); }
  const nextBoss = THEMES.find((t, i) => !(h.bosses || []).includes((i + 1) * 5));
  openSheet({
    title: 'Portão da Masmorra',
    html: `<p class="note" style="margin:0 0 10px">Limite de nível: <b style="color:#ffd86b">${cap >= 99 ? 'livre' : cap}</b>${cap < 99 && nextBoss ? ` · derrote ${esc(MONSTERS[nextBoss.boss].name)} para liberar mais` : ''}. Cada entrada gera um andar novo, e os monstros não param de aparecer: você decide quando descer ou voltar.</p>
      ${groups.map((g) => `<div class="section" style="color:${g.th.accent}">${g.th.name} <small style="opacity:.7">· monstros nv ${g.th.lv[0]}–${g.th.lv[1]}</small></div>
        <div class="floorgrid">${g.fl.map((f) => `<button class="btn small floorbtn ${f % 5 === 0 ? 'boss' : ''}" data-f="${f}">${f % 5 === 0 ? '♛ ' : ''}${f}</button>`).join('')}</div>`).join('')}
      <p class="note" style="margin-top:12px">A Asa de Borboleta traz você para a cidade a qualquer momento.</p>`,
    mount(body) {
      body.querySelectorAll('[data-f]').forEach((b) => b.onclick = () => {
        closeSheet(true);
        Game.enterDungeon(Number(b.dataset.f));
        refresh('screen');
        handlers.onEnterDungeon && handlers.onEnterDungeon();
      });
    },
  });
}

export function heroSheet(tab = 'stats', first = false) {
  const h = G.state.hero;
  const tabs = [['stats', 'Atributos'], ['skills', 'Habilidades'], ['equip', 'Equipamento']];
  const body = openSheet({
    title: `${esc(h.name)} <small>${CLASSES[h.cls].name}, nível ${h.lv}</small>`,
    html: `<div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${n}${k === 'stats' && h.statPts ? ' •' : ''}${k === 'skills' && h.skillPts ? ' •' : ''}</button>`).join('')}</div><div id="hero-tab"></div>`,
    mount(b) {
      b.querySelectorAll('.tab').forEach((t) => t.onclick = () => { heroSheet(t.dataset.t); });
    },
  });
  const el = body.querySelector('#hero-tab');
  if (tab === 'stats') renderStats(el, first);
  if (tab === 'skills') renderSkills(el);
  if (tab === 'equip') renderEquip(el);
}

function jobBonusText(h) {
  const jb = jobBonus(h);
  return Object.entries(jb).filter(([, v]) => v > 0).map(([k, v]) => `${STAT_NAMES[k]} +${v}`).join(', ');
}

function renderStats(el, first) {
  const h = G.state.hero, d = G.d;
  const s = d.stats;
  el.innerHTML = `
    ${first ? `<div class="hint">Distribua alguns pontos para sobreviver aos primeiros andares. Você pode guardar o resto: ao escolher uma classe, ela passa a dar bônus nos atributos dela a cada nível, e aí os pontos rendem mais onde você quiser.</div>` : ''}
    ${h.cls === 'aprendiz' && !first ? `<div class="hint">Dica: pontos podem ser guardados. Cada classe dá bônus automáticos nos atributos dela a cada nível (por exemplo, Mago ganha INT e DES).</div>` : ''}
    ${(() => { const jb = jobBonusText(h); return jb ? `<div class="note">Bônus de classe: ${jb}</div>` : ''; })()}
    <div class="pts">Pontos de atributo <b>${h.statPts}</b></div>
    <div class="stats">${STATS.map((k) => {
      const c = statCost(h.base[k]);
      const bonus = s[k] - h.base[k];
      return `<div class="stat"><span class="nm">${STAT_NAMES[k]}</span><span class="v">${h.base[k]}${bonus ? `<em>+${bonus}</em>` : ''}</span><span class="ds">${STAT_DESC[k]}</span><span class="cost" title="custo">${c}</span><button class="plus" data-k="${k}" aria-label="Aumentar ${STAT_NAMES[k]}" ${h.statPts < c || h.base[k] >= 99 ? 'disabled' : ''}>${ICON.plus}</button></div>`;
    }).join('')}</div>
    <div class="derived">
      <div><span>Ataque</span><b>${d.atk}</b></div><div><span>Ataque mágico</span><b>${d.matk}</b></div>
      <div><span>Defesa</span><b>${d.def}</b></div><div><span>Defesa mágica</span><b>${d.mdef}</b></div>
      <div><span>Precisão</span><b>${d.hit}</b></div><div><span>Esquiva</span><b>${d.flee}</b></div>
      <div><span>Crítico</span><b>${d.crit.toFixed(1)}%</b></div><div><span>Velocidade</span><b>${Math.round(d.speed)}</b></div>
      <div><span>Alcance</span><b>${d.range}</b></div><div><span>Elemento</span><b>${ELEMENTS[d.el].name}</b></div>
      <div><span>Experiência</span><b>${h.lv >= Game.levelCap() ? 'limite ' + Game.levelCap() : Math.floor(h.xp / xpToNext(h.lv) * 100) + '%'}</b></div><div><span>Abates</span><b>${h.kills}</b></div>
    </div>`;
  el.querySelectorAll('.plus').forEach((b) => b.onclick = () => { Game.raiseStat(b.dataset.k); Audio.play('click'); renderStats(el, first); G.dirty = true; });
}

function renderSkills(el) {
  const h = G.state.hero;
  const lin = Game.lineage(h.cls);
  const co = Game.classOptions();
  let html = `<div class="pts">Pontos de habilidade <b>${h.skillPts}</b></div>`;
  for (const c of [...lin].reverse()) {
    html += `<div class="section">${CLASSES[c].name}</div><div class="list">`;
    for (const id of CLASSES[c].skills) {
      const sk = SKILLS[id];
      const l = h.skills[id] || 0;
      const active = sk.target !== 'passive';
      const pips = Array.from({ length: sk.max }, (_, i) => `<i class="${i < l ? 'on' : ''}"></i>`).join('');
      html += `<div class="skillrow ${l ? '' : 'unlearned'}"><div class="ic">${sk.icon}</div><div class="info"><strong>${esc(sk.name)}</strong><span class="pips">${pips}</span>${active ? '' : '<span class="tag">passiva</span>'}
        <small>${esc(sk.desc(Math.max(1, l)))}${active ? ` Custa ${sk.sp(Math.max(1, l))} SP.` : ''}</small></div>
        <div class="btns">${l < sk.max ? `<button class="up" data-up="${id}" ${h.skillPts ? '' : 'disabled style="opacity:.3"'}>${l ? 'Melhorar' : 'Aprender'}</button>` : ''}
        ${active && l ? `<button class="pin ${h.bar.includes(id) ? 'on' : ''}" data-pin="${id}">${h.bar.includes(id) ? 'Na barra' : 'Pôr na barra'}</button>` : ''}</div></div>`;
    }
    html += '</div>';
  }
  if (co.opts.length) html += `<p class="note" style="margin-top:14px">Próxima classe no nível ${co.need}, na Guilda das Classes.</p>`;
  el.innerHTML = html;
  el.querySelectorAll('[data-up]').forEach((b) => b.onclick = () => { if (Game.learnSkill(b.dataset.up)) { Audio.play('click'); renderSkills(el); G.dirty = true; } });
  el.querySelectorAll('[data-pin]').forEach((b) => b.onclick = () => { Game.toggleBar(b.dataset.pin); renderSkills(el); G.dirty = true; });
}

function renderEquip(el) {
  const h = G.state.hero;
  const names = { weapon: 'Arma', armor: 'Armadura', acc: 'Acessório' };
  el.innerHTML = `<div class="list">${Object.entries(names).map(([slot, n]) => {
    const it = h.equip[slot];
    if (!it) return `<div class="row"><div class="info"><strong style="color:var(--parch-dim)">${n}: nada equipado</strong><small>Escolha um item na mochila</small></div></div>`;
    return `<button class="row eq" data-u="${it.uid}"><img src="${itemIconURL(it)}"><div class="info"><strong style="color:${itemColor(it)}">${esc(itemName(it))}</strong><small>${esc(itemDesc(it).slice(0, 2).join(' · '))}</small></div><div class="side">${n}</div></button>`;
  }).join('')}</div>`;
  el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => itemSheet(Number(b.dataset.u), 'equip', () => heroSheet('equip')));
}

// ---------------- Mochila / itens ----------------
export function itemRow(it, side = '', extra = '') {
  const d = itemDef(it);
  const q = isStack(it) && it.qty > 1 ? ` ×${it.qty}` : '';
  return `<button class="row ${extra}" data-u="${it.uid}"><img src="${itemIconURL(it)}"><div class="info"><strong style="color:${itemColor(it)}">${esc(itemName(it))}${q}</strong><small>${esc(itemDesc(it)[0] || '')}</small></div><div class="side">${side}</div></button>`;
}

function sortInv(list) {
  const order = { use: 0, card: 1, weapon: 2, armor: 3, acc: 4, mat: 5 };
  return [...list].sort((a, b) => order[itemDef(a).kind] - order[itemDef(b).kind] || itemName(a).localeCompare(itemName(b)));
}

export function bagSheet() {
  const h = G.state.hero;
  const body = openSheet({
    title: `Mochila <small>${h.inv.length} de 30</small>`,
    html: h.inv.length ? `<div class="list">${sortInv(h.inv).map((it) => itemRow(it)).join('')}</div>` : `<div class="empty-msg">A mochila está vazia. Itens que você pegar aparecem aqui.</div>`,
  });
  body.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => itemSheet(Number(b.dataset.u), 'bag', bagSheet));
}

export function itemSheet(u, where, back) {
  const h = G.state.hero;
  let it = where === 'equip' ? Object.values(h.equip).find((e) => e && e.uid === u) : Game.findInv(u);
  if (!it) { back && back(); return; }
  const d = itemDef(it);
  const inDungeon = G.state.mode === 'dungeon';
  const acts = [];
  if (where === 'equip') acts.push(['unequip', 'Desequipar']);
  else {
    if (d.kind === 'use' && !(G.state.mode === 'town' && (d.teleport || d.recall))) acts.push(['use', 'Usar', 'primary']);
    if (isEquip(it)) acts.push(['equip', 'Equipar', 'primary']);
    if (d.kind === 'card') acts.push(['card', 'Encaixar', 'primary']);
    if (inDungeon) acts.push(['drop', 'Largar', 'danger']);
  }
  // comparação
  let cmp = '';
  if (isEquip(it) && where !== 'equip') {
    const cur = h.equip[d.kind];
    cmp = cur ? `<p class="cmp">Equipado agora: ${esc(itemName(cur))}</p>` : '';
  }
  openSheet({
    title: '', center: true,
    html: `<div class="detail"><div class="art"><img src="${itemIconURL(it)}"></div><h4 style="color:${itemColor(it)}">${esc(itemName(it))}${isStack(it) && it.qty > 1 ? ` ×${it.qty}` : ''}</h4>
      ${itemDesc(it).map((l) => `<p>${esc(l)}</p>`).join('')}${cmp}
      <div class="actions2">${acts.map(([a, n, c]) => `<button class="btn ${c || ''}" data-a="${a}">${n}</button>`).join('')}<button class="btn" data-a="back">Voltar</button></div></div>`,
    mount(body) {
      body.querySelectorAll('[data-a]').forEach((b) => b.onclick = () => {
        const a = b.dataset.a;
        if (a === 'back') { back ? back() : closeSheet(); return; }
        if (a === 'use') { closeSheet(true); Game.useItem(u); handlers.afterAction && handlers.afterAction(); if (G.state.mode === 'town') { renderTown(); bagSheet(); } return; }
        if (a === 'equip') { Game.equipItem(u); back ? back() : closeSheet(); return; }
        if (a === 'unequip') { Game.unequip(d.kind); back ? back() : closeSheet(); return; }
        if (a === 'drop') { Game.dropItem(u); closeSheet(); return; }
        if (a === 'card') { cardTargetSheet(u, back); return; }
      });
    },
  });
}

function cardTargetSheet(cardUid, back) {
  const h = G.state.hero;
  const card = Game.findInv(cardUid);
  const cd = itemDef(card);
  const opts = [...Object.values(h.equip).filter(Boolean), ...h.inv].filter((e) => isEquip(e) && itemDef(e).kind === cd.slot && (e.cards || []).length < e.slots);
  const body = openSheet({
    title: `Encaixar ${esc(cd.name)}`,
    html: `<p class="note">Escolha um equipamento com espaço livre. A carta não sai depois de encaixada.</p>` +
      (opts.length ? `<div class="list">${opts.map((e) => itemRow(e, `${(e.cards || []).length}/${e.slots}`)).join('')}</div>` : `<div class="empty-msg">Nenhum equipamento deste tipo tem espaço livre para cartas.</div>`),
  });
  body.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
    if (Game.insertCard(cardUid, Number(b.dataset.u))) { toast('Carta encaixada! ✨'); back ? back() : closeSheet(); }
  });
}

// ---------------- Loja ----------------
function shopSheet() {
  const meta = G.state.meta;
  const body = openSheet({
    title: `Empório ${purse()}`,
    html: `<div class="list">${SHOP_ITEMS.map((id) => { const it = makeItem(id); return itemRow(it, `<span class="price">${fmt(buyPrice(it, G.d))} z</span>`); }).join('')}</div>`,
  });
  body.querySelectorAll('[data-u]').forEach((b, i) => b.onclick = () => {
    const err = Game.buy(SHOP_ITEMS[i]);
    if (err) toast(err); else { toast(`Comprou ${ITEMS[SHOP_ITEMS[i]].name}`, 900); shopSheet(); renderTown(); }
  });
}

// ---------------- Ferreiro ----------------
function smithSheet(tab = 'refine') {
  const h = G.state.hero, meta = G.state.meta;
  const tabs = [['refine', 'Refinar'], ['buy', 'Comprar'], ['sell', 'Vender']];
  const body = openSheet({
    title: `Forja ${purse()}`,
    html: `<div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div id="smith"></div>`,
    mount(b) { b.querySelectorAll('.tab').forEach((t) => t.onclick = () => smithSheet(t.dataset.t)); },
  });
  const el = body.querySelector('#smith');
  if (tab === 'refine') {
    const frags = h.inv.find((i) => i.id === 'fragmento')?.qty || 0;
    const eqs = [...Object.entries(h.equip).filter(([, e]) => e).map(([, e]) => ({ it: e, where: 'equip' })), ...h.inv.filter((i) => ['weapon', 'armor'].includes(itemDef(i).kind)).map((it) => ({ it, where: 'bag' }))]
      .filter(({ it }) => ['weapon', 'armor'].includes(itemDef(it).kind));
    el.innerHTML = `<div class="pts">Fragmentos Rúnicos <b>${frags}</b></div><p class="note">Refinar até +4 é seguro. A partir daí, uma falha destrói o item e as cartas nele.</p>` +
      (eqs.length ? `<div class="list">${eqs.map(({ it, where }) => { const inf = Game.refineInfo(it); return itemRow(it, inf.max ? 'Máx.' : `<span style="color:${inf.safe ? 'var(--good)' : inf.rate >= 50 ? 'var(--gold)' : 'var(--bad)'}">${inf.rate}%</span><br><span class="price">${fmt(inf.cost)} z</span>`, where === 'equip' ? 'eq' : '').replace('class="row', `data-w="${where}" class="row`); }).join('')}</div>` : `<div class="empty-msg">Você não tem armas nem armaduras para refinar.</div>`);
    el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
      const u = Number(b.dataset.u), where = b.dataset.w;
      const it = where === 'equip' ? Object.values(h.equip).find((e) => e && e.uid === u) : Game.findInv(u);
      const inf = Game.refineInfo(it);
      if (inf.max) return;
      const go = () => { const r = Game.refine(u, where); toast((r.ok ? '✨ ' : r.ok === false ? '💥 ' : '') + esc(r.msg), 2200); smithSheet('refine'); renderTown(); };
      if (!inf.safe) confirmSheet(`Refinar para +${inf.next}?`, `Chance de sucesso: <b>${inf.rate}%</b>.<br>Se falhar, <b style="color:var(--bad)">${esc(itemName(it))}</b> será destruído, com as cartas.`, 'Refinar', go, () => smithSheet('refine'));
      else go();
    });
  }
  if (tab === 'buy') {
    const gear = Game.shopGear();
    el.innerHTML = `<div class="list">${gear.map((g) => { const it = makeItem(g.id); return itemRow(it, `<span class="price">${fmt(buyPrice(it, G.d))} z</span>`); }).join('')}</div><p class="note" style="margin-top:10px">O estoque melhora conforme seu herói desce mais fundo. Itens da forja não têm espaço para cartas.</p>`;
    el.querySelectorAll('[data-u]').forEach((b, i) => b.onclick = () => { const err = Game.buy(gear[i].id); if (err) toast(err); else { toast('Comprado!', 900); smithSheet('buy'); renderTown(); } });
  }
  if (tab === 'sell') {
    const inv = sortInv(h.inv);
    el.innerHTML = inv.length ? `<div class="list">${inv.map((it) => itemRow(it, `<span class="price">${fmt(sellPrice(it, G.d) * (it.qty || 1))} z</span>`)).join('')}</div>` : `<div class="empty-msg">A mochila está vazia.</div>`;
    el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
      const it = Game.findInv(Number(b.dataset.u));
      const sell = () => { const p = Game.sell(it.uid); toast(`+${fmt(p)} z`, 900); smithSheet('sell'); renderTown(); };
      if (itemDef(it).kind === 'card' || (it.cards || []).length || (it.refine || 0) >= 5) confirmSheet('Vender?', `Vender <b>${esc(itemName(it))}</b>?`, 'Vender', sell, () => smithSheet('sell'));
      else sell();
    });
  }
}

function confirmSheet(title, msg, ok, onOk, onCancel) {
  openSheet({ title, center: true, html: `<p style="line-height:1.5;font-size:16px;margin:0">${msg}</p><div class="actions2"><button class="btn" data-a="no">Cancelar</button><button class="btn primary" data-a="ok">${ok}</button></div>`,
    mount(b) { b.querySelector('[data-a=ok]').onclick = () => { closeSheet(true); onOk(); }; b.querySelector('[data-a=no]').onclick = () => { onCancel ? onCancel() : closeSheet(); }; } });
}
export { confirmSheet };

// ---------------- Armazém ----------------
function storageSheet(tab = 'store') {
  const h = G.state.hero, meta = G.state.meta;
  const tabs = [['store', `Armazém (${meta.storage.length})`], ['bag', `Mochila (${h.inv.length})`]];
  const body = openSheet({
    title: 'Armazém',
    html: `<div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div id="st"></div>`,
    mount(b) { b.querySelectorAll('.tab').forEach((t) => t.onclick = () => storageSheet(t.dataset.t)); },
  });
  const el = body.querySelector('#st');
  const list = tab === 'store' ? sortInv(meta.storage) : sortInv(h.inv);
  el.innerHTML = `<p class="note">${tab === 'store' ? 'Itens guardados aqui continuam mesmo se o herói cair. Toque para pegar.' : 'Toque em um item para guardar.'}</p>` +
    (list.length ? `<div class="list">${list.map((it) => itemRow(it, tab === 'store' ? 'Pegar' : 'Guardar')).join('')}</div>` : `<div class="empty-msg">${tab === 'store' ? 'Nada guardado ainda.' : 'A mochila está vazia.'}</div>`);
  el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
    const err = tab === 'store' ? Game.withdraw(Number(b.dataset.u)) : Game.deposit(Number(b.dataset.u));
    if (err) toast(err);
    storageSheet(tab); renderTown();
  });
}

// ---------------- Classes ----------------
function classSheet() {
  const h = G.state.hero;
  const co = Game.classOptions();
  const lv = co.need;
  let html;
  if (!co.opts.length) html = `<div class="empty-msg">${CLASSES[h.cls].name} é uma classe avançada. Não há outra evolução.</div>`;
  else {
    const why = !co.lvOk ? `Volte no nível ${lv}. Seu nível atual é ${h.lv}.`
      : co.pts ? `Antes de mudar de classe, gaste todos os pontos de habilidade de ${CLASSES[h.cls].name}. Faltam ${co.pts}.`
      : 'Escolha seu caminho. A escolha é permanente.';
    html = (co.lvOk && co.pts ? `<div class="hint">${why}</div><button class="btn" id="go-skills" style="margin-bottom:12px">Abrir habilidades</button>` : `<p class="note">${why}</p>`) + `<div class="classpick">` +
      co.opts.map((c) => `<button class="classcard frame" data-c="${c.id}" ${co.ok ? '' : 'style="opacity:.6"'}><img src="${heroURL(c.id, CLASS_WEAPON[c.id])}" alt=""><div><strong>${c.name}</strong><small>${esc(c.desc)}</small><em>${c.skills.map((s) => SKILLS[s].name).join(', ')}</em><small style="color:var(--good)">Bônus por nível: ${Object.entries(JOB_BONUS[c.id] || {}).map(([k, v]) => `${STAT_NAMES[k]} ${v >= 0.5 ? '++' : '+'}`).join(' ')}</small></div></button>`).join('') + '</div>';
  }
  const body = openSheet({ title: 'Guilda das Classes', html });
  const gs = body.querySelector('#go-skills');
  if (gs) gs.onclick = () => heroSheet('skills');
  body.querySelectorAll('[data-c]').forEach((b) => b.onclick = () => {
    if (!co.lvOk) { toast(`Disponível no nível ${lv}`); return; }
    if (co.pts) { toast(`Gaste os ${co.pts} pontos de habilidade antes`); return; }
    const c = CLASSES[b.dataset.c];
    confirmSheet(`Tornar-se ${c.name}?`, esc(c.desc), 'Confirmar', () => { Game.changeClass(b.dataset.c); toast(`Agora você é ${c.name}!`); renderTown(); heroSheet('skills'); }, classSheet);
  });
}

// ---------------- Santuário ----------------
function legacySheet() {
  const meta = G.state.meta;
  const body = openSheet({
    title: `Santuário ${purse()}`,
    html: `<p class="note">As bênçãos valem para todos os heróis, inclusive os próximos.</p><div class="list">${Object.entries(LEGACY).map(([k, L]) => {
      const lv = meta.legacy[k] || 0;
      const max = lv >= L.max;
      return `<div class="row legacy-row"><div class="info"><strong>${L.name}<span class="pips">${Array.from({ length: L.max }, (_, i) => `<i class="${i < lv ? 'on' : ''}"></i>`).join('')}</span></strong><small style="white-space:normal">${L.desc}</small></div><div class="side">${max ? 'Completa' : `<button class="btn small" data-k="${k}"><span class="price">${fmt(legacyCost(k, lv))} z</span></button>`}</div></div>`;
    }).join('')}</div>
    <div class="section">Ritual do recomeço</div>
    <div class="row"><div class="info"><strong>Redistribuir atributos</strong><small style="white-space:normal">Devolve todos os pontos de atributo do herói atual.</small></div><div class="side"><button class="btn small" id="reset"><span class="price">${fmt(Game.resetStatsCost())} z</span></button></div></div>`,
  });
  body.querySelectorAll('[data-k]').forEach((b) => b.onclick = () => { const e = Game.buyLegacy(b.dataset.k); if (e) toast(e); else { toast('Bênção recebida! ✨'); legacySheet(); renderTown(); } });
  body.querySelector('#reset').onclick = () => confirmSheet('Redistribuir?', 'Todos os pontos de atributo voltam para você distribuir de novo.', 'Confirmar', () => { const e = Game.resetStats(); if (e) toast(e); else { renderTown(); heroSheet('stats'); } }, legacySheet);
}

// ---------------- Menu ----------------
export function menuSheet() {
  const st = G.state;
  const s = st.settings;
  const inDungeon = st.mode === 'dungeon';
  const body = openSheet({
    title: 'Opções',
    html: `<div class="list">
      <button class="row" data-a="sound"><div class="info"><strong>Som</strong></div><div class="side">${s.sound ? 'Ligado' : 'Desligado'}</div></button>
      <button class="row" data-a="vib"><div class="info"><strong>Vibração</strong></div><div class="side">${s.vibrate ? 'Ligada' : 'Desligada'}</div></button>
      <button class="row" data-a="wiki"><div class="info"><strong>📖 Wiki</strong><small>Atributos, classes, habilidades, elementos, monstros</small></div><div class="side">›</div></button>
      <button class="row" data-a="help"><div class="info"><strong>Como jogar</strong></div><div class="side">›</div></button>
      <button class="row" data-a="dev"><div class="info"><strong>Desenvolvedor</strong><small>Andar, nível, classe, cidade...</small></div><div class="side">›</div></button>
      <button class="row" data-a="credits"><div class="info"><strong>Créditos da arte</strong></div><div class="side">›</div></button>
      ${st.meta.graveyard?.length ? `<button class="row" data-a="grave"><div class="info"><strong>Memorial</strong></div><div class="side">›</div></button>` : ''}
      ${inDungeon ? '' : `<button class="row" data-a="wipe"><div class="info"><strong style="color:var(--bad)">Apagar todo o progresso</strong></div><div class="side">›</div></button>`}
    </div><p class="foot">O jogo salva sozinho a cada passo e se atualiza ao abrir.<br>Versão ${window.__WEB_VERSION || 'local'}</p>`,
  });
  body.querySelectorAll('[data-a]').forEach((b) => b.onclick = () => {
    const a = b.dataset.a;
    if (a === 'sound') { s.sound = !s.sound; Audio.setEnabled(s.sound); Game.save(); menuSheet(); }
    if (a === 'vib') { s.vibrate = !s.vibrate; Game.save(); menuSheet(); }
    if (a === 'help') helpSheet();
    if (a === 'credits') creditsSheet();
    if (a === 'wiki') wikiSheet();
    if (a === 'dev') devSheet();
    if (a === 'grave') graveSheet();
    if (a === 'wipe') confirmSheet('Apagar tudo?', 'Herói, banco, armazém e bênçãos serão apagados para sempre.', 'Apagar', () => { Game.wipeSave(); refresh('screen'); });
  });
}

// ---------------- Desenvolvedor (testes) ----------------
export function devSheet() {
  const st = G.state, h = st.hero;
  const inD = st.mode === 'dungeon';
  const cls = Object.entries(CLASSES).map(([id, c]) => `<button class="btn small ${h.cls === id ? 'primary' : ''}" data-cls="${id}" style="padding:9px 6px;font-size:13px">${esc(c.name)}</button>`).join('');
  const updLog = (() => { try { return JSON.parse(localStorage.getItem('upd_log') || '[]'); } catch (_) { return []; } })();
  const body = openSheet({
    title: 'Desenvolvedor',
    html: `<div style="display:grid;gap:12px;font-size:14px">
      <div class="section" style="margin:0">Andar ${inD ? `(agora: ${st.run.floor})` : ''}</div>
      <div style="display:flex;gap:8px"><input id="dv-floor" type="number" min="1" max="99" value="${inD ? st.run.floor + 1 : 1}" class="dv-in"><button class="btn small" id="dv-go">Ir</button></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">${[1, 5, 6, 10, 11, 15, 16, 20, 21, 25].map((f) => `<button class="btn small" data-f="${f}" style="width:auto;padding:8px 12px">${f}</button>`).join('')}</div>
      <div class="section" style="margin:0">Nível (agora: ${h.lv})</div>
      <div style="display:flex;gap:8px"><input id="dv-lv" type="number" min="1" max="99" value="${Math.min(99, h.lv + 5)}" class="dv-in"><button class="btn small" id="dv-setlv">Definir</button></div>
      <div class="section" style="margin:0">Classe</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">${cls}</div>
      <div class="section" style="margin:0">Atalhos</div>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px">
        ${inD ? '<button class="btn small" data-x="town">Voltar à cidade</button>' : ''}
        <button class="btn small" data-x="heal">Curar tudo</button>
        <button class="btn small" data-x="zeny">+10.000 zeny</button>
        <button class="btn small" data-x="pts">+10 pontos</button>
        ${inD ? '<button class="btn small" data-x="reveal">Revelar andar</button><button class="btn small" data-x="kill">Matar monstros</button>' : ''}
        <button class="btn small ${st.settings.god ? 'primary' : ''}" data-x="god">Invencível: ${st.settings.god ? 'sim' : 'não'}</button>
      </div>
      <div class="section" style="margin:0">Atualização (versão ${window.__WEB_VERSION || '?'})</div>
      <button class="btn small" id="dv-upd">Verificar atualização agora</button>
      <div style="font:12px/1.4 monospace;color:#b8b4d8;white-space:pre-wrap;max-height:160px;overflow:auto;background:rgba(0,0,0,.25);border-radius:10px;padding:8px">${esc(updLog.slice(-14).join('\n') || 'sem registros ainda')}</div>
    </div>`,
  });
  const done = (msg, enteredDungeon) => {
    closeSheet(true);
    if (msg) toast(msg, 1400);
    refresh('screen');
    if (enteredDungeon && handlers.onEnterDungeon) handlers.onEnterDungeon();
    else handlers.afterAction && handlers.afterAction();
  };
  const goF = (f) => { Game.Dev.goFloor(f); done(`Andar ${f}`, true); };
  body.querySelector('#dv-go').onclick = () => goF(parseInt(body.querySelector('#dv-floor').value, 10) || 1);
  body.querySelectorAll('[data-f]').forEach((b) => b.onclick = () => goF(+b.dataset.f));
  body.querySelector('#dv-setlv').onclick = () => { const v = parseInt(body.querySelector('#dv-lv').value, 10) || 1; Game.Dev.setLevel(v); done(`Nível ${G.state.hero.lv}`); };
  body.querySelectorAll('[data-cls]').forEach((b) => b.onclick = () => { Game.Dev.setClass(b.dataset.cls); done(CLASSES[b.dataset.cls].name); });
  body.querySelectorAll('[data-x]').forEach((b) => b.onclick = () => {
    const x = b.dataset.x;
    if (x === 'town') { Game.Dev.town(); return done('Cidade'); }
    if (x === 'heal') Game.Dev.heal();
    if (x === 'zeny') Game.Dev.zeny(10000);
    if (x === 'pts') Game.Dev.pts(10);
    if (x === 'reveal') Game.Dev.reveal();
    if (x === 'kill') Game.Dev.killAll();
    if (x === 'god') { Game.Dev.god(!G.state.settings.god); return devSheet(); }
    done('Feito');
  });
  body.querySelector('#dv-upd').onclick = () => { closeSheet(true); handlers.checkUpdate && handlers.checkUpdate(); };
}

function creditsSheet() {
  openSheet({
    title: 'Créditos da arte',
    html: `<div style="font-size:13px;line-height:1.5;color:#d8d5ee">
    <p><b>Heróis</b>: Universal LPC Spritesheet Character Generator (Liberated Pixel Cup). Licenças CC-BY-SA 3.0, GPL 3.0, OGA-BY 3.0 e CC0, conforme cada peça. Grimório do Bruxo desenhado para este jogo.</p>
    <p><b>Monstros</b>: Dungeon Crawl Stone Soup tiles (CC0), por diversos artistas da comunidade do DCSS. Algumas cores foram ajustadas.</p>
    <p><b>Cenário</b>: Liberated Pixel Cup base assets, por Lanea Zimmerman (Sharm) e Hugh Spectrum (CC-BY-SA 3.0 / GPL 3.0).</p>
    <p style="font-weight:800;margin-top:14px">Autores das peças dos heróis</p>
    <p style="color:#b8b4d8;font-size:12px">${LPC_CREDITS.map(esc).join(', ')}</p></div>`,
  });
}

function helpSheet() {
  openSheet({
    title: 'Como jogar',
    html: `<div style="font-size:13.5px;line-height:1.55;color:#d8d5ee">
    <p><b>Toque</b> em um lugar para andar até lá. Toque em um monstro para atacar (ou ir até ele). Cada ação gasta um turno: os monstros só agem quando você age.</p>
    <p><b>Explorar</b> anda sozinho até achar algo. <b>Esperar</b> passa um turno; segure parado para recuperar HP e SP mais rápido.</p>
    <p><b>Habilidades</b>: toque no botão e depois no alvo. Toque de novo no botão para mirar no inimigo mais próximo.</p>
    <p><b>Atributos</b>: cada nível dá pontos. Valores altos custam mais pontos.</p>
    <p><b>Classes</b>: no nível ${CLASS_LV[1]} você escolhe uma classe; no ${CLASS_LV[2]}, a classe avançada. Fale com o Mestre de Classes na cidade.</p>
    <p><b>Cartas</b> caem raramente dos monstros e encaixam nos slots [ ] dos equipamentos.</p>
    <p><b>Refino</b> com Fragmentos Rúnicos no Ferreiro. Acima de +4, uma falha quebra o item!</p>
    <p><b>Chefes</b> a cada 5 andares. Quadrados vermelhos no chão avisam um golpe forte: saia de cima!</p>
    <p>Se o herói cair, ele se vai. Zeny no banco, o armazém e as bênçãos ficam.</p></div>`,
  });
}
