// Regras: atributos derivados, dano, itens, preços
import { CLASSES, SKILLS, ITEMS, WTYPES, MONSTERS, elemMult, STAT_NAMES, ELEMENTS, RACES, LEGACY, JOB_BONUS, baseCls, MAX_TIER, TRANS_MONSTERS, TRANS_HARD, OFFHAND } from './data.js';
import { rnd, chance, clamp, weighted, pick, uid } from './util.js';

export const STATS = ['str', 'agi', 'vit', 'int', 'dex', 'luk'];
// XP por nível: a partir do 30 a curva fica 25% mais íngreme (aos poucos até o 40); renascidos precisam de +50%
export const xpToNext = (lv, h) => Math.floor(10 * Math.pow(lv, 1.7) * (1 + 0.25 * Math.min(1, Math.max(0, (lv - 30) / 10))) * (h && h.reborn ? 1.5 : 1));
export const REBORN_STAT_BONUS = 40;
export const statCost = (v) => 1 + Math.floor((v - 1) / 10);
export const statPtsForLevel = (lv) => 3 + Math.floor(lv / 15);
const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII'];

// ---------------- Itens ----------------
export function itemDef(it) {
  if (!it) return null;
  if (it.id === 'card') {
    const m = MONSTERS[it.mon];
    return { kind: 'card', name: 'Carta ' + m.name, slot: m.card.slot, mods: m.card.mods, mon: it.mon, boss: !!m.boss, power: m.card.power };
  }
  const base = ITEMS[it.id];
  if (base.kind === 'acc') return { ...base, tier: it.tier || 1, mods: { [base.stat]: (it.tier || 1) + 1 } };
  return base;
}

export const isStack = (it) => { const d = itemDef(it); return d.kind === 'use' || d.kind === 'mat'; };
export const EQUIP_KINDS = ['weapon', 'armor', 'acc', 'head', 'shield'];
export const isEquip = (it) => EQUIP_KINDS.includes(itemDef(it).kind);

export function itemName(it) {
  const d = itemDef(it);
  let n = d.name;
  if (d.kind === 'acc') n += ' ' + ROMAN[d.tier];
  if (it.refine) n = `+${it.refine} ${n}`;
  if (isEquip(it) && it.slots) n += ` [${it.slots}]`;
  return n;
}

export function itemColor(it) {
  const d = itemDef(it);
  if (d.kind === 'card') return d.boss ? '#ffb84a' : '#ffd86b';
  if (d.kind === 'use' || d.kind === 'mat') return '#e8eaf2';
  const t = d.tier || 1;
  return ['#e8eaf2', '#e8eaf2', '#9fe08a', '#7ab8ff', '#c48aff', '#ffb84a', '#ff6a8a', '#ff5ae0'][t] || '#ff5ae0';
}

export function modsText(mods) {
  const out = [];
  for (const [k, v] of Object.entries(mods || {})) {
    if (STAT_NAMES[k]) out.push(`${STAT_NAMES[k]} +${v}`);
    else if (k === 'hp') out.push(`HP +${v}`);
    else if (k === 'sp') out.push(`SP +${v}`);
    else if (k === 'hpPct') out.push(`HP +${v}%`);
    else if (k === 'spPct') out.push(`SP +${v}%`);
    else if (k === 'atk') out.push(`ATQ +${v}`);
    else if (k === 'atkPct') out.push(`ATQ +${v}%`);
    else if (k === 'matk') out.push(`ATQM +${v}`);
    else if (k === 'matkPct') out.push(`ATQM +${v}%`);
    else if (k === 'def') out.push(`DEF +${v}`);
    else if (k === 'mdef') out.push(`DEFM +${v}`);
    else if (k === 'hit') out.push(`Precisão +${v}`);
    else if (k === 'flee') out.push(`Esquiva ${v > 0 ? '+' : ''}${v}`);
    else if (k === 'crit') out.push(`Crítico +${v}%`);
    else if (k === 'speed') out.push(`Velocidade ${v > 0 ? '+' : ''}${v}`);
    else if (k === 'regenHp') out.push(`Regen. HP +${v}`);
    else if (k === 'lifesteal') out.push(`Roubo de vida ${v}%`);
    else if (k === 'poisonImmune') out.push('Imune a veneno');
    else if (k === 'armorEl') out.push(`Armadura de ${ELEMENTS[v].name}`);
    else if (k === 'weaponEl') out.push(`Arma de ${ELEMENTS[v].name}`);
    else if (k === 'dmgReduce') out.push(`Dano recebido -${v}%`);
    else if (k === 'raceDmg') for (const [r, p] of Object.entries(v)) out.push(`+${p}% dano vs ${RACES[r]}`);
    else if (k === 'revive') out.push(`Revive com ${v * 12}% do HP (1× por andar)`);
    else if (k === 'healBoost') out.push(`Curas e poções +${v}%`);
    else if (k === 'echo') out.push(`${v}% de repetir magias`);
    else if (k === 'thorns') out.push(`Devolve ${v}% do dano corpo a corpo`);
    else if (k === 'castSpeed') out.push(`Conjuração ${v}% mais rápida`);
    else if (k === 'spOnKill') out.push(`+${v}% de SP por abate`);
    else if (k === 'cleave') out.push(`Ataque atinge os vizinhos (${v}%)`);
    else if (k === 'plunder') out.push(`${v}% de pilhagem por abate`);
    else if (k === 'frostbite') out.push(`${v}% de congelar quem te ataca`);
    else if (k === 'freezeImmune') out.push('Imune a congelamento');
    else if (k === 'stoneSkin') out.push(`${v}% de petrificar quem te acerta`);
    else if (k === 'regenHpPct') out.push(`Regen. HP +${v}% do máx.`);
    else if (k === 'rage') out.push(`Fervor de Batalha nv ${v}`);
    else if (k === 'rageUp') out.push(`Fúria de Batalha nv ${v}`);
    else if (k === 'dmgNormal') out.push(`+${v}% de dano em monstros normais`);
    else if (k === 'dmgBoss') out.push(`+${v}% de dano em chefes`);
    else if (k === 'redNormal') out.push(`-${v}% de dano de monstros normais`);
    else if (k === 'redBoss') out.push(`-${v}% de dano de chefes`);
    else if (k === 'pierce') out.push(`Ignora ${v}% da DEF e DEFM`);
    else if (k === 'execute') out.push(`Dano dobrado abaixo de ${v}% do HP`);
    else if (k === 'critDmg') out.push(`Dano crítico +${v}%`);
    else if (k === 'matk') out.push(`ATQM +${v}`);
  }
  return out.join(', ');
}

export function itemDesc(it) {
  const d = itemDef(it);
  const lines = [];
  if (d.kind === 'weapon') {
    const wt = WTYPES[d.wtype];
    lines.push(`${wt.name} · ${wt.hands === 2 ? 'Duas mãos' : 'Uma mão'} · Nível ${d.tier}${wt.range > 1 ? ` · Alcance ${wt.range}` : ''}`);
    lines.push(`ATQ ${weaponAtk(it)}` + (d.matk ? ` · ATQM ${weaponMatk(it)}` : ''));
    if (wt.unarmed) lines.push('Conta como mãos vazias: o Taekwon mantém seus bônus.');
    if (d.el) lines.push(`Elemento: ${ELEMENTS[d.el].name}`);
    const m = modsText({ ...wt.mods, ...(d.mods || {}) });
    if (m) lines.push(m);
  } else if (d.kind === 'armor') {
    lines.push(`Armadura · Nível ${d.tier}`);
    lines.push(`DEF ${armorDef(it)} · DEFM ${d.mdef}`);
    const m = modsText(d.mods);
    if (m) lines.push(m);
  } else if (d.kind === 'head' || d.kind === 'shield') {
    lines.push(`${d.kind === 'head' ? 'Cabeça' : d.cat === 'grimorio' ? 'Grimório (mão esquerda)' : 'Escudo (mão esquerda)'} · Nível ${d.tier}`);
    lines.push(`DEF ${armorDef(it)} · DEFM ${d.mdef}${d.matk ? ` · ATQM +${d.matk}` : ''}`);
    const m = modsText(d.mods);
    if (m) lines.push(m);
  } else if (d.kind === 'acc') {
    lines.push('Acessório · ' + modsText(d.mods));
  } else if (d.kind === 'card') {
    const slotN = { weapon: 'arma', armor: 'armadura', acc: 'acessório', head: 'cabeça', shield: 'escudo' }[d.slot];
    lines.push(`Encaixa em ${slotN}.${d.boss ? ' ★ Carta de chefe' : ''}`);
    lines.push(modsText(d.mods));
    if (d.power) lines.push('★ ' + d.power);
  } else if (d.kind === 'use') {
    if (d.heal) lines.push(`Recupera ${d.heal} HP.`);
    if (d.sp) lines.push(`Recupera ${d.sp} SP.`);
    if (d.cure) lines.push('Cura envenenamento e queimadura.');
    if (d.teleport) lines.push('Teleporta para um lugar aleatório do andar.');
    if (d.recall) lines.push('Volta para a cidade levando tudo.');
  } else if (d.kind === 'mat') {
    lines.push('Usado pelo ferreiro para refinar equipamentos.');
  }
  if (it.bossDrop) lines.push(`★ Tesouro de ${it.bossDrop}`);
  if (isEquip(it) && it.slots) {
    const cards = it.cards || [];
    const parts = [];
    for (let i = 0; i < it.slots; i++) parts.push(cards[i] ? itemDef({ id: 'card', mon: cards[i] }).name : '— vazio —');
    lines.push('Slots: ' + parts.join(' | '));
  }
  return lines;
}

// armas de 2 mãos rendem mais; as de 1 mão deixam a outra mão livre (escudo ou segunda arma)
export const handsMul = (d) => (WTYPES[d.wtype] && WTYPES[d.wtype].hands === 2 ? 1.1 : 0.68);
export const weaponAtk = (it) => { const d = itemDef(it); return Math.floor((d.atk * (1 + 0.08 * (it.refine || 0)) + (it.refine || 0) * 2) * handsMul(d)); };
export const weaponMatk = (it) => { const d = itemDef(it); return Math.floor((d.matk || 0) * (1 + 0.08 * (it.refine || 0)) * handsMul(d)); };
export const armorDef = (it) => { const d = itemDef(it); return d.def + (it.refine || 0) * 2; };

export function makeItem(id, extra = {}) {
  const it = { uid: uid(), id, ...extra };
  const d = itemDef(it);
  if (d.kind === 'use' || d.kind === 'mat') it.qty = it.qty || 1;
  if (EQUIP_KINDS.includes(d.kind)) { it.refine = it.refine || 0; it.slots = it.slots || 0; it.cards = it.cards || []; }
  return it;
}

export function makeCard(mon) { return { uid: uid(), id: 'card', mon }; }

export function randomEquip(tier, kind) {
  tier = clamp(tier, 1, MAX_TIER);
  kind = kind || weighted([['weapon', 36], ['armor', 20], ['head', 14], ['shield', 12], ['acc', 18]]);
  if (kind === 'acc') {
    const ids = Object.keys(ITEMS).filter((k) => ITEMS[k].kind === 'acc');
    return makeItem(pick(ids), { tier, slots: weighted([[0, 65], [1, 35]]) });
  }
  const pool = Object.keys(ITEMS).filter((k) => ITEMS[k].kind === kind && ITEMS[k].tier === tier);
  const fallback = Object.keys(ITEMS).filter((k) => ITEMS[k].kind === kind && ITEMS[k].tier <= tier);
  const id = pick(pool.length ? pool : fallback);
  const slots = kind === 'weapon' ? weighted([[0, 45], [1, 33], [2, 16], [3, 6]]) : weighted([[0, 60], [1, 40]]); // só a arma passa de 1 slot
  const refine = chance(15) ? rnd(1, 3) : 0;
  return makeItem(id, { slots, refine });
}

export function equipValue(it) {
  const d = itemDef(it);
  if (d.kind === 'card') return d.boss ? 6000 : 400;
  if (d.kind === 'use' || d.kind === 'mat') return d.price;
  const t = d.tier || 1;
  return Math.floor((60 + 140 * t * t) * (1 + (it.slots || 0) * 0.5) * (1 + (it.refine || 0) * 0.35));
}

export const sellPrice = (it, d) => Math.floor(equipValue(it) * (isEquip(it) || itemDef(it).kind === 'card' ? 0.4 : 0.5) * (1 + (d?.mods?.zenyPct || 0) / 100));
export const buyPrice = (it, d) => Math.ceil(equipValue(it) * (isEquip(it) ? 1.6 : 1) * (1 - (d?.mods?.discount || 0) / 100));

// ---------------- Atributos derivados ----------------
function scaleMods(mods, k) {
  const out = {};
  for (const [key, v] of Object.entries(mods)) out[key] = typeof v === 'number' && !['freezeImmune', 'poisonImmune'].includes(key) ? Math.round(v * k * 10) / 10 : v;
  return out;
}
function addMods(acc, mods) {
  if (!mods) return;
  for (const [k, v] of Object.entries(mods)) {
    if (typeof v === 'number') acc[k] = (acc[k] || 0) + v;
    else if (typeof v === 'string') acc[k] = v;
    else if (typeof v === 'object') {
      acc[k] = acc[k] || {};
      for (const [kk, vv] of Object.entries(v)) acc[k][kk] = (acc[k][kk] || 0) + vv;
    }
  }
}

export function equipMods(it) {
  const out = {};
  if (!it) return out;
  const d = itemDef(it);
  if (d.kind === 'weapon') addMods(out, WTYPES[d.wtype].mods);
  addMods(out, d.mods);
  for (const c of it.cards || []) addMods(out, MONSTERS[c].card.mods);
  return out;
}

export function jobBonus(hero) {
  // soma o bônus de cada classe pelo tempo (níveis) passado nela
  const out = {};
  const hist = hero.clsHistory || [{ cls: hero.cls, since: 1 }];
  hist.forEach((h, i) => {
    const until = i + 1 < hist.length ? hist[i + 1].since : hero.lv;
    const lvls = Math.max(0, until - h.since);
    // renascidos: classe Alta = mesmo bônus da original; transcendental = +15%
    const c = CLASSES[h.cls] || {};
    const jb = JOB_BONUS[h.cls] || JOB_BONUS[baseCls(h.cls)] || {};
    const k2 = c.trans ? 1.15 : 1;
    for (const [k, r] of Object.entries(jb)) out[k] = (out[k] || 0) + r * k2 * lvls;
  });
  for (const k of Object.keys(out)) out[k] = Math.floor(out[k]);
  return out;
}

export function derive(hero, meta) {
  const mods = {};
  addMods(mods, jobBonus(hero));
  for (const [id, l] of Object.entries(hero.skills)) {
    const s = SKILLS[id];
    if (s && s.target === 'passive' && l > 0 && s.mods) addMods(mods, s.mods(l));
  }
  for (const slot of ['weapon', 'armor', 'head', 'acc1', 'acc2']) addMods(mods, equipMods(hero.equip[slot]));
  // mão esquerda: escudo/grimório inteiro; uma segunda arma rende 40% do ATQ e dos bônus dela, mas as cartas valem inteiras
  const left = hero.equip.left, ld = left ? itemDef(left) : null;
  if (ld && ld.kind === 'shield') addMods(mods, equipMods(left));
  else if (ld && ld.kind === 'weapon') { addMods(mods, scaleMods(ld.mods || {}, OFFHAND)); for (const c of left.cards || []) addMods(mods, MONSTERS[c].card.mods); }
  for (const b of hero.buffs || []) addMods(mods, b.mods);

  const s = {};
  for (const k of STATS) s[k] = Math.max(1, hero.base[k] + (mods[k] || 0));
  const cls = CLASSES[hero.cls];
  const L = hero.lv;
  const leg = meta?.legacy || {};
  const w = hero.equip.weapon;
  const wd = w ? itemDef(w) : null;
  const wt = wd ? WTYPES[wd.wtype] : null;
  const ranged = !!(wt && wt.ranged);
  const armed = !!(w && !wt.unarmed); // faixas contam como mãos vazias
  const offW = ld && ld.kind === 'weapon' ? left : null;
  const wAtk = (w ? weaponAtk(w) : 0) + (offW ? Math.floor(weaponAtk(offW) * OFFHAND) : 0);
  const wMatk = (w ? weaponMatk(w) : 0) + (offW ? Math.floor(weaponMatk(offW) * OFFHAND) : 0) + (ld && ld.kind === 'shield' ? (ld.matk || 0) : 0);
  const a = hero.equip.armor;

  const d = { stats: s, mods };
  const rb = hero.reborn ? 1.25 : 1; // renascidos: +25% HP e SP
  d.maxHp = Math.floor((50 + L * 12 + s.vit * 8 + L * s.vit * 0.35) * cls.hpMul * rb * (1 + (mods.hpPct || 0) / 100)) + (mods.hp || 0);
  d.maxSp = Math.floor((10 + L * 3 + s.int * 3) * cls.spMul * rb * (1 + (mods.spPct || 0) / 100)) + (mods.sp || 0);
  const main = ranged ? s.dex : s.str, sec = ranged ? s.str : s.dex;
  // à distância rende menos por ponto (o atirador já ganha ataques de graça antes do contato)
  const mainMul = ranged ? 1.45 : 2;
  // lutadores de taekwon ficam mais fortes de mãos vazias conforme sobem de nível
  const bc = baseCls(hero.cls);
  const tkd = !armed && (bc === 'taekwon' || bc === 'mestre_taekwon') ? Math.floor(L * (bc === 'taekwon' ? 1.2 : 0.6)) : 0;
  d.atk = Math.floor((main * mainMul + tkd + Math.pow(Math.floor(main / 10), 2) + Math.floor(sec / 5) + Math.floor(s.luk / 4) + wAtk + (mods.atk || 0) + (armed ? 0 : (mods.unarmedAtk || 0))) * (1 + (mods.atkPct || 0) / 100));
  // ataque à distância "puro" (pedras, kunais arremessadas): sempre usa DES
  d.dexAtk = Math.floor((s.dex * 2 + Math.pow(Math.floor(s.dex / 10), 2) + Math.floor(s.str / 5) + Math.floor(s.luk / 4) + (ranged ? wAtk : 0) + (mods.atk || 0)) * (1 + (mods.atkPct || 0) / 100));
  d.matk = Math.floor((s.int * 2 + Math.pow(Math.floor(s.int / 10), 2) + Math.floor(s.luk / 4) + wMatk + (mods.matk || 0)) * (1 + (mods.matkPct || 0) / 100));
  // Punhos Sagrados (Monge): parte do ATQM soma no ATQ
  if (cls.holyFist) d.atk += Math.floor(d.matk * cls.holyFist);
  // auras reservam parte do SP máximo enquanto ligadas
  const reserve = (hero.buffs || []).reduce((a2, b) => a2 + (b.aura || 0), 0);
  if (reserve) d.maxSp = Math.max(1, Math.floor(d.maxSp * (1 - Math.min(80, reserve) / 100)));
  const hd = hero.equip.head, sh = ld && ld.kind === 'shield' ? left : null;
  d.def = (a ? armorDef(a) : 0) + (hd ? armorDef(hd) : 0) + (sh ? armorDef(sh) : 0) + Math.floor(s.vit / 2) + (mods.def || 0);
  d.mdef = (a ? itemDef(a).mdef : 0) + (hd ? itemDef(hd).mdef : 0) + (sh ? itemDef(sh).mdef : 0) + Math.floor(s.int / 2) + Math.floor(s.vit / 3) + (mods.mdef || 0);
  d.hit = L + s.dex + (mods.hit || 0);
  d.flee = L + Math.floor(s.agi * 1.3 + s.luk / 5) + (mods.flee || 0);
  d.perfectDodge = Math.floor(s.luk / 8);
  d.crit = 1 + s.luk * 0.8 + (mods.crit || 0);
  d.statusResist = Math.min(60, s.luk * 0.6 + s.vit * 0.3); // % de resistência a status
  d.refineLuck = Math.floor(s.luk / 10);
  d.critDmg = (mods.critDmg || 0) * (wd && wd.wtype === 'katar' ? 2 : 1) + s.luk * 0.5; // SOR: +0,5% de dano crítico por ponto
  d.speed = clamp(100 + s.agi * 1.2 + Math.floor(s.dex * 0.3) + (mods.speed || 0), 60, 260);
  d.range = wt ? wt.range : 1;
  d.ranged = ranged;
  d.wtype = armed ? wd.wtype : null;
  d.el = mods.weaponEl || (wd && wd.el) || 'neutro';
  d.armorEl = mods.armorEl || 'neutro';
  d.regenHp = 0.4 + s.vit * 0.08 + L * 0.05 + d.maxHp * (0.2 + (mods.regenHpPct || 0)) / 100 + (mods.regenHp || 0); // como no Ragnarok: quem tem mais HP recupera mais
  d.regenSp = 0.15 + L * 0.02 + s.int * 0.05 + (mods.regenSp || 0);
  d.raceDmg = mods.raceDmg || {};
  d.dmgReduce = mods.dmgReduce || 0;
  d.lifesteal = mods.lifesteal || 0;
  d.race = 'humanoide';
  return d;
}

// ---------------- Monstros ----------------
export function monsterStats(id, floor) {
  const m = MONSTERS[id];
  const extra = floor > 40 ? (floor - 40) * 2 : 0;
  const lv = m.lv + extra;
  const b = m.boss;
  const T = TRANS_MONSTERS.has(id) ? TRANS_HARD : { hp: 1, atk: 1, def: 1 };
  const hp = Math.round((15 + lv * 10 + Math.pow(lv, 1.5) * 1.5) * (m.hpMul || 1) * (b ? 8 : 1) * T.hp);
  const atk = Math.round((3 + lv * 2.6 + Math.pow(lv, 1.5) * 0.35) * 1.12 * (m.atkMul || 1) * (b ? 1.3 : 1) * T.atk);
  return {
    lv, hp, maxHp: hp, atk, matk: Math.round(atk / T.atk * (T.atk > 1 ? 1.12 : 1)), // magia dos mundos novos cresce menos que o ataque físico
    def: Math.round(lv * 1.2 * (m.defMul || 1) * (b ? 1.5 : 1) * T.def),
    mdef: Math.round(lv * 0.8 * (m.mdefMul || 1) * (b ? 1.6 : 1)),
    hit: Math.round(lv * 1.5 + 10),
    flee: Math.round((lv * 1.3 + 5) * (m.fleeMul || 1)),
    crit: b ? 5 : 1, critDmg: 0,
    speed: m.speed, el: m.el, armorEl: m.el, race: m.race,
    range: m.range || 1,
    xp: Math.round(8 * Math.pow(lv, 1.5) * (b ? 10 : 1) * Math.sqrt(m.hpMul || 1)),
    zeny: lv * 3 * (b ? 20 : 1),
  };
}

// ---------------- Dano ----------------
export function physHit(a, t, mult = 1, opts = {}) {
  const crit = chance(a.crit + (opts.critBonus || 0));
  if (!crit && !opts.sure) {
    const hc = clamp(80 + a.hit - t.flee, 5, 100);
    if (!chance(hc) || (t.perfectDodge && chance(t.perfectDodge))) return { miss: true, dmg: 0 };
  }
  let dmg = a.atk * (0.85 + Math.random() * 0.2) * mult;
  if (crit) dmg *= 1.4 + (a.critDmg || 0) / 100;
  const el = opts.el || a.el || 'neutro';
  dmg *= elemMult(el, t.status && t.status.petrify > 0 ? 'terra' : (t.armorEl || t.el)); // petrificado vira Terra
  if (a.raceDmg && a.raceDmg[t.race]) dmg *= 1 + a.raceDmg[t.race] / 100;
  const def = opts.ignoreDef ? 0 : t.def * (1 - Math.min(100, (a.pierce || 0) + (opts.defPierce || 0)) / 100);
  if (!crit) dmg *= 60 / (60 + def);
  if (t.dmgReduce) dmg *= 1 - t.dmgReduce / 100;
  dmg *= vsMul(a, t);
  if (a.execute && t.maxHp && t.hp < t.maxHp * a.execute / 100) dmg *= 2;
  return { dmg: Math.max(1, Math.round(dmg)), crit, el };
}

export function magicHit(a, t, mult, el) {
  let dmg = a.matk * (0.9 + Math.random() * 0.2) * mult;
  dmg *= elemMult(el, t.status && t.status.petrify > 0 ? 'terra' : (t.armorEl || t.el)); // petrificado vira Terra
  if (a.raceDmg && a.raceDmg[t.race]) dmg *= 1 + a.raceDmg[t.race] / 200;
  const mdef = a.ignoreMdef ? 0 : t.mdef * (1 - Math.min(100, a.pierce || 0) / 100);
  dmg *= 60 / (60 + mdef);
  if (t.dmgReduce) dmg *= 1 - t.dmgReduce / 100;
  dmg *= vsMul(a, t);
  if (a.execute && t.maxHp && t.hp < t.maxHp * a.execute / 100) dmg *= 2;
  return { dmg: Math.max(1, Math.round(dmg)), el };
}

export function legacyCost(key, lv) {
  const L = LEGACY[key];
  return L.costs ? L.costs[Math.min(lv, L.costs.length - 1)] : Math.floor((L.base || 250) * Math.pow(lv + 1, 2));
}

// área de efeito: texto ("3×3, 9 casas") e um mini quadro das casas atingidas
export function aoeText(sk) {
  if (!sk.aoe) return '';
  const n = sk.aoe * 2 + 1;
  return `${n}×${n} (${n * n} casas, ${sk.target === 'self' ? 'você no centro' : 'centro no alvo'})`;
}
export function aoeGrid(sk) {
  if (!sk.aoe) return '';
  const n = sk.aoe * 2 + 1, c = Math.floor(n * n / 2);
  let cells = '';
  for (let i = 0; i < n * n; i++) cells += `<i class="${i === c ? (sk.target === 'self' ? 'me' : 'c') : ''}"></i>`;
  return `<span class="aoe-grid" style="grid-template-columns:repeat(${n},8px)">${cells}</span>`;
}

// dano contra/de monstros normais e chefes (cartas)
function vsMul(a, t) {
  let k = 1;
  if (a.dmgNormal && t.boss === false) k *= 1 + a.dmgNormal / 100;
  if (a.dmgBoss && t.boss) k *= 1 + a.dmgBoss / 100;
  if (t.redNormal && a.boss === false) k *= 1 - t.redNormal / 100;
  if (t.redBoss && a.boss) k *= 1 - t.redBoss / 100;
  return k;
}
