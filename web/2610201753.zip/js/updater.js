// Atualização automática do jogo.
// - Conteúdo (código, arte, balanceamento): baixado ao abrir o app e aplicado sem reinstalar.
// - App Android em si: quando exigir APK novo, mostra um aviso com botão para baixar.
import { WEB_VERSION } from './version.js';

const BASE = 'https://raw.githubusercontent.com/rafaelcvalladao99-collab/AnotheRO-versoes/main/';
export const APK_URL = 'https://github.com/rafaelcvalladao99-collab/AnotheRO-versoes/raw/main/AnotheRO.apk';

function plugin(name) {
  const cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return null;
  try { return cap.registerPlugin(name); } catch (_) { return null; }
}

export async function checkForUpdates({ canRestartNow, onStatus, onApkNeeded }) {
  const Updater = plugin('CapacitorUpdater');
  if (!Updater) return; // navegador comum: nada a fazer
  // avisa que esta versão abriu bem (senão o atualizador volta para a anterior)
  try { await Updater.notifyAppReady(); } catch (_) {}

  let info;
  try {
    const res = await fetch(BASE + 'version.json?t=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) return;
    info = await res.json();
  } catch (_) { return; } // sem internet: joga a versão atual

  // App Android desatualizado demais para o conteúdo novo
  try {
    const App = plugin('App');
    const appInfo = App ? await App.getInfo() : null;
    const build = appInfo ? parseInt(appInfo.build, 10) : 0;
    if (info.minApk && build && build < info.minApk) { onApkNeeded && onApkNeeded(info); return; }
  } catch (_) {}

  if (!info.web || info.web <= WEB_VERSION) return;
  try {
    onStatus && onStatus('Baixando atualização...');
    const bundle = await Updater.download({ url: BASE + info.webUrl, version: String(info.web) });
    if (canRestartNow()) {
      onStatus && onStatus('Atualizando...');
      await Updater.set({ id: bundle.id }); // recarrega o jogo já atualizado
    } else {
      await Updater.next({ id: bundle.id }); // aplica na próxima vez que abrir
      onStatus && onStatus('Atualização pronta. Ela entra na próxima vez que você abrir o jogo.');
    }
  } catch (e) {
    console.warn('falha na atualização', e);
  }
}
