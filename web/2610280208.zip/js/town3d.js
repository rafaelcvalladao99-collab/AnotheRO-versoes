// Cidade em 3D (prédios KayKit Medieval Hexagon + árvores KayKit Forest + herói LPC).
// Cena fixa: monta uma vez, depois só reposiciona os rótulos e troca o sprite do herói.
import * as THREE from 'three';
import { mark } from './diag.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { heroSheet, CELL, FEET } from './lpc.js';

const HB = (n) => `assets/3d/hb/${n}.gltf`;
const BL = (n) => HB(`building_${n}_blue`);
const KF = (n) => `assets/3d/kf/${n}_Color1.gltf`;

// lugares: [id, modelo, x, z, escala, giro, altura do rótulo]
export const PLACES = [
  ['dungeon', BL('castle'), 0, -15, 2.3, 0, 4.2],
  ['legacy', BL('church'), -4.6, -8.6, 2.0, 0.35, 3.6],
  ['class', BL('barracks'), 4.6, -8.6, 2.0, -0.35, 2.7],
  ['shop', BL('tavern'), -5.2, -1.6, 2.0, Math.PI / 2, 2.6],
  ['smith', BL('blacksmith'), 5.2, -1.6, 2.0, -Math.PI / 2, 2.4],
  ['storage', BL('lumbermill'), -4.6, 5.0, 1.9, 0.5, 2.4],
  ['market', BL('market'), 4.6, 5.0, 1.9, -0.5, 2.3],
];
const PLAZA = [0, -1.6];
// enfeites: [modelo, x, z, escala, giro]
const DECOR = [
  [BL('well'), 0, -1.6, 1.4, 0.3],
  [BL('tower_A'), -3.4, -16.4, 1.5, 0], [BL('tower_A'), 3.4, -16.4, 1.5, 0],
  [HB('wall_straight'), -5.1, -16.6, 1.5, 0], [HB('wall_straight'), 5.1, -16.6, 1.5, 0],
  [BL('home_A'), -8.4, -12.5, 1.8, 0.4], [BL('home_B'), 8.4, -12.6, 1.8, -0.4],
  [BL('windmill'), -8.8, 1.8, 1.9, 0.2], [BL('home_A'), 8.6, 2.2, 1.8, -0.6],
  [BL('home_B'), -8.2, 9.6, 1.8, 0.8], [BL('home_A'), 8.4, 9.8, 1.8, -0.8],
  [BL('watermill'), -5.6, 11.2, 1.7, 0.4], [BL('home_B'), 5.8, 11.0, 1.7, -0.3], [BL('home_A'), 2.6, 13.6, 1.6, 0.2], [HB('trees_A_medium'), -2.6, 10.6, 1.3, 0.4], [HB('trees_B_medium'), 3.0, 9.4, 1.2, 1.1], [HB('rock_single_B'), -1.8, 12.6, 1.1, 0.4], [HB('flag_red'), -1.6, 8.4, 1.2, 0], [HB('flag_red'), 1.6, 8.4, 1.2, 0], [BL('tower_B'), -9.6, -3.2, 1.5, 0.3],
  [HB('flag_blue'), -1.8, -12.4, 1.4, 0], [HB('flag_yellow'), 1.8, -12.4, 1.4, 0],
  [HB('weaponrack'), 6.6, -0.2, 1.3, -1.2], [HB('barrel'), 6.4, -3.2, 1.4, 0.4],
  [HB('crate_A_big'), 3.0, 6.8, 1.3, 0.3], [HB('sack'), 2.6, 5.6, 1.4, 1], [HB('crate_open'), 6.6, 6.9, 1.3, -0.4],
  [HB('resource_lumber'), -6.6, 6.6, 1.3, 0.5], [HB('wheelbarrow'), -2.8, 6.2, 1.3, 2.2],
  [HB('tent'), -6.6, -4.4, 1.4, 1.2], [HB('bucket_water'), -1.3, -0.4, 1.4, 0],
  [HB('target'), 7.0, -6.2, 1.3, -0.8],
  [HB('rock_single_A'), -2.4, 9.0, 1.2, 0], [HB('rock_single_C'), 9.6, -5.4, 1.4, 1], [HB('rock_single_B'), -9.8, -6.2, 1.4, 2],
];
const LANTERNS = [[-2.6, -3.6], [2.6, -3.6], [-2.6, 0.6], [2.6, 0.6], [-1.4, -10.6], [1.4, -10.6]];
const TREES = ['Tree_1_A', 'Tree_2_B', 'Tree_3_A', 'Tree_4_A', 'Tree_1_C', 'Tree_2_A'];
const BUSH = ['Bush_1_A', 'Bush_2_A', 'Bush_4_A', 'Bush_1_B'];

let T = null; // estado da cena

function rnd(seed) { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; }

// ---------- chão pintado em canvas: grama, ruas de terra, praça de pedra ----------
const GW = 64; // lado do chão em unidades
function groundTexture() {
  const N = 1024, k = N / GW, c = document.createElement('canvas'); c.width = c.height = N;
  const x = c.getContext('2d', { willReadFrequently: true }), R = rnd(7);
  const P = (wx, wz) => [(wx + GW / 2) * k, (wz + GW / 2) * k];
  // grama com manchas
  x.fillStyle = '#4f7f3a'; x.fillRect(0, 0, N, N);
  for (let i = 0; i < 1400; i++) { const r = 6 + R() * 30; x.fillStyle = `rgba(${R() < 0.5 ? '96,140,62' : '58,98,44'},${0.12 + R() * 0.16})`; x.beginPath(); x.ellipse(R() * N, R() * N, r, r * 0.8, R() * 3, 0, 7); x.fill(); }
  for (let i = 0; i < 9000; i++) { x.fillStyle = `rgba(${R() < 0.5 ? '150,190,90' : '40,80,34'},${0.25 + R() * 0.3})`; x.fillRect(R() * N, R() * N, 2, 3 + R() * 3); }
  // ruas (terra batida com borda irregular)
  const road = (pts, w) => {
    for (const [col, ww] of [['#6b5338', w + 0.5], ['#8c7151', w], ['#9d815e', w * 0.55]]) {
      x.strokeStyle = col; x.lineWidth = ww * k; x.lineCap = 'round'; x.lineJoin = 'round';
      x.beginPath(); pts.forEach(([a, b], i) => { const [px, py] = P(a, b); i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.stroke();
    }
  };
  road([[0, -13], [0, 30]], 2.2);
  for (const [, , px, pz] of PLACES) road([PLAZA, [px * 0.85, pz * 0.9]], 1.5);
  // pedrinhas na terra
  for (let i = 0; i < 2600; i++) { const [px, py] = P((R() - 0.5) * 30, (R() - 0.5) * 40); const d = x.getImageData(px | 0, py | 0, 1, 1).data; if (d[0] > 120 && d[1] < 130) { x.fillStyle = `rgba(${70 + R() * 50},${55 + R() * 40},${40 + R() * 30},0.55)`; x.fillRect(px, py, 2 + R() * 4, 2 + R() * 3); } }
  // praça: lajes em anéis
  const [cx, cy] = P(...PLAZA), RX = 4.6 * k, RY = 4.2 * k;
  x.fillStyle = '#5d564e'; x.beginPath(); x.ellipse(cx, cy, RX + 6, RY + 6, 0, 0, 7); x.fill();
  x.fillStyle = '#8f877a'; x.beginPath(); x.ellipse(cx, cy, RX, RY, 0, 0, 7); x.fill();
  for (let ring = 1; ring < 9; ring++) {
    const rr = ring / 9, n = 6 + ring * 6;
    for (let j = 0; j < n; j++) {
      const a0 = j / n * Math.PI * 2 + ring * 0.37, a1 = a0 + Math.PI * 2 / n * 0.9, r0 = rr * 0.98, r1 = rr + 0.1;
      const l = 120 + R() * 40 | 0; x.fillStyle = `rgb(${l},${l - 8},${l - 20})`;
      x.beginPath(); x.ellipse(cx, cy, RX * r1, RY * r1, 0, a0, a1); x.ellipse(cx, cy, RX * r0, RY * r0, 0, a1, a0, true); x.closePath(); x.fill();
    }
  }
  x.strokeStyle = 'rgba(40,34,30,0.5)'; x.lineWidth = 2; x.beginPath(); x.ellipse(cx, cy, RX, RY, 0, 0, 7); x.stroke();
  // florzinhas
  for (let i = 0; i < 420; i++) { const [px, py] = P((R() - 0.5) * 40, (R() - 0.5) * 50); const d = x.getImageData(px | 0, py | 0, 1, 1).data; if (d[1] > d[0] + 20) { x.fillStyle = ['#e8d070', '#d8d8c8', '#d888a8', '#98b0e0'][i % 4]; x.globalAlpha = 0.8; x.fillRect(px, py, 2, 2); x.globalAlpha = 1; } }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return t;
}

function heroTexture(cls) {
  const img = heroSheet(cls);
  const c = document.createElement('canvas'); c.width = c.height = CELL;
  if (img) { const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(img, 0, 2 * CELL, CELL, CELL, 0, 0, CELL, CELL); }
  const t = new THREE.CanvasTexture(c); t.magFilter = THREE.NearestFilter; t.minFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace;
  return { t, ok: !!img };
}

async function build(canvas) {
  const r = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  r.setPixelRatio(Math.min(2, devicePixelRatio || 1));
  r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.2;
  r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFShadowMap; r.shadowMap.autoUpdate = false;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0b0c14); scene.fog = new THREE.Fog(0x14182a, 60, 90);
  const cam = new THREE.PerspectiveCamera(32, 1, 1, 200);
  scene.add(new THREE.HemisphereLight(0xc4ccff, 0x3a2a1a, 0.75));
  const sun = new THREE.DirectionalLight(0xffc890, 1.7); sun.position.set(-12, 18, 8); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 20, bottom: -20, near: 1, far: 70 }); sun.shadow.bias = -0.0006; scene.add(sun);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(GW, GW), new THREE.MeshStandardMaterial({ map: groundTexture(), roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  // modelos (cache por URL)
  const L = new GLTFLoader(), cache = new Map();
  const get = (u) => { if (!cache.has(u)) cache.set(u, new Promise((ok) => L.load(u, (g) => ok(g.scene), undefined, () => ok(null)))); return cache.get(u); };
  const put = async (u, px, pz, s = 1, ry = 0) => {
    const src = await get(u); if (!src) return null;
    const m = src.clone(); m.scale.setScalar(s); m.position.set(px, 0, pz); m.rotation.y = ry;
    m.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    scene.add(m); return m;
  };
  const picks = [];
  await Promise.all([
    ...PLACES.map(async ([id, u, px, pz, s, ry, h]) => { const m = await put(u, px, pz, s, ry); if (m) { m.userData.place = id; picks.push(m); } }),
    ...DECOR.map(([u, px, pz, s, ry]) => put(u, px, pz, s, ry)),
  ]);
  // árvores em volta (um anel irregular) e moitas
  const R = rnd(11), tp = [];
  for (let i = 0; i < 70; i++) {
    const side = i % 2 ? 1 : -1, px = side * (8.6 + R() * 8), pz = -24 + R() * 40;
    tp.push(put(KF(TREES[i % TREES.length]), px, pz, 0.45 + R() * 0.2, R() * 6));
  }
  for (let i = 0; i < 16; i++) tp.push(put(KF(TREES[i % TREES.length]), (R() - 0.5) * 16, -22 - R() * 6, 0.5 + R() * 0.2, R() * 6));
  for (let i = 0; i < 26; i++) { const side = i % 2 ? 1 : -1; tp.push(put(KF(BUSH[i % BUSH.length]), side * (6.6 + R() * 3.4), -12 + R() * 28, 0.5 + R() * 0.25, R() * 6)); }
  for (const [lx, lz] of LANTERNS) {
    tp.push(put('assets/3d/hw/lantern_standing.gltf', lx, lz, 0.85));
    const l = new THREE.PointLight(0xffb060, 6, 7, 1.6); l.position.set(lx, 1.4, lz); scene.add(l);
  }
  await Promise.all(tp);
  // herói: sprite LPC em pé na praça, olhando para a câmera
  const hm = new THREE.MeshStandardMaterial({ alphaTest: 0.5, color: 0xb8b8b8, emissive: 0xffffff, emissiveIntensity: 0.4, side: THREE.DoubleSide });
  const HS = 4.4; // tamanho do quadro (a figura ocupa ~1/3)
  const hero = new THREE.Mesh(new THREE.PlaneGeometry(HS, HS), hm); hero.castShadow = true; scene.add(hero);
  T = { r, scene, cam, sun, hero, hm, HS, picks, canvas, cls: null, loop: 0, W: 0, H: 0, labels: [], top: 0, bot: 0 };
  return T;
}

function placeCamera() {
  const { cam, r, canvas } = T;
  const W = canvas.clientWidth || innerWidth, H = canvas.clientHeight || innerHeight;
  if (W === T.W && H === T.H) return false;
  T.W = W; T.H = H; r.setSize(W, H, false);
  // enquadra a cidade de x=-7..7 no topo da área livre; em telas largas afasta menos
  const P = 54 * Math.PI / 180, target = new THREE.Vector3(0, 0, -3.6);
  const aspect = W / H, dist = Math.max(38, Math.min(60, 14.2 / (2 * Math.tan(16 * Math.PI / 180) * aspect)));
  cam.aspect = aspect; cam.position.copy(target).add(new THREE.Vector3(0, Math.sin(P), Math.cos(P)).multiplyScalar(dist)); cam.lookAt(target);
  cam.updateProjectionMatrix();
  T.hero.quaternion.copy(cam.quaternion);
  return true;
}

function setHero(cls) {
  const { t, ok } = heroTexture(cls);
  if (T.hm.map) T.hm.map.dispose();
  T.hm.map = t; T.hm.emissiveMap = t; T.hm.needsUpdate = true;
  T.cls = ok ? cls : null;
  // pés do sprite (FEET) no chão da praça, logo à frente do poço
  const up = new THREE.Vector3(0, 1, 0).applyQuaternion(T.cam.quaternion);
  T.hero.position.set(PLAZA[0], 0, PLAZA[1] + 1.8).addScaledVector(up, (FEET / CELL - 0.5) * T.HS);
  T.r.shadowMap.needsUpdate = true;
}

export function project(px, py, pz) {
  const v = new THREE.Vector3(px, py, pz).project(T.cam);
  return [(v.x + 1) / 2 * T.W, (1 - v.y) / 2 * T.H];
}

// mostra a cidade (desenha só quando precisa: a cena é parada); devolve posições de tela dos rótulos
let hideGen = 0, building = null;
export async function showTown(cls) {
  const my = hideGen;
  if (!T) {
    if (!building) {
      const canvas = document.createElement('canvas'); canvas.id = 'town3d';
      document.getElementById('screen').before(canvas);
      mark('monta cidade');
      building = build(canvas).catch((e) => { console.warn('cidade 3D indisponível', e); canvas.remove(); return null; });
    }
    const t = await building; building = null;
    if (!t) return null;
    if (!T) return null;
    if (my !== hideGen) { dispose(); return null; }   // saiu da cidade enquanto montava
  }
  T.hidden = false; T.cls0 = cls;
  T.canvas.style.display = 'block';
  if (!T.onResize) { T.onResize = () => { if (T && !T.hidden) { redraw(); T.onLayout && T.onLayout(); } }; addEventListener('resize', T.onResize); }
  redraw();
  return labelPositions();
}
function redraw() {
  if (placeCamera() || T.cls !== T.cls0) setHero(T.cls0);
  if (!T.cls) { clearTimeout(T.retry); T.retry = setTimeout(() => T && !T.hidden && redraw(), 400); }   // folha do herói ainda carregando
  T.r.render(T.scene, T.cam);
}

export function labelPositions() {
  if (!T) return null;
  const o = {};
  for (const [id, , px, pz, , , h] of PLACES) o[id] = project(px, h, pz);
  return o;
}
export function onLayout(fn) { if (T) T.onLayout = fn; }

// ao sair da cidade a cena inteira sai da memória (placa de vídeo inclusa); volta a ser montada na próxima visita
export function hideTown() {
  hideGen++;
  if (!T) return;
  T.hidden = true;
  dispose();
}
function dispose() {
  if (!T) return;
  mark('solta cidade');
  clearTimeout(T.retry);
  if (T.onResize) removeEventListener('resize', T.onResize);
  T.scene.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
    for (const m of [].concat(o.material || [])) { for (const k of ['map', 'emissiveMap', 'normalMap']) if (m[k]) m[k].dispose(); m.dispose(); }
  });
  T.r.dispose(); T.r.forceContextLoss();
  T.canvas.remove();
  T = null;
}

// toque no canvas: qual prédio foi tocado?
export function pick(clientX, clientY) {
  if (!T) return null;
  const rect = T.canvas.getBoundingClientRect();
  const ray = new THREE.Raycaster();
  ray.setFromCamera(new THREE.Vector2((clientX - rect.left) / rect.width * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1), T.cam);
  const hit = ray.intersectObjects(T.picks, true)[0];
  if (!hit) return null;
  let o = hit.object; while (o && !o.userData.place) o = o.parent;
  return o ? o.userData.place : null;
}
