// Monstros no estilo LPC (gerados por tools/monsters/export.py)
import { MON_META } from './mon_meta.js';

const mons = new Map();

function loadImg(src) {
  return new Promise((ok) => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => ok(null); im.src = src; });
}

export async function preloadMonsters() {
  const jobs = [];
  for (const k of Object.keys(MON_META)) {
    jobs.push(loadImg(`assets/mon/${k}.png`).then((im) => {
      if (!im) return;
      // tela quadrada no tamanho nativo, criatura apoiada embaixo e centralizada
      const S = Math.max(im.width, im.height);
      const c = document.createElement('canvas'); c.width = c.height = S;
      c.getContext('2d').drawImage(im, Math.floor((S - im.width) / 2), S - im.height);
      c.pixel = true;
      c.lpc = S;          // desenhado na mesma escala de pixel dos heróis
      mons.set(k, c);
    }));
  }
  await Promise.all(jobs);
}

export const monsterImg = (type) => mons.get(type) || null;
