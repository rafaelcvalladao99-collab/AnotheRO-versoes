// Sprites: monstros e heróis vêm de imagens prontas; ícones de itens são desenhados em canvas.
import { artCls } from './data.js';
import { itemDef } from './rules.js';
import { heroPortrait } from './lpc.js';
import { monsterImg } from './monimg.js';

export const SPR = 96; // tamanho lógico dos sprites
const RES = 2;         // renderizados em 2x para telas de alta densidade
const cache = new Map();

function mk(size = SPR) {
  const c = document.createElement('canvas');
  c.width = size * RES; c.height = size * RES;
  c.getContext('2d').scale(RES, RES);
  return c;
}

function shade(hex, amt) {
  // amt: -1..1
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map((x) => x + x).join('');
  const n = parseInt(c, 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (amt >= 0) { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; }
  else { r *= 1 + amt; g *= 1 + amt; b *= 1 + amt; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}
export { shade };

const OUT = 'rgba(16,10,24,0.9)';

function ell(ctx, x, y, rx, ry, fill, stroke = OUT, lw = 3) {
  ctx.beginPath();
  ctx.ellipse(x, y, Math.max(0.5, rx), Math.max(0.5, ry), 0, 0, Math.PI * 2);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.stroke(); }
}

function rr(ctx, x, y, w, h, r, fill, stroke = OUT, lw = 3) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.stroke(); }
}

function grad(ctx, x, y, r, c0, c1) {
  const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.45, r * 0.1, x, y, r * 1.1);
  g.addColorStop(0, shade(c0, 0.35));
  g.addColorStop(0.55, c0);
  g.addColorStop(1, c1);
  return g;
}

function lin(ctx, x0, y0, x1, y1, stops) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  stops.forEach((c, i) => g.addColorStop(i / (stops.length - 1), c));
  return g;
}



// monstros: sprite pronto (tools/dcss); canvas vazio se faltar a imagem
const EMPTY = mk();
export function monsterSprite(type) {
  return monsterImg(type) || EMPTY;
}


// arma desenhada nos ícones de itens
function drawWeapon(ctx, wtype, x, y, scale = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.lineCap = 'round';
  const steel = (len, w) => { ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -len); ctx.lineWidth = w + 3; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = w; ctx.strokeStyle = '#dfe6f0'; ctx.stroke(); };
  switch (wtype) {
    case 'adaga': ctx.rotate(0.5); steel(16, 4); rr(ctx, -5, -2, 10, 3, 1, '#c9a24a', OUT, 1.5); break;
    case 'espada': ctx.rotate(0.35); steel(30, 5); rr(ctx, -7, -3, 14, 4, 1, '#c9a24a', OUT, 1.5); break;
    case 'lanca': ctx.rotate(0.15); ctx.beginPath(); ctx.moveTo(0, 14); ctx.lineTo(0, -38); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#8a5a2a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(-5, -36); ctx.lineTo(0, -52); ctx.lineTo(5, -36); ctx.closePath(); ctx.fillStyle = '#e8eef8'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); break;
    case 'varinha': ctx.rotate(0.3); ctx.beginPath(); ctx.moveTo(0, 6); ctx.lineTo(0, -22); ctx.lineWidth = 5; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3; ctx.strokeStyle = '#c8a070'; ctx.stroke(); ctx.save(); ctx.shadowColor = '#ffb8ff'; ctx.shadowBlur = 12; ell(ctx, 0, -26, 5, 5, '#ffd0ff', OUT, 2); ctx.restore(); break;
    case 'cajado': ctx.rotate(0.12); ctx.beginPath(); ctx.moveTo(0, 14); ctx.lineTo(0, -36); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#7a4a2a'; ctx.stroke(); ctx.save(); ctx.shadowColor = '#9ad8ff'; ctx.shadowBlur = 12; ell(ctx, 0, -40, 6, 6, '#9ad8ff', OUT, 2); ctx.restore(); break;
    case 'kunai': ctx.rotate(0.5); ctx.beginPath(); ctx.moveTo(-5, -4); ctx.lineTo(0, -34); ctx.lineTo(5, -4); ctx.closePath(); ctx.fillStyle = lin(ctx, -5, 0, 5, 0, ['#ffffff', '#9aa8bc']); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); rr(ctx, -2.5, -4, 5, 14, 1, '#2a2f45', OUT, 2); ctx.beginPath(); ctx.arc(0, 14, 5, 0, 7); ctx.lineWidth = 3; ctx.strokeStyle = '#c9d2e0'; ctx.stroke(); break;
    case 'fuuma': ctx.translate(4, -20); for (let i = 0; i < 4; i++) { ctx.save(); ctx.rotate(i * Math.PI / 2); ctx.beginPath(); ctx.moveTo(0, -5); ctx.lineTo(8, -8); ctx.lineTo(4, -28); ctx.lineTo(-2, -10); ctx.closePath(); ctx.fillStyle = lin(ctx, 0, -28, 0, 0, ['#ffffff', '#9aa8bc']); ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); ctx.restore(); } ell(ctx, 0, 0, 7, 7, '#3a3048', OUT, 2.5); break;
    case 'treino': ctx.rotate(0.35); ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(-4, -34); ctx.lineTo(0, -40); ctx.lineTo(4, -34); ctx.lineTo(4, 0); ctx.closePath(); ctx.fillStyle = lin(ctx, -4, 0, 4, 0, ['#e0b880', '#a87a48']); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); rr(ctx, -9, -2, 18, 5, 1, '#7a5230', OUT, 2); rr(ctx, -2.5, 3, 5, 10, 1, '#5a3a20', OUT, 2); break;
    case 'besta': ctx.rotate(-0.7); rr(ctx, -16, -4, 30, 7, 2, '#6a4a2a', OUT, 2.5); rr(ctx, 8, -20, 5, 40, 2, '#9aa8bc', OUT, 2.5); ctx.beginPath(); ctx.moveTo(10, -18); ctx.lineTo(-10, 0); ctx.lineTo(10, 18); ctx.lineWidth = 1.2; ctx.strokeStyle = '#eee'; ctx.stroke(); break;
    case 'katar': ctx.rotate(0.3); rr(ctx, -8, -4, 16, 10, 2, '#5a3a2a', OUT, 2.5); ctx.beginPath(); ctx.moveTo(-6, -4); ctx.lineTo(0, -42); ctx.lineTo(6, -4); ctx.closePath(); ctx.fillStyle = lin(ctx, -6, 0, 6, 0, ['#ffffff', '#b8c2d4']); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke(); break;
    case 'faixa': for (const [dy, c] of [[-14, '#f4efe2'], [-6, '#d83a3a'], [2, '#f4efe2']]) rr(ctx, -15, dy, 30, 8, 3, c, OUT, 2.5); break;
    case 'soqueira': rr(ctx, -16, -10, 32, 18, 5, lin(ctx, 0, -10, 0, 8, ['#e8eef8', '#7a88a0']), OUT, 3); for (const dx of [-10, -3, 4, 11]) { ctx.beginPath(); ctx.moveTo(dx - 3, -10); ctx.lineTo(dx, -17); ctx.lineTo(dx + 3, -10); ctx.closePath(); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); } break;
    case 'arco': ctx.beginPath(); ctx.arc(-6, -10, 20, -1.15, 1.15); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#a86a2a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(2, -28); ctx.lineTo(2, 8); ctx.lineWidth = 1; ctx.strokeStyle = '#eee'; ctx.stroke(); break;
    case 'maca': ctx.rotate(0.35); ctx.beginPath(); ctx.moveTo(0, 6); ctx.lineTo(0, -22); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#7a4a2a'; ctx.stroke(); ell(ctx, 0, -26, 7, 7, '#b8c0cc', OUT, 2); break;
    case 'machado': ctx.rotate(0.3); ctx.beginPath(); ctx.moveTo(0, 8); ctx.lineTo(0, -30); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.5; ctx.strokeStyle = '#7a4a2a'; ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, -28); ctx.quadraticCurveTo(16, -32, 14, -16); ctx.lineTo(0, -20); ctx.closePath(); ctx.fillStyle = '#dfe6f0'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke(); break;
  }
  ctx.restore();
}

// heróis: retrato LPC (tools/lpc); canvas vazio se faltar a imagem
export function heroSprite(cls) {
  return heroPortrait(artCls(cls)) || EMPTY;
}

// ---------------- Ícones de itens ----------------
function drawItemIcon(ctx, s, it) {
  const d = itemDef(it);
  const cx = s / 2, cy = s / 2;
  ctx.lineJoin = 'round';
  if (d.kind === 'use' && d.id !== undefined) {}
  if (d.kind === 'use') {
    if (d.teleport || d.recall) {
      const col = d.recall ? '#7ad0ff' : '#d8d2bc';
      for (const k of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx, cy + 6); ctx.quadraticCurveTo(cx + k * 34, cy - 30, cx + k * 30, cy + 2); ctx.quadraticCurveTo(cx + k * 20, cy + 14, cx, cy + 6); ctx.fillStyle = lin(ctx, 0, cy - 20, 0, cy + 10, [shade(col, 0.4), col]); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke(); }
      return;
    }
    if (d.cure) { for (const [dx, a] of [[-8, -0.4], [0, 0], [8, 0.4]]) { ctx.save(); ctx.translate(cx + dx, cy + 14); ctx.rotate(a); ell(ctx, 0, -16, 7, 16, '#5fd16a'); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -30); ctx.lineWidth = 1.5; ctx.strokeStyle = '#2a7a2a'; ctx.stroke(); ctx.restore(); } return; }
    const col = d.icon;
    rr(ctx, cx - 6, cy - 26, 12, 10, 3, '#b88a5a');
    ctx.beginPath(); ctx.moveTo(cx - 6, cy - 16); ctx.lineTo(cx - 6, cy - 10); ctx.bezierCurveTo(cx - 24, cy - 4, cx - 22, cy + 26, cx, cy + 26); ctx.bezierCurveTo(cx + 22, cy + 26, cx + 24, cy - 4, cx + 6, cy - 10); ctx.lineTo(cx + 6, cy - 16); ctx.closePath();
    ctx.fillStyle = grad(ctx, cx, cy + 8, 20, col, shade(col, -0.5)); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    ell(ctx, cx - 7, cy + 2, 4, 7, 'rgba(255,255,255,0.6)', null);
    return;
  }
  if (d.kind === 'mat') {
    ctx.save(); ctx.shadowColor = '#7affe0'; ctx.shadowBlur = 14;
    ctx.beginPath(); ctx.moveTo(cx, cy - 28); ctx.lineTo(cx + 16, cy - 4); ctx.lineTo(cx + 6, cy + 26); ctx.lineTo(cx - 10, cy + 22); ctx.lineTo(cx - 16, cy - 6); ctx.closePath();
    ctx.fillStyle = lin(ctx, cx - 16, cy - 28, cx + 16, cy + 26, ['#e0fff8', '#7affe0', '#2a8a9a']); ctx.fill(); ctx.restore();
    ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, cy - 28); ctx.lineTo(cx - 2, cy + 24); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.stroke();
    return;
  }
  if (d.kind === 'card') {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.08);
    rr(ctx, -22, -30, 44, 60, 5, lin(ctx, 0, -30, 0, 30, d.boss ? ['#fff0c0', '#ffb84a'] : ['#fffbe8', '#e8dcb0']));
    rr(ctx, -17, -24, 34, 34, 3, '#2a2438', null);
    const spr = monsterSprite(d.mon);
    ctx.drawImage(spr, -17, -24, 34, 34);
    ctx.fillStyle = 'rgba(60,40,20,0.7)'; ctx.fillRect(-15, 15, 30, 3); ctx.fillRect(-15, 21, 20, 3);
    ctx.restore();
    return;
  }
  if (d.kind === 'weapon') { drawWeapon(ctx, d.wtype, cx - 4, cy + 22, 1.15); return; }
  if (d.kind === 'armor') {
    const col = d.mdef >= 10 && d.def < 15 ? '#6a4ab8' : d.tier >= 3 ? '#9aa8bc' : '#a8784a';
    ctx.beginPath(); ctx.moveTo(cx - 12, cy - 24); ctx.lineTo(cx - 26, cy - 16); ctx.lineTo(cx - 22, cy - 2); ctx.lineTo(cx - 16, cy - 4); ctx.lineTo(cx - 16, cy + 24); ctx.lineTo(cx + 16, cy + 24); ctx.lineTo(cx + 16, cy - 4); ctx.lineTo(cx + 22, cy - 2); ctx.lineTo(cx + 26, cy - 16); ctx.lineTo(cx + 12, cy - 24); ctx.quadraticCurveTo(cx, cy - 14, cx - 12, cy - 24);
    ctx.fillStyle = lin(ctx, 0, cy - 24, 0, cy + 24, [shade(col, 0.35), col, shade(col, -0.35)]); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    return;
  }
  if (d.kind === 'head') {
    const col = d.cat === 'robe' ? '#6a4ab8' : d.cat === 'light' ? '#4a5a4a' : d.tier >= 3 ? '#9aa8bc' : '#a8784a';
    ctx.beginPath();
    if (d.cat === 'robe') { ctx.moveTo(cx - 28, cy + 16); ctx.lineTo(cx + 28, cy + 16); ctx.lineTo(cx + 14, cy + 6); ctx.lineTo(cx + 4, cy - 28); ctx.lineTo(cx - 14, cy + 6); ctx.closePath(); }
    else if (d.cat === 'light') { ctx.moveTo(cx - 20, cy + 20); ctx.quadraticCurveTo(cx - 24, cy - 26, cx, cy - 26); ctx.quadraticCurveTo(cx + 24, cy - 26, cx + 20, cy + 20); ctx.lineTo(cx + 10, cy + 6); ctx.lineTo(cx - 10, cy + 6); ctx.closePath(); }
    else { ctx.moveTo(cx - 22, cy + 18); ctx.lineTo(cx - 22, cy - 6); ctx.quadraticCurveTo(cx, cy - 32, cx + 22, cy - 6); ctx.lineTo(cx + 22, cy + 18); ctx.lineTo(cx + 8, cy + 18); ctx.lineTo(cx + 8, cy + 2); ctx.lineTo(cx - 8, cy + 2); ctx.lineTo(cx - 8, cy + 18); ctx.closePath(); }
    ctx.fillStyle = lin(ctx, 0, cy - 26, 0, cy + 20, [shade(col, 0.4), col, shade(col, -0.35)]); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    if (d.cat === 'robe') { ctx.fillStyle = '#ffd86b'; ctx.fillRect(cx - 14, cy + 4, 28, 4); }
    return;
  }
  if (d.kind === 'shield') {
    if (d.cat === 'grimorio') {
      rr(ctx, cx - 20, cy - 24, 40, 48, 4, lin(ctx, 0, cy - 24, 0, cy + 24, ['#9a5ae8', '#4a2a8a']), OUT, 3);
      ctx.fillStyle = '#ffd86b'; ctx.fillRect(cx - 20, cy - 24, 6, 48);
      ctx.save(); ctx.shadowColor = '#ffd86b'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(cx + 3, cy, 7, 0, 7); ctx.fillStyle = '#ffe8a0'; ctx.fill(); ctx.restore();
      return;
    }
    const col = d.tier >= 3 ? '#9aa8bc' : '#a8784a';
    ctx.beginPath(); ctx.moveTo(cx, cy - 26); ctx.lineTo(cx + 22, cy - 18); ctx.quadraticCurveTo(cx + 22, cy + 14, cx, cy + 28); ctx.quadraticCurveTo(cx - 22, cy + 14, cx - 22, cy - 18); ctx.closePath();
    ctx.fillStyle = lin(ctx, 0, cy - 26, 0, cy + 28, [shade(col, 0.4), col, shade(col, -0.35)]); ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, cy - 18); ctx.lineTo(cx, cy + 18); ctx.moveTo(cx - 13, cy - 4); ctx.lineTo(cx + 13, cy - 4); ctx.lineWidth = 4; ctx.strokeStyle = '#ffd86b'; ctx.stroke();
    return;
  }
  if (d.kind === 'acc') {
    const gems = { str: '#ff4a4a', int: '#7a5aff', dex: '#4ad86a', agi: '#4ad8ff', vit: '#ff9a3a', luk: '#ffd23f' };
    ctx.beginPath(); ctx.ellipse(cx, cy + 6, 18, 18, 0, 0, Math.PI * 2); ctx.lineWidth = 9; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 6; ctx.strokeStyle = '#e8c34a'; ctx.stroke();
    ctx.save(); ctx.shadowColor = gems[d.stat]; ctx.shadowBlur = 10;
    ctx.beginPath(); ctx.moveTo(cx, cy - 24); ctx.lineTo(cx + 10, cy - 12); ctx.lineTo(cx, cy - 4); ctx.lineTo(cx - 10, cy - 12); ctx.closePath(); ctx.fillStyle = gems[d.stat]; ctx.fill(); ctx.restore();
    ctx.lineWidth = 2.5; ctx.strokeStyle = OUT; ctx.stroke();
  }
}

export function itemSprite(it) {
  const d = itemDef(it);
  const key = 'i:' + (d.kind === 'card' ? 'card:' + it.mon : it.id);
  if (cache.has(key)) return cache.get(key);
  const c = mk(72);
  drawItemIcon(c.getContext('2d'), 72, it);
  cache.set(key, c);
  return c;
}

const urlCache = new Map();
export function itemIconURL(it) {
  const d = itemDef(it);
  const key = d.kind === 'card' ? 'card:' + it.mon : it.id;
  if (!urlCache.has(key)) urlCache.set(key, itemSprite(it).toDataURL());
  return urlCache.get(key);
}

export function spriteURL(canvas, key) {
  if (!urlCache.has(key)) {
    let c = canvas;
    if (canvas.pixel) { // pixel art: amplia sem borrar antes de virar imagem
      c = document.createElement('canvas'); c.width = c.height = canvas.width * 4;
      const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(canvas, 0, 0, c.width, c.height);
    }
    urlCache.set(key, c.toDataURL());
  }
  return urlCache.get(key);
}
