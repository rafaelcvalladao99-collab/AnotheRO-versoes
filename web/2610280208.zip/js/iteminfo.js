// Ficha do item com destaque no que importa: números principais grandes, bônus em verde, poderes em dourado.
import { itemDef, itemDesc, isEquip, modsText } from './rules.js';
import { WTYPES, ELEMENTS } from './data.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const chips = (txt) => txt.split(', ').map((p) => {
  const neg = /-\d|^Esquiva -|^Velocidade -/.test(p) && !/Dano recebido/.test(p);
  return `<span class="ii-chip ${neg ? 'neg' : ''}">${esc(p)}</span>`;
}).join('');

export function itemInfoHTML(it) {
  const d = itemDef(it);
  const lines = itemDesc(it);
  const mods = new Set([modsText(d.mods), d.kind === 'weapon' && WTYPES[d.wtype] ? modsText({ ...WTYPES[d.wtype].mods, ...(d.mods || {}) }) : null].filter(Boolean));
  const out = [];
  lines.forEach((l, i) => {
    if (/^(ATQ|DEF) \d/.test(l)) {
      out.push(`<div class="ii-main">${l.split(' · ').map((p) => { const m = p.match(/^(\S+) \+?(\d.*)$/); return m ? `<span><small>${esc(m[1])}</small><b>${esc(m[2])}</b></span>` : `<span><b>${esc(p)}</b></span>`; }).join('')}</div>`);
    } else if (i === 0 && isEquip(it) && !l.startsWith('Acessório')) {
      out.push(`<div class="ii-type">${esc(l)}</div>`);
    } else if (l.startsWith('Acessório · ') && mods.has(l.slice(12))) {
      out.push(`<div class="ii-type">Acessório</div><div class="ii-mods">${chips(l.slice(12))}</div>`);
    } else if (mods.has(l)) {
      out.push(`<div class="ii-mods">${chips(l)}</div>`);
    } else if (l.startsWith('★')) {
      out.push(`<div class="ii-power">${esc(l)}</div>`);
    } else if (l.startsWith('Elemento: ')) {
      const el = Object.values(ELEMENTS).find((e) => e.name === l.slice(10));
      out.push(`<div class="ii-el" style="color:${el ? el.color : '#fff'}">◆ ${esc(l)}</div>`);
    } else if (l.startsWith('Slots: ')) {
      // cartas encaixadas: nome + o que cada uma dá
      const cards = it.cards || [];
      out.push(`<div class="ii-slots">${Array.from({ length: it.slots }, (_, k) => {
        if (!cards[k]) return '<span class="empty">slot vazio</span>';
        const cd = itemDef({ id: 'card', mon: cards[k] });
        const cm = modsText(cd.mods);
        return `<span>${esc(cd.name)}${cm ? `<em>${esc(cm)}</em>` : ''}${cd.power ? `<em class="pw">★ ${esc(cd.power)}</em>` : ''}</span>`;
      }).join('')}</div>`);
    } else if (/^Recupera /.test(l)) {
      out.push(`<div class="ii-main">${(() => { const m = l.match(/^Recupera (\d+) (HP|SP)/); return m ? `<span><small>${m[2]}</small><b>+${m[1]}</b></span>` : esc(l); })()}</div>`);
    } else out.push(`<div class="ii-text">${esc(l)}</div>`);
  });
  return `<div class="ii">${out.join('')}</div>`;
}

// linha curta para as listas: o que o item dá (ATQ/DEF e bônus), com os números em destaque; o tipo fica para a ficha
export function itemSummaryHTML(it) {
  const d = itemDef(it);
  const lines = itemDesc(it);
  let pick;
  if (isEquip(it)) {
    const main = lines.find((l) => /^(ATQ|DEF) \d/.test(l));
    const m = d.kind === 'acc' ? (lines[0] || '').replace(/^Acessório · /, '') : lines.find((l, i) => i > 0 && l !== main && !l.startsWith('Slots') && !l.startsWith('★') && !l.startsWith('Conta como') && !l.startsWith('Elemento'));
    pick = [main, m].filter(Boolean).join(' · ');
    if (!pick) pick = lines[0] || '';
  } else if (d.kind === 'card') pick = lines[1] || lines[0] || '';
  else pick = lines[0] || '';
  return esc(pick).replace(/(&#?\w+;)|([+-]?\d[\d.,]*%?)/g, (m, ent, n) => ent || `<b class="hn">${n}</b>`);
}
