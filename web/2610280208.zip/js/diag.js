// Diagnóstico de desempenho: mede FPS, quadros travados, erros e crashes, e monta um relatório para copiar.
// Fica tudo no próprio aparelho (localStorage); nada é enviado sozinho.
const KEY = 'diag_v1';
const now = () => Date.now();
let ctxFn = () => ({});
let showFps = false, fpsEl = null;

const D = load();
function load() {
  let d; try { d = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (_) { d = null; }
  d = d && d.v === 1 ? d : { v: 1, sessions: [], errors: [] };
  // a sessão anterior terminou sem fechar direito enquanto o jogo estava aberto e na tela = provável crash
  const last = d.cur;
  if (last) {
    last.end = last.beat;
    last.crash = !last.clean && !last.hidden;
    d.sessions.push(last);
    d.sessions = d.sessions.slice(-8);
  }
  d.cur = { start: now(), beat: now(), clean: false, hidden: false, fps: [], worst: 0, slow: 0, frames: 0, lost: 0, ctx: {} };
  return d;
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(D)); } catch (_) { /* cheio */ } }

export function setContext(fn) { ctxFn = fn; }
// marcas do que o jogo estava fazendo (gravadas na hora: se o celular morrer, sabemos o último passo)
export function mark(label) {
  const c = D.cur; (c.marks ||= []).push(`${((now() - c.start) / 1000).toFixed(1)}s ${label}`);
  if (c.marks.length > 14) c.marks.shift();
  c.beat = now(); save();
}
// tempo gasto desenhando cada quadro (média e pior por segundo)
let drawSum = 0, drawN = 0, drawMax = 0;
export function drawTime(ms) { drawSum += ms; drawN++; if (ms > drawMax) drawMax = ms; }

function err(kind, msg, stack) {
  const c = safeCtx();
  D.errors.push({ t: now(), kind, msg: String(msg).slice(0, 300), stack: String(stack || '').split('\n').slice(0, 4).join(' | ').slice(0, 500), where: c });
  D.errors = D.errors.slice(-20);
  save();
}
const safeCtx = () => { try { return ctxFn() || {}; } catch (_) { return {}; } };

window.addEventListener('error', (e) => err('erro', e.message, e.error && e.error.stack));
window.addEventListener('unhandledrejection', (e) => err('promessa', e.reason && (e.reason.message || e.reason), e.reason && e.reason.stack));
document.addEventListener('visibilitychange', () => { D.cur.hidden = document.hidden; D.cur.beat = now(); save(); });
window.addEventListener('pagehide', () => { D.cur.clean = true; save(); });
// o 3D perdeu o contexto (o Android tirou a placa de vídeo do jogo, geralmente por falta de memória)
document.addEventListener('webglcontextlost', (e) => { D.cur.lost++; err('gpu', `contexto WebGL perdido (${e.target && e.target.id || 'canvas'})`); }, true);

// engasgadas: o que aconteceu desde o quadro anterior (efeitos novos, sombra, névoa, código JS demorado...)
let notes = [];
export function note(s) { if (notes.length < 12 && !notes.includes(s)) notes.push(s); }
try {
  new PerformanceObserver((l) => { for (const e of l.getEntries()) if (e.duration > 80) note(`JS ${Math.round(e.duration)}ms`); }).observe({ entryTypes: ['longtask'] });
} catch (_) { /* sem suporte */ }

// chamado a cada quadro pelo laço de desenho
let secStart = 0, secFrames = 0, lastTs = 0, secWorst = 0;
export function tick(ts) {
  if (lastTs) {
    const dt = ts - lastTs;
    if (dt > 50 && dt < 5000) { D.cur.slow++; if (dt > D.cur.worst) D.cur.worst = Math.round(dt); }
    if (dt > secWorst && dt < 5000) secWorst = dt;
    if (dt > 150 && dt < 5000 && !document.hidden) {
      (D.cur.hitches ||= []).push(`${((now() - D.cur.start) / 1000).toFixed(1)}s ${Math.round(dt)}ms: ${notes.join(', ') || 'nada anotado'}`);
      if (D.cur.hitches.length > 12) D.cur.hitches.shift();
    }
  }
  notes = [];
  lastTs = ts; secFrames++; D.cur.frames++;
  if (!secStart) secStart = ts;
  if (ts - secStart >= 1000) {
    const fps = Math.round(secFrames * 1000 / (ts - secStart));
    if (!document.hidden) {
      const c = safeCtx();
      D.cur.fps.push([fps, Math.round(secWorst), c.mode || '', c.gfx || '', c.floor || 0, drawN ? +(drawSum / drawN).toFixed(1) : 0, Math.round(drawMax), drawN]);
      drawSum = 0; drawN = 0; drawMax = 0;
      if (D.cur.fps.length > 600) D.cur.fps.splice(0, D.cur.fps.length - 600);
      D.cur.ctx = c;
    }
    if (fpsEl) fpsEl.textContent = `${fps} fps · pior ${Math.round(secWorst)} ms`;
    secStart = ts; secFrames = 0; secWorst = 0;
  }
}
// batida a cada 3 s: guarda o estado para sabermos onde estava se o jogo morrer
setInterval(() => {
  D.cur.beat = now();
  const m = performance.memory;
  if (m) D.cur.heap = Math.round(m.usedJSHeapSize / 1048576);
  save();
}, 3000);

export function setFpsVisible(on) {
  showFps = on;
  if (on && !fpsEl) {
    fpsEl = document.createElement('div');
    Object.assign(fpsEl.style, { position: 'fixed', left: '50%', top: 'calc(4px + env(safe-area-inset-top, 0px))', transform: 'translateX(-50%)', zIndex: 50, font: '600 11px monospace', color: '#9f9', background: 'rgba(0,0,0,.55)', padding: '1px 6px', borderRadius: '6px', pointerEvents: 'none' });
    document.body.appendChild(fpsEl);
  }
  if (fpsEl) fpsEl.style.display = on ? 'block' : 'none';
}
export const fpsVisible = () => showFps;

function gpuInfo() {
  try {
    const c = document.createElement('canvas'), gl = c.getContext('webgl');
    if (!gl) return 'sem WebGL';
    const x = gl.getExtension('WEBGL_debug_renderer_info');
    const s = x ? gl.getParameter(x.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
    const mx = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return `${s} (tex ${mx})`;
  } catch (_) { return '?'; }
}

// resumo por modo de jogo/visual: média de FPS, % do tempo abaixo de 30 e pior quadro
function summarize(fps) {
  const g = {};
  for (const [f, w, mode, gfx, , dm, dx, dn] of fps) { const k = `${mode}/${gfx}`; (g[k] ||= []).push([f, w, dm || 0, dx || 0, dn || 0]); }
  return Object.entries(g).map(([k, a]) => {
    const avg = Math.round(a.reduce((s, x) => s + x[0], 0) / a.length);
    const low = Math.round(a.filter((x) => x[0] < 30).length / a.length * 100);
    const worst = Math.max(...a.map((x) => x[1]));
    const dm = (a.reduce((s, x) => s + x[2], 0) / a.length).toFixed(1), dx = Math.max(...a.map((x) => x[3])), dn = Math.round(a.reduce((s, x) => s + x[4], 0) / a.length);
    return { k, seg: a.length, avg, low, worst, dm, dx, dn };
  });
}

export function report() {
  const cur = D.cur;
  const lines = [];
  lines.push(`AnotheRO · relatório de desempenho · versão ${window.__WEB_VERSION || '?'}`);
  lines.push(`aparelho: ${navigator.userAgent.replace(/.*Android/, 'Android').slice(0, 90)}`);
  lines.push(`tela: ${innerWidth}x${innerHeight} @${devicePixelRatio} · núcleos ${navigator.hardwareConcurrency || '?'} · RAM ${navigator.deviceMemory || '?'} GB · GPU ${gpuInfo()}`);
  const fmtS = (s, label) => {
    const mins = Math.round(((s.end || s.beat) - s.start) / 60000);
    lines.push(`${label}: ${new Date(s.start).toLocaleString('pt-BR')} · ${mins} min · ${s.crash ? '⚠ TERMINOU DE REPENTE (provável crash)' : 'ok'} · travadas >50ms: ${s.slow} · pior ${s.worst} ms · GPU perdida: ${s.lost || 0} · memória JS ${s.heap || '?'} MB`);
    if (s.ctx && Object.keys(s.ctx).length) lines.push(`   último estado: ${JSON.stringify(s.ctx)}`);
    for (const r of summarize(s.fps || [])) lines.push(`   ${r.k.padEnd(18)} ${String(r.avg).padStart(3)} fps médio · ${r.low}% do tempo abaixo de 30 · pior ${r.worst} ms (${r.seg}s) · desenho ${r.dn}/s, ${r.dm} ms médio, pior ${r.dx} ms`);
    if (s.marks && s.marks.length) lines.push(`   últimos passos: ${s.marks.join(' › ')}`);
    if (s.hitches && s.hitches.length) { lines.push('   engasgadas (quando · duração: o que aconteceu antes):'); for (const h of s.hitches) lines.push(`     ${h}`); }
  };
  fmtS(cur, 'sessão atual');
  D.sessions.slice().reverse().forEach((s, i) => fmtS(s, `sessão -${i + 1}`));
  if (D.errors.length) {
    lines.push('erros:');
    for (const e of D.errors.slice(-10)) lines.push(`   ${new Date(e.t).toLocaleTimeString('pt-BR')} [${e.kind}] ${e.msg} ${e.stack ? '@ ' + e.stack : ''} ${JSON.stringify(e.where || {})}`);
  }
  return lines.join('\n');
}
export function crashes() { return D.sessions.filter((s) => s.crash).length; }
export function clearDiag() { D.sessions = []; D.errors = []; D.cur.fps = []; D.cur.slow = 0; D.cur.worst = 0; save(); }

export function cleanExit(why) { mark(why || 'saída limpa'); D.cur.clean = true; save(); }
