import { itemInfoHTML } from './iteminfo.js';
// Interface do Mercado de Runa
import * as Game from './game.js';
import { G } from './game.js';
import { itemDef, itemName, itemDesc, itemColor } from './rules.js';
import { itemIconURL } from './sprites.js';
import { openSheet, toast, refresh, itemRow } from './ui.js';
import { priceGuide, saleOdds, topBuyers, activeEvents, LIST_FEE } from './market.js';
import { fmt } from './util.js';

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ago = (t) => { const s = Math.max(0, (Date.now() - t) / 1000); return s < 60 ? 'agora' : s < 3600 ? `${Math.floor(s / 60)} min` : s < 86400 ? `${Math.floor(s / 3600)} h` : `${Math.floor(s / 86400)} d`; };
const KIND = { all: 'Tudo', weapon: 'Armas', shield: 'Escudos', head: 'Cabeça', armor: 'Armaduras', acc: 'Acessórios', card: 'Cartas' };
let st = { tab: 'buy', kind: 'all', q: '' };

function online(m) { const h = new Date().getHours(); const base = h >= 18 || h < 1 ? 0.55 : h < 8 ? 0.15 : 0.35; return Math.round(m.players.length * base + (Date.now() / 60000 % 7)); }

export function marketSheet(tab) {
  if (tab) st.tab = tab;
  Game.marketTick();
  const m = Game.market();
  const meta = G.state.meta;
  const tabs = [['buy', 'Comprar'], ['sell', 'Vender'], ['mine', `Meus (${m.mine.length}/${m.myMax})`], ['hist', 'Preços'], ['news', 'Notícias']];
  const ev = activeEvents(m);
  openSheet({
    title: `Mercado de Runa <small>${online(m)} aventureiros online</small>`,
    html: `<div class="mk-top"><span>Banco: <b>${fmt(meta.zeny)} z</b></span><span class="mk-dim">taxa de venda ${(m.myTax * 100).toFixed(1).replace('.0', '').replace('.', ',')}%</span></div>
      ${ev.map((e) => `<div class="mk-event">📣 ${esc(e.text)} <small>(${ago(Date.now() * 2 - e.until).replace('agora', 'menos de 1 min')} restantes)</small></div>`).join('')}
      <div class="tabs wiki-tabs">${tabs.map(([k, n]) => `<button class="tab ${k === st.tab ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div id="mk"></div>`,
    mount(b) {
      b.querySelectorAll('[data-t]').forEach((t) => t.onclick = () => marketSheet(t.dataset.t));
      const el = b.querySelector('#mk');
      ({ buy: renderBuy, sell: renderSell, mine: renderMine, hist: renderHist, news: renderNews })[st.tab](el, m);
    },
  });
}

function kindFilter(el, rerender) {
  return `<div class="wiki-filter">${Object.entries(KIND).map(([k, n]) => `<button class="wiki-chip ${st.kind === k ? 'on' : ''}" data-k="${k}">${n}</button>`).join('')}</div>`;
}
function bindKind(el, rerender) { el.querySelectorAll('[data-k]').forEach((b) => b.onclick = () => { st.kind = b.dataset.k; rerender(); }); }
const matchKind = (it) => st.kind === 'all' || itemDef(it).kind === st.kind;

// ---------------- Comprar ----------------
function renderBuy(el, m) {
  const list = m.npc.filter((l) => matchKind(l.item)).sort((a, b) => b.at - a.at);
  el.innerHTML = kindFilter() + (list.length ? `<div class="list">${list.map((l) => itemRow(l.item, `<span class="price">${fmt(l.price)} z</span><br><small class="mk-dim">${esc(l.seller)}</small>`).replace('class="row', `data-l="${l.id}" class="row`)).join('')}</div>`
    : '<div class="empty-msg">Nenhum anúncio desse tipo agora. Volte mais tarde: os aventureiros anunciam o tempo todo.</div>');
  bindKind(el, () => renderBuy(el, m));
  el.querySelectorAll('[data-l]').forEach((b) => b.onclick = () => buySheet(b.dataset.l));
}
function buySheet(id) {
  const m = Game.market();
  const l = m.npc.find((o) => o.id === id);
  if (!l) { toast('Esse anúncio acabou de sair.'); marketSheet('buy'); return; }
  const g = priceGuide(m, l.item);
  const lines = itemDesc(l.item);
  openSheet({
    title: `<span style="color:${itemColor(l.item)}">${esc(itemName(l.item))}</span>`,
    html: `<div class="ii-head"><img src="${itemIconURL(l.item)}" alt=""></div>${itemInfoHTML(l.item)}
      <div class="wiki-kv"><span>Vendedor</span><b>${esc(l.seller)}</b><span>Anunciado</span><b>há ${ago(l.at)}</b>
      <span>Preço</span><b class="price">${fmt(l.price)} z</b>${g.median ? `<span>Média recente</span><b>${fmt(g.median)} z</b>` : ''}<span>A loja paga</span><b>${fmt(g.shop)} z</b></div>
      <div class="actions2"><button class="btn" data-a="back">Voltar</button><button class="btn primary" data-a="buy">Comprar</button></div>
      <p class="note">O item vai para a mochila (ou para o Armazém, se ela estiver cheia). O zeny sai do banco.</p>`,
    mount(b) {
      b.querySelector('[data-a=back]').onclick = () => marketSheet('buy');
      b.querySelector('[data-a=buy]').onclick = () => { const e = Game.marketBuy(id); if (e) toast(e); else { toast('Comprado! 🎉'); refresh('screen'); marketSheet('buy'); } };
    },
  });
}

// ---------------- Vender ----------------
function renderSell(el, m) {
  const items = Game.marketSellables().filter(({ it }) => matchKind(it));
  el.innerHTML = `<p class="note">Escolha um item da mochila ou do armazém. Ele fica anunciado até alguém que precise dele topar o preço, mesmo com o jogo fechado.</p>` + kindFilter() +
    (items.length ? `<div class="list">${items.map(({ it, where }) => itemRow(it, where === 'storage' ? '<small class="mk-dim">armazém</small>' : '')).join('')}</div>`
      : '<div class="empty-msg">Nenhum equipamento ou carta para vender.</div>');
  bindKind(el, () => renderSell(el, m));
  el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => sellSheet(Number(b.dataset.u)));
}
function sellSheet(u) {
  const m = Game.market();
  const found = Game.marketSellables().find(({ it }) => it.uid === u);
  if (!found) { marketSheet('sell'); return; }
  const it = found.it;
  const g = priceGuide(m, it);
  const tops = topBuyers(m, it, 3);
  let price = g.suggest || Math.max(1, g.shop);
  openSheet({
    title: `Vender <span style="color:${itemColor(it)}">${esc(itemName(it))}</span>`,
    html: `<div class="ii-head"><img src="${itemIconURL(it)}" alt=""></div>${itemInfoHTML(it)}
      <div class="wiki-kv"><span>Interessados agora</span><b>${g.buyers}</b>${g.median ? `<span>Média das últimas vendas</span><b>${fmt(g.median)} z</b>` : '<span>Últimas vendas</span><b>poucas ainda</b>'}
        <span>Vende rápido por</span><b>até ${fmt(g.fast)} z</b><span>Quase ninguém paga</span><b>mais de ${fmt(g.max)} z</b><span>A loja paga</span><b>${fmt(g.shop)} z</b></div>
      ${tops.length ? `<p class="note">Quem mais quer: ${tops.map((t) => `<b>${esc(t.nick)}</b> (${esc(t.cls)} nv ${t.lv})`).join(', ')}</p>` : '<p class="note">Ninguém precisa disso agora. Talvez mais tarde, ou com um preço bem baixo.</p>'}
      <div class="mk-price"><button class="btn small" data-d="-0.1">−10%</button><input id="mk-p" class="dv-in" type="number" min="1" value="${price}"><button class="btn small" data-d="0.1">+10%</button></div>
      <div class="wiki-filter"><button class="wiki-chip" data-p="${g.fast}">Rápido</button><button class="wiki-chip" data-p="${g.suggest}">Sugerido</button><button class="wiki-chip" data-p="${Math.round((g.suggest + g.max) / 2)}">Caro</button></div>
      <p class="note" id="mk-odds"></p>
      <div class="actions2"><button class="btn" data-a="back">Voltar</button><button class="btn primary" data-a="ok">Anunciar</button></div>`,
    mount(b) {
      const inp = b.querySelector('#mk-p');
      const odds = () => {
        const p = Math.max(1, Math.floor(Number(inp.value) || 1));
        const o = saleOdds(m, it, p);
        const fee = Math.max(1, Math.floor(p * LIST_FEE));
        const time = !o.interested ? 'ninguém pagaria isso agora' : o.hours < 1 ? 'deve vender em menos de 1 hora' : o.hours < 24 ? `deve vender em cerca de ${Math.round(o.hours)} h` : 'pode demorar mais de um dia';
        b.querySelector('#mk-odds').innerHTML = `${o.interested} aventureiro${o.interested === 1 ? '' : 's'} pagaria${o.interested === 1 ? '' : 'm'} isso: ${time}. Você recebe <b>${fmt(Math.floor(p * (1 - m.myTax)))} z</b> (taxa de anúncio ${fmt(fee)} z agora).`;
      };
      inp.oninput = odds; odds();
      b.querySelectorAll('[data-d]').forEach((x) => x.onclick = () => { inp.value = Math.max(1, Math.round((Number(inp.value) || 1) * (1 + Number(x.dataset.d)))); odds(); });
      b.querySelectorAll('[data-p]').forEach((x) => x.onclick = () => { inp.value = Math.max(1, Number(x.dataset.p)); odds(); });
      b.querySelector('[data-a=back]').onclick = () => marketSheet('sell');
      b.querySelector('[data-a=ok]').onclick = () => {
        if (Game.market().mine.length >= m.myMax) { toast(`Máximo de ${m.myMax} anúncios (o Santuário libera mais).`); return; }
        const e = Game.marketList(u, Number(inp.value));
        if (e) toast(e); else { toast('Anunciado!'); refresh('screen'); marketSheet('mine'); }
      };
    },
  });
}

// ---------------- Meus anúncios ----------------
function renderMine(el, m) {
  el.innerHTML = m.mine.length ? `<div class="list">${m.mine.map((l) => { const o = saleOdds(m, l.item, l.price); return itemRow(l.item, `<span class="price">${fmt(l.price)} z</span><br><small class="mk-dim">${o.interested} interessado${o.interested === 1 ? '' : 's'} · ${ago(l.at)}</small>`).replace('class="row', `data-l="${l.id}" class="row`); }).join('')}</div>
    <p class="note">Toque num anúncio para retirá-lo (a taxa de anúncio não volta). Vendas caem direto no banco.</p>`
    : `<div class="empty-msg">Você não tem nada à venda. Use a aba Vender.</div>`;
  el.querySelectorAll('[data-l]').forEach((b) => b.onclick = () => {
    const l = m.mine.find((o) => o.id === b.dataset.l);
    if (!l) return;
    openSheet({ title: 'Retirar anúncio?', center: true, html: `<p style="line-height:1.5">${esc(itemName(l.item))} volta para a mochila (ou para o Armazém).</p><div class="actions2"><button class="btn" data-a="no">Manter</button><button class="btn primary" data-a="ok">Retirar</button></div>`,
      mount(x) { x.querySelector('[data-a=no]').onclick = () => marketSheet('mine'); x.querySelector('[data-a=ok]').onclick = () => { const e = Game.marketCancel(l.id); if (e) toast(e); marketSheet('mine'); }; } });
  });
}

// ---------------- Preços ----------------
function renderHist(el, m) {
  const q = st.q.trim().toLowerCase();
  const rows = [...m.history].reverse().filter((h) => !q || h.name.toLowerCase().includes(q)).slice(0, 60);
  el.innerHTML = `<input class="dv-in wiki-search" placeholder="Buscar item ou carta" value="${esc(st.q)}">
    ${rows.length ? `<table class="wiki-t mk-hist"><tbody>${rows.map((h) => `<tr><td>${ago(h.at)}</td><td>${esc(h.name)}</td><td class="price">${fmt(h.price)} z</td></tr>`).join('')}</tbody></table>` : '<div class="empty-msg">Nenhuma venda registrada ainda.</div>'}`;
  const inp = el.querySelector('.wiki-search');
  inp.oninput = () => { st.q = inp.value; const pos = inp.selectionStart; renderHist(el, m); const n = el.querySelector('.wiki-search'); n.focus(); n.setSelectionRange(pos, pos); };
}

// ---------------- Notícias ----------------
function renderNews(el, m) {
  el.innerHTML = m.news.length ? `<div class="mk-news">${m.news.slice(0, 40).map((n) => `<div class="mk-n ${n.kind}"><small>${ago(n.at)}</small> ${esc(n.text)}</div>`).join('')}</div>` : '<div class="empty-msg">Nada ainda.</div>';
}

// aviso de vendas (ao abrir o jogo e enquanto joga)
export function announceSales() {
  const m = Game.market();
  const u = m.unread || [];
  if (!u.length) return;
  m.unread = [];
  Game.save();
  if (u.length === 1) toast(`💰 ${u[0].buyer} comprou ${itemName(u[0].item)}: +${fmt(u[0].net)} z no banco`, 3500);
  else toast(`💰 ${u.length} itens vendidos no mercado: +${fmt(u.reduce((a, s) => a + s.net, 0))} z no banco`, 3500);
}
