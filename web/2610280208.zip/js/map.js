// Geração de masmorra, campo de visão e caminhos
import { rnd, chance, pick, DIRS8, DIRS4 } from './util.js';
import { themeForFloor, THEMES } from './data.js';

export const T = { WALL: 0, FLOOR: 1, DOOR: 2, STAIRS: 3, LIQUID: 4, CHASM: 5, PORTAL: 6 };

export const passable = (t) => t !== T.WALL && t !== T.CHASM;
export const transparent = (t) => t !== T.WALL;

export function inb(m, x, y) { return x >= 0 && y >= 0 && x < m.w && y < m.h; }
export function tileAt(m, x, y) { return inb(m, x, y) ? m.t[y * m.w + x] : T.WALL; }
export function setTile(m, x, y, v) { if (inb(m, x, y)) m.t[y * m.w + x] = v; }

function carveRoom(m, r) {
  for (let y = r.y; y < r.y + r.h; y++) for (let x = r.x; x < r.x + r.w; x++) setTile(m, x, y, T.FLOOR);
}

// Sala orgânica: elipse com borda irregular (sem cantos retos)
function carveBlobRoom(m, r) {
  const cx = r.x + (r.w - 1) / 2, cy = r.y + (r.h - 1) / 2, rx = r.w / 2 + 0.3, ry = r.h / 2 + 0.3;
  const k = [Math.random() * 6, Math.random() * 6, Math.random() * 6];
  for (let y = r.y - 1; y <= r.y + r.h; y++) for (let x = r.x - 1; x <= r.x + r.w; x++) {
    const dx = (x - cx) / rx, dy = (y - cy) / ry;
    const a = Math.atan2(dy, dx);
    const wob = 1 + 0.16 * Math.sin(a * 3 + k[0]) + 0.1 * Math.sin(a * 5 + k[1]) + 0.06 * Math.sin(a * 2 + k[2]);
    if (dx * dx + dy * dy <= wob * wob && x > 0 && y > 0 && x < m.w - 1 && y < m.h - 1) setTile(m, x, y, T.FLOOR);
  }
}

// Corredor sinuoso: anda em direção ao alvo com desvios, às vezes mais largo
function carveWindy(m, ax, ay, bx, by) {
  let x = ax, y = ay, guard = 0;
  const wide = Math.random() < 0.35;
  while ((x !== bx || y !== by) && guard++ < 400) {
    setTile(m, x, y, T.FLOOR);
    if (wide) setTile(m, x + 1, y, T.FLOOR);
    const dx = Math.sign(bx - x), dy = Math.sign(by - y);
    const r = Math.random();
    if (r < 0.2) { // desvio
      if (dx && Math.random() < 0.5) y += Math.random() < 0.5 ? 1 : -1; else if (dy) x += Math.random() < 0.5 ? 1 : -1;
    } else if (dx && (!dy || Math.abs(bx - x) > Math.abs(by - y) ? r < 0.85 : r < 0.4)) x += dx;
    else if (dy) y += dy; else x += dx;
    x = Math.max(1, Math.min(m.w - 2, x)); y = Math.max(1, Math.min(m.h - 2, y));
  }
  setTile(m, bx, by, T.FLOOR);
}

// Suaviza as bordas (autômato celular) sem mexer em escadas/portais
function smooth(m, passes = 2) {
  for (let p = 0; p < passes; p++) {
    const nt = m.t.slice();
    for (let y = 1; y < m.h - 1; y++) for (let x = 1; x < m.w - 1; x++) {
      const i = y * m.w + x;
      let n = 0;
      for (let yy = -1; yy <= 1; yy++) for (let xx = -1; xx <= 1; xx++) if ((xx || yy) && m.t[(y + yy) * m.w + x + xx] !== T.WALL) n++;
      if (m.t[i] === T.WALL && n >= 6) nt[i] = T.FLOOR;          // preenche reentrâncias
      else if (m.t[i] === T.FLOOR && n <= 1) nt[i] = T.WALL;     // remove pontas soltas
    }
    m.t = nt;
  }
}

// Mantém só a parte conectada à entrada
function pruneUnreachable(m, sx, sy) {
  const d = bfs(m, sx, sy);
  for (let i = 0; i < m.t.length; i++) if (passable(m.t[i]) && d[i] === -1) m.t[i] = T.WALL;
}

function carveCorridor(m, ax, ay, bx, by) {
  let x = ax, y = ay;
  const horizFirst = Math.random() < 0.5;
  const stepX = () => { while (x !== bx) { setTile(m, x, y, T.FLOOR); x += Math.sign(bx - x); } };
  const stepY = () => { while (y !== by) { setTile(m, x, y, T.FLOOR); y += Math.sign(by - y); } };
  if (horizFirst) { stepX(); stepY(); } else { stepY(); stepX(); }
  setTile(m, x, y, T.FLOOR);
}

const center = (r) => ({ x: r.x + Math.floor(r.w / 2), y: r.y + Math.floor(r.h / 2) });

function overlaps(a, b, pad = 1) {
  return a.x - pad < b.x + b.w && a.x + a.w + pad > b.x && a.y - pad < b.y + b.h && a.y + a.h + pad > b.y;
}

export function bfs(m, sx, sy, blockFn) {
  const d = new Int16Array(m.w * m.h).fill(-1);
  const q = [sx, sy];
  d[sy * m.w + sx] = 0;
  let head = 0;
  while (head < q.length) {
    const x = q[head++], y = q[head++];
    const cd = d[y * m.w + x];
    for (const [dx, dy] of DIRS8) {
      const nx = x + dx, ny = y + dy;
      if (!inb(m, nx, ny)) continue;
      const i = ny * m.w + nx;
      if (d[i] !== -1) continue;
      if (!passable(m.t[i])) continue;
      if (blockFn && blockFn(nx, ny)) continue;
      d[i] = cd + 1;
      q.push(nx, ny);
    }
  }
  return d;
}

function connectedOk(m, sx, sy) {
  const d = bfs(m, sx, sy);
  for (let i = 0; i < m.t.length; i++) if (passable(m.t[i]) && d[i] === -1) return false;
  return true;
}

function blob(cx, cy, r) {
  const pts = [];
  for (let y = -r; y <= r; y++) for (let x = -r; x <= r; x++) {
    if (x * x + y * y <= r * r + rnd(-1, 1)) pts.push([cx + x, cy + y]);
  }
  return pts;
}

export function generateFloor(floor) {
  const theme = themeForFloor(floor);
  const themeIdx = THEMES.indexOf(theme);
  const isBoss = floor % 5 === 0;
  const W = 40, H = 40;
  const m = { w: W, h: H, t: new Array(W * H).fill(T.WALL), seen: new Array(W * H).fill(0),
    decor: new Array(W * H).fill(0), lights: [], rooms: [], theme: themeIdx, floor, isBoss };

  if (isBoss) {
    const arena = { x: 10, y: 6, w: 20, h: 16 };
    const entry = { x: 16, y: 28, w: 8, h: 6 };
    carveBlobRoom(m, arena); carveBlobRoom(m, entry);
    carveRoom(m, { x: 18, y: 6, w: 5, h: 15 }); carveRoom(m, { x: 12, y: 10, w: 17, h: 7 }); // miolo da arena garantido
    carveWindy(m, 20, 29, 20, 20);
    m.rooms = [entry, arena];
    // Pilares decorativos na arena
    for (const [px, py] of [[13, 9], [26, 9], [13, 18], [26, 18]]) setTile(m, px, py, T.WALL);
    m.start = { x: 20, y: 31 };
    m.bossSpot = { x: 20, y: 13 };
    m.stairs = null;
    for (const [lx, ly] of [[10, 5], [29, 5], [16, 27], [23, 27]]) m.lights.push({ x: lx, y: ly });
    for (const [lx, ly] of [[10, 5], [29, 5], [16, 27], [23, 27]]) m.decor[ly * W + lx] = 'torch';
  } else {
    const target = rnd(9, 13);
    let tries = 0;
    while (m.rooms.length < target && tries++ < 400) {
      const r = { w: rnd(4, 9), h: rnd(4, 8) };
      r.x = rnd(1, W - r.w - 2);
      r.y = rnd(1, H - r.h - 2);
      if (m.rooms.some((o) => overlaps(o, r, 2))) continue;
      m.rooms.push(r);
    }
    // castelo mantém salas retas (é construção); os outros biomas ganham salas e corredores orgânicos
    const built = !!theme.built;
    for (const r of m.rooms) (built ? carveRoom : carveBlobRoom)(m, r);
    // conecta em cadeia (ordenado por posição) + extras
    const sorted = [...m.rooms].sort((a, b) => (a.x + a.y * 0.6) - (b.x + b.y * 0.6));
    const link = built ? carveCorridor : carveWindy;
    for (let i = 1; i < sorted.length; i++) {
      const a = center(sorted[i - 1]), b = center(sorted[i]);
      link(m, a.x, a.y, b.x, b.y);
    }
    for (let k = 0; k < 3; k++) {
      const a = center(pick(m.rooms)), b = center(pick(m.rooms));
      link(m, a.x, a.y, b.x, b.y);
    }
    const startRoom = sorted[0];
    m.start = center(startRoom);
    if (!built) smooth(m, 2);
    setTile(m, m.start.x, m.start.y, T.FLOOR);
    pruneUnreachable(m, m.start.x, m.start.y);
    m.rooms = m.rooms.filter((r) => passable(tileAt(m, center(r).x, center(r).y)));
    const d = bfs(m, m.start.x, m.start.y);
    let best = null, bd = -1;
    for (const r of m.rooms) {
      const c = center(r);
      const v = d[c.y * W + c.x];
      if (v > bd) { bd = v; best = c; }
    }
    m.stairs = best;
    setTile(m, best.x, best.y, T.STAIRS);

    // Líquidos e abismos decorativos
    for (const r of m.rooms) {
      if (r === startRoom) continue;
      if (r.w >= 7 && r.h >= 6 && chance(35)) {
        const c = center(r);
        const deep = theme.liquid === 'lava' || chance(25);
        const pts = blob(c.x + rnd(-1, 1), c.y + rnd(-1, 1), rnd(1, 2));
        const backup = pts.map(([x, y]) => tileAt(m, x, y));
        let ok = true;
        for (const [x, y] of pts) {
          if (x <= r.x || y <= r.y || x >= r.x + r.w - 1 || y >= r.y + r.h - 1) continue;
          if (tileAt(m, x, y) === T.STAIRS) { ok = false; continue; }
          setTile(m, x, y, deep ? T.CHASM : T.LIQUID);
        }
        if (!ok || (deep && !connectedOk(m, m.start.x, m.start.y))) {
          pts.forEach(([x, y], i) => setTile(m, x, y, backup[i]));
        } else if (deep && theme.liquid === 'lava') {
          m.lights.push({ x: c.x, y: c.y, color: '#ff6a2a', r: 4 });
        }
      } else if (r.w >= 8 && r.h >= 7 && chance(30)) {
        // pilares
        const saved = [];
        for (let y = r.y + 2; y < r.y + r.h - 2; y += 3) for (let x = r.x + 2; x < r.x + r.w - 2; x += 3) {
          if (tileAt(m, x, y) === T.FLOOR) { saved.push([x, y]); setTile(m, x, y, T.WALL); }
        }
        if (!connectedOk(m, m.start.x, m.start.y)) saved.forEach(([x, y]) => setTile(m, x, y, T.FLOOR));
      }
    }
    // Tochas: paredes com chão logo abaixo
    for (const r of m.rooms) {
      if (!chance(70)) continue;
      const tx = rnd(r.x, r.x + r.w - 1), ty = r.y - 1;
      if (tileAt(m, tx, ty) === T.WALL && tileAt(m, tx, ty + 1) !== T.WALL) {
        m.decor[ty * W + tx] = 'torch';
        m.lights.push({ x: tx, y: ty });
      }
    }
  }
  // Decoração de chão
  for (let i = 0; i < m.t.length; i++) {
    if (m.t[i] === T.FLOOR && !m.decor[i] && chance(9)) m.decor[i] = pick(theme.decor);
  }
  return m;
}

export function randomFloorTile(m, avoidFn) {
  for (let k = 0; k < 2000; k++) {
    const x = rnd(1, m.w - 2), y = rnd(1, m.h - 2);
    const t = tileAt(m, x, y);
    if ((t === T.FLOOR || t === T.LIQUID) && !(avoidFn && avoidFn(x, y))) return { x, y };
  }
  return null;
}

// ---------------- Campo de visão (shadowcasting) ----------------
const MULT = [
  [1, 0, 0, -1, -1, 0, 0, 1],
  [0, 1, -1, 0, 0, -1, 1, 0],
  [0, 1, 1, 0, 0, -1, -1, 0],
  [1, 0, 0, 1, -1, 0, 0, -1],
];

export function computeFov(m, ox, oy, radius) {
  const vis = new Uint8Array(m.w * m.h);
  vis[oy * m.w + ox] = 1;
  const castLight = (row, start, end, xx, xy, yx, yy) => {
    if (start < end) return;
    let newStart = 0;
    for (let j = row; j <= radius; j++) {
      let dx = -j - 1, dy = -j, blocked = false;
      while (dx <= 0) {
        dx += 1;
        const X = ox + dx * xx + dy * xy, Y = oy + dx * yx + dy * yy;
        const lSlope = (dx - 0.5) / (dy + 0.5), rSlope = (dx + 0.5) / (dy - 0.5);
        if (start < rSlope) continue;
        else if (end > lSlope) break;
        if (dx * dx + dy * dy <= radius * radius + radius && inb(m, X, Y)) vis[Y * m.w + X] = 1;
        const opaque = !transparent(tileAt(m, X, Y));
        if (blocked) {
          if (opaque) { newStart = rSlope; continue; }
          blocked = false; start = newStart;
        } else if (opaque && j < radius) {
          blocked = true;
          castLight(j + 1, start, lSlope, xx, xy, yx, yy);
          newStart = rSlope;
        }
      }
      if (blocked) break;
    }
  };
  for (let o = 0; o < 8; o++) castLight(1, 1.0, 0.0, MULT[0][o], MULT[1][o], MULT[2][o], MULT[3][o]);
  return vis;
}

// Linha de visão para projéteis (Bresenham)
export function lineTiles(ax, ay, bx, by) {
  const pts = [];
  let x = ax, y = ay;
  const dx = Math.abs(bx - ax), dy = -Math.abs(by - ay);
  const sx = ax < bx ? 1 : -1, sy = ay < by ? 1 : -1;
  let err = dx + dy;
  while (true) {
    pts.push([x, y]);
    if (x === bx && y === by) break;
    const e2 = 2 * err;
    if (e2 >= dy) { err += dy; x += sx; }
    if (e2 <= dx) { err += dx; y += sy; }
  }
  return pts;
}

export function hasLos(m, ax, ay, bx, by) {
  const pts = lineTiles(ax, ay, bx, by);
  for (let i = 1; i < pts.length - 1; i++) if (!transparent(tileAt(m, pts[i][0], pts[i][1]))) return false;
  return true;
}

// Caminho para o jogador (tiles conhecidos)
export function findPath(m, sx, sy, tx, ty, blockFn) {
  if (sx === tx && sy === ty) return [];
  const prev = new Int32Array(m.w * m.h).fill(-1);
  const q = [sx, sy];
  prev[sy * m.w + sx] = sy * m.w + sx;
  let head = 0, found = false;
  while (head < q.length) {
    const x = q[head++], y = q[head++];
    if (x === tx && y === ty) { found = true; break; }
    for (const [dx, dy] of DIRS8) {
      const nx = x + dx, ny = y + dy;
      if (!inb(m, nx, ny)) continue;
      const i = ny * m.w + nx;
      if (prev[i] !== -1) continue;
      if (!passable(m.t[i]) || !m.seen[i]) continue;
      if (blockFn && !(nx === tx && ny === ty) && blockFn(nx, ny)) continue;
      prev[i] = y * m.w + x;
      q.push(nx, ny);
    }
  }
  if (!found) return null;
  const path = [];
  let cur = ty * m.w + tx;
  while (cur !== sy * m.w + sx) {
    path.push({ x: cur % m.w, y: Math.floor(cur / m.w) });
    cur = prev[cur];
  }
  return path.reverse();
}

export { DIRS4 };
