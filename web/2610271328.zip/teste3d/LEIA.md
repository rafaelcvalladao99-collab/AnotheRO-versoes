Página temporária de teste de desempenho do cenário 3D (HD-2D).
Aberta pelo menu Opções → "Teste do cenário 3D". Mede os quadros por segundo em duas cenas
(Castelo e Cemitério) com três qualidades. Sai do jogo quando o motor 3D de verdade entrar.
Modelos: KayKit Dungeon Remastered e KayKit Halloween Bits (Kay Lousberg, CC0). three.js (MIT).
