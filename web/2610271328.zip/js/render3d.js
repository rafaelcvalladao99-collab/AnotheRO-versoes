// Cenário 3D (HD-2D): chão e paredes em 3D com a arte LPC, heróis e monstros em pé (sprites),
// luz de tochas, sombras, brilho e desfoque nas bordas. Os efeitos, números e barras continuam
// no canvas 2D por cima (render.js), que usa a mesma projeção desta câmera.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export const PITCH = 55 * Math.PI / 180;           // inclinação da câmera
export const SIN_P = Math.sin(PITCH), COS_P = Math.cos(PITCH);
const PX = 1.3 / 64;                               // 1 pixel de sprite em unidades do mundo (64 px = 1,3 casa)
const WALL_H = 1.0;

export const QUALITY = {
  alta: { pr: 2, shadow: 2048, bloom: true },
  media: { pr: 1.5, shadow: 1024, bloom: true },
  baixa: { pr: 1, shadow: 0, bloom: false },
};

const W3 = {
  ok: false, renderer: null, scene: null, cam: null, composer: null, bloom: null, tilt: null, q: 'media',
  floorKey: null, world: null, ents: new Map(), texCache: new Map(), models: {}, lastFog: 0,
};

const TiltShift = {
  uniforms: { tDiffuse: { value: null }, res: { value: new THREE.Vector2(1, 1) }, focus: { value: 0.5 }, band: { value: 0.24 }, amount: { value: 5.0 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform vec2 res; uniform float focus, band, amount; varying vec2 vUv;
  void main(){ float d = max(0.0, abs(vUv.y - focus) - band); float k = smoothstep(0.0, 0.35, d) * amount; vec4 c = vec4(0.0); float tw = 0.0;
    for (int i = 0; i < 12; i++) { float a = float(i) * 2.39996; float r = sqrt(float(i) + 0.5) / 3.5; vec2 o = vec2(cos(a), sin(a)) * r * k / res; float w = 1.0 - r * 0.5; c += texture2D(tDiffuse, vUv + o) * w; tw += w; }
    c /= tw; vec2 q = vUv - 0.5; float v = 1.0 - 0.38 * dot(q, q) * 2.2; gl_FragColor = vec4(c.rgb * v, c.a); }`,
};

export function init3d(canvas2d, quality = 'media') {
  try {
    const r = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.15;
    r.domElement.id = 'gl3d';
    Object.assign(r.domElement.style, { position: 'fixed', inset: '0', zIndex: '0', pointerEvents: 'none' });
    canvas2d.parentNode.insertBefore(r.domElement, canvas2d);
    W3.renderer = r;
  } catch (e) { console.warn('3D indisponível', e); return false; }
  W3.scene = new THREE.Scene();
  W3.cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 200);
  W3.ok = true;
  setQuality(quality);
  const load = (n) => new Promise((ok) => new GLTFLoader().load(`assets/3d/${n}.gltf.glb`, (g) => ok(g.scene), undefined, () => ok(null)));
  for (const n of ['torch_mounted', 'barrel_large', 'box_small', 'candle_lit']) load(n).then((m) => { W3.models[n] = m; W3.floorKey = null; });
  return true;
}
export const ready3d = () => W3.ok;
export function show3d(on) { if (W3.renderer) W3.renderer.domElement.style.display = on ? 'block' : 'none'; }

export function setQuality(q) {
  W3.q = QUALITY[q] ? q : 'media';
  if (!W3.ok) return;
  const Q = QUALITY[W3.q];
  W3.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, Q.pr));
  W3.renderer.shadowMap.enabled = Q.shadow > 0;
  W3.renderer.shadowMap.type = THREE.PCFShadowMap;
  W3.composer = null; W3.floorKey = null;   // reconstrói tudo com a nova qualidade
}

function buildComposer(W, H) {
  const Q = QUALITY[W3.q];
  const c = new EffectComposer(W3.renderer);
  c.addPass(new RenderPass(W3.scene, W3.cam));
  if (Q.bloom) c.addPass(new UnrealBloomPass(new THREE.Vector2(W, H), 0.32, 0.45, 0.86));
  W3.tilt = new ShaderPass(TiltShift); c.addPass(W3.tilt);
  c.addPass(new OutputPass());
  W3.composer = c; W3.size = `${W}x${H}`;
  c.setSize(W, H);
}

const pxTex = (src) => { const t = src.isTexture ? src : new THREE.CanvasTexture(src); t.magFilter = THREE.NearestFilter; t.minFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace; t.generateMipmaps = false; return t; };
function texOf(key, src) {
  let t = W3.texCache.get(key);
  if (!t) { t = pxTex(src); W3.texCache.set(key, t); }
  return t;
}
const hexColor = (h) => new THREE.Color(h);

// ---------------- Montagem do andar ----------------
// env: { m, th, theme, ground (canvas com o chão desenhado), wallTex: {top, side}, natural, trees }
function buildFloor(env) {
  const old = W3.world;
  if (old) { W3.scene.remove(old.group); old.group.traverse((o) => { if (o.geometry) o.geometry.dispose(); for (const mt of [].concat(o.material || [])) if (mt.map && !W3.texCache.has(mt.map.__key)) mt.dispose(); }); }
  for (const e of W3.ents.values()) W3.scene.remove(e.mesh);
  W3.ents.clear();
  const { m, th } = env;
  const g = new THREE.Group();
  const Q = QUALITY[W3.q];
  // fundo e névoa da cor do bioma
  W3.scene.background = hexColor('#07080c');
  // chão: uma textura só com o andar inteiro desenhado (texturas LPC, líquidos, escadas, decoração rasteira)
  const gt = pxTex(new THREE.CanvasTexture(env.ground));
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(m.w, m.h), new THREE.MeshStandardMaterial({ map: gt, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.position.set(m.w / 2, 0, m.h / 2); ground.receiveShadow = true; g.add(ground);
  // paredes: caixas com o topo e a face do LPC
  const walls = [];
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) if (m.t[y * m.w + x] === env.WALL) walls.push([x, y]);
  const side = new THREE.MeshStandardMaterial({ map: pxTex(env.wallTex.side), roughness: 1 });
  const top = new THREE.MeshStandardMaterial({ map: pxTex(env.wallTex.top), roughness: 1 });
  const box = new THREE.BoxGeometry(1, WALL_H, 1);
  const wm = new THREE.InstancedMesh(box, [side, side, top, top, side, side], walls.length);
  wm.castShadow = true; wm.receiveShadow = true;
  const mtx = new THREE.Matrix4();
  walls.forEach(([x, y], i) => { mtx.makeTranslation(x + 0.5, WALL_H / 2, y + 0.5); wm.setMatrixAt(i, mtx); wm.setColorAt(i, new THREE.Color(1, 1, 1)); });
  wm.instanceMatrix.needsUpdate = true; if (wm.instanceColor) wm.instanceColor.needsUpdate = true;
  g.add(wm);
  // árvores dos Campos (em pé sobre as paredes que dão para o chão)
  const props = [];
  if (env.trees && env.trees.length) {
    for (const [x, y] of walls) {
      const open = [[0, 1], [0, -1], [1, 0], [-1, 0]].some(([dx, dy]) => { const t = m.t[(y + dy) * m.w + x + dx]; return t !== undefined && t !== env.WALL; });
      if (!open) continue;
      const h = Math.abs((x * 374761393 + y * 668265263) | 0);
      const img = env.trees[(h >>> 3) % env.trees.length];
      const tex = texOf('tree' + ((h >>> 3) % env.trees.length), img);
      const w = 1.55, hh = w * img.height / img.width;
      const mat = new THREE.MeshStandardMaterial({ map: tex, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 1 });
      const pl = new THREE.Mesh(new THREE.PlaneGeometry(w, hh), mat);
      pl.castShadow = true;
      pl.userData = { x, y, bill: true, foot: [x + 0.5, y + 0.9], hh, scaleY: 1 };
      g.add(pl); props.push(pl);
    }
  }
  // tochas nas paredes, barris, caixas, velas
  const torchSpots = [];
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const d = m.decor[y * m.w + x]; if (!d) continue;
    if (d === 'torch' && m.t[y * m.w + x] === env.WALL && m.t[(y + 1) * m.w + x] !== env.WALL) torchSpots.push([x, y]);
    const model = { barrel: 'barrel_large', crate: 'box_small', candle: 'candle_lit' }[d];
    if (model && W3.models[model]) {
      const o = W3.models[model].clone(true); const s = model === 'candle_lit' ? 0.5 : 0.28;
      o.scale.setScalar(s); o.position.set(x + 0.5, 0, y + 0.5); o.rotation.y = ((x * 7 + y * 13) % 8) * 0.4;
      o.traverse((k) => { if (k.isMesh) { k.castShadow = true; k.receiveShadow = true; } });
      o.userData = { x, y, prop: true }; g.add(o); props.push(o);
    }
  }
  for (const [x, y] of torchSpots) {
    if (!W3.models.torch_mounted) break;
    const o = W3.models.torch_mounted.clone(true); o.scale.setScalar(0.3); o.position.set(x + 0.5, 0.35, y + 1.02);
    o.userData = { x, y, prop: true }; g.add(o); props.push(o);
    const fl = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), new THREE.MeshBasicMaterial({ color: hexColor(th.light), toneMapped: false }));
    fl.material.color.multiplyScalar(2.2); fl.position.set(x + 0.5, 0.86, y + 1.12); fl.userData = { x, y, prop: true, flame: true }; g.add(fl); props.push(fl);
  }
  // luzes: ambiente do bioma, luz do herói, tochas (as mais próximas), lua/sol com sombra
  const amb = new THREE.HemisphereLight(0x9aa8d8, 0x201810, 0.55); g.add(amb);
  const sun = new THREE.DirectionalLight(hexColor(th.light).lerp(new THREE.Color(0xffffff), 0.6), 0.55);
  sun.castShadow = Q.shadow > 0;
  if (Q.shadow) { sun.shadow.mapSize.set(Q.shadow, Q.shadow); sun.shadow.bias = -0.0015; Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -14, near: 1, far: 60 }); }
  g.add(sun); g.add(sun.target);
  const heroLight = new THREE.PointLight(hexColor(th.light), 9, 9, 1.6); g.add(heroLight);
  const pool = []; for (let i = 0; i < 6; i++) { const l = new THREE.PointLight(hexColor(th.light), 0, 6, 1.6); g.add(l); pool.push(l); }
  // névoa de guerra: textura com um texel por casa, suavizada
  const fogData = new Uint8Array(m.w * m.h * 4);
  const fogTex = new THREE.DataTexture(fogData, m.w, m.h, THREE.RGBAFormat);
  fogTex.magFilter = THREE.LinearFilter; fogTex.minFilter = THREE.LinearFilter; fogTex.flipY = false; fogTex.needsUpdate = true;
  const fog = new THREE.Mesh(new THREE.PlaneGeometry(m.w, m.h), new THREE.MeshBasicMaterial({ color: 0x06050e, alphaMap: fogTex, transparent: true, depthWrite: false }));
  fog.rotation.x = -Math.PI / 2; fog.position.set(m.w / 2, 0.02, m.h / 2); fog.renderOrder = 2; g.add(fog);
  // alphaMap usa o canal verde
  W3.scene.add(g);
  W3.world = { group: g, m, walls, wm, props, sun, heroLight, pool, fogData, fogTex, theme: env.theme, lights: env.lights || [] };
}

// visibilidade: o que nunca foi visto some; o que já foi visto fica escuro
function updateFog(m, fov) {
  const w = W3.world; const d = w.fogData;
  // a textura cresce para cima e o mapa para baixo: linha y vai para a linha (h-1-y)
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const i = y * m.w + x, o = ((m.h - 1 - y) * m.w + x) * 4;
    const a = !m.seen[i] ? 255 : fov[i] ? 0 : 150;
    d[o] = d[o + 1] = d[o + 2] = a; d[o + 3] = 255;
  }
  w.fogTex.needsUpdate = true;
  const mtx = new THREE.Matrix4(), c = new THREE.Color();
  w.walls.forEach(([x, y], k) => {
    const i = y * m.w + x;
    if (!m.seen[i]) mtx.makeScale(0, 0, 0); else mtx.makeTranslation(x + 0.5, WALL_H / 2, y + 0.5);
    w.wm.setMatrixAt(k, mtx);
    c.setScalar(fov[i] ? 1 : 0.38); w.wm.setColorAt(k, c);
  });
  w.wm.instanceMatrix.needsUpdate = true; if (w.wm.instanceColor) w.wm.instanceColor.needsUpdate = true;
  for (const p of w.props) {
    const i = p.userData.y * m.w + p.userData.x;
    p.visible = !!m.seen[i];
  }
}

// ---------------- Sprites (heróis e monstros) ----------------
const camUp = new THREE.Vector3(0, COS_P, -SIN_P);
function spriteMesh(key, tex, wpx, hpx) {
  const mat = new THREE.MeshStandardMaterial({ map: tex, emissiveMap: tex, emissive: 0xffffff, emissiveIntensity: 0.42, color: 0xa0a0a0, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 1 });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(wpx * PX, hpx * PX), mat);
  mesh.castShadow = true; mesh.quaternion.copy(W3.cam.quaternion);
  W3.scene.add(mesh);
  return { mesh, key };
}
// coloca o sprite com o ponto "pé" (fx, fy em pixels da imagem) sobre o chão (gx, gz), mais um deslocamento na tela (dy em casas)
function placeSprite(mesh, wpx, hpx, fxp, fyp, gx, gz, upTiles = 0) {
  const ox = (wpx / 2 - fxp) * PX, oy = (fyp - hpx / 2) * PX + upTiles;
  mesh.position.set(gx + ox, 0, gz).addScaledVector(camUp, oy);
  mesh.quaternion.copy(W3.cam.quaternion);
}

// ents: [{id, kind:'hero', img, sx, sy, cell, feet, x, y, flash, alpha}] ou [{id, kind:'mon', canvas, type, x, y, up, sq, flash}]
function syncEntities(list, now) {
  const seen = new Set();
  for (const e of list) {
    seen.add(e.id);
    let s = W3.ents.get(e.id);
    if (e.kind === 'hero') {
      if (!e.img) continue;
      const key = 'h:' + e.img.src;
      if (!s || s.key !== key) {
        if (s) W3.scene.remove(s.mesh);
        const t = texOf(key, e.img).clone(); t.needsUpdate = true;
        t.repeat.set(e.cell / e.img.width, e.cell / e.img.height);
        s = spriteMesh(key, t, e.cell, e.cell); W3.ents.set(e.id, s);
      }
      const t = s.mesh.material.map;
      t.offset.set(e.sx / e.img.width, 1 - (e.sy + e.cell) / e.img.height);
      placeSprite(s.mesh, e.cell, e.cell, e.cell / 2, e.feet, e.x + 0.5, e.y + 0.78);
    } else {
      if (!e.canvas || !e.canvas.width) continue;
      const key = 'm:' + e.type;
      if (!s || s.key !== key) {
        if (s) W3.scene.remove(s.mesh);
        s = spriteMesh(key, texOf(key, e.canvas), e.canvas.width, e.canvas.height); W3.ents.set(e.id, s);
      }
      const S = e.canvas.width;
      s.mesh.scale.set(1 / (e.sq || 1), e.sq || 1, 1);
      placeSprite(s.mesh, S, S, S / 2, S * 0.97, e.x + 0.5, e.y + 0.78, e.up || 0);
    }
    const mat = s.mesh.material;
    mat.emissiveIntensity = e.flash ? 1.6 : 0.42;
    mat.transparent = e.alpha < 1; mat.opacity = e.alpha ?? 1;
  }
  for (const [id, s] of W3.ents) if (!seen.has(id)) { W3.scene.remove(s.mesh); W3.ents.delete(id); }
}

// ---------------- Quadro ----------------
// view: { camX, camY, TS, W, H, viewCY, shake:[x,y], now, hero:{x,y}, fov, envFn }
export function render3d(view) {
  if (!W3.ok) return;
  const { m } = view;
  const R3 = W3.renderer;
  if (R3.domElement.width !== Math.round(view.W * R3.getPixelRatio()) || !W3.composer || W3.size !== `${view.W}x${view.H}`) {
    R3.setSize(view.W, view.H);
    buildComposer(view.W, view.H);
  }
  const key = m;
  if (W3.floorKey !== key || !W3.world || W3.world.m !== m) { buildFloor(view.envFn()); W3.floorKey = key; W3.lastFog = -1; }
  // câmera ortográfica inclinada: um tile = TS pixels na largura e TS*sen(inclinação) na altura
  const cam = W3.cam, TS = view.TS;
  cam.left = -view.W / 2 / TS; cam.right = view.W / 2 / TS;
  cam.top = view.viewCY / TS; cam.bottom = -(view.H - view.viewCY) / TS;
  const tx = view.camX + 0.5 - view.shake[0] / TS, tz = view.camY + 0.5 - view.shake[1] / TS / SIN_P;
  const dir = new THREE.Vector3(0, -SIN_P, -COS_P);
  cam.position.set(tx, 0, tz).addScaledVector(dir, -60);
  cam.up.set(0, 1, 0); cam.lookAt(tx, 0, tz);
  cam.updateProjectionMatrix();
  // névoa de guerra: atualiza quando o campo de visão muda
  if (view.fovStamp !== W3.lastFog) { updateFog(m, view.fov); W3.lastFog = view.fovStamp; }
  // luzes perto do herói
  const w = W3.world, t = view.now / 1000;
  w.heroLight.position.set(view.hero.x + 0.5, 1.6, view.hero.y + 0.6);
  w.sun.position.set(tx - 6, 14, tz + 6); w.sun.target.position.set(tx, 0, tz);
  const near = w.lights.filter((l) => m.seen[l.y * m.w + l.x]).map((l) => [l, Math.hypot(l.x - view.hero.x, l.y - view.hero.y)]).sort((a, b) => a[1] - b[1]);
  w.pool.forEach((pl, i) => {
    const e = near[i];
    if (!e || e[1] > 13) { pl.intensity = 0; return; }
    const l = e[0];
    pl.position.set(l.x + 0.5, 1.1, l.y + 0.7);
    if (l.color) pl.color.set(l.color);
    pl.distance = (l.r || 3.5) * 1.6;
    pl.intensity = 6 * (0.88 + 0.12 * Math.sin(t * 9 + l.x * 3));
  });
  for (const p of w.props) if (p.userData.bill) {
    p.quaternion.copy(cam.quaternion);
    const [fx, fz] = p.userData.foot; p.position.set(fx, 0, fz).addScaledVector(camUp, p.userData.hh * 0.47);
  } else if (p.userData.flame) p.scale.setScalar(1 + 0.18 * Math.sin(t * 13 + p.userData.x));
  syncEntities(view.ents, view.now);
  if (W3.tilt) { W3.tilt.uniforms.res.value.set(view.W * R3.getPixelRatio(), view.H * R3.getPixelRatio()); W3.tilt.uniforms.focus.value = 1 - view.viewCY / view.H; }
  W3.composer.render();
}

export function clearFloor3d() { W3.floorKey = null; }
