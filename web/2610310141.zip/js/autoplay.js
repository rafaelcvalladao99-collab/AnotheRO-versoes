// Jogo automático: o mesmo "jogador esperto" dos testes, jogando o andar atual.
// Luta, usa poções e habilidades, descansa, pega itens e explora.
// NUNCA desce de andar nem volta para a cidade — isso é sempre decisão do jogador.
import * as Game from './game.js';
import { G } from './game.js';
import { findPath, bfs, tileAt, passable } from './map.js';
import { CLASSES, SKILLS, elemMult } from './data.js';
import { itemDef } from './rules.js';
import { dist } from './util.js';

const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
const run = () => G.state.run;
function hasBuff(id) { return G.state.hero.buffs.some((x) => x.id === id); }

function knightMul(id, m, targets) {
  const sk = SKILLS[id], d = G.d, f = Game.fervorOf ? Game.fervorOf() : 0; let k = 1;
  if ((m.status.abertura || 0) > 0) k *= (1.4 + (d.critDmg || 0) / 100) * (sk.openMul || 1) * (sk.openPierce ? (60 + m.def) / 60 : (60 + m.def) / (60 + m.def * 0.5));
  if (sk.fervor && f >= sk.fervor && ['cavaleiro', 'lorde'].includes(G.state.hero.cls)) {
    if (id === 'perfuracao_espiral') k *= 2 * (60 + m.def) / (60 + m.def * 0.5);
    if (id === 'redemoinho' && (targets.length >= 2 || m.boss)) k *= 1.6;
  }
  return k;
}
const KICK_IDS = new Set(['chute_giratorio', 'chute_machado', 'chute_rasteira', 'chute_voador', 'furia_solar', 'chute_ascendente']);
function shadowMul(sk, m) {
  let k = 1;
  if (hasBuff('oculto')) k *= 1.5 * (1.4 + (G.d.critDmg || 0) / 100) * 0.9;
  if (sk.execute3) k *= m.boss ? (m.hp <= m.maxHp * 0.3 ? 1.5 : 1) : (m.hp <= m.maxHp * 0.4 ? 2 : 1);
  return k;
}
function ritmoMul(id) {
  const h = G.state.hero; if (!KICK_IDS.has(id) || !G.d.mods.ritmo) return 1;
  const r = h.ritmo || 0; if (r >= 5) return 2 * 1.4;
  return h.ritmoLast === id ? 0.55 : 1 + 0.08 * r + 0.06;
}
function expected(id, targets) {
  const sk = SKILLS[id], h = G.state.hero, l = h.skills[id], d = G.d; let t = 0;
  for (const m of targets) {
    const fz = (m.status.freeze || 0) > 0;
    const vid = ['ira_thor', 'vortice_jupiter', 'relampago'].find((v) => h.skills[v]);
    if (sk.freeze && !fz) t += vid ? (d.matk * SKILLS[vid].mult(h.skills[vid]) + SKILLS[vid].base(h.skills[vid])) * 4 * sk.freeze(l) / 100 * elemMult('vento', m.armorEl || m.el) * 60 / (60 + m.mdef) * 0.8 : d.matk * sk.freeze(l) / 100 * 1.2;
    const st = (m.status.petrify || 0) > 0;
    if (sk.petrify && !st && !fz && !m.boss) { const fid = ['meteoro', 'lanca_fogo'].find((v) => h.skills[v]); t += (fid ? (d.matk * SKILLS[fid].mult(h.skills[fid]) + SKILLS[fid].base(h.skills[fid])) * 8 * 60 / (60 + m.mdef) * 0.8 : d.matk * 1.6) * sk.petrify(l) / 100; }
    if (sk.kind === 'magic') t += (fz && sk.el === 'vento' ? 6 : 1) * (st && sk.el === 'fogo' ? 10 : 1) * ((m.status.burn || 0) > 0 && sk.el === 'agua' && !fz ? 5.5 : 1) * (d.matk * sk.mult(l, h.sp) + (sk.base ? sk.base(l) : 0)) * elemMult(sk.el, st ? 'terra' : (m.armorEl || m.el)) * 60 / (60 + m.mdef);
    if (sk.bleed) t += Math.min(sk.bleed, 5 - Game.bleedOf(m)) * d.atk * 0.45;
    if (sk.bleedDouble) t += Math.min(Math.max(1, Game.bleedOf(m)), 5 - Game.bleedOf(m)) * d.atk * 0.45;
    if (G.d.mods.chi && Game.chiOf() > 0 && ['luz_divina', 'palma_ferro', 'investida_monge'].includes(id) && m === targets[0]) t += d.atk * (0.3 + 0.06 * G.d.mods.chi);
    if (sk.kind === 'phys') t += (id === 'asura' && G.d.mods.chi ? 1 + 0.3 * Game.chiOf() : 1) * shadowMul(sk, m) * ritmoMul(id) * (sk.needsBow ? Game.hunterMul(m) * (G.d.hunter && m.status.presa > 0 ? 1.1 : 1) : 1) * knightMul(id, m, targets) * (sk.ambush && hasBuff('oculto') ? 1.5 : 1) * ((sk.useDex ? d.dexAtk : sk.agiBonus ? d.atk + d.stats.agi * 2 : d.atk) * sk.mult(l, h.sp) + (sk.base ? sk.base(l) : 0)) * elemMult(sk.el || d.el, m.armorEl || m.el) * (sk.ignoreDef ? 1 : 60 / (60 + m.def));
    else if (sk.kind === 'field') { const f = sk.field(l); t += d.matk * f.mult * f.turns * 0.6 + (run().fields?.length ? 0 : d.matk * (targets.length >= 3 ? 0.9 : 0.2)); }
    else if (sk.kind === 'blood') { const b = Game.bleedOf(m); if (b) t += b * (sk.base(l) + d.atk * sk.mult(l)) + Math.min((m.maxHp - m.hp) * sk.lost(l) / 100 * b, m.boss ? d.atk * 1.5 * b : 1e12); }
    else if (sk.kind === 'falcon') t += (d.stats.dex * 3 + d.stats.int * 2 + h.lv * 2) * (1 + l * 0.5);
  }
  return t;
}

const healPot = (h) => h.inv.filter((i) => itemDef(i).heal).sort((a, c) => itemDef(c).heal - itemDef(a).heal)[0];
const free = (r, x, y) => passable(tileAt(r.map, x, y)) && !Game.monsterAt(x, y);
// melhor casa vizinha segundo uma nota (menor = melhor); devolve [dx,dy] ou null
function bestStep(r, scoreFn, limit) {
  let bs = null, bv = limit;
  for (const [dx, dy] of DIRS) { const x = r.px + dx, y = r.py + dy; if (!free(r, x, y)) continue; const v = scoreFn(x, y); if (v < bv) { bv = v; bs = [dx, dy]; } }
  return bs;
}
const mv = (s) => !!s && Game.move(s[0], s[1]);
const cast = (id, x, y) => { Game.castSkill(id, x, y); return true; };

// Uma ação. Devolve true (agiu), 'explore' (nada conhecido para fazer: explorar) ou 'idle' (esperar).
export function autoAct(opts = {}) {
  const r = run(), h = G.state.hero, d = G.d;
  const vis = Game.visibleMonsters();
  const awakeV = vis.filter((m) => !m.asleep);
  const near = vis.slice().sort((a, c) => dist(a.x, a.y, r.px, r.py) - dist(c.x, c.y, r.px, r.py))[0];
  const danger = new Set(r.telegraphs.flatMap((t) => t.tiles.map(([x, y]) => x + ',' + y)));
  const guardOk = h.skills.aparar_golpe && Game.skillUsable('aparar_golpe').ok;
  if (danger.has(r.px + ',' + r.py) && guardOk && h.hp > d.maxHp * 0.45) {
    const here = r.telegraphs.filter((t) => t.tiles.some(([x, y]) => x === r.px && y === r.py));
    if (here.every((t) => t.kind !== 'magic')) {
      if (here.some((t) => Game.teleTurns(t) <= 1)) return cast('aparar_golpe');
      danger.clear();
    }
  }
  // fora da área marcada do golpe que vem
  if (danger.has(r.px + ',' + r.py)) {
    const dm = bfs(r.map, r.px, r.py, (x, y) => !!Game.monsterAt(x, y)); let best = null, bd = 99;
    for (let y = r.py - 4; y <= r.py + 4; y++) for (let x = r.px - 4; x <= r.px + 4; x++) { if (x < 0 || y < 0 || x >= r.map.w || y >= r.map.h) continue; const v = dm[y * r.map.w + x]; if (v > 0 && !danger.has(x + ',' + y) && v < bd) { bd = v; best = { x, y }; } }
    if (best) { const p = findPath(r.map, r.px, r.py, best.x, best.y, (x, y) => !!Game.monsterAt(x, y)); if (p && p.length && Game.move(p[0].x - r.px, p[0].y - r.py)) return true; }
  }
  const healId = ['curar', 'primeiros_socorros'].find((id) => h.skills[id]);
  const adjA = awakeV.filter((m) => dist(m.x, m.y, r.px, r.py) <= 1 && !(m.status.stun > 0) && !(m.status.freeze > 0) && !(m.status.petrify > 0));
  const incoming = adjA.reduce((a, m) => a + m.atk * 60 / (60 + d.def), 0) * 1.1;
  const potCd = !!(h.cd && h.cd.potHp);
  // cercado e ferido: recua para um corredor
  if (adjA.length >= 2 && h.hp < d.maxHp * 0.75 && !r.map.isBoss) {
    const s = bestStep(r, (x, y) => { const n = adjA.filter((m) => dist(m.x, m.y, x, y) <= 1).length; let open = 0; for (const [ex, ey] of DIRS) if (passable(tileAt(r.map, x + ex, y + ey))) open++; return n * 10 + open; }, adjA.length * 10);
    if (mv(s)) return true;
  }
  if ((h.hp < d.maxHp * 0.5 || h.hp < incoming * 2.5) && h.hp < d.maxHp * 0.8 && !hasBuff('frenesi') && !potCd) { const pot = healPot(h); if (pot) { Game.useItem(pot.uid); return true; } }
  // poção em recarga e quase morto: foge se for mais rápido
  if (potCd && h.hp < Math.max(d.maxHp * 0.3, incoming * 2) && adjA.length && !r.map.isBoss && adjA.every((m) => d.speed > m.speed * 1.05)) {
    let bs = null, bd = 0;
    for (const [dx, dy] of DIRS) { const x = r.px + dx, y = r.py + dy; if (!free(r, x, y)) continue; const dd = Math.min(...awakeV.map((m) => dist(m.x, m.y, x, y))); if (dd > bd) { bd = dd; bs = [dx, dy]; } }
    if (bs && bd >= 2 && mv(bs)) return true;
  }
  if (h.hp < d.maxHp * 0.35 && !hasBuff('frenesi') && !potCd) { const pot = healPot(h); if (pot) { Game.useItem(pot.uid); return true; } }
  if (!d.energy && h.sp < d.maxSp * 0.2 && awakeV.length && !(h.cd && h.cd.potSp)) { const pot = h.inv.filter((i) => itemDef(i).sp).sort((a, c) => itemDef(c).sp - itemDef(a).sp)[0]; if (pot) { Game.useItem(pot.uid); return true; } }
  if (healId && h.hp < d.maxHp * 0.5 && Game.skillUsable(healId).ok && SKILLS[healId].heal(h.skills[healId], h, d.stats) > incoming * 1.3) return cast(healId);
  if (h.skills.zen && h.sp < d.maxSp * 0.25 && Game.skillUsable('zen').ok && awakeV.length) return cast('zen');
  if (hasBuff('fusao') && (!awakeV.length || h.sp < d.maxSp * 0.15)) return cast('fusao_estelar');
  for (const id of Object.keys(h.skills)) { const sk = SKILLS[id]; if (sk && sk.aura && !hasBuff(sk.buffs(1).id) && h.sp >= sk.sp(1) && Game.skillUsable(id).ok) return cast(id); }
  if (near) {
    const awake = awakeV.length > 0;
    for (const id of Object.keys(h.skills)) {
      const sk = SKILLS[id]; if (!sk || !sk.buffs || sk.aura || !Game.skillUsable(id).ok) continue;
      const bid = sk.buffs(1).id; if (hasBuff(bid)) continue;
      if (bid === 'oculto') { if (id === 'esconderijo' || dist(near.x, near.y, r.px, r.py) < 2) continue; } else if (!awake) continue;
      if (bid === 'frenesi' && !vis.some((m) => m.boss) && awakeV.length < 2) continue;
      if (bid === 'fusao' && (h.sp < d.maxSp * 0.4 || (!vis.some((m) => m.boss) && awakeV.length < 2))) continue;
      return cast(id);
    }
    if (guardOk) {
      const opened = vis.some((m) => (m.status.abertura || 0) > 0 && dist(m.x, m.y, r.px, r.py) <= 2);
      const cc = h.skills.corte_cruzado ? expected('corte_cruzado', adjA.slice(0, 1)) : d.atk;
      if (adjA.length && !opened && (adjA.some((m) => m.boss) || adjA.length >= 2 || adjA[0].hp > cc * 1.6)) return cast('aparar_golpe');
    }
    const adj = awakeV.filter((m) => dist(m.x, m.y, r.px, r.py) <= 1);
    if (h.skills.postura_imovel && Game.skillUsable('postura_imovel').ok && !hasBuff('imovel') && (adj.some((m) => m.boss) || adj.length >= 3)) return cast('postura_imovel');
    if (h.skills.bomba_fumaca && Game.skillUsable('bomba_fumaca').ok && !hasBuff('oculto') && (adj.some((m) => m.boss) || adj.length >= 3)) return cast('bomba_fumaca');
    // Caçador: mantém distância
    if (d.hunter) {
      const ok = (id) => h.skills[id] && Game.skillUsable(id).ok;
      const melee = awakeV.filter((m) => !(m.range > 1)).sort((a, c) => dist(a.x, a.y, r.px, r.py) - dist(c.x, c.y, r.px, r.py));
      const m0 = melee[0], d0 = m0 ? dist(m0.x, m0.y, r.px, r.py) : 99;
      const held = (m) => (m.status.snare || 0) > 0 || (m.status.stun || 0) > 0;
      const use = (id, x, y) => Game.castSkill(id, x, y);
      if (m0 && d0 <= 1 && !held(m0)) {
        if (ok('salto_tras') && use('salto_tras', m0.x, m0.y)) return true;
        if (!m0.boss && ok('virote_impacto') && use('virote_impacto', m0.x, m0.y)) return true;
        if (ok('rede') && use('rede', m0.x, m0.y)) return true;
      }
      if (m0 && d0 === 2 && !held(m0) && ok('armadilha')) {
        const tx = r.px + Math.sign(m0.x - r.px), ty = r.py + Math.sign(m0.y - r.py);
        if (Game.validSkillTarget('armadilha', tx, ty) && !(r.traps || []).some((t) => t.x === tx && t.y === ty) && use('armadilha', tx, ty)) return true;
      }
      const prey = awakeV.find((m) => m.status.presa > 0);
      const big = awakeV.filter((m) => dist(m.x, m.y, r.px, r.py) >= 3).sort((a, c) => (c.boss ? 1e9 : c.hp) - (a.boss ? 1e9 : a.hp))[0];
      if (!prey && big && ok('rede') && Game.validSkillTarget('rede', big.x, big.y) && use('rede', big.x, big.y)) return true;
      if (m0 && d0 <= 2 && !held(m0) && d.speed > m0.speed * 1.15) {
        let bs = null, bd = d0;
        for (const [dx, dy] of DIRS) { const x = r.px + dx, y = r.py + dy; if (!free(r, x, y)) continue; const dd = Math.min(...melee.map((m) => dist(m.x, m.y, x, y))); if (dd > bd) { bd = dd; bs = [dx, dy]; } }
        if (mv(bs)) return true;
      }
    }
    // Shinobi sem energia: se afasta enquanto o sangramento trabalha
    if (d.energy && h.sp < 30 && h.hp > d.maxHp * 0.4) {
      const adjM = awakeV.filter((m) => dist(m.x, m.y, r.px, r.py) <= 1 && !(m.range > 1));
      if (adjM.length && adjM.every((m) => Game.bleedOf(m) >= 2)) {
        let bs = null, bd = -1;
        for (const [dx, dy] of DIRS) { const x = r.px + dx, y = r.py + dy; if (!free(r, x, y)) continue; const dd = Math.min(...vis.map((m) => dist(m.x, m.y, x, y))); if (dd > bd) { bd = dd; bs = [dx, dy]; } }
        if (bs && bd >= 2 && mv(bs)) return true;
      }
    }
    const reserve = healId ? SKILLS[healId].sp(1) : 0;
    const CHEAP = new Set(['faisca_arcana', 'arremessar_pedra']);
    const realOk = CLASSES[h.cls].tier > 0 && Object.keys(h.skills).some((id) => { const sk = SKILLS[id]; return sk && !CHEAP.has(id) && ['phys', 'magic', 'field', 'falcon'].includes(sk.kind) && Game.skillUsable(id).ok && h.sp - sk.sp(1) >= reserve; });
    let best = null, bv = 0;
    for (const id of Object.keys(h.skills)) {
      const sk = SKILLS[id]; if (!sk || !['phys', 'magic', 'field', 'falcon', 'curse', 'petrifyArea', 'blood'].includes(sk.kind) || !Game.skillUsable(id).ok || h.sp - sk.sp(1) < reserve) continue;
      if (sk.allSp && !vis.some((m) => m.boss) && vis.length < 2) continue;
      if (realOk && CHEAP.has(id)) continue;
      if (id === 'luz_divina' && CLASSES[h.cls].monk) continue;
      let tx, ty, ts = [];
      if (sk.target === 'self') { ts = vis.filter((m) => dist(m.x, m.y, r.px, r.py) <= sk.aoe); tx = r.px; ty = r.py; }
      else if (sk.target === 'tile') { for (const c of vis) { if (!Game.validSkillTarget(id, c.x, c.y)) continue; const t2 = vis.filter((m) => dist(m.x, m.y, c.x, c.y) <= sk.aoe); if (t2.length > ts.length) { ts = t2; tx = c.x; ty = c.y; } } }
      else { let bc = null, bcv = -1; for (const c of vis) { if (!Game.validSkillTarget(id, c.x, c.y)) continue; const e = expected(id, [c]); const cv = e / Math.max(1, c.hp) * 1000 + e; if (cv > bcv) { bcv = cv; bc = c; } } if (bc) { ts = [bc]; tx = bc.x; ty = bc.y; } }
      if (!ts.length) continue;
      const v = expected(id, ts); if (v > bv) { bv = v; best = { id, tx, ty }; }
    }
    const atk = vis.filter((m) => Game.canAttack(m)).sort((a, c) => a.hp - c.hp)[0];
    const near1 = awakeV.slice().sort((a, c) => dist(a.x, a.y, r.px, r.py) - dist(c.x, c.y, r.px, r.py))[0];
    const magic = d.matk > d.atk * 1.1;
    const basic = atk ? d.atk * (1 + (d.mods.doubleAtk || 0) / 100) * 60 / (60 + atk.def) : (!magic && !d.ranged && near1 ? d.atk * 0.5 * 60 / (60 + near1.def) : 0);
    if (best && bv > basic * 1.15) return cast(best.id, best.tx, best.ty);
    if (atk) { Game.attack(atk); return true; }
  }
  if (G.d.mods.chi && Game.chiOf() < 5 && h.skills.curar && h.sp > d.maxSp * 0.7 && !awakeV.length && Game.skillUsable('curar').ok) return cast('curar');
  if ((h.hp < d.maxHp * 0.6 || h.sp < d.maxSp * 0.35) && !awakeV.length) { Game.rest10(); return true; }
  // caça: monstro acordado à vista; senão monstro conhecido (casa já vista); senão item no chão já visto
  const m = r.map, seen = (x, y) => !!m.seen[y * m.w + x];
  const dm = bfs(m, r.px, r.py);
  const reach = (x, y) => dm[y * m.w + x] > 0;
  let tgt = (near && !near.asleep ? near : null)
    || r.monsters.filter((o) => o.hp > 0 && seen(o.x, o.y) && reach(o.x, o.y) && !(o.pvp)).sort((a, c) => dm[a.y * m.w + a.x] - dm[c.y * m.w + c.x])[0];
  if (!tgt && !opts.bagFull) tgt = r.items.filter((g) => seen(g.x, g.y) && reach(g.x, g.y)).sort((a, c) => dm[a.y * m.w + a.x] - dm[c.y * m.w + c.x])[0];
  if (!tgt) return 'explore';
  const p = findPath(m, r.px, r.py, tgt.x, tgt.y, (x, y) => !!Game.monsterAt(x, y)) || findPath(m, r.px, r.py, tgt.x, tgt.y);
  if (p && p.length && !Game.monsterAt(p[0].x, p[0].y)) { if (!Game.move(p[0].x - r.px, p[0].y - r.py)) Game.wait(); return true; }
  if (p && p.length) { const o = Game.monsterAt(p[0].x, p[0].y); if (Game.canAttack(o)) Game.attack(o); else Game.wait(); return true; }
  return 'explore';
}
