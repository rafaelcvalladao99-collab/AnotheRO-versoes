// Inicialização, entrada por toque, caminhada automática
import * as Game from './game.js';
import { G } from './game.js';
import { SKILLS } from './data.js';
import { T, findPath, tileAt } from './map.js';
import { dist } from './util.js';
import { initRender, screenToTile, setTargeting, setMarker, setPads, snapCamera, R, panCamera, zoomCamera, followHero, resetZoom, cameraFree } from './render.js';
import * as UI from './ui.js';
import { Audio } from './audio.js';
import { checkForUpdates, APK_URL } from './updater.js';
import { WEB_VERSION } from './version.js';
import { preloadPortraits, heroSheet } from './lpc.js';

let walkPath = null;     // fila de passos da caminhada automática
let walkTimer = 0;
let exploring = false;
let targetSkill = null;  // habilidade aguardando alvo
let walkSnapshot = null; // para interromper ao surgir perigo

function busy() { return UI.sheetOpen() || G.state.mode !== 'dungeon'; }

function stopWalk() {
  walkPath = null;
  exploring = false;
  clearTimeout(walkTimer);
  document.getElementById('btn-explore').classList.remove('on');
}

function dangerSnapshot() {
  const r = G.state.run;
  return { hp: G.state.hero.hp, mons: Game.visibleMonsters().filter((m) => !m.asleep).map((m) => m.uid).sort().join(','), items: r.items.length };
}

function dangerChanged(before) {
  const now = dangerSnapshot();
  if (now.hp < before.hp) return true;
  const nowSet = now.mons.split(',').filter(Boolean);
  const oldSet = new Set(before.mons.split(',').filter(Boolean));
  return nowSet.some((u) => !oldSet.has(u));
}

function after() {
  followHero();
  if (window.__updateCamBtn) window.__updateCamBtn();
  UI.refresh();
  if (G.state.mode !== 'dungeon') { stopWalk(); cancelTarget(); UI.refresh('screen'); }
}

function stepWalk() {
  if (!walkPath || busy()) { stopWalk(); return; }
  if (walkPath.length === 0) {
    if (exploring) { if (!planExplore()) { stopWalk(); after(); return; } }
    else { stopWalk(); return; }
  }
  const r = G.state.run;
  const next = walkPath.shift();
  const snap = dangerSnapshot();
  const m = Game.monsterAt(next.x, next.y);
  if (m && Game.visible(m.x, m.y)) {
    // chegou no alvo
    if (Game.canAttack(m)) Game.attack(m);
    stopWalk(); after(); return;
  }
  const ok = Game.move(next.x - r.px, next.y - r.py);
  after();
  if (!ok || G.state.mode !== 'dungeon') { stopWalk(); return; }
  if (dangerChanged(snap)) { stopWalk(); if (exploring) Game.log('Algo se aproxima!', '#ffb0b0'); after(); return; }
  if (tileAt(r.map, r.px, r.py) === T.STAIRS && exploring) { stopWalk(); return; }
  walkTimer = setTimeout(stepWalk, 115);
}

function planExplore() {
  const r = G.state.run, m = r.map;
  // itens conhecidos primeiro
  let best = null, bd = 1e9;
  for (const g of r.items) {
    const v = G.dmap[g.y * m.w + g.x];
    if (v > 0 && v < bd && m.seen[g.y * m.w + g.x]) { bd = v; best = { x: g.x, y: g.y }; }
  }
  if (!best) {
    for (let y = 1; y < m.h - 1; y++) for (let x = 1; x < m.w - 1; x++) {
      const i = y * m.w + x;
      if (!m.seen[i] || G.dmap[i] <= 0) continue;
      if (m.seen[i - 1] && m.seen[i + 1] && m.seen[i - m.w] && m.seen[i + m.w]) continue;
      if (G.dmap[i] < bd) { bd = G.dmap[i]; best = { x, y }; }
    }
  }
  if (!best && m.stairs && m.seen[m.stairs.y * m.w + m.stairs.x] && !(r.px === m.stairs.x && r.py === m.stairs.y)) best = m.stairs;
  if (!best) { Game.log('Andar totalmente explorado.', '#9ab'); return false; }
  const p = findPath(m, r.px, r.py, best.x, best.y, (x, y) => !!Game.monsterAt(x, y));
  if (!p || !p.length) return false;
  walkPath = p;
  return true;
}

function startExplore() {
  if (busy()) return;
  if (exploring) { stopWalk(); return; }
  if (Game.visibleMonsters().some((m) => !m.asleep)) { Game.log('Há inimigos à vista!', '#ffb0b0'); after(); return; }
  exploring = true;
  document.getElementById('btn-explore').classList.add('on');
  if (planExplore()) stepWalk(); else { stopWalk(); after(); }
}

// ---------------- Habilidades ----------------
function cancelTarget() {
  targetSkill = null;
  setTargeting(null);
  document.getElementById('target-banner').classList.add('hidden');
  G.dirty = true;
}

function nearestTarget(id) {
  const r = G.state.run;
  const ms = Game.visibleMonsters().sort((a, b) => dist(a.x, a.y, r.px, r.py) - dist(b.x, b.y, r.px, r.py));
  return ms.find((m) => Game.validSkillTarget(id, m.x, m.y)) || null;
}

function onSkill(id) {
  if (busy()) return;
  stopWalk();
  const sk = SKILLS[id];
  const u = Game.skillUsable(id);
  if (!u.ok) { UI.toast(`${sk.name}: ${u.why}`, 1200); return; }
  if (sk.target === 'self') { cancelTarget(); Game.castSkill(id); after(); return; }
  if (targetSkill === id) {
    const m = nearestTarget(id);
    if (m) { cancelTarget(); Game.castSkill(id, m.x, m.y); after(); }
    else UI.toast('Nenhum alvo ao alcance', 1000);
    return;
  }
  targetSkill = id;
  setTargeting({ range: sk.range || 1 });
  const b = document.getElementById('target-banner');
  document.getElementById('target-txt').textContent = `${sk.icon} ${sk.name}: toque no alvo`;
  b.style.top = (document.getElementById('hud').getBoundingClientRect().bottom + 6) + 'px';
  b.classList.remove('hidden');
  G.dirty = true;
  UI.refresh();
}

// ---------------- Toque no mapa ----------------
function onTap(px, py) {
  if (busy()) return;
  Audio.unlock();
  if (walkPath) { stopWalk(); return; }
  const r = G.state.run;
  const { x, y } = screenToTile(px, py);
  if (targetSkill) {
    const id = targetSkill;
    if (Game.validSkillTarget(id, x, y)) { cancelTarget(); Game.castSkill(id, x, y); after(); }
    else UI.toast('Fora de alcance ou sem visão', 900);
    return;
  }
  if (x === r.px && y === r.py) {
    const t = tileAt(r.map, x, y);
    if (t === T.STAIRS) { Game.descend(); after(); return; }
    Game.wait(); after(); return;
  }
  const m = Game.monsterAt(x, y);
  if (m && Game.visible(x, y)) {
    if (Game.canAttack(m)) { Game.attack(m); after(); return; }
  }
  if (!r.map.seen[y * r.map.w + x]) return;
  // passo adjacente direto
  if (dist(x, y, r.px, r.py) === 1 && !m) { Game.move(x - r.px, y - r.py); after(); return; }
  const p = findPath(r.map, r.px, r.py, x, y, (xx, yy) => { const mm = Game.monsterAt(xx, yy); return mm && Game.visible(xx, yy); });
  if (!p || !p.length) return;
  setMarker(x, y);
  walkPath = p;
  walkSnapshot = dangerSnapshot();
  stepWalk();
}

function onContext(a) {
  if (a === 'descend') { stopWalk(); Game.descend(); after(); }
  if (a === 'portal') { stopWalk(); Game.usePortal(); after(); }
}

function onPotion(u) {
  if (busy()) return;
  stopWalk();
  Game.useItem(u);
  after();
}

function onRest() {
  if (busy()) return;
  stopWalk();
  const h = G.state.hero;
  if (Game.visibleMonsters().some((m) => !m.asleep) || (h.hp >= G.d.maxHp && h.sp >= G.d.maxSp)) Game.wait();
  else Game.rest10();
  after();
}

// ---------------- Inicialização ----------------
async function boot() {
  await preloadPortraits();
  if (G.state?.hero?.cls) heroSheet(G.state.hero.cls);
  const canvas = document.getElementById('view');
  initRender(canvas);
  if (!Game.load()) Game.newState();
  if (!G.state.settings) G.state.settings = { sound: true, vibrate: true };
  Audio.setEnabled(G.state.settings.sound);

  UI.setHandlers({
    onSkill, onPotion, onContext,
    selectedSkill: () => targetSkill,
    afterAction: after,
    onLayout: (top, bot) => setPads(top, bot),
    onEnterDungeon: () => { snapCamera(); after(); },
  });
  UI.hydrateIcons();
  UI.refresh('screen');
  if (G.state.mode === 'dungeon') snapCamera();

  // toque: um dedo = tocar ou arrastar o mapa; dois dedos = zoom
  const pts = new Map();
  let gesture = null; // { mode: 'tap' | 'pan' | 'pinch', ... }
  const updateCamBtn = () => document.getElementById('btn-center').classList.toggle('hidden', !cameraFree() || G.state.mode !== 'dungeon');
  canvas.addEventListener('pointerdown', (e) => {
    canvas.setPointerCapture(e.pointerId);
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 1) gesture = { mode: 'tap', sx: e.clientX, sy: e.clientY, lx: e.clientX, ly: e.clientY };
    else if (pts.size === 2) {
      const [a, b] = [...pts.values()];
      gesture = { mode: 'pinch', d: Math.hypot(a.x - b.x, a.y - b.y) };
    }
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!pts.has(e.pointerId) || !gesture || G.state.mode !== 'dungeon') return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (gesture.mode === 'pinch' && pts.size >= 2) {
      const [a, b] = [...pts.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (gesture.d > 0) zoomCamera(d / gesture.d, (a.x + b.x) / 2, (a.y + b.y) / 2);
      gesture.d = d; updateCamBtn();
      return;
    }
    if (gesture.mode === 'tap' && Math.hypot(e.clientX - gesture.sx, e.clientY - gesture.sy) > 14) gesture.mode = 'pan';
    if (gesture.mode === 'pan') { panCamera(e.clientX - gesture.lx, e.clientY - gesture.ly); updateCamBtn(); }
    gesture.lx = e.clientX; gesture.ly = e.clientY;
  });
  const end = (e) => {
    const g = gesture;
    pts.delete(e.pointerId);
    if (pts.size === 0) {
      gesture = null;
      if (g && g.mode === 'tap' && e.type === 'pointerup') onTap(e.clientX, e.clientY);
    } else if (g && g.mode === 'pinch') gesture = { mode: 'pan-after-pinch', lx: 0, ly: 0 };
  };
  canvas.addEventListener('pointerup', end);
  canvas.addEventListener('pointercancel', end);
  canvas.addEventListener('wheel', (e) => { if (G.state.mode !== 'dungeon') return; e.preventDefault(); zoomCamera(e.deltaY < 0 ? 1.1 : 0.9, e.clientX, e.clientY); updateCamBtn(); }, { passive: false });
  document.getElementById('btn-center').onclick = () => { resetZoom(); updateCamBtn(); };
  window.__updateCamBtn = updateCamBtn;

  document.getElementById('btn-bag').onclick = () => { stopWalk(); cancelTarget(); UI.bagSheet(); };
  document.getElementById('btn-hero').onclick = () => { stopWalk(); cancelTarget(); UI.heroSheet(); };
  document.getElementById('portrait').onclick = () => { stopWalk(); cancelTarget(); UI.heroSheet(); };
  document.getElementById('btn-explore').onclick = () => { cancelTarget(); startExplore(); };
  document.getElementById('btn-rest').onclick = onRest;
  document.getElementById('btn-menu').onclick = () => { stopWalk(); cancelTarget(); UI.menuSheet(); };
  document.getElementById('target-cancel').onclick = cancelTarget;

  // atualização periódica do HUD (desbotar mensagens)
  setInterval(() => { if (G.state.mode === 'dungeon') UI.updateHUD(); }, 400);
  window.addEventListener('resize', () => UI.refresh(true));

  // salvar ao sair / minimizar
  document.addEventListener('visibilitychange', () => { if (document.hidden) Game.save(); });
  window.addEventListener('pagehide', () => Game.save());

  // botão voltar do Android (Capacitor)
  try {
    const cap = window.Capacitor;
    if (cap && cap.registerPlugin) {
      const App = cap.registerPlugin('App');
      App.addListener('backButton', () => {
        if (UI.sheetOpen()) { UI.closeSheet(); return; }
        if (targetSkill) { cancelTarget(); return; }
        if (walkPath) { stopWalk(); return; }
        if (G.state.mode === 'dungeon' || G.state.mode === 'town') { UI.menuSheet(); return; }
        Game.save();
        App.exitApp();
      });
      App.addListener('pause', () => Game.save());
    }
  } catch (_) { /* navegador comum */ }

  // atualização automática
  window.__WEB_VERSION = WEB_VERSION;
  checkForUpdates({
    canRestartNow: () => G.state.mode !== 'dungeon' && !UI.sheetOpen(),
    onStatus: (msg) => UI.toast(msg, 2500),
    onApkNeeded: () => UI.confirmSheet('Nova versão do app', 'Esta atualização precisa de um APK novo. Toque em Baixar, depois abra o arquivo e confirme a instalação. Seu progresso continua salvo.', 'Baixar', () => { Game.save(); window.location.href = APK_URL; }),
  });

  // depuração no navegador
  window.__G = G; window.__Game = Game;
}

boot();
