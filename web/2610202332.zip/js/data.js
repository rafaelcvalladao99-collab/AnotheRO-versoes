// =============================================================
// Dados do jogo: elementos, raças, classes, habilidades, monstros,
// itens e cartas.
// =============================================================

export const ELEMENTS = {
  neutro: { name: 'Neutro', color: '#c9ccd6' },
  agua: { name: 'Água', color: '#4fb3ff' },
  terra: { name: 'Terra', color: '#c79a5a' },
  fogo: { name: 'Fogo', color: '#ff7a3d' },
  vento: { name: 'Vento', color: '#9cf2c8' },
  sagrado: { name: 'Sagrado', color: '#ffe9a3' },
  sombrio: { name: 'Sombrio', color: '#a37bff' },
  fantasma: { name: 'Fantasma', color: '#cfe7ff' },
  morto: { name: 'Morto-vivo', color: '#9aa88a' },
};

// atacante > defensor = 1.5x
const STRONG = {
  agua: ['fogo'],
  fogo: ['terra', 'morto'],
  terra: ['vento'],
  vento: ['agua'],
  sagrado: ['sombrio', 'morto', 'fantasma'],
  sombrio: ['sagrado'],
  fantasma: ['fantasma'],
};

export function elemMult(atk, def) {
  if (!atk) atk = 'neutro';
  if (!def) def = 'neutro';
  if (def === 'fantasma' && atk === 'neutro') return 0.5;
  if ((STRONG[atk] || []).includes(def)) return 1.5;
  if ((STRONG[def] || []).includes(atk)) return 0.75;
  if (atk === def && atk !== 'neutro' && atk !== 'fantasma') return 0.5;
  return 1;
}

export const RACES = {
  amorfo: 'Amorfo', inseto: 'Inseto', planta: 'Planta', bruto: 'Bruto', peixe: 'Peixe',
  morto: 'Morto-vivo', demonio: 'Demônio', humanoide: 'Humanoide', dragao: 'Dragão',
};

export const STAT_NAMES = { str: 'FOR', agi: 'AGI', vit: 'VIT', int: 'INT', dex: 'DES', luk: 'SOR' };
export const STAT_DESC = {
  str: 'Dano corpo a corpo',
  agi: 'Esquiva e velocidade',
  vit: 'HP máximo e defesa',
  int: 'Dano mágico e SP',
  dex: 'Precisão e dano à distância',
  luk: 'Crítico, esquiva perfeita e resistência',
};

// ------------------------------------------------------------------
// Classes
// ------------------------------------------------------------------
export const CLASSES = {
  aprendiz: { name: 'Aprendiz', tier: 0, hpMul: 1, spMul: 1, colors: ['#8a6a4a', '#d8c3a0'], hat: 'none',
    desc: 'Todo aventureiro começa aqui.', skills: ['primeiros_socorros', 'faisca_arcana', 'arremessar_pedra', 'resistencia'] },

  espadachim: { name: 'Espadachim', tier: 1, from: 'aprendiz', hpMul: 1.45, spMul: 0.8, colors: ['#3b6fd1', '#c7d4ef'], hat: 'band',
    desc: 'Guerreiro resistente de corpo a corpo.', skills: ['golpe_fulminante', 'impacto_explosivo', 'vigor', 'maestria_espada'] },
  mago: { name: 'Mago', tier: 1, from: 'aprendiz', hpMul: 1.0, spMul: 1.5, colors: ['#7c3fbf', '#e5d2ff'], hat: 'wizard',
    desc: 'Magias elementais poderosas, mas frágil. Gelo + raio estilhaça.', skills: ['lanca_fogo', 'lanca_gelo', 'relampago', 'congelar', 'meditacao'] },
  arqueiro: { name: 'Arqueiro', tier: 1, from: 'aprendiz', hpMul: 1.0, spMul: 1.0, colors: ['#3f9a52', '#d7f0c9'], hat: 'feather',
    desc: 'Ataques à distância com arco.', skills: ['tiro_duplo', 'chuva_flechas', 'olhos_coruja', 'olho_aguia'] },
  gatuno: { name: 'Gatuno', tier: 1, from: 'aprendiz', hpMul: 1.3, spMul: 0.9, colors: ['#3c3f4a', '#b9bdc9'], hat: 'hood',
    desc: 'Ágil, furtivo e venenoso.', skills: ['ataque_duplo', 'envenenar_arma', 'esconderijo', 'furto'] },
  novico: { name: 'Clérigo', tier: 1, from: 'aprendiz', hpMul: 1.25, spMul: 1.3, colors: ['#e9e3d3', '#4a5f9e'], hat: 'cap',
    desc: 'Cura, bênçãos, escudo sagrado e luz divina.', skills: ['curar', 'bencao', 'kyrie', 'luz_divina'] },
  ninja: { name: 'Ninja', tier: 1, from: 'aprendiz', hpMul: 1.05, spMul: 1.2, colors: ['#2a2f45', '#c43a4a'], hat: 'none',
    desc: 'Ágil, lança kunais e domina jutsus de fogo.', skills: ['kunai', 'jutsu_fogo', 'substituicao', 'passos_sombra'] },

  taekwon: { name: 'Taekwon', tier: 1, from: 'aprendiz', hpMul: 1.15, spMul: 1.0, colors: ['#f4f2ec', '#d83a3a'], hat: 'none',
    desc: 'Luta com chutes. Fica mais forte sem arma nas mãos.', skills: ['chute_giratorio', 'chute_machado', 'postura_taekwon', 'corrida'] },

  cavaleiro: { name: 'Cavaleiro', tier: 2, from: 'espadachim', hpMul: 1.75, spMul: 0.9, colors: ['#1f4fa8', '#e4ecff'], hat: 'helm',
    desc: 'Luta com duas espadas na linha de frente e apara golpes.', skills: ['corte_cruzado', 'redemoinho', 'aparar_golpe', 'ambidestria'] },
  bruxo: { name: 'Bruxo', tier: 2, from: 'mago', hpMul: 0.95, spMul: 1.8, colors: ['#4a1f8a', '#f0b84a'], hat: 'wizard',
    desc: 'Magias em área devastadoras.', skills: ['meteoro', 'nevasca', 'vortice_jupiter', 'amplificacao'] },
  cacador: { name: 'Caçador', tier: 2, from: 'arqueiro', hpMul: 1.1, spMul: 1.0, colors: ['#2e6e3a', '#e8d9a8'], hat: 'feather',
    desc: 'Atirador de besta com falcão e redes.', skills: ['tiro_certeiro', 'rede', 'falcao', 'instinto'] },
  assassino: { name: 'Assassino', tier: 2, from: 'gatuno', hpMul: 1.4, spMul: 0.9, colors: ['#5a1a2e', '#d6c5cb'], hat: 'mask',
    desc: 'Mestre do katar: críticos letais nas sombras.', skills: ['laminas_sonicas', 'garra_sombria', 'furtividade', 'maestria_katar'] },
  monge: { name: 'Monge', tier: 2, from: 'novico', hpMul: 1.55, spMul: 1.2, colors: ['#d8742a', '#f4e2b8'], hat: 'none',
    desc: 'Lutador de punhos guiado pela energia espiritual. Punhos Sagrados: metade do ATQM vira ATQ.', holyFist: 0.5, skills: ['punhos_triplos', 'esferas_espirituais', 'palma_ferro', 'asura'] },
  mestre_taekwon: { name: 'Mestre Taekwon', tier: 2, from: 'taekwon', hpMul: 1.3, spMul: 1.1, colors: ['#1a1a24', '#ffcf4a'], hat: 'none',
    desc: 'Chutes voadores e o poder do sol e das estrelas.', skills: ['chute_voador', 'furia_solar', 'protecao_estelar', 'unidade_corpo'] },
  shinobi: { name: 'Shinobi', tier: 2, from: 'ninja', hpMul: 1.25, spMul: 1.4, colors: ['#1c1830', '#8a4ae8'], hat: 'none',
    desc: 'Mestre ninja: clones, lâminas e chuva de shurikens.', skills: ['lamina_fantasma', 'chuva_shuriken', 'clones_sombra', 'arte_ninja'] },
};

export const CLASS_LV = { 1: 8, 2: 25 };

// Bônus de classe: atributos ganhos automaticamente por nível passado na classe
export const JOB_BONUS = {
  espadachim: { str: 0.5, vit: 0.35, dex: 0.15 }, cavaleiro: { str: 0.55, vit: 0.4, dex: 0.15, agi: 0.1 },
  mago: { int: 0.6, dex: 0.3 }, bruxo: { int: 0.7, dex: 0.35 },
  arqueiro: { dex: 0.6, agi: 0.25 }, cacador: { dex: 0.65, agi: 0.25, luk: 0.1 },
  gatuno: { agi: 0.6, str: 0.4, luk: 0.15 }, assassino: { agi: 0.55, str: 0.35, luk: 0.2 },
  novico: { int: 0.4, vit: 0.3, dex: 0.15 }, monge: { str: 0.6, agi: 0.3, vit: 0.3 },
  ninja: { agi: 0.4, dex: 0.3, int: 0.2 }, shinobi: { agi: 0.45, dex: 0.35, int: 0.25 },
  taekwon: { agi: 0.45, str: 0.35 }, mestre_taekwon: { agi: 0.5, str: 0.4, vit: 0.15 },
};

// Arma de assinatura entregue ao mudar de classe
export const CLASS_STARTER = {
  espadachim: 'espada_curta', mago: 'vara', arqueiro: 'arco_curto', gatuno: 'faca', novico: 'clava', ninja: 'kunai', taekwon: null,
  cavaleiro: 'sabre', bruxo: 'cajado_carvalho', cacador: 'besta_caca', assassino: 'katar_serrilhado', monge: 'soqueira_ferro', shinobi: 'fuuma_lamina', mestre_taekwon: null,
}; // nível exigido para cada tier

// ------------------------------------------------------------------
// Habilidades
// target: self | enemy | tile | passive
// ------------------------------------------------------------------
const pct = (n) => Math.round(n * 100) + '%';
export const SKILLS = {
  // Aprendiz
  primeiros_socorros: { name: 'Primeiros Socorros', icon: '✚', target: 'self', max: 5, sp: (l) => 3,
    heal: (l, h) => 10 + l * 8 + h.lv * 2, desc: (l) => `Recupera ${10 + l * 8} + 2×nível de HP.` },
  faisca_arcana: { name: 'Faísca Arcana', icon: '✦', target: 'enemy', range: 5, max: 5, sp: (l) => 5,
    kind: 'magic', el: 'neutro', mult: (l) => 1.0 + l * 0.3, proj: '#c8b8ff',
    desc: (l) => `Dispara uma faísca mágica: ${pct(1.0 + l * 0.3)} do ATQM. Fica forte com INT.` },
  arremessar_pedra: { name: 'Arremessar Pedra', icon: '●', target: 'enemy', range: 4, max: 5, sp: (l) => 3,
    kind: 'phys', useDex: true, mult: (l) => 0.9 + l * 0.25, proj: '#b8a890',
    desc: (l) => `Arremessa uma pedra: ${pct(0.9 + l * 0.25)} do ataque à distância. Fica forte com DES.` },
  resistencia: { name: 'Resistência', icon: '♥', target: 'passive', max: 5,
    mods: (l) => ({ hpPct: l * 3, regenHp: l * 0.5 }), desc: (l) => `+${l * 3}% HP máximo e regeneração.` },

  // Espadachim
  golpe_fulminante: { name: 'Golpe Fulminante', icon: '⚔', target: 'enemy', range: 1, max: 5, sp: (l) => 4 + l,
    kind: 'phys', mult: (l) => 1.4 + l * 0.35, stun: (l) => l * 6,
    desc: (l) => `Golpe de ${pct(1.4 + l * 0.35)} do ATQ. ${l * 6}% de atordoar.` },
  impacto_explosivo: { name: 'Impacto Explosivo', icon: '✹', target: 'self', aoe: 1, max: 5, sp: (l) => 10 + l,
    kind: 'phys', el: 'fogo', mult: (l) => 1.2 + l * 0.25, knock: 1,
    desc: (l) => `Explosão de fogo ao redor: ${pct(1.2 + l * 0.25)} do ATQ e empurra.` },
  vigor: { name: 'Vigor', icon: '❤', target: 'passive', max: 5,
    mods: (l) => ({ regenHp: l * 1.5 }), desc: (l) => `Regenera HP mais rápido (+${l * 1.5}/turno).` },
  maestria_espada: { name: 'Maestria com Armas', icon: '⚒', target: 'passive', max: 5,
    mods: (l) => ({ atk: l * 4, hit: l * 2 }), desc: (l) => `+${l * 4} ATQ e +${l * 2} precisão.` },

  // Cavaleiro
  perfurar: { name: 'Perfurar', icon: '➹', target: 'enemy', range: 2, max: 5, sp: (l) => 7 + l,
    kind: 'phys', mult: (l) => 1.6 + l * 0.45, hits: 2,
    desc: (l) => `Dois golpes de lança (alcance 2), total ${pct(1.6 + l * 0.45)} do ATQ.` },
  giro_lanca: { name: 'Giro de Lança', icon: '◎', target: 'self', aoe: 2, max: 5, sp: (l) => 14 + l * 2,
    kind: 'phys', mult: (l) => 1.6 + l * 0.4, knock: 2,
    desc: (l) => `Gira a lança atingindo tudo em raio 2: ${pct(1.6 + l * 0.4)} do ATQ.` },
  concentracao: { name: 'Concentração', icon: '⚡', target: 'self', buff: true, max: 5, sp: (l) => 15,
    buffs: (l) => ({ id: 'concentracao', turns: 15 + l * 3, mods: { speed: 10 + l * 5, atkPct: l * 5 } }),
    desc: (l) => `+${10 + l * 5} velocidade e +${l * 5}% ATQ por ${15 + l * 3} turnos.` },
  cavalaria: { name: 'Cavalaria', icon: '♞', target: 'passive', max: 5,
    mods: (l) => ({ hpPct: l * 4, def: l * 2 }), desc: (l) => `+${l * 4}% HP e +${l * 2} DEF.` },

  // Cavaleiro (duas espadas)
  corte_cruzado: { name: 'Corte Cruzado', icon: '✖', target: 'enemy', range: 1, max: 5, sp: (l) => 7 + l,
    kind: 'phys', mult: (l) => 1.7 + l * 0.45, hits: 2,
    desc: (l) => `Duas lâminas em X: ${pct(1.7 + l * 0.45)} do ATQ.` },
  redemoinho: { name: 'Redemoinho de Lâminas', icon: '◎', target: 'self', aoe: 1, max: 5, sp: (l) => 12 + l * 2,
    kind: 'phys', mult: (l) => 1.7 + l * 0.4, hits: 2, knock: 1,
    desc: (l) => `Gira com as duas espadas atingindo tudo em volta: ${pct(1.7 + l * 0.4)} do ATQ.` },
  aparar_golpe: { name: 'Aparar Golpe', icon: '⛉', target: 'passive', max: 5,
    mods: (l) => ({ parry: l * 6 }), desc: (l) => `${l * 6}% de chance de aparar um ataque corpo a corpo com as espadas e contra-atacar (50% do ATQ).` },
  ambidestria: { name: 'Ambidestria', icon: '⚔', target: 'passive', max: 5,
    mods: (l) => ({ doubleAtk: l * 7, atk: l * 4, hpPct: l * 2 }), desc: (l) => `${l * 7}% de chance de golpear com as duas espadas, +${l * 4} ATQ e +${l * 2}% HP.` },

  // Monge
  punhos_triplos: { name: 'Punhos Triplos', icon: '✊', target: 'passive', max: 5,
    mods: (l) => ({ tripleAtk: l * 8, atk: l * 4 }), desc: (l) => `${l * 8}% de chance de uma sequência de 3 socos e +${l * 4} ATQ.` },
  esferas_espirituais: { name: 'Esferas Espirituais', icon: '◉', target: 'self', buff: true, aura: 20, max: 5, sp: (l) => 8 + l * 2,
    buffs: (l) => ({ id: 'esferas', turns: 30 + l * 6, mods: { atk: l * 12, hit: l * 3, regenSp: 0.3 * l } }),
    desc: (l) => `Invoca ${l} esferas: +${l * 12} ATQ e +${l * 3} precisão. Aura: fica ligada e reserva 20% do SP.` },
  palma_ferro: { name: 'Palma de Ferro', icon: '✋', target: 'enemy', range: 1, max: 5, sp: (l) => 9 + l,
    kind: 'phys', mult: (l) => 1.8 + l * 0.45, stun: (l) => 15 + l * 6, knock: 1,
    desc: (l) => `Golpe concentrado: ${pct(1.8 + l * 0.45)} do ATQ, ${15 + l * 6}% de atordoar e empurra.` },
  asura: { name: 'Punho de Asura', icon: '☄', target: 'enemy', range: 1, max: 5, sp: (l) => 20, allSp: true,
    kind: 'phys', mult: (l, spent = 20) => 3.5 + l * 0.8 + spent / 25, sureHit: true,
    desc: (l) => `Gasta todo o SP num golpe devastador: ${pct(3.5 + l * 0.8)} do ATQ + bônus pelo SP gasto. Nunca erra.` },

  // Ninja
  kunai: { name: 'Arremesso de Kunai', icon: '⟡', target: 'enemy', range: 5, max: 5, sp: (l) => 5 + l,
    kind: 'phys', mult: (l) => 1.3 + l * 0.32, proj: '#d8dce8',
    desc: (l) => `Arremessa uma kunai a distância: ${pct(1.3 + l * 0.32)} do ATQ.` },
  jutsu_fogo: { name: 'Jutsu: Lótus de Fogo', icon: '✿', target: 'tile', range: 5, aoe: 1, max: 5, sp: (l) => 12 + l * 2,
    kind: 'magic', el: 'fogo', mult: (l) => 1.0 + l * 0.42, cast: 1.2,
    desc: (l) => `Explosão de chamas em raio 1: ${pct(1.0 + l * 0.42)} do ATQM.` },
  substituicao: { name: 'Substituição', icon: '❖', target: 'self', buff: true, aura: 15, max: 5, sp: (l) => 12,
    buffs: (l) => ({ id: 'substituicao', turns: 18 + l * 3, mods: { flee: 10 + l * 5 } }),
    desc: (l) => `Troca de lugar com um tronco ao ser atacado: +${10 + l * 5} esquiva. Aura: fica ligada e reserva 15% do SP.` },
  passos_sombra: { name: 'Passos da Sombra', icon: '➹', target: 'passive', max: 5,
    mods: (l) => ({ agi: l, speed: l * 3, crit: l }), desc: (l) => `+${l} AGI, +${l * 3} velocidade e +${l}% crítico.` },

  // Shinobi
  lamina_fantasma: { name: 'Lâmina Fantasma', icon: '⟋', target: 'enemy', range: 3, max: 5, sp: (l) => 14 + l * 2,
    kind: 'phys', mult: (l) => 2.4 + l * 0.6, critBonus: 20, sureHit: true,
    desc: (l) => `Avança como um borrão e corta: ${pct(2.4 + l * 0.6)} do ATQ, +20% crítico, alcance 3.` },
  chuva_shuriken: { name: 'Chuva de Shurikens', icon: '✦', target: 'self', aoe: 2, max: 5, sp: (l) => 18 + l * 3,
    kind: 'phys', mult: (l) => 1.4 + l * 0.35, hits: 3,
    desc: (l) => `Shurikens em todas as direções, raio 2: ${pct(1.4 + l * 0.35)} do ATQ.` },
  clones_sombra: { name: 'Clones de Sombra', icon: '❂', target: 'self', buff: true, max: 5, sp: (l) => 20,
    buffs: (l) => ({ id: 'clones', turns: 15 + l * 3, mods: { flee: 20 + l * 6, crit: 10 } }),
    desc: (l) => `Clones confundem os inimigos: +${20 + l * 6} esquiva e +10% crítico por ${15 + l * 3} turnos.` },
  arte_ninja: { name: 'Arte Ninja', icon: '☯', target: 'passive', max: 5,
    mods: (l) => ({ matkPct: l * 5, atk: l * 4, int: l }), desc: (l) => `+${l * 5}% ATQM, +${l * 4} ATQ e +${l} INT.` },

  // Taekwon
  chute_giratorio: { name: 'Chute Giratório', icon: '↻', target: 'self', aoe: 1, max: 5, sp: (l) => 10 + l,
    kind: 'phys', mult: (l) => 1.5 + l * 0.3, knock: 1,
    desc: (l) => `Gira chutando tudo em volta: ${pct(1.5 + l * 0.3)} do ATQ e empurra.` },
  chute_machado: { name: 'Chute Machado', icon: '⤓', target: 'enemy', range: 1, max: 5, sp: (l) => 8 + l,
    kind: 'phys', mult: (l) => 1.9 + l * 0.45, stun: (l) => 10 + l * 5,
    desc: (l) => `Calcanhar descendo como um machado: ${pct(1.9 + l * 0.45)} do ATQ, ${10 + l * 5}% de atordoar.` },
  postura_taekwon: { name: 'Postura de Combate', icon: '☗', target: 'self', buff: true, aura: 15, max: 5, sp: (l) => 12,
    buffs: (l) => ({ id: 'postura', turns: 25 + l * 5, mods: { agi: l + 1, flee: l * 3, atk: l * 5 } }),
    desc: (l) => `+${l + 1} AGI, +${l * 3} esquiva e +${l * 5} ATQ. Aura: fica ligada e reserva 15% do SP.` },
  corrida: { name: 'Corrida', icon: '»', target: 'passive', max: 5,
    mods: (l) => ({ speed: l * 5, agi: l, unarmedAtk: l * 8 }), desc: (l) => `+${l * 5} velocidade, +${l} AGI e +${l * 8} ATQ lutando sem arma.` },

  // Mestre Taekwon
  chute_voador: { name: 'Chute Voador', icon: '➚', target: 'enemy', range: 4, max: 5, sp: (l) => 14 + l * 2,
    kind: 'phys', mult: (l) => 2.4 + l * 0.6, sureHit: true, knock: 1,
    desc: (l) => `Salta até o alvo com um chute: ${pct(2.4 + l * 0.6)} do ATQ, alcance 4, nunca erra.` },
  furia_solar: { name: 'Fúria do Sol', icon: '☀', target: 'self', aoe: 2, max: 5, sp: (l) => 20 + l * 3,
    kind: 'phys', el: 'fogo', mult: (l) => 1.8 + l * 0.45,
    desc: (l) => `Chute flamejante em raio 2: ${pct(1.8 + l * 0.45)} do ATQ de fogo.` },
  protecao_estelar: { name: 'Proteção Estelar', icon: '✧', target: 'self', buff: true, max: 5, sp: (l) => 18,
    buffs: (l) => ({ id: 'kyrie', turns: 25, mods: { def: l * 3 }, shieldPct: 0.1 + l * 0.04 }),
    desc: (l) => `Escudo de estrelas que absorve ${Math.round((0.1 + l * 0.04) * 100)}% do HP máximo em dano, +${l * 3} DEF.` },
  unidade_corpo: { name: 'Unidade do Corpo', icon: '✪', target: 'passive', max: 5,
    mods: (l) => ({ hpPct: l * 4, atk: l * 5, crit: l, unarmedAtk: l * 12 }), desc: (l) => `+${l * 4}% HP, +${l * 5} ATQ, +${l}% crítico e +${l * 12} ATQ lutando sem arma.` },

  // Mago
  lanca_fogo: { name: 'Lança de Fogo', icon: '🔥', target: 'enemy', range: 6, max: 5, sp: (l) => 10,
    kind: 'magic', el: 'fogo', mult: (l) => 0.7 + l * 0.38, cast: 1, proj: '#ff7a3d',
    desc: (l) => `Dano mágico de fogo: ${pct(0.7 + l * 0.38)} do ATQM.` },
  lanca_gelo: { name: 'Lança de Gelo', icon: '❄', target: 'enemy', range: 6, max: 5, sp: (l) => 10,
    kind: 'magic', el: 'agua', mult: (l) => 0.65 + l * 0.34, cast: 1, freeze: (l) => 20 + l * 8, proj: '#7fd3ff',
    desc: (l) => `Água: ${pct(0.65 + l * 0.34)} do ATQM, ${20 + l * 8}% de congelar.` },
  relampago: { name: 'Relâmpago', icon: 'ϟ', target: 'enemy', range: 6, max: 5, sp: (l) => 10,
    kind: 'magic', el: 'vento', mult: (l) => 0.7 + l * 0.38, cast: 1, proj: '#d8fff0',
    desc: (l) => `Vento: ${pct(0.7 + l * 0.38)} do ATQM.` },
  congelar: { name: 'Congelar', icon: '❆', target: 'self', aoe: 2, max: 5, sp: (l) => 22,
    kind: 'magic', el: 'agua', mult: (l) => 0.5 + l * 0.15, freeze: (l) => 40 + l * 10, cast: 1,
    desc: (l) => `Onda de gelo em raio 2: ${pct(0.5 + l * 0.15)} do ATQM e ${40 + l * 10}% de congelar. Raios estilhaçam o gelo.` },
  meditacao: { name: 'Meditação', icon: '☯', target: 'passive', max: 5,
    mods: (l) => ({ spPct: l * 6, regenSp: l * 0.6 }), desc: (l) => `+${l * 6}% SP e regeneração de SP.` },

  // Bruxo
  meteoro: { name: 'Chuva de Meteoros', icon: '☄', target: 'tile', range: 6, aoe: 2, max: 5, sp: (l) => 38,
    kind: 'magic', el: 'fogo', mult: (l) => 1.3 + l * 0.5, stun: (l) => 10, cast: 1.6,
    desc: (l) => `Meteoros em raio 2: ${pct(1.3 + l * 0.5)} do ATQM, pode atordoar.` },
  nevasca: { name: 'Nevasca', icon: '❅', target: 'tile', range: 6, aoe: 2, max: 5, sp: (l) => 34,
    kind: 'magic', el: 'agua', mult: (l) => 1.1 + l * 0.45, freeze: (l) => 25 + l * 6, cast: 1.5,
    desc: (l) => `Tempestade de gelo em raio 2: ${pct(1.1 + l * 0.45)} do ATQM, congela.` },
  vortice_jupiter: { name: 'Trovão de Júpiter', icon: '✦', target: 'enemy', range: 6, max: 5, sp: (l) => 22,
    kind: 'magic', el: 'vento', mult: (l) => 1.4 + l * 0.5, cast: 1.3, knock: 2, proj: '#b9fff0',
    desc: (l) => `Esfera elétrica: ${pct(1.4 + l * 0.5)} do ATQM e empurra.` },
  amplificacao: { name: 'Amplificação', icon: '✧', target: 'passive', max: 5,
    mods: (l) => ({ matkPct: l * 5, int: l }), desc: (l) => `+${l * 5}% ATQM e +${l} INT.` },

  // Arqueiro
  tiro_duplo: { name: 'Tiro Duplo', icon: '➶', target: 'enemy', range: 6, needsBow: true, max: 5, sp: (l) => 12,
    kind: 'phys', mult: (l) => 1.7 + l * 0.35, hits: 2, proj: '#f0e2b6',
    desc: (l) => `Dois disparos: ${pct(1.7 + l * 0.35)} do ATQ. Exige arco ou besta.` },
  chuva_flechas: { name: 'Chuva de Flechas', icon: '⇊', target: 'tile', range: 6, aoe: 1, needsBow: true, max: 5, sp: (l) => 12,
    kind: 'phys', mult: (l) => 1.1 + l * 0.25, knock: 1,
    desc: (l) => `Disparos em raio 1: ${pct(1.1 + l * 0.25)} do ATQ. Exige arco ou besta.` },
  olhos_coruja: { name: 'Olhos de Coruja', icon: '◉', target: 'passive', max: 5,
    mods: (l) => ({ dex: l * 2 }), desc: (l) => `+${l * 2} DES.` },
  olho_aguia: { name: 'Olho de Águia', icon: '◎', target: 'passive', max: 5,
    mods: (l) => ({ hit: l * 3, crit: l }), desc: (l) => `+${l * 3} precisão e +${l}% crítico.` },

  // Caçador
  tiro_certeiro: { name: 'Virote Perfurante', icon: '➳', target: 'enemy', range: 7, needsBow: true, line: true, max: 5, sp: (l) => 26,
    kind: 'phys', mult: (l) => 2.2 + l * 0.55, critBonus: 25, proj: '#ffe8a0',
    desc: (l) => `Disparo que atravessa a linha: ${pct(2.2 + l * 0.55)} do ATQ, +25% crítico. Exige arco ou besta.` },
  rede: { name: 'Rede de Caça', icon: '#', target: 'enemy', range: 5, max: 5, sp: (l) => 10,
    kind: 'status', snare: (l) => 2 + l, proj: '#d9c48a',
    desc: (l) => `Prende o alvo por ${2 + l} turnos.` },
  falcao: { name: 'Falcão de Caça', icon: '🦅', target: 'passive', max: 5,
    mods: (l) => ({ falcon: l }), desc: (l) => `${l * 5}% de chance do falcão atacar junto (ignora esquiva).` },
  instinto: { name: 'Instinto', icon: '☘', target: 'passive', max: 5,
    mods: (l) => ({ agi: l, flee: l * 3 }), desc: (l) => `+${l} AGI e +${l * 3} esquiva.` },

  // Gatuno
  ataque_duplo: { name: 'Ataque Duplo', icon: '⚔', target: 'passive', max: 5,
    mods: (l) => ({ doubleAtk: l * 10 }), desc: (l) => `${l * 10}% de chance de golpear duas vezes.` },
  envenenar: { name: 'Envenenar', icon: '☠', target: 'enemy', range: 1, max: 5, sp: (l) => 10,
    kind: 'phys', mult: (l) => 1.4 + l * 0.3, flat: (l) => l * 15, poison: (l) => 25 + l * 9,
    desc: (l) => `Golpe venenoso: ${pct(1.4 + l * 0.3)} ATQ +${l * 15}, ${25 + l * 9}% de envenenar.` },
  envenenar_arma: { name: 'Envenenar Arma', icon: '☠', target: 'self', aura: 15, max: 5, sp: (l) => 12,
    buffs: (l) => ({ id: 'veneno_arma', mods: { poisonFlat: 6 + l * 6, poisonChance: 10 + l * 6 } }),
    desc: (l) => `Aura (reserva 15% do SP): cada ataque básico causa +${6 + l * 6} de dano de veneno e tem ${10 + l * 6}% de envenenar.` },
  esconderijo: { name: 'Esconderijo', icon: '◐', target: 'self', buff: true, max: 5, sp: (l) => 10,
    buffs: (l) => ({ id: 'oculto', turns: 4 + l * 2, mods: {} }),
    desc: (l) => `Fica invisível por ${4 + l * 2} turnos. O próximo ataque causa +50%.` },
  furto: { name: 'Furto', icon: '✋', target: 'enemy', range: 1, max: 5, sp: (l) => 6,
    kind: 'steal', desc: (l) => `${15 + l * 7}% de chance de roubar zeny ou item (1× por monstro).` },

  // Assassino
  laminas_sonicas: { name: 'Lâminas Sônicas', icon: '✶', target: 'enemy', range: 1, max: 5, sp: (l) => 16 + l * 2,
    kind: 'phys', mult: (l) => 3 + l * 0.8, hits: 8, stun: (l) => 10 + l * 2,
    desc: (l) => `8 golpes rápidos: ${pct(3 + l * 0.8)} do ATQ, pode atordoar.` },
  garra_sombria: { name: 'Garra Sombria', icon: '✷', target: 'tile', range: 3, aoe: 1, max: 5, sp: (l) => 8 + l,
    kind: 'phys', el: 'sombrio', mult: (l) => 1.3 + l * 0.3, keepHidden: true,
    desc: (l) => `Ataque sombrio em raio 1 a distância: ${pct(1.3 + l * 0.3)} do ATQ. Não revela.` },
  furtividade: { name: 'Furtividade', icon: '◑', target: 'self', buff: true, max: 5, sp: (l) => 14,
    buffs: (l) => ({ id: 'oculto', turns: 8 + l * 3, mods: { crit: 30 } }),
    desc: (l) => `Invisível por ${8 + l * 3} turnos com +30% crítico.` },
  maestria_katar: { name: 'Maestria com Katar', icon: '⚚', target: 'passive', max: 5,
    mods: (l) => ({ crit: l * 2, atk: l * 4, critDmg: l * 6 }), desc: (l) => `+${l * 2}% crítico, +${l * 4} ATQ e +${l * 6}% de dano crítico. Dobra com katar.` },

  // Noviço
  curar: { name: 'Curar', icon: '✚', target: 'self', max: 5, sp: (l) => 8 + l * 3,
    heal: (l, h, d) => Math.floor((d.int * 2 + h.lv * 2) * (1 + l * 0.6)) + 30,
    desc: (l) => `Cura (2×INT + 2×nível) × ${(1 + l * 0.6).toFixed(1)} + 30 HP.` },
  bencao: { name: 'Bênção', icon: '✺', target: 'self', buff: true, aura: 20, max: 5, sp: (l) => 12 + l * 2,
    buffs: (l) => ({ id: 'bencao', turns: 30 + l * 10, mods: { str: l + 1, int: l + 1, dex: l + 1, agi: l + 1, speed: l * 3 } }),
    desc: (l) => `+${l + 1} FOR, AGI, INT e DES e +${l * 3} velocidade. Aura: fica ligada e reserva 20% do SP.` },
  aumentar_agilidade: { name: 'Aumentar Agilidade', icon: '➚', target: 'self', buff: true, max: 5, sp: (l) => 15,
    buffs: (l) => ({ id: 'agilidade', turns: 30 + l * 10, mods: { agi: l + 2, speed: l * 5 } }),
    desc: (l) => `+${l + 2} AGI e +${l * 5} velocidade por ${30 + l * 10} turnos.` },
  luz_divina: { name: 'Luz Divina', icon: '☀', target: 'enemy', range: 6, max: 5, sp: (l) => 12,
    kind: 'magic', el: 'sagrado', mult: (l) => 1.8 + l * 0.45, cast: 1, proj: '#fff2b0',
    desc: (l) => `Raio sagrado: ${pct(1.8 + l * 0.45)} do ATQM. Forte contra mortos-vivos.` },

  // Sacerdote
  magnus: { name: 'Magnus Exorcismus', icon: '✝', target: 'tile', range: 6, aoe: 2, max: 5, sp: (l) => 30 + l * 4,
    kind: 'magic', el: 'sagrado', mult: (l) => 1.8 + l * 0.5,
    desc: (l) => `Cruz sagrada em raio 2: ${pct(1.8 + l * 0.5)} do ATQM.` },
  kyrie: { name: 'Kyrie Eleison', icon: '⛨', target: 'self', buff: true, max: 5, sp: (l) => 20,
    buffs: (l) => ({ id: 'kyrie', turns: 25, mods: {}, shieldPct: 0.12 + l * 0.05 }),
    desc: (l) => `Escudo que absorve ${Math.round((0.12 + l * 0.05) * 100)}% do HP máx. em dano.` },
  graca_divina: { name: 'Graça Divina', icon: '✟', target: 'passive', max: 5,
    mods: (l) => ({ revive: l }), desc: (l) => `Ao morrer, revive com ${l * 12}% do HP (1× por andar).` },
  cura_maior: { name: 'Santuário', icon: '❋', target: 'self', buff: true, max: 5, sp: (l) => 25 + l * 3,
    buffs: (l) => ({ id: 'santuario', turns: 10, mods: { regenHp: 8 + l * 6 } }),
    desc: (l) => `Regenera ${8 + l * 6} HP por turno durante 10 turnos.` },

  // Mercador
  mammonita: { name: 'Mammonita', icon: '¤', target: 'enemy', range: 1, max: 5, sp: (l) => 5,
    kind: 'phys', mult: (l) => 1.6 + l * 0.5, zeny: (l) => l * 25,
    desc: (l) => `Golpe de ${pct(1.6 + l * 0.5)} do ATQ. Custa ${l * 25} zeny.` },
  carrinhada: { name: 'Carrinhada', icon: '⛟', target: 'enemy', range: 1, aoe: 1, max: 5, sp: (l) => 12,
    kind: 'phys', mult: (l) => 1.5 + l * 0.2, knock: 2,
    desc: (l) => `Carrinho em raio 1 do alvo: ${pct(1.5 + l * 0.2)} do ATQ e empurra.` },
  desconto: { name: 'Desconto', icon: '%', target: 'passive', max: 5,
    mods: (l) => ({ discount: l * 4 }), desc: (l) => `Compras ${l * 4}% mais baratas.` },
  superfaturar: { name: 'Superfaturar', icon: '$', target: 'passive', max: 5,
    mods: (l) => ({ zenyPct: l * 6 }), desc: (l) => `+${l * 6}% de zeny ganho e nas vendas.` },

  // Ferreiro
  martelo_thor: { name: 'Martelo de Thor', icon: '⚒', target: 'self', aoe: 2, max: 5, sp: (l) => 12 + l,
    kind: 'phys', mult: (l) => 0.9 + l * 0.15, stun: (l) => 25 + l * 10,
    desc: (l) => `Abala o chão em raio 2: ${pct(0.9 + l * 0.15)} ATQ e ${25 + l * 10}% de atordoar.` },
  adrenalina: { name: 'Adrenalina', icon: '⚡', target: 'self', buff: true, max: 5, sp: (l) => 20,
    buffs: (l) => ({ id: 'adrenalina', turns: 15 + l * 5, mods: { speed: 15 + l * 5 } }),
    desc: (l) => `+${15 + l * 5} velocidade por ${15 + l * 5} turnos.` },
  forca_bruta: { name: 'Força Bruta', icon: '✊', target: 'self', buff: true, max: 5, sp: (l) => 15,
    buffs: (l) => ({ id: 'forca_bruta', turns: 20 + l * 4, mods: { atkPct: 5 + l * 5 } }),
    desc: (l) => `+${5 + l * 5}% ATQ por ${20 + l * 4} turnos.` },
  forja: { name: 'Mestre da Forja', icon: '⚙', target: 'passive', max: 5,
    mods: (l) => ({ refineBonus: l * 4, atk: l * 3 }), desc: (l) => `+${l * 4}% de sucesso no refino e +${l * 3} ATQ.` },
};

// O custo de SP não cresce com o nível da habilidade: fica fixo no valor do nível 1
for (const sk of Object.values(SKILLS)) {
  if (typeof sk.sp === 'function') { const c = sk.sp(1); sk.sp = () => c; }
}

// ------------------------------------------------------------------
// Temas / biomas
// ------------------------------------------------------------------
export const THEMES = [
  { name: 'Campos de Prado', floors: [1, 5], lv: [1, 6], floor: ['#3e5f36', '#456b3b'], wall: ['#5a7a4a', '#2f4426', '#3a5530'], accent: '#ffe08a',
    decor: ['grass', 'flower', 'rock', 'grass', 'crate'], liquid: 'agua', ambient: 'rgba(255,240,200,0.05)', light: '#ffd890',
    monsters: ['gelim', 'larvinha', 'cogumelo', 'coelho', 'abelha', 'lobo'], boss: 'rei_gelim' },
  { name: 'Esgotos Antigos', floors: [6, 10], lv: [7, 14], floor: ['#3a4146', '#40484e'], wall: ['#5d666c', '#2a3034', '#373e43'], accent: '#7fe0a8',
    decor: ['puddle', 'pipe', 'bones', 'barrel', 'crate'], liquid: 'lodo', ambient: 'rgba(120,255,160,0.04)', light: '#a6ffcf',
    monsters: ['rato', 'morcego', 'sapo', 'barata', 'lodo', 'crocodilo'], boss: 'rainha_barata' },
  { name: 'Dunas de Sombra', floors: [11, 15], lv: [15, 22], floor: ['#8f7448', '#9a7d4e'], wall: ['#b8955e', '#6e5530', '#86683c'], accent: '#ffcf6b',
    decor: ['sand', 'skull', 'cactus', 'barrel'], liquid: 'areia', ambient: 'rgba(255,200,120,0.05)', light: '#ffc874',
    monsters: ['escorpiao', 'serpente', 'mumia', 'aranha', 'golem_areia', 'dancarina'], boss: 'farao' },
  { name: 'Castelo Sombrio', floors: [16, 20], lv: [23, 32], floor: ['#34303f', '#3a3547'], wall: ['#5b5470', '#221f2b', '#2d2939'], accent: '#c9a6ff',
    decor: ['carpet', 'bones', 'candle', 'crystal', 'barrel'], liquid: 'agua', ambient: 'rgba(170,140,255,0.05)', light: '#d8b8ff',
    monsters: ['esqueleto', 'arq_esqueleto', 'fantasma', 'vampiro', 'gargula', 'cavaleiro_fantasma'], boss: 'lorde_sombrio' },
  { name: 'Abismo Ígneo', floors: [21, 25], lv: [33, 42], floor: ['#3b2420', '#432923'], wall: ['#6e3a2c', '#24120e', '#3a1d16'], accent: '#ff8a4a',
    decor: ['ember', 'rock', 'bones', 'crystal'], liquid: 'lava', ambient: 'rgba(255,110,60,0.06)', light: '#ff9a5a',
    monsters: ['diabrete', 'salamandra', 'golem_magma', 'bruxa', 'dragao', 'pesadelo'], boss: 'bafome' },
];

export function themeForFloor(f) {
  if (f > 25) return THEMES[4];
  return THEMES[Math.min(4, Math.floor((f - 1) / 5))];
}

// ------------------------------------------------------------------
// Monstros
// sprite: forma procedural + cores
// ai: lista de comportamentos
// ------------------------------------------------------------------
export const MONSTERS = {
  // Campos
  gelim: { name: 'Gelim', lv: 1, el: 'agua', race: 'amorfo', speed: 85, hpMul: 0.9, atkMul: 0.8, ai: ['erratic'],
    sprite: { shape: 'blob', c: ['#ff9cc0', '#e0507f'] }, card: { slot: 'armor', mods: { luk: 2, flee: 3 } } },
  larvinha: { name: 'Larvinha', lv: 2, el: 'terra', race: 'inseto', speed: 80, hpMul: 1.1, ai: [],
    sprite: { shape: 'bug', c: ['#9be36a', '#4f9a2c'] }, card: { slot: 'armor', mods: { vit: 1, hp: 30 } } },
  cogumelo: { name: 'Cogumelo Esporento', lv: 3, el: 'agua', race: 'planta', speed: 90, ai: [],
    sprite: { shape: 'mushroom', c: ['#e8584a', '#f4e3c8'] }, card: { slot: 'acc', mods: { int: 1, sp: 15 } } },
  coelho: { name: 'Coelho Chifrudo', lv: 2, el: 'neutro', race: 'bruto', speed: 115, ai: ['erratic'],
    sprite: { shape: 'beast', c: ['#f2f2f2', '#c9c9c9'], ears: 'long', horn: true }, card: { slot: 'acc', mods: { luk: 1, crit: 3 } } },
  abelha: { name: 'Vespa Dourada', lv: 4, el: 'vento', race: 'inseto', speed: 125, atkMul: 1.1, hpMul: 0.8, ai: [],
    sprite: { shape: 'bug', c: ['#ffd23f', '#4a3a10'], wings: true, stripes: true }, card: { slot: 'weapon', mods: { str: 1, atk: 5 } } },
  lobo: { name: 'Lobo Cinzento', lv: 6, el: 'terra', race: 'bruto', speed: 115, atkMul: 1.15, ai: [],
    sprite: { shape: 'beast', c: ['#8d939e', '#5b616b'], ears: 'pointy' }, card: { slot: 'weapon', mods: { atk: 10 } } },
  rei_gelim: { name: 'Rei Gelim', lv: 8, el: 'agua', race: 'amorfo', speed: 95, boss: true, hpMul: 0.8, atkMul: 0.85, ai: ['summon', 'slam'], summon: 'gelim',
    sprite: { shape: 'blob', c: ['#ffd36b', '#d99a1c'], crown: true, scale: 1.5 }, card: { slot: 'armor', mods: { hpPct: 10, vit: 3 } } },

  // Esgoto
  rato: { name: 'Ratazana', lv: 7, el: 'neutro', race: 'bruto', speed: 120, hpMul: 0.9, ai: [],
    sprite: { shape: 'beast', c: ['#8a6a52', '#5e4535'], ears: 'round', tail: true, small: true }, card: { slot: 'acc', mods: { agi: 2 } } },
  morcego: { name: 'Morcego', lv: 8, el: 'sombrio', race: 'bruto', speed: 130, hpMul: 0.75, ai: ['erratic', 'drain'],
    sprite: { shape: 'bat', c: ['#7d5ab8', '#3d2a63'] }, card: { slot: 'weapon', mods: { lifesteal: 3 } } },
  sapo: { name: 'Sapo Venenoso', lv: 9, el: 'agua', race: 'peixe', speed: 95, ai: ['poison'],
    sprite: { shape: 'frog', c: ['#5fd16a', '#e8f06a'] }, card: { slot: 'armor', mods: { poisonImmune: 1, vit: 1 } } },
  barata: { name: 'Barata Gigante', lv: 10, el: 'terra', race: 'inseto', speed: 130, fleeMul: 1.3, ai: [],
    sprite: { shape: 'bug', c: ['#8b5a2b', '#3e2612'], flat: true }, card: { slot: 'armor', mods: { flee: 6 } } },
  lodo: { name: 'Lodo Tóxico', lv: 12, el: 'terra', race: 'amorfo', speed: 80, hpMul: 1.6, ai: ['poison'],
    sprite: { shape: 'blob', c: ['#a6e34a', '#4d7a17'], drip: true }, card: { slot: 'armor', mods: { regenHp: 2, hp: 60 } } },
  crocodilo: { name: 'Crocodilo', lv: 14, el: 'agua', race: 'bruto', speed: 90, hpMul: 1.5, defMul: 1.5, atkMul: 1.15, ai: [],
    sprite: { shape: 'beast', c: ['#4f7a3a', '#2c4a1e'], long: true }, card: { slot: 'weapon', mods: { raceDmg: { bruto: 20 } } } },
  rainha_barata: { name: 'Rainha Barata', lv: 17, el: 'fogo', race: 'inseto', speed: 110, boss: true, mdefMul: 1.4, defMul: 1.2, atkMul: 0.85, ai: ['summon', 'slam'], summon: 'barata', summonN: 1,
    sprite: { shape: 'bug', c: ['#e8a83a', '#6a3a10'], flat: true, wings: true, crown: true, scale: 1.6 }, card: { slot: 'armor', mods: { mdef: 25 } } },

  // Dunas
  escorpiao: { name: 'Escorpião', lv: 15, el: 'fogo', race: 'inseto', speed: 105, ai: ['poison'],
    sprite: { shape: 'scorpion', c: ['#e08a3a', '#7a3d12'] }, card: { slot: 'weapon', mods: { atk: 15, dex: 2 } } },
  serpente: { name: 'Serpente das Dunas', lv: 16, el: 'terra', race: 'bruto', speed: 110, ai: ['poison'],
    sprite: { shape: 'snake', c: ['#d8b65a', '#7a5a22'] }, card: { slot: 'acc', mods: { hit: 12 } } },
  mumia: { name: 'Múmia', lv: 18, el: 'morto', race: 'morto', speed: 85, hpMul: 1.6, ai: [],
    sprite: { shape: 'humanoid', c: ['#d9cfb2', '#9a8f72'], wrap: true }, card: { slot: 'armor', mods: { hpPct: 6, def: 4 } } },
  aranha: { name: 'Aranha da Areia', lv: 19, el: 'terra', race: 'inseto', speed: 110, ai: ['web'],
    sprite: { shape: 'spider', c: ['#5a4a3a', '#d84a3a'] }, card: { slot: 'weapon', mods: { raceDmg: { inseto: 20 } } } },
  golem_areia: { name: 'Golem de Areia', lv: 21, el: 'terra', race: 'amorfo', speed: 75, hpMul: 1.8, atkMul: 1.4, defMul: 2, ai: [],
    sprite: { shape: 'golem', c: ['#c9a66a', '#8a6a3a'] }, card: { slot: 'armor', mods: { def: 10 } } },
  dancarina: { name: 'Dançarina Serpente', lv: 22, el: 'sombrio', race: 'demonio', speed: 120, fleeMul: 1.5, ai: [],
    sprite: { shape: 'humanoid', c: ['#7a3fa8', '#3fbf9a'], snakeHair: true }, card: { slot: 'acc', mods: { agi: 3, flee: 4 } } },
  farao: { name: 'Faraó Esquecido', lv: 26, el: 'morto', race: 'morto', speed: 100, boss: true, ai: ['summon', 'slam', 'curse'], summon: 'mumia', summonN: 1,
    sprite: { shape: 'humanoid', c: ['#e8c34a', '#2a4ab8'], pharaoh: true, scale: 1.5 }, card: { slot: 'acc', mods: { spPct: 15, int: 3 } } },

  // Castelo
  esqueleto: { name: 'Esqueleto', lv: 23, el: 'morto', race: 'morto', speed: 100, ai: [],
    sprite: { shape: 'skeleton', c: ['#ece6d6', '#8a8474'] }, card: { slot: 'weapon', mods: { atk: 20 } } },
  arq_esqueleto: { name: 'Arqueiro Esqueleto', lv: 24, el: 'morto', race: 'morto', speed: 100, range: 5, ai: ['ranged'], proj: '#e8e0c8',
    sprite: { shape: 'skeleton', c: ['#e2dccb', '#7a7464'], bow: true }, card: { slot: 'weapon', mods: { dex: 3, hit: 8 } } },
  fantasma: { name: 'Espectro', lv: 26, el: 'fantasma', race: 'demonio', speed: 105, fleeMul: 1.8, hpMul: 0.8, ai: ['erratic'],
    sprite: { shape: 'ghost', c: ['#d8ecff', '#7aa8e8'] }, card: { slot: 'armor', mods: { armorEl: 'fantasma' } } },
  vampiro: { name: 'Morcego Vampiro', lv: 27, el: 'sombrio', race: 'bruto', speed: 135, ai: ['erratic', 'drain'],
    sprite: { shape: 'bat', c: ['#c43a4a', '#4a1018'] }, card: { slot: 'weapon', mods: { lifesteal: 5 } } },
  gargula: { name: 'Gárgula', lv: 29, el: 'vento', race: 'demonio', speed: 110, range: 4, ai: ['ranged'], proj: '#b8f0d8',
    sprite: { shape: 'humanoid', c: ['#8a8f99', '#4a4f59'], wings: true, horns: true }, card: { slot: 'acc', mods: { dex: 2, agi: 2 } } },
  cavaleiro_fantasma: { name: 'Cavaleiro Negro', lv: 32, el: 'sombrio', race: 'humanoide', speed: 100, hpMul: 1.6, defMul: 1.8, atkMul: 1.3, ai: [],
    sprite: { shape: 'humanoid', c: ['#2a2a35', '#8a1a2a'], armored: true }, card: { slot: 'armor', mods: { dmgReduce: 10 } } },
  lorde_sombrio: { name: 'Lorde Sombrio', lv: 36, el: 'sombrio', race: 'demonio', speed: 110, boss: true, hpMul: 1.3, atkMul: 1.2, ai: ['summon', 'meteor', 'teleport'], summon: 'esqueleto',
    sprite: { shape: 'humanoid', c: ['#1a1424', '#c43aff'], cape: true, horns: true, scale: 1.55 }, card: { slot: 'weapon', mods: { matkPct: 15, int: 4 } } },

  // Abismo
  diabrete: { name: 'Diabrete', lv: 33, el: 'fogo', race: 'demonio', speed: 130, hpMul: 0.85, ai: ['erratic'],
    sprite: { shape: 'humanoid', c: ['#e0433a', '#3a1010'], horns: true, small: true, tail: true }, card: { slot: 'acc', mods: { str: 3, luk: 2 } } },
  salamandra: { name: 'Salamandra', lv: 35, el: 'fogo', race: 'bruto', speed: 110, atkMul: 1.2, ai: ['burn'],
    sprite: { shape: 'beast', c: ['#ff6a2a', '#8a1a0a'], long: true, flameTail: true }, card: { slot: 'weapon', mods: { weaponEl: 'fogo', atk: 10 } } },
  golem_magma: { name: 'Golem de Magma', lv: 37, el: 'fogo', race: 'amorfo', speed: 75, hpMul: 1.9, defMul: 2, atkMul: 1.4, ai: ['burn'],
    sprite: { shape: 'golem', c: ['#4a2a22', '#ff7a2a'], lava: true }, card: { slot: 'armor', mods: { armorEl: 'fogo', hp: 200 } } },
  bruxa: { name: 'Bruxa do Abismo', lv: 39, el: 'sombrio', race: 'humanoide', speed: 105, range: 5, magic: true, ai: ['ranged'], proj: '#c47aff',
    sprite: { shape: 'humanoid', c: ['#3a1a5a', '#9affb0'], witch: true }, card: { slot: 'acc', mods: { int: 4, matk: 20 } } },
  dragao: { name: 'Dragão Jovem', lv: 41, el: 'fogo', race: 'dragao', speed: 105, hpMul: 1.4, atkMul: 1.2, range: 4, ai: ['ranged', 'burn'], proj: '#ff8a3a',
    sprite: { shape: 'dragon', c: ['#c4302a', '#ffc04a'] }, card: { slot: 'weapon', mods: { atkPct: 10 } } },
  pesadelo: { name: 'Pesadelo', lv: 42, el: 'fantasma', race: 'demonio', speed: 135, ai: ['stunhit'],
    sprite: { shape: 'beast', c: ['#1a1a24', '#8a4aff'], ears: 'pointy', mane: true, ghostly: true }, card: { slot: 'acc', mods: { agi: 4, speed: 8 } } },
  bafome: { name: 'Bafomé', lv: 50, el: 'sombrio', race: 'demonio', speed: 115, boss: true, hpMul: 1.3, atkMul: 1.15, ai: ['summon', 'slam', 'meteor', 'teleport'], summon: 'diabrete',
    sprite: { shape: 'humanoid', c: ['#3a2a3a', '#c4302a'], goat: true, scythe: true, scale: 1.7 }, card: { slot: 'weapon', mods: { atkPct: 20, crit: 10 } } },
};

// ------------------------------------------------------------------
// Itens
// ------------------------------------------------------------------
export const WTYPES = {
  adaga: { name: 'Adaga', range: 1, mods: { crit: 8, speed: 10 } },
  espada: { name: 'Espada', range: 1, mods: {} },
  lanca: { name: 'Lança', range: 2, mods: {} },
  cajado: { name: 'Cajado', range: 1, mods: {} },
  arco: { name: 'Arco', range: 5, ranged: true, mods: {} },
  maca: { name: 'Maça', range: 1, mods: { hit: 5 } },
  machado: { name: 'Machado', range: 1, mods: { speed: -10, crit: 2 } },
  kunai: { name: 'Kunai', range: 1, mods: { crit: 6, speed: 6 } },
  fuuma: { name: 'Fuuma Shuriken', range: 2, mods: { speed: -6, crit: 3 } },
  treino: { name: 'Espada de Treino', range: 1, mods: { hit: 6 } },
  besta: { name: 'Besta', range: 5, ranged: true, mods: { crit: 3, speed: -4 } },
  katar: { name: 'Katar', range: 1, mods: { crit: 12 } },
  soqueira: { name: 'Soqueira', range: 1, mods: { speed: 10, hit: 4 } },
};

export const ITEMS = {
  // Armas [tipo, tier, atk, matk, extras]
  faca: { kind: 'weapon', name: 'Faca', wtype: 'adaga', tier: 1, atk: 10 },
  adaga: { kind: 'weapon', name: 'Adaga', wtype: 'adaga', tier: 2, atk: 26 },
  estilete: { kind: 'weapon', name: 'Estilete', wtype: 'adaga', tier: 3, atk: 48 },
  gladius: { kind: 'weapon', name: 'Lâmina Gladius', wtype: 'adaga', tier: 4, atk: 80 },
  punhal_sombrio: { kind: 'weapon', name: 'Punhal Sombrio', wtype: 'adaga', tier: 5, atk: 120, el: 'sombrio' },

  espada_curta: { kind: 'weapon', name: 'Espada Curta', wtype: 'espada', tier: 1, atk: 14 },
  sabre: { kind: 'weapon', name: 'Sabre', wtype: 'espada', tier: 2, atk: 33 },
  espada_bastarda: { kind: 'weapon', name: 'Espada Bastarda', wtype: 'espada', tier: 3, atk: 60 },
  montante: { kind: 'weapon', name: 'Montante Rúnico', wtype: 'espada', tier: 4, atk: 96 },
  lamina_celeste: { kind: 'weapon', name: 'Lâmina Celeste', wtype: 'espada', tier: 5, atk: 145, el: 'sagrado' },

  lanca_simples: { kind: 'weapon', name: 'Lança Simples', wtype: 'lanca', tier: 1, atk: 13 },
  pique: { kind: 'weapon', name: 'Pique', wtype: 'lanca', tier: 2, atk: 31 },
  glaive: { kind: 'weapon', name: 'Glaive', wtype: 'lanca', tier: 3, atk: 57 },
  lanca_cavaleiro: { kind: 'weapon', name: 'Lança de Cavaleiro', wtype: 'lanca', tier: 4, atk: 92 },
  lanca_trovao: { kind: 'weapon', name: 'Lança Trovejante', wtype: 'lanca', tier: 5, atk: 140, el: 'vento' },

  vara: { kind: 'weapon', name: 'Vara de Aprendiz', wtype: 'cajado', tier: 1, atk: 6, matk: 15 },
  cajado_carvalho: { kind: 'weapon', name: 'Cajado de Carvalho', wtype: 'cajado', tier: 2, atk: 10, matk: 36, mods: { int: 1 } },
  cetro_arcano: { kind: 'weapon', name: 'Cetro Arcano', wtype: 'cajado', tier: 3, atk: 14, matk: 66, mods: { int: 2 } },
  cajado_sabio: { kind: 'weapon', name: 'Cajado do Sábio', wtype: 'cajado', tier: 4, atk: 18, matk: 102, mods: { int: 3 } },
  baculo_celestial: { kind: 'weapon', name: 'Báculo Celestial', wtype: 'cajado', tier: 5, atk: 24, matk: 150, mods: { int: 4, spPct: 10 } },

  arco_curto: { kind: 'weapon', name: 'Arco Curto', wtype: 'arco', tier: 1, atk: 12 },
  arco_composto: { kind: 'weapon', name: 'Arco Composto', wtype: 'arco', tier: 2, atk: 29 },
  arco_longo: { kind: 'weapon', name: 'Arco Longo', wtype: 'arco', tier: 3, atk: 53 },
  arco_caca: { kind: 'weapon', name: 'Arco de Caça', wtype: 'arco', tier: 4, atk: 85 },
  arco_elfico: { kind: 'weapon', name: 'Arco Élfico', wtype: 'arco', tier: 5, atk: 130, mods: { dex: 4 } },

  clava: { kind: 'weapon', name: 'Clava', wtype: 'maca', tier: 1, atk: 15 },
  maca: { kind: 'weapon', name: 'Maça', wtype: 'maca', tier: 2, atk: 35 },
  maca_estrela: { kind: 'weapon', name: 'Maça Estrela', wtype: 'maca', tier: 3, atk: 62 },
  martelo_sagrado: { kind: 'weapon', name: 'Martelo Sagrado', wtype: 'maca', tier: 4, atk: 97, el: 'sagrado' },
  maca_divina: { kind: 'weapon', name: 'Maça Divina', wtype: 'maca', tier: 5, atk: 146, mods: { int: 3 } },

  machadinha: { kind: 'weapon', name: 'Machadinha', wtype: 'machado', tier: 1, atk: 19 },
  machado: { kind: 'weapon', name: 'Machado', wtype: 'machado', tier: 2, atk: 42 },
  machado_duplo: { kind: 'weapon', name: 'Machado Duplo', wtype: 'machado', tier: 3, atk: 74 },
  machado_barbaro: { kind: 'weapon', name: 'Machado Bárbaro', wtype: 'machado', tier: 4, atk: 112 },
  machado_tita: { kind: 'weapon', name: 'Machado Titânico', wtype: 'machado', tier: 5, atk: 168 },

  espada_treino: { kind: 'weapon', name: 'Espada de Treino', wtype: 'treino', tier: 1, atk: 9 },

  kunai: { kind: 'weapon', name: 'Kunai', wtype: 'kunai', tier: 1, atk: 11 },
  kunai_aco: { kind: 'weapon', name: 'Kunai de Aço', wtype: 'kunai', tier: 2, atk: 27 },
  kunai_serpente: { kind: 'weapon', name: 'Kunai Serpente', wtype: 'kunai', tier: 3, atk: 50 },
  kunai_sombria: { kind: 'weapon', name: 'Kunai Sombria', wtype: 'kunai', tier: 4, atk: 82, el: 'sombrio' },
  kunai_celestial: { kind: 'weapon', name: 'Kunai Celestial', wtype: 'kunai', tier: 5, atk: 124 },

  fuuma_ferro: { kind: 'weapon', name: 'Fuuma de Ferro', wtype: 'fuuma', tier: 1, atk: 17 },
  fuuma_lamina: { kind: 'weapon', name: 'Fuuma de Lâminas', wtype: 'fuuma', tier: 2, atk: 39 },
  fuuma_dentada: { kind: 'weapon', name: 'Fuuma Dentada', wtype: 'fuuma', tier: 3, atk: 68 },
  fuuma_sombria: { kind: 'weapon', name: 'Fuuma Sombria', wtype: 'fuuma', tier: 4, atk: 104, el: 'sombrio' },
  fuuma_celestial: { kind: 'weapon', name: 'Fuuma Celestial', wtype: 'fuuma', tier: 5, atk: 150 },

  besta_leve: { kind: 'weapon', name: 'Besta Leve', wtype: 'besta', tier: 1, atk: 14 },
  besta_caca: { kind: 'weapon', name: 'Besta de Caça', wtype: 'besta', tier: 2, atk: 32 },
  besta_pesada: { kind: 'weapon', name: 'Besta Pesada', wtype: 'besta', tier: 3, atk: 58 },
  besta_repeticao: { kind: 'weapon', name: 'Besta de Repetição', wtype: 'besta', tier: 4, atk: 90 },
  besta_tempestade: { kind: 'weapon', name: 'Besta Tempestade', wtype: 'besta', tier: 5, atk: 136, el: 'vento' },

  katar_ferro: { kind: 'weapon', name: 'Katar de Ferro', wtype: 'katar', tier: 1, atk: 13 },
  katar_serrilhado: { kind: 'weapon', name: 'Katar Serrilhado', wtype: 'katar', tier: 2, atk: 30 },
  katar_gemeo: { kind: 'weapon', name: 'Katar Gêmeo', wtype: 'katar', tier: 3, atk: 55 },
  katar_sombrio: { kind: 'weapon', name: 'Katar Sombrio', wtype: 'katar', tier: 4, atk: 88, el: 'sombrio' },
  katar_abismo: { kind: 'weapon', name: 'Katar do Abismo', wtype: 'katar', tier: 5, atk: 132 },

  soqueira_couro: { kind: 'weapon', name: 'Soqueira de Couro', wtype: 'soqueira', tier: 1, atk: 12 },
  soqueira_ferro: { kind: 'weapon', name: 'Soqueira de Ferro', wtype: 'soqueira', tier: 2, atk: 29 },
  garras_tigre: { kind: 'weapon', name: 'Garras de Tigre', wtype: 'soqueira', tier: 3, atk: 54 },
  punho_aco: { kind: 'weapon', name: 'Punho de Aço', wtype: 'soqueira', tier: 4, atk: 86 },
  punho_celestial: { kind: 'weapon', name: 'Punho Celestial', wtype: 'soqueira', tier: 5, atk: 130, el: 'sagrado' },

  // Armaduras
  roupa_algodao: { kind: 'armor', name: 'Roupa de Algodão', tier: 1, def: 4, mdef: 2 },
  tunica_couro: { kind: 'armor', name: 'Túnica de Couro', tier: 2, def: 10, mdef: 3 },
  cota_malha: { kind: 'armor', name: 'Cota de Malha', tier: 3, def: 22, mdef: 4 },
  armadura_placas: { kind: 'armor', name: 'Armadura de Placas', tier: 4, def: 36, mdef: 5 },
  armadura_runica: { kind: 'armor', name: 'Armadura Rúnica', tier: 5, def: 52, mdef: 10, mods: { hpPct: 5 } },
  manto_aprendiz: { kind: 'armor', name: 'Manto de Estudante', tier: 2, def: 6, mdef: 10, mods: { int: 1 } },
  robe_arcano: { kind: 'armor', name: 'Robe Arcano', tier: 3, def: 10, mdef: 18, mods: { int: 3 } },
  traje_ladino: { kind: 'armor', name: 'Traje de Ladino', tier: 3, def: 13, mdef: 5, mods: { agi: 3, flee: 5 } },
  manto_estelar: { kind: 'armor', name: 'Manto Estelar', tier: 5, def: 22, mdef: 30, mods: { int: 5, spPct: 10 } },
  couraca_sombra: { kind: 'armor', name: 'Couraça das Sombras', tier: 5, def: 30, mdef: 12, mods: { agi: 5, crit: 5 } },

  // Acessórios (valor = tier + 1)
  anel_forca: { kind: 'acc', name: 'Anel de Força', stat: 'str' },
  brinco_sabio: { kind: 'acc', name: 'Brinco do Sábio', stat: 'int' },
  luvas_precisas: { kind: 'acc', name: 'Luvas Precisas', stat: 'dex' },
  botas_leves: { kind: 'acc', name: 'Botas Leves', stat: 'agi' },
  colar_vida: { kind: 'acc', name: 'Colar da Vida', stat: 'vit' },
  trevo: { kind: 'acc', name: 'Trevo de Quatro Folhas', stat: 'luk' },

  // Consumíveis
  pocao_vermelha: { kind: 'use', name: 'Poção Vermelha', heal: 45, price: 25, icon: '#e8434a' },
  pocao_laranja: { kind: 'use', name: 'Poção Laranja', heal: 130, price: 80, icon: '#ff9a3a' },
  pocao_amarela: { kind: 'use', name: 'Poção Amarela', heal: 320, price: 220, icon: '#ffd23f' },
  pocao_branca: { kind: 'use', name: 'Poção Branca', heal: 750, price: 520, icon: '#f4f4f4' },
  pocao_azul: { kind: 'use', name: 'Poção Azul', sp: 60, price: 280, icon: '#4a8aff' },
  erva_verde: { kind: 'use', name: 'Erva Verde', cure: true, price: 20, icon: '#5fd16a' },
  asa_mosca: { kind: 'use', name: 'Asa de Mosca', teleport: true, price: 45, icon: '#c9c4b0' },
  asa_borboleta: { kind: 'use', name: 'Asa de Borboleta', recall: true, price: 160, icon: '#7ad0ff' },
  fragmento: { kind: 'mat', name: 'Fragmento Rúnico', price: 450, icon: '#9affe8' },
};

export const POTION_BY_TIER = ['pocao_vermelha', 'pocao_vermelha', 'pocao_laranja', 'pocao_amarela', 'pocao_amarela', 'pocao_branca'];

export const SHOP_ITEMS = ['pocao_vermelha', 'pocao_laranja', 'pocao_amarela', 'pocao_branca', 'pocao_azul', 'erva_verde', 'asa_mosca', 'asa_borboleta', 'fragmento'];

// Equipamentos básicos à venda na cidade (tier 1 e 2)
export const SHOP_GEAR = ['faca', 'espada_curta', 'lanca_simples', 'vara', 'arco_curto', 'besta_leve', 'katar_ferro', 'soqueira_couro', 'kunai', 'fuuma_ferro', 'clava', 'machadinha', 'roupa_algodao', 'tunica_couro', 'manto_aprendiz'];

// Melhorias permanentes do Santuário
export const LEGACY = {
  vida: { name: 'Bênção da Vida', desc: '+5% de HP máximo para todos os heróis.', max: 10, base: 250 },
  mente: { name: 'Bênção da Mente', desc: '+5% de SP máximo.', max: 10, base: 250 },
  talento: { name: 'Talento Inato', desc: '+2 pontos de atributo iniciais.', max: 5, base: 400 },
  fortuna: { name: 'Fortuna', desc: '+6% de zeny e chance de itens.', max: 10, base: 300 },
  kit: { name: 'Kit do Aventureiro', desc: 'Novos heróis começam com poções e asas.', max: 5, base: 200 },
};

// Refino: chance de sucesso por nível alvo (+1 ... +10)
export const REFINE_RATES = [100, 100, 100, 100, 70, 60, 50, 40, 25, 15];
