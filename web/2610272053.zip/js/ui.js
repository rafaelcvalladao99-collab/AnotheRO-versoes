// Interface (HTML sobre o canvas): HUD, cidade, folhas de menu
import * as Game from './game.js';
import { G } from './game.js';
import { BOOSTS } from './data.js';
import { WTYPES, CLASSES, SKILLS, ITEMS, THEMES, LEGACY, SHOP_ITEMS, STAT_NAMES, STAT_DESC, MONSTERS, CLASS_LV, themeForFloor, ELEMENTS } from './data.js';
import { itemDef, itemName, itemDesc, itemColor, isEquip, isStack, sellPrice, buyPrice, makeItem, statCost, xpToNext, STATS, legacyCost, jobBonus, aoeText, aoeGrid } from './rules.js';
import { JOB_BONUS } from './data.js';
import { heroSprite, itemIconURL, spriteURL } from './sprites.js';
import { Audio } from './audio.js';
import { ICON } from './icons.js';
import { sceneURL } from './town.js';
import { fmt } from './util.js';
import { LPC_CREDITS } from './credits.js';
import { wikiSheet } from './wiki.js';
import { marketSheet } from './marketui.js';
import { setGfx } from './render.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let handlers = {};
export function setHandlers(h) { handlers = h; }

const heroURL = (cls) => spriteURL(heroSprite(cls), `h:${cls}`);
const ic = (n) => `<i>${ICON[n]}</i>`;
const purse = () => `<span class="purse price">${ic('coin')}${fmt(G.state.meta.zeny)}</span>`;
export function hydrateIcons(root = document) { root.querySelectorAll('[data-ic]').forEach((e) => { e.innerHTML = ICON[e.dataset.ic]; }); }

// ---------------- Toast ----------------
let toastT = 0;
export function toast(msg, ms = 1800) {
  const t = $('toast');
  t.innerHTML = msg;
  t.classList.remove('hidden');
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.add('hidden'), ms);
}

// ---------------- Folhas ----------------
let sheetStack = [];
export function openSheet({ title, html, mount, center = false, onClose }) {
  closeSheet(true);
  const root = $('sheet-root');
  root.innerHTML = `<div class="sheet-back"></div><div class="sheet ${center ? 'center' : ''}">${center ? '' : '<div class="grab"></div>'}
    <h3>${title}<button class="x" aria-label="Fechar">${ICON.close}</button></h3><div class="body">${html}</div></div>`;
  const close = () => { closeSheet(); };
  root.querySelector('.sheet-back').onclick = close;
  root.querySelector('.x').onclick = close;
  sheetStack = [{ onClose }];
  if (mount) mount(root.querySelector('.body'), root.querySelector('.sheet'));
  return root.querySelector('.body');
}
export function closeSheet(silent) {
  const root = $('sheet-root');
  if (!root.innerHTML) return false;
  const top = sheetStack.pop();
  root.innerHTML = '';
  if (!silent && top && top.onClose) top.onClose();
  if (!silent) refresh(true);
  return true;
}
export const sheetOpen = () => !!$('sheet-root').innerHTML;

// ---------------- HUD ----------------
let lastMode = null;
let lastHudAt = 0;
export function refresh(force) {
  const st = G.state;
  if (!st) return;
  if (st.mode !== lastMode || force === 'screen') {
    lastMode = st.mode;
    renderMode();
  }
  if (st.mode === 'dungeon') updateHUD(force);
  else if (st.mode === 'town' && force) renderTown();
}

function renderMode() {
  const st = G.state;
  const dungeon = st.mode === 'dungeon';
  for (const id of ['hud', 'bottom']) $(id).classList.toggle('hidden', !dungeon);
  $('ctx-btns').classList.toggle('hidden', !dungeon);
  if (!dungeon) $('target-banner').classList.add('hidden');
  $('screen').classList.toggle('hidden', dungeon);
  if (st.mode !== 'town') { hideTown3d(); $('screen').classList.remove('town3d'); }
  if (st.mode === 'title') renderTitle();
  else if (st.mode === 'town') renderTown();
  else if (st.mode === 'dead') renderDeath();
  else if (dungeon) { closeSheet(true); updateHUD(true); }
  const bot = 70; // o leque fica no canto; a câmera só reserva a faixa de baixo
  const top = $('hud').getBoundingClientRect().height || 100;
  handlers.onLayout && handlers.onLayout(Math.min(top, 140), bot);
}

export function updateHUD(force) {
  const now = performance.now();
  if (!force && !G.dirty && now - lastHudAt < 300) return;
  lastHudAt = now;
  G.dirty = false;
  const h = G.state.hero, r = G.state.run, d = G.d;
  if (!h || !r || !d) return;
  $('portrait-img').src = heroURL(h.cls, d.wtype);
  $('hud-lv').textContent = h.lv;
  $('hud-who').textContent = `${h.name} · ${CLASSES[h.cls].name}`;
  const pts = h.statPts > 0 || h.skillPts > 0;
  $('pts-dot').classList.toggle('hidden', !pts);
  $('pts-dot2').classList.toggle('hidden', !pts);
  $('hp-fill').style.width = Math.max(0, h.hp / d.maxHp * 100) + '%';
  $('hp-txt').textContent = `${Math.max(0, Math.ceil(h.hp))} / ${d.maxHp}`;
  $('sp-fill').style.width = (h.sp / d.maxSp * 100) + '%';
  $('sp-txt').textContent = `${Math.floor(h.sp)} / ${d.maxSp}`;
  const capped = h.lv >= Game.levelCap();
  const debt = h.xp < 0;
  $('xp-fill').style.width = (capped && !debt ? 100 : Math.min(100, Math.abs(h.xp) / xpToNext(h.lv, h) * 100)) + '%';
  $('xp-fill').classList.toggle('capped', capped && !debt);
  $('xp-fill').classList.toggle('debt', debt);
  $('hud-floor').textContent = `Andar ${r.floor}`;
  $('hud-floor').style.color = themeForFloor(r.floor).accent;
  $('hud-zeny').innerHTML = `${ic('coin')}${fmt(h.zeny)}`;
  // buffs e status
  const bf = [];
  for (const b of h.buffs) bf.push(`<span class="buff">${b.skill ? `<img src="${skIcon(b.skill)}" alt="">` : (b.icon || "✦")}${b.aura ? "∞" : b.turns}</span>`);
  for (const [k, B] of Object.entries(BOOSTS)) if (h.boosts?.[k] > 0) bf.push(`<span class="buff boost">${B.icon} ${h.boosts[k]}</span>`);
  const stn = { poison: '☠ Veneno', burn: '🔥 Queimando', stun: '✶ Atordoado', freeze: '❄ Congelado', snare: '# Preso', noSpRegen: '☄ SP travado' };
  for (const [k, v] of Object.entries(h.status)) bf.push(`<span class="buff bad">${stn[k] || k} ${v}</span>`);
  $('buffs').innerHTML = bf.join('');
  // chefe
  const boss = r.monsters.find((m) => m.boss && m.hp > 0 && Game.visible(m.x, m.y));
  $('bossbar').classList.toggle('hidden', !boss);
  if (boss) { $('boss-name').textContent = MONSTERS[boss.type].name; $('boss-fill').style.width = (boss.hp / boss.maxHp * 100) + '%'; }
  // log
  const lg = r.log.slice(-4);
  $('log').innerHTML = lg.map((l) => {
    const age = (now - l.at) / 1000;
    const op = age > 6 ? 0 : age > 4 ? 0.35 : 1;
    return `<div style="color:${l.color};opacity:${op}">${esc(l.text)}</div>`;
  }).join('');
  // botões contextuais
  const t = Game.G.state.run.map.t[r.py * r.map.w + r.px];
  const cb = [];
  if (t === 3) cb.push(`<button class="ctx-btn" data-a="descend">${ic('stairs')}Descer</button>`);
  if (t === 6) cb.push(`<button class="ctx-btn gold" data-a="portal">${ic('portal')}Cidade</button>`);
  const ctx = $('ctx-btns');
  ctx.innerHTML = cb.join('');
  ctx.querySelectorAll('button').forEach((b) => b.onclick = () => handlers.onContext(b.dataset.a));
  renderSkillbar();
}

function bestPotion() {
  const h = G.state.hero;
  const order = ['pocao_branca', 'pocao_amarela', 'pocao_laranja', 'pocao_vermelha'];
  const missing = G.d.maxHp - h.hp;
  const have = order.map((id) => h.inv.find((i) => i.id === id)).filter(Boolean);
  if (!have.length) return null;
  // usa a menor poção que cura o que falta; senão a maior
  const fit = [...have].reverse().find((i) => ITEMS[i.id].heal >= missing * 0.8);
  return fit || have[0];
}
export { bestPotion };

// leque de habilidades no canto direito (polegar): 3 no anel de dentro, 5 no de fora, poção no centro
const FAN = [[84, 180], [84, 225], [84, 270], [146, 180], [146, 202.5], [146, 225], [146, 247.5], [146, 270]];
const fanPos = (i) => { const [r, a] = FAN[i]; const t = a * Math.PI / 180; return `--r:${Math.round(32 - r * Math.cos(t) - 24)}px;--b:${Math.round(32 - r * Math.sin(t) - 24)}px`; };
const skIcon = (id) => `assets/icons/sk/${id}.svg`;
export { skIcon };

function renderSkillbar() {
  const h = G.state.hero;
  const bar = $('skillbar');
  const sel = handlers.selectedSkill && handlers.selectedSkill();
  const html = h.bar.slice(0, FAN.length).map((id, i) => {
    if (!id) return `<button class="skill empty" style="${fanPos(i)}" data-i="${i}" aria-label="Escolher habilidade">${ic('plus')}</button>`;
    const sk = SKILLS[id];
    const u = Game.skillUsable(id);
    const auraOn = sk.aura && Game.hasBuff(sk.buffs(1).id);
    return `<button class="skill ${u.ok ? '' : 'off'} ${sel === id ? 'active' : ''} ${auraOn ? 'aura' : ''}" style="${fanPos(i)}" data-id="${id}" aria-label="${esc(sk.name)}"><img class="ski" src="${skIcon(id)}" alt=""><span class="cost">${sk.sp(h.skills[id] || 1)}</span></button>`;
  });
  const pot = bestPotion();
  html.push(pot
    ? `<button class="skill potion" style="--r:0px;--b:0px" data-pot="${pot.uid}"><img src="${itemIconURL(pot)}"><span class="qty">${h.inv.filter((i) => i.id.startsWith('pocao') && i.id !== 'pocao_azul').reduce((a, b) => a + b.qty, 0)}</span></button>`
    : `<button class="skill potion empty" style="--r:0px;--b:0px" aria-label="Sem poções">${ic('potion')}</button>`);
  bar.innerHTML = html.join('');
  bar.querySelectorAll('button').forEach((b) => {
    b.onclick = () => {
      Audio.play('click');
      if (b.dataset.id) handlers.onSkill(b.dataset.id);
      else if (b.dataset.pot) handlers.onPotion(Number(b.dataset.pot));
      else if (b.dataset.i !== undefined) heroSheet('skills');
    };
  });
}

// ---------------- Título / seleção de personagens ----------------
function renderTitle() {
  const st = G.state;
  const meta = st.meta;
  const roster = st.roster || [];
  const veteran = meta.heroesLost || meta.zeny || meta.bestFloor;
  $('screen').innerHTML = `
    <div class="logo">AnotheRO</div>
    <div class="tagline">Desça. Evolua. Negocie. Volte mais forte.</div>
    <div class="title-box">
      ${roster.length ? `<div class="chars">${roster.map((h, i) => `<button class="char frame ${h.hardcore ? 'hc' : ''}" data-i="${i}"><img src="${heroURL(h.cls)}" alt=""><div class="cinfo"><strong>${h.hardcore ? '☠ ' : ''}${esc(h.name)}</strong><small>${h.reborn ? "✦ " : ""}${CLASSES[h.cls].name}, nível ${h.lv}</small><small class="mk-dim">${h.deepest ? `recorde: andar ${h.deepest}` : 'ainda não desceu'}${h.hardcore ? ' · Hardcore' : ''}</small></div><span class="cdel" data-del="${i}" aria-label="Apagar">✕</span></button>`).join('')}</div>`
        : `<div class="title-hero"><img src="${heroURL('mago', 'cajado')}" alt=""><img src="${heroURL('aprendiz', 'adaga')}" alt=""><img src="${heroURL('arqueiro', 'arco')}" alt=""></div>`}
      ${roster.length < Game.MAX_HEROES ? `<button class="btn primary" id="btn-new">${roster.length ? 'Novo personagem' : 'Criar personagem'} <small style="opacity:.7">(${roster.length}/${Game.MAX_HEROES})</small></button>` : `<div class="foot">Todas as ${Game.MAX_HEROES} vagas estão ocupadas.</div>`}
      ${veteran ? `<div class="records"><div><b>${fmt(meta.zeny)}</b><small>zeny no banco</small></div><div><b>${meta.bestFloor}</b><small>andar recorde</small></div><div><b>${meta.victories}</b><small>vitórias</small></div></div>` : ''}
      ${meta.graveyard?.length ? `<button class="btn" id="btn-grave">${ic('skull')}Hall dos heróis caídos</button>` : ''}
      <div class="foot">Banco, armazém, mercado e as bênçãos do Santuário são de todos os seus personagens.</div>
    </div>`;
  $('screen').querySelectorAll('.char').forEach((b) => b.onclick = (e) => {
    if (e.target.closest('[data-del]')) return;
    Audio.unlock();
    Game.selectHero(Number(b.dataset.i));
    refresh('screen');
  });
  $('screen').querySelectorAll('[data-del]').forEach((b) => b.onclick = (e) => {
    e.stopPropagation();
    const h = roster[Number(b.dataset.del)];
    confirmSheet('Apagar personagem?', `${esc(h.name)} (${h.reborn ? "✦ " : ""}${CLASSES[h.cls].name}, nível ${h.lv}) e tudo o que ele carrega e veste serão apagados para sempre. Banco e armazém continuam.`, 'Apagar', () => { Game.deleteHero(Number(b.dataset.del)); refresh('screen'); });
  });
  const nb = $('btn-new');
  if (nb) nb.onclick = () => newHeroSheet();
  const g = $('btn-grave');
  if (g) g.onclick = graveSheet;
}

function newHeroSheet() {
  const meta = G.state.meta;
  let hc = false;
  openSheet({
    title: 'Novo personagem',
    html: `<input class="dv-in" id="nh-name" maxlength="16" placeholder="Nome do herói" value="${esc(meta.lastName || '')}" style="width:100%;box-sizing:border-box">
      <div class="hc-pick">
        <button class="hc-opt on" data-hc="0"><b>Normal</b><small>Ao cair, volta para a vila: perde 25% do XP do nível (pode ficar com dívida de XP) e 75% do zeny ganho na viagem.</small></button>
        <button class="hc-opt" data-hc="1"><b>☠ Hardcore</b><small>Ao cair, o herói se vai para sempre. Em troca: +30% de XP, +30% de zeny e 50% mais chance de drop (inclusive cartas).</small></button>
      </div>
      <button class="btn primary" id="nh-ok" style="margin-top:12px">Começar jornada</button>`,
    mount(b) {
      b.querySelectorAll('[data-hc]').forEach((x) => x.onclick = () => { hc = x.dataset.hc === '1'; b.querySelectorAll('.hc-opt').forEach((o) => o.classList.toggle('on', o === x)); });
      b.querySelector('#nh-ok').onclick = () => {
        Audio.unlock();
        const name = b.querySelector('#nh-name').value.trim() || 'Aventureiro';
        meta.lastName = name;
        const err = Game.createHero(name, hc);
        if (err) { toast(err); return; }
        closeSheet(true);
        refresh('screen');
        setTimeout(() => heroSheet('stats', true), 250);
      };
    },
  });
}

function graveSheet() {
  const gy = G.state.meta.graveyard || [];
  openSheet({ title: '🪦 Hall dos heróis caídos', html: `<div class="list">${gy.map((g) => `<div class="row"><div class="info"><strong>${g.hardcore ? '☠ ' : ''}${esc(g.name)}, ${esc(g.cls)} nível ${g.lv}</strong><small>Caiu no andar ${g.floor}, derrotado por ${esc(g.by || '?')}, em ${new Date(g.at).toLocaleDateString('pt-BR')}</small></div></div>`).join('')}</div>` });
}

// ---------------- Morte ----------------
function renderDeath() {
  const d = G.state.lastDeath || {};
  if (d.hardcore) {
    $('screen').innerHTML = `<div class="death">
      <div class="stone">R.I.P.</div>
      <h1>☠ ${esc(d.name || 'Herói')} caiu</h1>
      <p>${esc(d.cls || '')}, nível ${d.lv}, no andar ${d.floor}</p>
      <p>Derrotado por <b>${esc(d.by || 'algo nas sombras')}</b></p>
      <p style="color:var(--parch-dim)">${d.kills || 0} monstros derrotados. Um herói Hardcore não volta.</p>
      <p style="color:var(--brass-hi);margin-top:18px">O nome dele fica no Hall dos heróis caídos. Banco, armazém e mercado continuam.</p>
      <div class="title-box" style="margin-top:22px"><button class="btn primary" id="btn-ack">Voltar aos personagens</button></div></div>`;
  } else {
    $('screen').innerHTML = `<div class="death">
      <div class="stone">✖</div>
      <h1>${esc(d.name || 'Herói')} foi derrotado</h1>
      <p>Andar ${d.floor}, por <b>${esc(d.by || 'algo nas sombras')}</b></p>
      <p style="color:var(--parch-dim)">Perdeu ${fmt(d.xpLoss || 0)} de XP${d.debt ? ` e ficou com uma <b style="color:#ff8a8a">dívida de ${fmt(d.debt)} XP</b> para pagar antes de evoluir` : ''}.</p>
      <p style="color:var(--parch-dim)">Perdeu ${fmt(d.zenyLost || 0)} zeny da viagem${d.kept ? ` (${fmt(d.kept)} foram para o banco)` : ''}. A mochila e o equipamento ficaram.</p>
      <div class="title-box" style="margin-top:22px"><button class="btn primary" id="btn-ack">Acordar na vila</button></div></div>`;
  }
  $('btn-ack').onclick = () => { Game.acknowledgeDeath(); refresh('screen'); };
}

// ---------------- Cidade ----------------
// ---------------- Cidade 3D ----------------
let town3d = null, town3dFail = false;
const loadTown3d = () => (town3d ||= import('./town3d.js'));
function hideTown3d() { if (town3d) town3d.then((T) => T.hideTown()); }
export { hideTown3d };

function townPlaces() {
  const h = G.state.hero, meta = G.state.meta, co = Game.classOptions();
  const bo = h.boosts || {}, on = Object.entries(BOOSTS).filter(([k]) => bo[k] > 0).map(([k, B]) => `${B.icon} ${bo[k]}`);
  const m = Game.market();
  return {
    dungeon: ['Portão da Masmorra', h.deepest ? `Recorde: andar ${h.deepest}` : 'O primeiro andar espera', false, true],
    legacy: ['Santuário', on.length ? on.join(' · ') : 'Bênçãos e melhorias'],
    class: ['Guilda das Classes', co.opts.length ? (co.ok ? 'Novo caminho pronto!' : co.lvOk ? 'Gaste os pontos' : `Classe nova no nível ${co.need}`) : 'Classe dominada', co.ok],
    shop: ['Empório', 'Poções e asas'],
    smith: ['Forja', 'Refino e armas'],
    storage: ['Armazém', `${meta.storage.length} itens guardados`],
    market: ['Mercado', m.mine.length ? `${m.mine.length} à venda` : 'Negocie com outros'],
  };
}

function townGo(go) {
  Audio.play('click');
  if (go === 'dungeon') dungeonSheet();
  if (go === 'hero') heroSheet();
  if (go === 'bag') bagSheet();
  if (go === 'shop') shopSheet();
  if (go === 'smith') smithSheet();
  if (go === 'storage') storageSheet();
  if (go === 'class') classSheet();
  if (go === 'legacy') legacySheet();
  if (go === 'market') marketSheet();
  if (go === 'menu') menuSheet();
}

export function renderTown() {
  const h = G.state.hero, meta = G.state.meta, d = G.d;
  if (!h) return;
  if (town3dFail) { $('screen').classList.remove('town3d'); return renderTownCards(); }
  const pts = h.statPts > 0 || h.skillPts > 0;
  const tl = (G.state.townLog || []).slice(-1)[0];
  const P = townPlaces();
  const scr = $('screen');
  scr.classList.add('town3d');
  scr.innerHTML = `
    <div class="tplaque">
      <button class="tpor" data-go="hero" aria-label="Herói"><img src="${heroURL(h.cls, d.wtype)}" alt=""><span>${h.lv}</span>${pts ? '<i class="dot"></i>' : ''}</button>
      <button class="twho" data-go="hero"><b>${h.hardcore ? '☠ ' : ''}${esc(h.name)}</b><small>${h.reborn ? '✦ ' : ''}${CLASSES[h.cls].name} · Vila de Runa</small></button>
      <span class="tzeny"><img src="assets/icons/ui/coin.svg" alt="">${fmt(meta.zeny)}</span>
      <button class="tic" data-go="bag" aria-label="Mochila"><img src="assets/icons/ui/bag.svg" alt=""></button>
      <button class="tic" data-go="menu" aria-label="Opções"><img src="assets/icons/ui/menu.svg" alt=""></button>
    </div>
    <div class="tlabels">${Object.entries(P).map(([id, [n, sub, dot, main]]) => `<button class="tlbl ${main ? 'main' : ''}" data-go="${id}" style="visibility:hidden"><b>${n}${dot ? '<i class="tdot"></i>' : ''}</b><small>${esc(sub)}</small></button>`).join('')}</div>
    ${tl ? `<div class="tlog">${esc(tl.text)}</div>` : ''}`;
  scr.querySelectorAll('[data-go]').forEach((b) => b.onclick = (e) => { e.stopPropagation(); townGo(b.dataset.go); });
  const cv = $('town3d');
  scr.onclick = (e) => { if (e.target !== scr && !e.target.classList.contains('tlabels')) return; town3d && town3d.then((T) => { const id = T.pick(e.clientX, e.clientY); if (id) townGo(id); }); };
  loadTown3d().then(async (T) => {
    const pos = await T.showTown(cv, h.cls);
    if (!pos) { town3dFail = true; return renderTown(); }
    if (G.state.mode !== 'town') { T.hideTown(); return; }
    const place = () => {
      const p = T.labelPositions();
      scr.querySelectorAll('.tlbl').forEach((b) => { const q = p[b.dataset.go]; if (!q) return; const minT = scr.querySelector('.tplaque').getBoundingClientRect().bottom + 34; b.style.left = Math.max(70, Math.min(innerWidth - 70, q[0])) + 'px'; b.style.top = Math.max(minT, q[1]) + 'px'; b.style.visibility = ''; });
    };
    place(); T.onFrame(() => { if (cv.clientWidth !== lastTW) { lastTW = cv.clientWidth; place(); } });
  }).catch((e) => { console.warn(e); town3dFail = true; renderTown(); });
}
let lastTW = 0;

function renderTownCards() {
  const h = G.state.hero, meta = G.state.meta, d = G.d;
  if (!h) return;
  const co = Game.classOptions();
  const pts = h.statPts > 0 || h.skillPts > 0;
  const tl = (G.state.townLog || []).slice(-1)[0];
  const place = (go, scene, name, sub, extra = '', dot = false) =>
    `<button class="place frame ${extra}" data-go="${go}"><img src="${sceneURL(scene)}" alt="">${dot ? '<i class="dot"></i>' : ''}<div class="cap"><strong>${name}</strong><small>${sub}</small></div></button>`;
  $('screen').innerHTML = `
    <div class="plaque frame">
      <button class="pic" data-go="hero" aria-label="Herói"><img src="${heroURL(h.cls, d.wtype)}" alt="">${pts ? '<i class="dot"></i>' : ''}</button>
      <button class="who" data-go="hero"><h2>${h.hardcore ? '☠ ' : ''}${esc(h.name)}</h2><p>${h.reborn ? "✦ " : ""}${CLASSES[h.cls].name}, nível ${h.lv}</p></button>
      <div class="purse"><b>${ic('coin')}${fmt(meta.zeny)}</b><button data-go="bag" aria-label="Mochila">${ICON.bag}</button> <button data-go="menu" aria-label="Opções">${ICON.gear}</button></div>
    </div>
    <div class="town-name">Vila de Runa</div>
    <div class="town-sub">As tochas estão acesas. A masmorra espera.</div>
    <div class="places">
      ${place('dungeon', 'gate', 'Portão da Masmorra', h.deepest ? `Seu recorde: andar ${h.deepest}. Atalhos a cada chefe derrotado.` : 'O primeiro andar fica logo depois do arco.', 'wide')}
      ${place('shop', 'shop', 'Empório', 'Poções, asas e fragmentos')}
      ${place('smith', 'smith', 'Forja', 'Refino, armas e vendas')}
      ${place('storage', 'storage', 'Armazém', `${meta.storage.length} itens guardados`)}
      ${place('class', 'guild', 'Guilda das Classes', co.opts.length ? (co.ok ? 'Seu novo caminho está pronto' : co.lvOk ? 'Gaste os pontos de habilidade para mudar' : `Mudança de classe no nível ${co.need}`) : 'Você já domina sua classe', '', co.ok)}
      ${place('market', 'market', 'Mercado', (() => { const m = Game.market(); return m.mine.length ? `${m.mine.length} anúncio${m.mine.length > 1 ? 's' : ''} seu${m.mine.length > 1 ? 's' : ''} à venda` : 'Negocie com outros aventureiros'; })(), 'wide')}
      ${place('legacy', 'temple', 'Santuário', (() => { const bo = h.boosts || {}; const on = Object.entries(BOOSTS).filter(([k]) => bo[k] > 0).map(([k, B]) => `${B.icon} ${bo[k]}`); return on.length ? `Bênçãos ativas: ${on.join(' · ')}` : 'Melhorias da conta e bênçãos para o herói'; })(), 'wide')}
    </div>
    <div class="town-log">${tl ? esc(tl.text) : ''}</div>`;
  $('screen').querySelectorAll('[data-go]').forEach((b) => b.onclick = () => {
    Audio.play('click');
    const go = b.dataset.go;
    if (go === 'dungeon') dungeonSheet();
    if (go === 'hero') heroSheet();
    if (go === 'bag') bagSheet();
    if (go === 'shop') shopSheet();
    if (go === 'smith') smithSheet();
    if (go === 'storage') storageSheet();
    if (go === 'class') classSheet();
    if (go === 'legacy') legacySheet();
    if (go === 'market') marketSheet();
    if (go === 'menu') menuSheet();
  });
}

function dungeonSheet() {
  const floors = Game.availableFloors();
  const h = G.state.hero;
  const cap = Game.levelCap();
  const groups = [];
  for (const f of floors) { const th = themeForFloor(f); let g = groups.find((x) => x.th === th); if (!g) groups.push(g = { th, fl: [] }); g.fl.push(f); }
  const nextBoss = THEMES.find((t, i) => !(h.bosses || []).includes((i + 1) * 5));
  openSheet({
    title: 'Portão da Masmorra',
    html: `<p class="note" style="margin:0 0 10px">Limite de nível: <b style="color:#ffd86b">${cap >= 99 ? 'livre' : cap}</b>${cap < 99 && nextBoss ? (nextBoss.trans && !CLASSES[h.cls].trans ? ' · o próximo passo é o Renascimento (Guilda das Classes)' : ` · derrote ${esc(MONSTERS[nextBoss.boss].name)} para liberar mais`) : ''}. Cada entrada gera um andar novo, e os monstros não param de aparecer: você decide quando descer ou voltar.</p>
      ${groups.map((g) => `<div class="section" style="color:${g.th.accent}">${g.th.name} <small style="opacity:.7">· monstros nv ${g.th.lv[0]}–${g.th.lv[1]}</small></div>
        <div class="floorgrid">${g.fl.map((f) => { const t = f % 5 === 0 ? Game.bossRespawnAt(f) : 0; return `<button class="btn small floorbtn ${f % 5 === 0 ? 'boss' : ''} ${t ? 'down' : ''}" data-f="${f}">${f % 5 === 0 ? (t ? '💤 ' : '♛ ') : ''}${f}${t ? `<small>${Math.ceil((t - Date.now()) / 60000)}min</small>` : ''}</button>`; }).join('')}</div>`).join('')}
      <p class="note" style="margin-top:12px">A Asa de Borboleta traz você para a cidade a qualquer momento.</p>`,
    mount(body) {
      body.querySelectorAll('[data-f]').forEach((b) => b.onclick = () => {
        closeSheet(true);
        Game.enterDungeon(Number(b.dataset.f));
        refresh('screen');
        handlers.onEnterDungeon && handlers.onEnterDungeon();
      });
    },
  });
}

export function heroSheet(tab = 'stats', first = false) {
  const h = G.state.hero;
  const tabs = [['stats', 'Atributos'], ['skills', 'Habilidades'], ['equip', 'Equipamento']];
  const body = openSheet({
    title: `${esc(h.name)} <small>${h.reborn ? "✦ " : ""}${CLASSES[h.cls].name}, nível ${h.lv}</small>`,
    html: `<div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${n}${k === 'stats' && h.statPts ? ' •' : ''}${k === 'skills' && h.skillPts ? ' •' : ''}</button>`).join('')}</div><div id="hero-tab"></div>`,
    mount(b) {
      b.querySelectorAll('.tab').forEach((t) => t.onclick = () => { heroSheet(t.dataset.t); });
    },
  });
  const el = body.querySelector('#hero-tab');
  if (tab === 'stats') renderStats(el, first);
  if (tab === 'skills') renderSkills(el);
  if (tab === 'equip') renderEquip(el);
}

function jobBonusText(h) {
  const jb = jobBonus(h);
  return Object.entries(jb).filter(([, v]) => v > 0).map(([k, v]) => `${STAT_NAMES[k]} +${v}`).join(', ');
}

function renderStats(el, first) {
  const h = G.state.hero, d = G.d;
  const s = d.stats;
  el.innerHTML = `
    ${first ? `<div class="hint">Distribua alguns pontos para sobreviver aos primeiros andares. Você pode guardar o resto: ao escolher uma classe, ela passa a dar bônus nos atributos dela a cada nível, e aí os pontos rendem mais onde você quiser.</div>` : ''}
    ${h.cls === 'aprendiz' && !first ? `<div class="hint">Dica: pontos podem ser guardados. Cada classe dá bônus automáticos nos atributos dela a cada nível (por exemplo, Mago ganha INT e DES).</div>` : ''}
    ${(() => { const jb = jobBonusText(h); return jb ? `<div class="note">Bônus de classe: ${jb}</div>` : ''; })()}
    <div class="pts">Pontos de atributo <b>${h.statPts}</b></div>
    <div class="stats">${STATS.map((k) => {
      const c = statCost(h.base[k]);
      const bonus = s[k] - h.base[k];
      return `<div class="stat"><span class="nm">${STAT_NAMES[k]}</span><span class="v">${h.base[k]}${bonus ? `<em>+${bonus}</em>` : ''}</span><span class="ds">${STAT_DESC[k]}</span><span class="cost" title="custo">${c}</span><button class="plus" data-k="${k}" aria-label="Aumentar ${STAT_NAMES[k]}" ${h.statPts < c || h.base[k] >= 99 ? 'disabled' : ''}>${ICON.plus}</button></div>`;
    }).join('')}</div>
    <div class="derived">
      <div><span>Ataque</span><b>${d.atk}</b></div><div><span>Ataque mágico</span><b>${d.matk}</b></div>
      <div><span>Defesa</span><b>${d.def}</b></div><div><span>Defesa mágica</span><b>${d.mdef}</b></div>
      <div><span>Precisão</span><b>${d.hit}</b></div><div><span>Esquiva</span><b>${d.flee}</b></div>
      <div><span>Crítico</span><b>${d.crit.toFixed(1)}%</b></div><div><span>Velocidade</span><b>${Math.round(d.speed)}</b></div>
      <div><span>Alcance</span><b>${d.range}</b></div><div><span>Elemento</span><b>${ELEMENTS[d.el].name}</b></div>
      <div><span>Experiência</span><b>${h.xp < 0 ? `<span style="color:#ff8a8a">dívida ${Math.ceil(-h.xp / xpToNext(h.lv, h) * 100)}%</span>` : h.lv >= Game.levelCap() ? 'limite ' + Game.levelCap() : Math.floor(h.xp / xpToNext(h.lv, h) * 100) + '%'}</b></div><div><span>Abates</span><b>${h.kills}</b></div>
    </div>`;
  el.querySelectorAll('.plus').forEach((b) => b.onclick = () => { Game.raiseStat(b.dataset.k); Audio.play('click'); renderStats(el, first); G.dirty = true; });
}

function renderSkills(el) {
  const h = G.state.hero;
  const lin = Game.lineage(h.cls);
  const co = Game.classOptions();
  let html = `<div class="pts">Pontos de habilidade <b>${h.skillPts}</b></div>`;
  for (const c of [...lin].reverse()) {
    html += `<div class="section">${CLASSES[c].name}</div><div class="list">`;
    for (const id of CLASSES[c].skills) {
      const sk = SKILLS[id];
      const l = h.skills[id] || 0;
      const active = sk.target !== 'passive';
      const pips = Array.from({ length: sk.max }, (_, i) => `<i class="${i < l ? 'on' : ''}"></i>`).join('');
      html += `<div class="skillrow ${l ? '' : 'unlearned'}"><div class="ic"><img src="${skIcon(id)}" alt=""></div><div class="info"><strong>${esc(sk.name)}</strong><span class="pips">${pips}</span>${active ? '' : '<span class="tag">passiva</span>'}
        <small>${esc(sk.desc(Math.max(1, l)))}${active ? ` Custa ${sk.sp(Math.max(1, l))} SP.` : ''}</small>${sk.aoe ? `<span class="aoe">Área ${aoeText(sk)} ${aoeGrid(sk)}</span>` : ''}</div>
        <div class="btns">${l < sk.max ? `<button class="up" data-up="${id}" ${h.skillPts ? '' : 'disabled style="opacity:.3"'}>${l ? 'Melhorar' : 'Aprender'}</button>` : ''}
        ${active && l ? `<button class="pin ${h.bar.includes(id) ? 'on' : ''}" data-pin="${id}">${h.bar.includes(id) ? 'Na barra' : 'Pôr na barra'}</button>` : ''}</div></div>`;
    }
    html += '</div>';
  }
  if (co.opts.length) html += `<p class="note" style="margin-top:14px">Próxima classe no nível ${co.need}, na Guilda das Classes.</p>`;
  el.innerHTML = html;
  el.querySelectorAll('[data-up]').forEach((b) => b.onclick = () => { if (Game.learnSkill(b.dataset.up)) { Audio.play('click'); renderSkills(el); G.dirty = true; } });
  el.querySelectorAll('[data-pin]').forEach((b) => b.onclick = () => { Game.toggleBar(b.dataset.pin); renderSkills(el); G.dirty = true; });
}

function renderEquip(el) {
  const h = G.state.hero;
  const main = h.equip.weapon && itemDef(h.equip.weapon);
  el.innerHTML = `<div class="list">${Game.SLOTS.map((slot) => {
    const n = Game.SLOT_NAMES[slot];
    const it = h.equip[slot];
    if (!it && slot === 'left' && main && WTYPES[main.wtype]?.hands === 2) return `<div class="row"><div class="info"><strong style="color:var(--parch-dim)">${n}: ocupada pela arma de duas mãos</strong></div></div>`;
    if (!it) return `<div class="row"><div class="info"><strong style="color:var(--parch-dim)">${n}: nada equipado</strong><small>Escolha um item na mochila</small></div></div>`;
    return `<button class="row eq" data-u="${it.uid}"><img src="${itemIconURL(it)}"><div class="info"><strong style="color:${itemColor(it)}">${esc(itemName(it))}</strong><small>${esc(itemDesc(it).slice(0, 2).join(' · '))}</small></div><div class="side">${n}</div></button>`;
  }).join('')}</div>`;
  el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => itemSheet(Number(b.dataset.u), 'equip', () => heroSheet('equip')));
}

// ---------------- Mochila / itens ----------------
export function itemRow(it, side = '', extra = '') {
  const d = itemDef(it);
  const q = isStack(it) && it.qty > 1 ? ` ×${it.qty}` : '';
  return `<button class="row ${extra}" data-u="${it.uid}"><img src="${itemIconURL(it)}"><div class="info"><strong style="color:${itemColor(it)}">${esc(itemName(it))}${q}</strong><small>${esc(itemDesc(it)[0] || '')}</small></div><div class="side">${side}</div></button>`;
}

function sortInv(list) {
  const order = { use: 0, card: 1, weapon: 2, shield: 3, head: 4, armor: 5, acc: 6, mat: 7 };
  return [...list].sort((a, b) => order[itemDef(a).kind] - order[itemDef(b).kind] || itemName(a).localeCompare(itemName(b)));
}

export function bagSheet() {
  const h = G.state.hero;
  const body = openSheet({
    title: `Mochila <small>${h.inv.length} de 30</small>`,
    html: h.inv.length ? `<div class="list">${sortInv(h.inv).map((it) => itemRow(it)).join('')}</div>` : `<div class="empty-msg">A mochila está vazia. Itens que você pegar aparecem aqui.</div>`,
  });
  body.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => itemSheet(Number(b.dataset.u), 'bag', bagSheet));
}

export function itemSheet(u, where, back) {
  const h = G.state.hero;
  let it = where === 'equip' ? Object.values(h.equip).find((e) => e && e.uid === u) : Game.findInv(u);
  if (!it) { back && back(); return; }
  const d = itemDef(it);
  const inDungeon = G.state.mode === 'dungeon';
  const acts = [];
  if (where === 'equip') acts.push(['unequip', 'Desequipar']);
  else {
    if (d.kind === 'use' && !(G.state.mode === 'town' && (d.teleport || d.recall))) acts.push(['use', 'Usar', 'primary']);
    if (isEquip(it)) {
      const opts = Game.slotsFor(it);
      if (!opts.length) acts.push(['none', 'Sua classe não usa']);
      else if (opts.length === 1) acts.push(['equip:' + opts[0], 'Equipar', 'primary']);
      else for (const k of opts) acts.push(['equip:' + k, k === 'left' ? 'Mão esquerda' : k === 'weapon' ? 'Mão direita' : Game.SLOT_NAMES[k], 'primary']);
    }
    if (d.kind === 'card') acts.push(['card', 'Encaixar', 'primary']);
    if (inDungeon) acts.push(['drop', 'Largar', 'danger']);
  }
  // comparação
  let cmp = '';
  if (isEquip(it) && where !== 'equip') {
    const cur = Game.slotsFor(it).map((k) => h.equip[k]).filter(Boolean);
    cmp = cur.length ? `<p class="cmp">Equipado agora: ${cur.map((c) => esc(itemName(c))).join(' · ')}</p>` : '';
  }
  openSheet({
    title: '', center: true,
    html: `<div class="detail"><div class="art"><img src="${itemIconURL(it)}"></div><h4 style="color:${itemColor(it)}">${esc(itemName(it))}${isStack(it) && it.qty > 1 ? ` ×${it.qty}` : ''}</h4>
      ${itemDesc(it).map((l) => `<p>${esc(l)}</p>`).join('')}${cmp}
      <div class="actions2">${acts.map(([a, n, c]) => `<button class="btn ${c || ''}" data-a="${a}">${n}</button>`).join('')}<button class="btn" data-a="back">Voltar</button></div></div>`,
    mount(body) {
      body.querySelectorAll('[data-a]').forEach((b) => b.onclick = () => {
        const a = b.dataset.a;
        if (a === 'back') { back ? back() : closeSheet(); return; }
        if (a === 'use') { closeSheet(true); Game.useItem(u); handlers.afterAction && handlers.afterAction(); if (G.state.mode === 'town') { renderTown(); bagSheet(); } return; }
        if (a === 'none') return;
        if (a.startsWith('equip:')) { Game.equipItem(u, a.slice(6)); back ? back() : closeSheet(); return; }
        if (a === 'unequip') { Game.unequip(Game.slotOf(it)); back ? back() : closeSheet(); return; }
        if (a === 'drop') { Game.dropItem(u); closeSheet(); return; }
        if (a === 'card') { cardTargetSheet(u, back); return; }
      });
    },
  });
}

function cardTargetSheet(cardUid, back) {
  const h = G.state.hero;
  const card = Game.findInv(cardUid);
  const cd = itemDef(card);
  const opts = [...Object.values(h.equip).filter(Boolean), ...h.inv].filter((e) => isEquip(e) && itemDef(e).kind === cd.slot && (e.cards || []).length < e.slots);
  const body = openSheet({
    title: `Encaixar ${esc(cd.name)}`,
    html: `<p class="note">Escolha um equipamento com espaço livre. A carta não sai depois de encaixada.</p>` +
      (opts.length ? `<div class="list">${opts.map((e) => itemRow(e, `${(e.cards || []).length}/${e.slots}`)).join('')}</div>` : `<div class="empty-msg">Nenhum equipamento deste tipo tem espaço livre para cartas.</div>`),
  });
  body.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
    if (Game.insertCard(cardUid, Number(b.dataset.u))) { toast('Carta encaixada! ✨'); back ? back() : closeSheet(); }
  });
}

// ---------------- Loja ----------------
function shopSheet() {
  const meta = G.state.meta;
  const body = openSheet({
    title: `Empório ${purse()}`,
    html: `<div class="list">${SHOP_ITEMS.map((id) => { const it = makeItem(id); return itemRow(it, `<span class="price">${fmt(buyPrice(it, G.d))} z</span>`); }).join('')}</div>`,
  });
  body.querySelectorAll('[data-u]').forEach((b, i) => b.onclick = () => {
    const err = Game.buy(SHOP_ITEMS[i]);
    if (err) toast(err); else { toast(`Comprou ${ITEMS[SHOP_ITEMS[i]].name}`, 900); shopSheet(); renderTown(); }
  });
}

// ---------------- Ferreiro ----------------
function smithSheet(tab = 'refine') {
  const h = G.state.hero, meta = G.state.meta;
  const tabs = [['refine', 'Refinar'], ['buy', 'Comprar'], ['sell', 'Vender']];
  const body = openSheet({
    title: `Forja ${purse()}`,
    html: `<div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div id="smith"></div>`,
    mount(b) { b.querySelectorAll('.tab').forEach((t) => t.onclick = () => smithSheet(t.dataset.t)); },
  });
  const el = body.querySelector('#smith');
  if (tab === 'refine') {
    const frags = h.inv.find((i) => i.id === 'fragmento')?.qty || 0;
    const eqs = [...Object.entries(h.equip).filter(([, e]) => e).map(([, e]) => ({ it: e, where: 'equip' })), ...h.inv.filter((i) => ['weapon', 'armor', 'head', 'shield'].includes(itemDef(i).kind)).map((it) => ({ it, where: 'bag' }))]
      .filter(({ it }) => ['weapon', 'armor', 'head', 'shield'].includes(itemDef(it).kind));
    el.innerHTML = `<div class="pts">Fragmentos Rúnicos <b>${frags}</b></div><p class="note">Refinar até +4 é seguro. A partir daí, uma falha destrói o item e as cartas nele.</p>` +
      (eqs.length ? `<div class="list">${eqs.map(({ it, where }) => { const inf = Game.refineInfo(it); return itemRow(it, inf.max ? 'Máx.' : `<span style="color:${inf.safe ? 'var(--good)' : inf.rate >= 50 ? 'var(--gold)' : 'var(--bad)'}">${inf.rate}%</span><br><span class="price">${fmt(inf.cost)} z</span>`, where === 'equip' ? 'eq' : '').replace('class="row', `data-w="${where}" class="row`); }).join('')}</div>` : `<div class="empty-msg">Você não tem armas nem armaduras para refinar.</div>`);
    el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
      const u = Number(b.dataset.u), where = b.dataset.w;
      const it = where === 'equip' ? Object.values(h.equip).find((e) => e && e.uid === u) : Game.findInv(u);
      const inf = Game.refineInfo(it);
      if (inf.max) return;
      const go = () => { const r = Game.refine(u, where); toast((r.ok ? '✨ ' : r.ok === false ? '💥 ' : '') + esc(r.msg), 2200); smithSheet('refine'); renderTown(); };
      if (!inf.safe) confirmSheet(`Refinar para +${inf.next}?`, `Chance de sucesso: <b>${inf.rate}%</b>.<br>Se falhar, <b style="color:var(--bad)">${esc(itemName(it))}</b> será destruído, com as cartas.`, 'Refinar', go, () => smithSheet('refine'));
      else go();
    });
  }
  if (tab === 'buy') {
    const gear = Game.shopGear();
    el.innerHTML = `<div class="list">${gear.map((g) => { const it = makeItem(g.id); return itemRow(it, `<span class="price">${fmt(buyPrice(it, G.d))} z</span>`); }).join('')}</div><p class="note" style="margin-top:10px">O estoque melhora conforme seu herói desce mais fundo. Itens da forja não têm espaço para cartas.</p>`;
    el.querySelectorAll('[data-u]').forEach((b, i) => b.onclick = () => { const err = Game.buy(gear[i].id); if (err) toast(err); else { toast('Comprado!', 900); smithSheet('buy'); renderTown(); } });
  }
  if (tab === 'sell') {
    const inv = sortInv(h.inv);
    el.innerHTML = inv.length ? `<div class="list">${inv.map((it) => itemRow(it, `<span class="price">${fmt(sellPrice(it, G.d) * (it.qty || 1))} z</span>`)).join('')}</div>` : `<div class="empty-msg">A mochila está vazia.</div>`;
    el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
      const it = Game.findInv(Number(b.dataset.u));
      const sell = () => { const p = Game.sell(it.uid); toast(`+${fmt(p)} z`, 900); smithSheet('sell'); renderTown(); };
      if (itemDef(it).kind === 'card' || (it.cards || []).length || (it.refine || 0) >= 5) confirmSheet('Vender?', `Vender <b>${esc(itemName(it))}</b>?`, 'Vender', sell, () => smithSheet('sell'));
      else sell();
    });
  }
}

function confirmSheet(title, msg, ok, onOk, onCancel) {
  openSheet({ title, center: true, html: `<p style="line-height:1.5;font-size:16px;margin:0">${msg}</p><div class="actions2"><button class="btn" data-a="no">Cancelar</button><button class="btn primary" data-a="ok">${ok}</button></div>`,
    mount(b) { b.querySelector('[data-a=ok]').onclick = () => { closeSheet(true); onOk(); }; b.querySelector('[data-a=no]').onclick = () => { onCancel ? onCancel() : closeSheet(); }; } });
}
export { confirmSheet };

// ---------------- Armazém ----------------
function storageSheet(tab = 'store') {
  const h = G.state.hero, meta = G.state.meta;
  const tabs = [['store', `Armazém (${meta.storage.length})`], ['bag', `Mochila (${h.inv.length})`]];
  const body = openSheet({
    title: 'Armazém',
    html: `<div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div id="st"></div>`,
    mount(b) { b.querySelectorAll('.tab').forEach((t) => t.onclick = () => storageSheet(t.dataset.t)); },
  });
  const el = body.querySelector('#st');
  const list = tab === 'store' ? sortInv(meta.storage) : sortInv(h.inv);
  el.innerHTML = `<p class="note">${tab === 'store' ? 'Itens guardados aqui continuam mesmo se o herói cair. Toque para pegar.' : 'Toque em um item para guardar.'}</p>` +
    (list.length ? `<div class="list">${list.map((it) => itemRow(it, tab === 'store' ? 'Pegar' : 'Guardar')).join('')}</div>` : `<div class="empty-msg">${tab === 'store' ? 'Nada guardado ainda.' : 'A mochila está vazia.'}</div>`);
  el.querySelectorAll('[data-u]').forEach((b) => b.onclick = () => {
    const err = tab === 'store' ? Game.withdraw(Number(b.dataset.u)) : Game.deposit(Number(b.dataset.u));
    if (err) toast(err);
    storageSheet(tab); renderTown();
  });
}

// ---------------- Classes ----------------
function classSheet() {
  const h = G.state.hero;
  const co = Game.classOptions();
  const lv = co.need;
  let html;
  if (!co.opts.length && CLASSES[h.cls].trans) html = `<div class="empty-msg">${CLASSES[h.cls].name} é uma classe transcendental: o auge do seu caminho. Os andares 26 a 40 estão abertos para você.</div>`;
  else if (!co.opts.length) {
    const rb = Game.rebirthInfo(h);
    html = `<div class="empty-msg">${CLASSES[h.cls].name} é uma classe avançada.</div>
      <div class="frame" style="padding:14px;margin-top:10px"><h3 style="margin:0 0 6px">✦ Renascimento</h3>
      <p class="note">Volte ao nível 1 como <b>Aprendiz Renascido</b> e refaça a jornada mais forte: <b>+25% de HP e SP</b>, <b>+40 pontos de atributo</b> e <b>+1 ponto de habilidade a cada 10 níveis</b>. Equipamentos, banco e armazém continuam com você. Você seguirá o mesmo caminho até a classe transcendental (${esc(Object.values(CLASSES).filter((c) => c.trans && Game.lineage(h.cls).includes(c.base)).map((c) => c.name).join(', ') || '—')}), com duas habilidades novas, e só os transcendentais descem além do andar 25. Renascidos precisam de 50% mais experiência por nível.</p>
      ${rb.ok ? '<button class="btn primary" id="rebirth">Renascer</button>' : `<p class="note" style="color:var(--bad, #ff8a8a)">${rb.why.map(esc).join('<br>')}</p>`}</div>`;
  }
  else {
    const why = !co.lvOk ? `Volte no nível ${lv}. Seu nível atual é ${h.lv}.`
      : co.pts ? `Antes de mudar de classe, gaste todos os pontos de habilidade de ${CLASSES[h.cls].name}. Faltam ${co.pts}.`
      : 'Escolha seu caminho. A escolha é permanente.';
    html = (co.lvOk && co.pts ? `<div class="hint">${why}</div><button class="btn" id="go-skills" style="margin-bottom:12px">Abrir habilidades</button>` : `<p class="note">${why}</p>`) + `<div class="classpick">` +
      co.opts.map((c) => `<button class="classcard frame" data-c="${c.id}" ${co.ok ? '' : 'style="opacity:.6"'}><img src="${heroURL(c.id)}" alt=""><div><strong>${c.name}</strong><small>${esc(c.desc)}</small><em>${c.skills.map((s) => SKILLS[s].name).join(', ')}</em><small style="color:var(--good)">Bônus por nível: ${Object.entries(JOB_BONUS[c.id] || JOB_BONUS[c.base] || {}).map(([k, v]) => `${STAT_NAMES[k]} ${v >= 0.5 ? '++' : '+'}`).join(' ')}</small></div></button>`).join('') + '</div>';
  }
  const body = openSheet({ title: 'Guilda das Classes', html });
  const gs = body.querySelector('#go-skills');
  if (gs) gs.onclick = () => heroSheet('skills');
  const rbt = body.querySelector('#rebirth');
  if (rbt) rbt.onclick = () => confirmSheet('Renascer?', `${esc(h.name)} volta ao nível 1 como Aprendiz Renascido. Atributos e habilidades são zerados e os chefes voltam a contar do zero. Não dá para desfazer.`, 'Renascer', () => {
    const err = Game.rebirth(); if (err) { toast(err); return; }
    toast('Você renasceu!'); renderTown(); heroSheet('stats', true);
  }, classSheet);
  body.querySelectorAll('[data-c]').forEach((b) => b.onclick = () => {
    if (!co.lvOk) { toast(`Disponível no nível ${lv}`); return; }
    if (co.pts) { toast(`Gaste os ${co.pts} pontos de habilidade antes`); return; }
    const c = CLASSES[b.dataset.c];
    confirmSheet(`Tornar-se ${c.name}?`, esc(c.desc), 'Confirmar', () => { Game.changeClass(b.dataset.c); toast(`Agora você é ${c.name}!`); renderTown(); heroSheet('skills'); }, classSheet);
  });
}

// ---------------- Santuário ----------------
function legacySheet() {
  const meta = G.state.meta, h = G.state.hero;
  const bo = h.boosts || {};
  const body = openSheet({
    title: `Santuário ${purse()}`,
    html: `${meta.legacyRefund ? `<div class="hint">O Santuário mudou: as bênçãos antigas viraram conforto para a conta. Devolvemos ${fmt(meta.legacyRefund)} z ao seu banco.</div>` : ''}
    <div class="section">Melhorias da conta</div>
    <div class="list">${Object.entries(LEGACY).map(([k, L]) => {
      const lv = meta.legacy[k] || 0;
      const max = lv >= L.max;
      const locked = k === 'veterano' && !Game.veteranUnlocked();
      return `<div class="row legacy-row"><div class="info"><strong>${L.name}<span class="pips">${Array.from({ length: L.max }, (_, i) => `<i class="${i < lv ? 'on' : ''}"></i>`).join('')}</span></strong><small style="white-space:normal">${L.desc}</small></div><div class="side">${max ? 'Completa' : locked ? '<small class="mk-dim">bloqueado</small>' : `<button class="btn small" data-k="${k}"><span class="price">${fmt(legacyCost(k, lv))} z</span></button>`}</div></div>`;
    }).join('')}</div>
    <div class="section">Bênçãos de ${esc(h.name)} <small class="mk-dim">· valem pelos próximos monstros derrotados</small></div>
    <div class="list">${Object.entries(BOOSTS).map(([k, B]) => `<div class="row legacy-row"><div class="info"><strong>${B.icon} ${B.name}${bo[k] > 0 ? ` <span class="mk-dim">(restam ${bo[k]})</span>` : ''}</strong><small style="white-space:normal">${B.desc} nos próximos ${B.kills} monstros. Comprar de novo soma.</small></div><div class="side"><button class="btn small" data-b="${k}"><span class="price">${fmt(B.price(h.lv))} z</span></button></div></div>`).join('')}
      <div class="row legacy-row"><div class="info"><strong>🔨 Martelo Abençoado${meta.safeRefine ? ` <span class="mk-dim">(você tem ${meta.safeRefine})</span>` : ''}</strong><small style="white-space:normal">Se um refino falhar, o item não quebra. Gasta um por falha. Vale para toda a conta.</small></div><div class="side"><button class="btn small" id="hammer"><span class="price">${fmt(Game.SAFE_REFINE_PRICE)} z</span></button></div></div></div>
    <div class="section">Serviços</div>
    <div class="list">
      <div class="row"><div class="info"><strong>Redistribuir atributos</strong><small style="white-space:normal">Devolve todos os pontos de atributo de ${esc(h.name)}.</small></div><div class="side"><button class="btn small" id="reset"><span class="price">${fmt(Game.resetStatsCost())} z</span></button></div></div>
      <div class="row"><div class="info"><strong>Redistribuir habilidades</strong><small style="white-space:normal">Devolve todos os pontos de habilidade de ${esc(h.name)}.</small></div><div class="side"><button class="btn small" id="resetsk"><span class="price">${fmt(Game.resetSkillsCost())} z</span></button></div></div>
      <div class="row"><div class="info"><strong>Trocar o nome</strong><small style="white-space:normal">Escolha um novo nome para ${esc(h.name)}.</small></div><div class="side"><button class="btn small" id="rename"><span class="price">${fmt(Game.RENAME_PRICE)} z</span></button></div></div>
    </div>`,
  });
  if (meta.legacyRefund) { delete meta.legacyRefund; Game.save(); }
  body.querySelectorAll('[data-k]').forEach((b) => b.onclick = () => { const e = Game.buyLegacy(b.dataset.k); if (e) toast(e); else { toast('Melhoria comprada! ✨'); legacySheet(); renderTown(); } });
  body.querySelectorAll('[data-b]').forEach((b) => b.onclick = () => { const e = Game.buyBoost(b.dataset.b); if (e) toast(e); else { toast(`${BOOSTS[b.dataset.b].name} ativado!`); legacySheet(); renderTown(); } });
  body.querySelector('#hammer').onclick = () => { const e = Game.buySafeRefine(); if (e) toast(e); else { toast('Martelo Abençoado guardado.'); legacySheet(); renderTown(); } };
  body.querySelector('#reset').onclick = () => confirmSheet('Redistribuir atributos?', 'Todos os pontos de atributo voltam para você distribuir de novo.', 'Confirmar', () => { const e = Game.resetStats(); if (e) toast(e); else { renderTown(); heroSheet('stats'); } }, legacySheet);
  body.querySelector('#resetsk').onclick = () => confirmSheet('Redistribuir habilidades?', 'Todas as habilidades voltam ao nível 0 e os pontos ficam livres. Auras ligadas são desligadas.', 'Confirmar', () => { const e = Game.resetSkills(); if (e) toast(e); else { renderTown(); heroSheet('skills'); } }, legacySheet);
  body.querySelector('#rename').onclick = () => openSheet({ title: 'Novo nome', center: true, html: `<input class="dv-in" id="rn" maxlength="16" value="${esc(h.name)}" style="width:100%;box-sizing:border-box"><div class="actions2"><button class="btn" data-a="no">Cancelar</button><button class="btn primary" data-a="ok">Trocar</button></div>`,
    mount(x) { x.querySelector('[data-a=no]').onclick = () => legacySheet(); x.querySelector('[data-a=ok]').onclick = () => { const e = Game.renameHero(x.querySelector('#rn').value); if (e) toast(e); else { renderTown(); legacySheet(); } }; } });
}

// ---------------- Menu ----------------
const GFX_NAMES = { hd: 'HD 3D (teste)', alta: 'Alta', media: 'Média', baixa: 'Baixa', '2d': 'Clássico (2D)' };
export function menuSheet() {
  const st = G.state;
  const s = st.settings;
  const inDungeon = st.mode === 'dungeon';
  const body = openSheet({
    title: 'Opções',
    html: `<div class="list">
      <button class="row" data-a="sound"><div class="info"><strong>Som</strong></div><div class="side">${s.sound ? 'Ligado' : 'Desligado'}</div></button>
      <button class="row" data-a="vib"><div class="info"><strong>Vibração</strong></div><div class="side">${s.vibrate ? 'Ligada' : 'Desligada'}</div></button>
      ${inDungeon ? '' : `<button class="row" data-a="chars"><div class="info"><strong>👥 Trocar de personagem</strong><small>${(st.roster || []).length}/${Game.MAX_HEROES} vagas</small></div><div class="side">›</div></button>`}
      <button class="row" data-a="wiki"><div class="info"><strong>📖 Wiki</strong><small>Atributos, classes, habilidades, elementos, monstros</small></div><div class="side">›</div></button>
      <button class="row" data-a="help"><div class="info"><strong>Como jogar</strong></div><div class="side">›</div></button>
      <button class="row" data-a="dev"><div class="info"><strong>Desenvolvedor</strong><small>Andar, nível, classe, cidade...</small></div><div class="side">›</div></button>
      <button class="row" data-a="credits"><div class="info"><strong>Créditos da arte</strong></div><div class="side">›</div></button>
      <button class="row" data-a="gfx"><div class="info"><strong>Visual</strong><small>HD 3D: cenário novo com modelos 3D (em teste) · Clássico: o visual 2D antigo</small></div><div class="side">${GFX_NAMES[s.gfx || 'media']}</div></button>
      ${st.meta.graveyard?.length ? `<button class="row" data-a="grave"><div class="info"><strong>Memorial</strong></div><div class="side">›</div></button>` : ''}
      ${inDungeon ? '' : `<button class="row" data-a="wipe"><div class="info"><strong style="color:var(--bad)">Apagar todo o progresso</strong></div><div class="side">›</div></button>`}
    </div><p class="foot">O jogo salva sozinho a cada passo e se atualiza ao abrir.<br>Versão ${window.__WEB_VERSION || 'local'}</p>`,
  });
  body.querySelectorAll('[data-a]').forEach((b) => b.onclick = () => {
    const a = b.dataset.a;
    if (a === 'sound') { s.sound = !s.sound; Audio.setEnabled(s.sound); Game.save(); menuSheet(); }
    if (a === 'vib') { s.vibrate = !s.vibrate; Game.save(); menuSheet(); }
    if (a === 'help') helpSheet();
    if (a === 'credits') creditsSheet();
    if (a === 'gfx') { const o = ['hd', 'alta', 'media', 'baixa', '2d']; s.gfx = o[(o.indexOf(s.gfx || 'media') + 1) % o.length]; Game.save(); setGfx(s.gfx); menuSheet(); }
    if (a === 'wiki') wikiSheet();
    if (a === 'chars') { closeSheet(true); Game.toCharacterSelect(); refresh('screen'); }
    if (a === 'dev') devSheet();
    if (a === 'grave') graveSheet();
    if (a === 'wipe') confirmSheet('Apagar tudo?', 'Herói, banco, armazém e bênçãos serão apagados para sempre.', 'Apagar', () => { Game.wipeSave(); refresh('screen'); });
  });
}

// ---------------- Desenvolvedor (testes) ----------------
export function devSheet() {
  const st = G.state, h = st.hero;
  const inD = st.mode === 'dungeon';
  const cls = Object.entries(CLASSES).map(([id, c]) => `<button class="btn small ${h.cls === id ? 'primary' : ''}" data-cls="${id}" style="padding:9px 6px;font-size:13px">${esc(c.name)}</button>`).join('');
  const updLog = (() => { try { return JSON.parse(localStorage.getItem('upd_log') || '[]'); } catch (_) { return []; } })();
  const body = openSheet({
    title: 'Desenvolvedor',
    html: `<div style="display:grid;gap:12px;font-size:14px">
      <div class="section" style="margin:0">Andar ${inD ? `(agora: ${st.run.floor})` : ''}</div>
      <div style="display:flex;gap:8px"><input id="dv-floor" type="number" min="1" max="99" value="${inD ? st.run.floor + 1 : 1}" class="dv-in"><button class="btn small" id="dv-go">Ir</button></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">${[1, 5, 6, 10, 11, 15, 16, 20, 21, 25].map((f) => `<button class="btn small" data-f="${f}" style="width:auto;padding:8px 12px">${f}</button>`).join('')}</div>
      <div class="section" style="margin:0">Nível (agora: ${h.lv})</div>
      <div style="display:flex;gap:8px"><input id="dv-lv" type="number" min="1" max="99" value="${Math.min(99, h.lv + 5)}" class="dv-in"><button class="btn small" id="dv-setlv">Definir</button></div>
      <div class="section" style="margin:0">Classe</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">${cls}</div>
      <div class="section" style="margin:0">Atalhos</div>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px">
        ${inD ? '<button class="btn small" data-x="town">Voltar à cidade</button>' : ''}
        <button class="btn small" data-x="heal">Curar tudo</button>
        <button class="btn small" data-x="zeny">+10.000 zeny</button>
        <button class="btn small" data-x="pts">+10 pontos</button>
        ${inD ? '<button class="btn small" data-x="reveal">Revelar andar</button><button class="btn small" data-x="kill">Matar monstros</button>' : ''}
        ${!inD && !h.reborn ? '<button class="btn small" data-x="reborn">Renascer agora</button>' : ''}
        <button class="btn small ${st.settings.god ? 'primary' : ''}" data-x="god">Invencível: ${st.settings.god ? 'sim' : 'não'}</button>
      </div>
      <div class="section" style="margin:0">Atualização (versão ${window.__WEB_VERSION || '?'})</div>
      <button class="btn small" id="dv-upd">Verificar atualização agora</button>
      <div style="font:12px/1.4 monospace;color:#b8b4d8;white-space:pre-wrap;max-height:160px;overflow:auto;background:rgba(0,0,0,.25);border-radius:10px;padding:8px">${esc(updLog.slice(-14).join('\n') || 'sem registros ainda')}</div>
    </div>`,
  });
  const done = (msg, enteredDungeon) => {
    closeSheet(true);
    if (msg) toast(msg, 1400);
    refresh('screen');
    if (enteredDungeon && handlers.onEnterDungeon) handlers.onEnterDungeon();
    else handlers.afterAction && handlers.afterAction();
  };
  const goF = (f) => { Game.Dev.goFloor(f); done(`Andar ${f}`, true); };
  body.querySelector('#dv-go').onclick = () => goF(parseInt(body.querySelector('#dv-floor').value, 10) || 1);
  body.querySelectorAll('[data-f]').forEach((b) => b.onclick = () => goF(+b.dataset.f));
  body.querySelector('#dv-setlv').onclick = () => { const v = parseInt(body.querySelector('#dv-lv').value, 10) || 1; Game.Dev.setLevel(v); done(`Nível ${G.state.hero.lv}`); };
  body.querySelectorAll('[data-cls]').forEach((b) => b.onclick = () => { Game.Dev.setClass(b.dataset.cls); done(CLASSES[b.dataset.cls].name); });
  body.querySelectorAll('[data-x]').forEach((b) => b.onclick = () => {
    const x = b.dataset.x;
    if (x === 'town') { Game.Dev.town(); return done('Cidade'); }
    if (x === 'heal') Game.Dev.heal();
    if (x === 'zeny') Game.Dev.zeny(10000);
    if (x === 'pts') Game.Dev.pts(10);
    if (x === 'reveal') Game.Dev.reveal();
    if (x === 'kill') Game.Dev.killAll();
    if (x === 'reborn') { Game.Dev.rebirth(); return done('Renascido'); }
    if (x === 'god') { Game.Dev.god(!G.state.settings.god); return devSheet(); }
    done('Feito');
  });
  body.querySelector('#dv-upd').onclick = () => { closeSheet(true); handlers.checkUpdate && handlers.checkUpdate(); };
}

function creditsSheet() {
  openSheet({
    title: 'Créditos da arte',
    html: `<div style="font-size:13px;line-height:1.5;color:#d8d5ee">
    <p><b>Heróis</b>: Universal LPC Spritesheet Character Generator (Liberated Pixel Cup). Licenças CC-BY-SA 3.0, GPL 3.0, OGA-BY 3.0 e CC0, conforme cada peça. Grimório do Bruxo desenhado para este jogo.</p>
    <p><b>Monstros</b>: montados no estilo LPC com peças do Universal LPC Spritesheet Character Generator e com os pacotes [LPC] Monsters e LPC Spiders (Stephen Challener / Redshrike), [LPC] Imp, [LPC] Fish (FiveBrosStopMosYT e Lanea Zimmerman / Sharm), [LPC] Monster Death Animations (Pierre Vigier e Charles Sanchez / CharlesGabriel) e LPC Animals 2022 (bluecarrot16 e colaboradores), todos do OpenGameArt (CC-BY-SA 3.0 / GPL 3.0 / OGA-BY 3.0). Cores harmonizadas e chefes ampliados para este jogo.</p>
    <p><b>Cenário</b>: Liberated Pixel Cup base assets, por Lanea Zimmerman (Sharm) e Hugh Spectrum (CC-BY-SA 3.0 / GPL 3.0).</p>
    <p><b>Cenário 3D</b>: KayKit Dungeon Remastered, Halloween Bits, Forest Nature Pack e Medieval Hexagon (Kay Lousberg, CC0); Pirate Kit (Kenney, CC0); Ultimate Nature Pack (Quaternius, CC0); three.js (MIT).</p>
    <p><b>Ícones</b>: game-icons.net (Lorc, Delapouite, Skoll e outros, CC BY 3.0), adaptados. <b>Fonte</b>: Pixelify Sans (OFL).</p>
    <p><b>Falcão</b>: [LPC] Birds, por bluecarrot16, encomendado por castelonia (OpenGameArt, CC-BY 4.0 / CC-BY-SA / GPL / OGA-BY), repintado para este jogo.</p>
    <p><b>Efeitos</b>: Ice, Earth, Thunder, Acid e Holy Spell Effects (pimen), Pixel Art VFX Priest (Frostwindz) e Shield Effect (LinkNinja); demais efeitos feitos para este jogo e com o LPC magic pack.</p>
    <p style="font-weight:800;margin-top:14px">Autores das peças LPC (heróis e monstros)</p>
    <p style="color:#b8b4d8;font-size:12px">${LPC_CREDITS.map(esc).join(', ')}</p></div>`,
  });
}

function helpSheet() {
  openSheet({
    title: 'Como jogar',
    html: `<div style="font-size:13.5px;line-height:1.55;color:#d8d5ee">
    <p><b>Toque</b> em um lugar para andar até lá. Toque em um monstro para atacar (ou ir até ele). Cada ação gasta um turno: os monstros só agem quando você age.</p>
    <p><b>Explorar</b> anda sozinho até achar algo. <b>Esperar</b> passa um turno; segure parado para recuperar HP e SP mais rápido.</p>
    <p><b>Habilidades</b>: toque no botão e depois no alvo. Toque de novo no botão para mirar no inimigo mais próximo.</p>
    <p><b>Atributos</b>: cada nível dá pontos. Valores altos custam mais pontos.</p>
    <p><b>Classes</b>: no nível ${CLASS_LV[1]} você escolhe uma classe; no ${CLASS_LV[2]}, a classe avançada. Fale com o Mestre de Classes na cidade.</p>
    <p><b>Cartas</b> caem raramente dos monstros e encaixam nos slots [ ] dos equipamentos.</p>
    <p><b>Refino</b> com Fragmentos Rúnicos no Ferreiro. Acima de +4, uma falha quebra o item!</p>
    <p><b>Chefes</b> a cada 5 andares. Quadrados vermelhos no chão avisam um golpe forte: saia de cima!</p>
    <p>Se o herói cair, ele se vai. Zeny no banco, o armazém e as bênçãos ficam.</p></div>`,
  });
}
