import { tick as tickDiag, drawTime, mark, note } from './diag.js';
// Renderização em canvas: masmorra, iluminação suave, entidades e efeitos
import { G, visible, teleTurns } from './game.js';
import { THEMES, MONSTERS, ELEMENTS, artCls } from './data.js';
import { T, tileAt } from './map.js';
import { monsterSprite, heroSprite, itemSprite, shade } from './sprites.js';
import { itemDef } from './rules.js';
import { heroFrame, frameCount, CELL, FEET } from './lpc.js';
import { terrainTiles } from './terrain.js';
import { HERO_META } from './hero_meta.js';
import { Audio } from './audio.js';
import { FX_META } from './fx_meta.js';
import { HERO_MOVES } from './hero_moves.js';

const R = {
  cv: null, ctx: null, dpr: 1, W: 0, H: 0, TS: 44, baseTS: 44, zoom: 1, follow: true,
  camX: 0, camY: 0, topPad: 96, botPad: 170,
  anims: new Map(), dying: new Map(), hold: new Map(), parts: [], texts: [], projs: [], rings: [], corpses: [], pending: [], vfx: [], sfx: [], falcon: [],
  shake: 0, hurt: 0, flashFloor: 0, tiles: null, tilesKey: '', lc: null, lctx: null,
  targeting: null, marker: null, face: 1, hdir: 2, hanim: null, hmove: -1e9, last: 0, time: 0, victory: 0,
  m3d: false, r3: null, gfx: '2d', fovStamp: 0, groundKey: null, ky: 1,
};
export { R };

export function initRender(canvas) {
  R.cv = canvas;
  R.ctx = canvas.getContext('2d');
  resize();
  window.addEventListener('resize', resize);
  requestAnimationFrame(loop);
}

export function resize() {
  R.dpr = Math.min(window.devicePixelRatio || 1, 3);
  R.W = window.innerWidth; R.H = window.innerHeight;
  R.cv.width = Math.round(R.W * R.dpr); R.cv.height = Math.round(R.H * R.dpr);
  R.cv.style.width = R.W + 'px'; R.cv.style.height = R.H + 'px';
  R.baseTS = Math.max(38, Math.min(64, Math.floor(R.W / 9)));
  applyZoom();
  R.tilesKey = '';
}

export function setPads(top, bot) { R.topPad = top; R.botPad = bot; }

// ---------------- Conversões ----------------
const viewCY = () => R.topPad + (R.H - R.topPad - R.botPad) / 2;
// no cenário 3D a câmera é inclinada: uma casa tem TS de largura e TS*ky de altura na tela
export function screenToTile(px, py) {
  if (persp()) { const w = R.r3.unproject(px, py) || { x: R.camX, y: R.camY }; return { x: Math.floor(w.x + 0.5), y: Math.floor(w.y + 0.5) }; }
  const x = Math.floor((px - R.W / 2) / R.TS + R.camX + 0.5);
  const y = Math.floor((py - viewCY()) / (R.TS * R.ky) + R.camY + 0.5);
  return { x, y };
}
// câmera em perspectiva (HD): a posição na tela depende de x e y juntos, então cada chamada passa a outra coordenada
const persp = () => R.m3d && R.r3 && R.r3.HD && R.p3;
const sx = (tx, ty = R.camY) => persp() ? R.r3.project(tx + 0.5, ty + 0.5)[0] - R.TS / 2 : (tx - R.camX) * R.TS + R.W / 2 - R.TS / 2;
const sy = (ty, tx = R.camX) => persp() ? R.r3.project(tx + 0.5, ty + 0.5)[1] - R.TS / 2 : (ty - R.camY) * R.TS * R.ky + viewCY() - R.TS / 2;

// contorno de uma casa no chão (na perspectiva vira um trapézio)
function tileShape(ctx, x, y, inset, rad) {
  if (!persp()) { const TS = R.TS; ctx.roundRect(sx(x) + inset, sy(y) + inset + TS * (1 - R.ky) / 2, TS - inset * 2, TS * R.ky - inset * 2, rad); return; }
  const k = inset / R.TS, P = [[k, k], [1 - k, k], [1 - k, 1 - k], [k, 1 - k]].map(([a, b]) => R.r3.project(x + a, y + b));
  ctx.moveTo(P[0][0], P[0][1]); for (let i = 1; i < 4; i++) ctx.lineTo(P[i][0], P[i][1]); ctx.closePath();
}

// ---------------- Visual: 2D clássico ou cenário 3D ----------------
export async function setGfx(mode) {
  mark(`visual ${mode}`);
  R.gfx = mode || 'hd';
  if (R.gfx === '2d') { R.m3d = false; R.ky = 1; if (R.r3) R.r3.show3d(false); return; }
  try {
    if (!R.r3) { R.r3 = await import('./render3d.js'); if (!R.r3.init3d(R.cv, R.gfx)) { R.r3 = null; R.m3d = false; R.ky = 1; return; } }
    R.r3.setQuality(R.gfx); R.r3.show3d(true);
    R.m3d = true; R.ky = R.r3.SIN_P; R.groundKey = null;
  } catch (e) { console.warn('3D falhou, usando 2D', e); R.m3d = false; R.ky = 1; }
}

// ---------------- Tiles pré-renderizados ----------------
function hash(x, y) { let h = (x * 374761393 + y * 668265263) | 0; h = (h ^ (h >>> 13)) * 1274126177; return (h ^ (h >>> 16)) >>> 0; }

function chamfer(x, a, b, w, h, k) {
  x.beginPath(); x.moveTo(a + k, b); x.lineTo(a + w - k, b); x.lineTo(a + w, b + k); x.lineTo(a + w, b + h - k);
  x.lineTo(a + w - k, b + h); x.lineTo(a + k, b + h); x.lineTo(a, b + h - k); x.lineTo(a, b + k); x.closePath();
}
// Placa de pedra chanfrada com luz no canto superior esquerdo
function slab(x, a, b, w, h, base, d) {
  const k = Math.min(w, h) * 0.16;
  chamfer(x, a, b, w, h, k);
  const g = x.createLinearGradient(a, b, a + w * 0.7, b + h);
  g.addColorStop(0, shade(base, 0.07)); g.addColorStop(0.6, base); g.addColorStop(1, shade(base, -0.1));
  x.fillStyle = g; x.fill();
  x.lineWidth = 1 * d; x.strokeStyle = 'rgba(0,0,0,0.25)'; x.stroke();
  // reflexo nas bordas de cima e esquerda
  x.beginPath(); x.moveTo(a + 1.5 * d, b + h - k); x.lineTo(a + 1.5 * d, b + k); x.lineTo(a + k, b + 1.5 * d); x.lineTo(a + w - k, b + 1.5 * d);
  x.lineWidth = 1 * d; x.strokeStyle = 'rgba(255,255,255,0.07)'; x.stroke();
}

function buildTiles(theme) {
  const s = Math.round(R.TS * R.dpr);
  const d = R.dpr;
  const th = THEMES[theme];
  const mkc = () => { const c = document.createElement('canvas'); c.width = s; c.height = s; return c; };
  const floors = [];
  const gap = 1.5 * d;
  for (let v = 0; v < 4; v++) {
    const c = mkc(), x = c.getContext('2d');
    x.fillStyle = shade(th.floor[0], -0.3); x.fillRect(0, 0, s, s); // rejunte
    const c0 = th.floor[0], c1 = th.floor[1];
    if (v === 0) slab(x, gap, gap, s - gap * 2, s - gap * 2, c0, d);
    else if (v === 1) { slab(x, gap, gap, s * 0.5 - gap * 1.5, s - gap * 2, c0, d); slab(x, s * 0.5 + gap * 0.5, gap, s * 0.5 - gap * 1.5, s * 0.55, c1, d); slab(x, s * 0.5 + gap * 0.5, s * 0.55 + gap * 2, s * 0.5 - gap * 1.5, s * 0.45 - gap * 3, c0, d); }
    else if (v === 2) { slab(x, gap, gap, s - gap * 2, s * 0.45, c1, d); slab(x, gap, s * 0.45 + gap * 2, s * 0.62, s * 0.55 - gap * 3, c0, d); slab(x, s * 0.62 + gap * 2, s * 0.45 + gap * 2, s * 0.38 - gap * 3, s * 0.55 - gap * 3, c1, d); }
    else { for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) slab(x, gap + i * s / 2, gap + j * s / 2, s / 2 - gap * 2, s / 2 - gap * 2, (i + j) % 2 ? c0 : c1, d); }
    // pequenas rachaduras e pontos
    x.strokeStyle = 'rgba(0,0,0,0.22)'; x.lineWidth = 1 * d;
    if (hash(v, 9) % 2) { x.beginPath(); x.moveTo(s * 0.3, s * 0.35); x.lineTo(s * 0.42, s * 0.48); x.lineTo(s * 0.38, s * 0.6); x.stroke(); }
    for (let i = 0; i < 4; i++) { x.fillStyle = i % 2 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.12)'; x.fillRect((hash(v, i) % 90) / 100 * s, (hash(i, v + 7) % 90) / 100 * s, 1.5 * d, 1.5 * d); }
    floors.push(c);
  }
  // topo da parede: placa escura chanfrada
  const wallTop = mkc(), wt = wallTop.getContext('2d');
  wt.fillStyle = shade(th.wall[1], -0.55); wt.fillRect(0, 0, s, s);
  slab(wt, 1 * d, 1 * d, s - 2 * d, s - 2 * d, shade(th.wall[2], -0.15), d);

  // face da parede: blocos chanfrados com reflexo
  const wallFace = mkc(), wf = wallFace.getContext('2d');
  wf.drawImage(wallTop, 0, 0);
  const fh = s * 0.58, top = s - fh;
  wf.fillStyle = shade(th.wall[0], -0.55); wf.fillRect(0, top, s, fh);
  const rows = 3, bh = fh / rows;
  for (let r = 0; r < rows; r++) {
    const off = r % 2 ? -s / 4 : 0;
    for (let cx = off; cx < s; cx += s / 2) {
      const bw = s / 2;
      slab(wf, Math.max(0, cx) + gap / 2, top + r * bh + gap / 2, Math.min(bw, s - Math.max(0, cx), cx + bw) - gap, bh - gap, shade(th.wall[0], 0.08 - 0.08 * r), d);
    }
  }
  // borda superior iluminada
  wf.fillStyle = 'rgba(255,255,255,0.22)'; wf.fillRect(0, top, s, 1.5 * d);
  // sombra na base
  const sg = wf.createLinearGradient(0, s - fh * 0.35, 0, s);
  sg.addColorStop(0, 'rgba(0,0,0,0)'); sg.addColorStop(1, 'rgba(0,0,0,0.35)');
  wf.fillStyle = sg; wf.fillRect(0, s - fh * 0.35, s, fh * 0.35);
  R.tiles = { floors, wallTop, wallFace, s, dc: terrainTiles(theme, s) };
}

// chão de uma casa (piso, sombra da parede, líquido, escada, portal, decoração rasteira)
function drawGroundTile(ctx, m, tl, th, x, y, X, Y, TS, t, skipDecor) {
  const i = y * m.w + x, tt = m.t[i];
    if (tl.dc) {
      const open = (dx, dy) => tileAt(m, x + dx, y + dy) !== T.WALL;
      let edge = false;
      if (tl.dc.floorAuto) for (const [dx, dy] of [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]]) if (!open(dx, dy)) { edge = true; break; }
      if (edge) { ctx.drawImage(tl.dc.base, X, Y, TS, TS); ctx.drawImage(tl.dc.floorAuto(open), X, Y, TS, TS); }
      else ctx.drawImage(tl.dc.floors[pickVar(x, y, 4)], X, Y, TS, TS);
    }
    else { const hv = hash(x, y) % 10; ctx.drawImage(tl.floors[hv < 5 ? 0 : hv < 7 ? 3 : hv < 9 ? 1 : 2], X, Y, TS, TS); }
    // sombra de parede acima
    if (tileAt(m, x, y - 1) === T.WALL && !(tl.dc && tl.dc.natural)) { const g = ctx.createLinearGradient(0, Y, 0, Y + TS * 0.45); g.addColorStop(0, 'rgba(0,0,0,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(X, Y, TS, TS * 0.45); }
    if (tt === T.LIQUID || tt === T.CHASM) {
      // líquido e buraco com bordas contínuas (autotile); lava funda também é lava
      const lava = th.liquid === 'lava';
      const auto = tt === T.LIQUID || lava ? tl.dc && tl.dc.liquid : tl.dc && tl.dc.hole;
      if (auto) {
        const isMe = (k) => k === tt || (lava && (k === T.LIQUID || k === T.CHASM));
        ctx.drawImage(auto((dx, dy) => isMe(tileAt(m, x + dx, y + dy))), X, Y, TS, TS);
      } else drawLiquid(ctx, X, Y, TS, t, th, x, y, tt === T.CHASM);
    }
    else if (tt === T.STAIRS) {
      if (tl.dc && tl.dc.stairs) {
        ctx.drawImage(tl.dc.stairs, X, Y, TS, TS);
        const g = ctx.createLinearGradient(0, Y, 0, Y + TS); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.55)');
        ctx.fillStyle = g; ctx.fillRect(X, Y, TS, TS);
      } else drawStairs(ctx, X, Y, TS, t);
    }
    else if (tt === T.PORTAL) drawPortal(ctx, X, Y, TS, t);
    if (m.decor[i] && m.decor[i] !== 'torch' && !(tl.dc && TEXTURE_DECOR.has(m.decor[i])) && !(skipDecor && skipDecor.has(m.decor[i]))) drawDecor(ctx, m.decor[i], X, Y, TS, hash(x, y), t, th);
}

// chão inteiro do andar numa imagem só (textura do cenário 3D), 32 px por casa
const DECOR_3D = new Set(['barrel', 'crate', 'candle', 'torch']);
const ALL_DECOR = { has: () => true };   // no cenário HD toda a decoração vira modelo 3D (ou some)
function bakeGround(m) {
  const th = THEMES[m.theme], S = 32;
  const c = document.createElement('canvas'); c.width = m.w * S; c.height = m.h * S;
  const ctx = c.getContext('2d'); ctx.imageSmoothingEnabled = false;
  const saved = R.tiles, savedTS = R.TS, savedDpr = R.dpr;
  R.TS = S; R.dpr = 1; buildTiles(m.theme); const tl = R.tiles;
  ctx.fillStyle = '#07080c'; ctx.fillRect(0, 0, c.width, c.height);
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const X = x * S, Y = y * S;
    if (m.t[y * m.w + x] === T.WALL) { if (tl.dc) ctx.drawImage(tl.dc.natural ? tl.dc.base : tl.dc.tops[0], X, Y, S, S); continue; }
    drawGroundTile(ctx, m, tl, th, x, y, X, Y, S, 0, R.r3 && R.r3.HD ? ALL_DECOR : DECOR_3D);
  }
  const wallTex = tl.dc ? (tl.dc.natural ? { top: tl.dc.base, side: tl.dc.base } : { top: tl.dc.tops[0], side: tl.dc.faces[0] }) : { top: tl.wallTop, side: tl.wallFace };
  const out = { m, th, theme: m.theme, ground: c, wallTex, WALL: T.WALL, trees: tl.dc && tl.dc.trees, lights: m.lights };
  R.tiles = saved; R.TS = savedTS; R.dpr = savedDpr; R.tilesKey = '';
  return out;
}

// ---------------- Processamento de efeitos ----------------
function animOf(id) {
  if (!R.anims.has(id)) R.anims.set(id, {});
  return R.anims.get(id);
}

function renderPos(id, x, y, now) {
  const a = R.anims.get(id);
  if (!a || !a.move) return { x, y };
  const el = now - a.move.t0, w = a.move.wait || 0;
  if (el < w) return { x: a.move.fx, y: a.move.fy };   // salto: ainda agachado antes de decolar
  const t = Math.min(1, (el - w) / (a.move.dur - w));
  if (t >= 1) { a.move = null; return { x, y }; }
  const e = a.move.lin ? t : 1 - Math.pow(1 - t, 2);
  return { x: a.move.fx + (x - a.move.fx) * e, y: a.move.fy + (y - a.move.fy) * e };
}

// variação de piso/parede: as primeiras são as mais comuns (as últimas, como flores, aparecem pouco)
const TEXTURE_DECOR = new Set(['grass', 'flower', 'sand', 'carpet', 'puddle']);
function pickVar(x, y, n) {
  const h = Math.abs(hash(x, y)) % 100;
  if (n <= 3) return h % n;
  return h < 80 ? h % 3 : 3 + (h % (n - 3));
}

function heroDir(dx, dy) {
  if (!dx && !dy) return;
  R.hdir = Math.abs(dx) >= Math.abs(dy) ? (dx > 0 ? 3 : 1) : (dy > 0 ? 2 : 0);
  if (dx) R.face = dx > 0 ? 1 : -1;
}

// quadro atual do herói LPC (andar / atacar / magia)
const FRAME_MS = { slash: 55, thrust: 55, shoot: 38, spellcast: 65 };
const MVIMG = new Map();
function movesSheet(cls) {
  let im = MVIMG.get(cls);
  if (!im) { im = new Image(); im.src = `assets/heroes/${cls}_mv.png`; MVIMG.set(cls, im); }
  return im.complete && im.naturalWidth ? im : null;
}
// quadro da coreografia da habilidade: {img, sx, sy, dx (casas), up (casas), flip}
function choreoFrame(cls, now) {
  const c = R.choreo; if (!c) return null;
  const M = FX_META[c.id], k = Math.floor((now - c.t0) / (M.ms || FX_MS));
  if (k >= M.n) { R.choreo = null; return null; }
  let f = null; for (let i = Math.min(k, M.ch.length - 1); i >= 0 && !f; i--) f = M.ch[i];
  if (!f) return null;
  const [anim, col, dx, lift, row] = f;
  const PXT = 1.3 / 64, side = c.mirror ? 1 : 3;
  const mv = HERO_MOVES[cls] && HERO_MOVES[cls][anim], im = mv && movesSheet(cls);
  let out;
  if (mv && im) {
    const r = mv.rows[row] ?? mv.rows[3];
    out = { img: im, sx: (Math.max(0, col) % mv.n) * CELL, sy: r * CELL, flip: c.mirror && row !== 1 && row !== 0 && row !== 2 };
  } else {
    const a = anim === 'spellcast' ? 'cast' : ['slash', 'halfslash', 'backslash', 'thrust', 'shoot'].includes(anim) ? 'atk' : 'walk';
    const fr = heroFrame(cls, a, row === 3 || row === undefined ? side : row, a === 'walk' && anim !== 'walk' ? 0 : col);
    if (!fr) return null;
    out = { ...fr, flip: false };
  }
  out.dx = dx * PXT * (c.mirror ? -1 : 1); out.up = lift * PXT; out.dy = 0;
  // investidas (Chute Voador, Lâmina Fantasma...): a prévia tinha o alvo a ~1 casa; no jogo o alvo pode estar longe
  // ou na diagonal, então o avanço é esticado na direção do alvo até parar na mesma distância dele
  const maxDx = M.maxDx ??= Math.max(0, ...M.ch.filter(Boolean).map((q) => q[2]));
  const dist = Math.hypot(c.vx || 0, c.vy || 0);
  if (M.tx && maxDx > 16 && dist > 0 && dx > 0) {
    const stop = (M.tx - M.hx - maxDx) * PXT;   // folga entre herói e alvo no fim da investida (negativa: passa por trás do alvo)
    const travel = (dx / maxDx) * Math.max(0, dist - stop);
    out.dx = c.vx / dist * travel; out.dy = c.vy / dist * travel;
  }
  return out;
}

function heroFrameNow(cls, now) {
  const cf = choreoFrame(cls, now); if (cf) return cf;
  const ha = R.hanim;
  if (ha) {
    const n = frameCount(cls, ha.anim);
    const ms = ha.anim === 'cast' ? 65 : (FRAME_MS[HERO_META[artCls(cls)]?.atkType] || 55);
    const col = Math.floor((now - ha.t0) / ms);
    if (col < n) return heroFrame(cls, ha.anim, R.hdir, col);
    R.hanim = null;
  }
  const walking = now - R.hmove < 190;
  return heroFrame(cls, 'walk', R.hdir, walking ? 1 + Math.floor(now / 75) % 8 : 0);
}

function burst(x, y, color, n = 10, speed = 2.5, life = 600, size = 3) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, v = (0.3 + Math.random()) * speed;
    R.parts.push({ x: x + 0.5, y: y + 0.5, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 1, g: 3, life, t0: R.time, color, size: size * (0.6 + Math.random() * 0.8) });
  }
}

function handleFx(e) {
  const now = R.time;
  poke(700);
  if (e.type !== 'sfx' && e.type !== 'move') note(e.type === 'skillfx' ? `efeito ${e.id}` : e.type);
  switch (e.type) {
    case 'sfx': Audio.play(e.name); break;
    case 'dmg': {
      const hd = e.uid !== undefined && R.hold.get(e.uid); if (hd) hd.hp -= e.val;   // a barra cai junto com o número
      R.texts.push({ x: e.x + 0.5, y: e.y + 0.1, text: String(e.val), color: e.color, crit: e.crit, t0: now, big: e.crit || e.val > 999 });
      burst(e.x, e.y, e.onHero ? '#ff6a6a' : (e.el && e.el !== 'neutro' ? ELEMENTS[e.el].color : '#fff3d0'), e.crit ? 14 : 6, 2.2, 450, 2.5);
      break;
    }
    case 'text': {   // avisos (estilhaçou!, atordoado...) acima da cabeça, empilhados, para não cobrir o número do dano
      R.texts.push({ x: e.x + 0.5, y: e.y - 0.75, tx: e.x, ty: e.y, text: e.text, color: e.color, t0: now, small: true }); break;
    }
    case 'heal':
      R.texts.push({ x: e.x + 0.5, y: e.y, text: '+' + e.val, color: '#7af08a', t0: now });
      for (let i = 0; i < 12; i++) R.parts.push({ x: e.x + 0.2 + Math.random() * 0.6, y: e.y + 0.9, vx: 0, vy: -1.2 - Math.random(), g: 0, life: 800, t0: now, color: '#9affb0', size: 2.5, glow: true });
      break;
    case 'flash': animOf(e.id).flash = now; break;
    case 'move': {
      const a = animOf(e.id);
      let fx = e.fx, fy = e.fy;
      if (a.move) {
        // continua da posição visual atual (movimento anterior ainda em curso)
        const q = Math.min(1, (now - a.move.t0) / a.move.dur), k = 1 - Math.pow(1 - q, 2);
        fx = a.move.fx + (e.fx - a.move.fx) * k; fy = a.move.fy + (e.fy - a.move.fy) * k;
      }
      if (e.id === 'hero' && e.tx !== undefined) { heroDir(e.tx - e.fx, e.ty - e.fy); R.hmove = now; }
      if (e.instant) { a.move = null; break; }
      if (e.leap) { a.move = { fx: e.fx, fy: e.fy, t0: now, dur: e.leap.dur, wait: e.leap.wait, lin: true, leap: true }; break; }
      a.move = { fx, fy, t0: now, dur: e.id === 'hero' ? 115 : 130 };
      break;
    }
    case 'lunge': {
      const a = animOf(e.id); a.lunge = { tx: e.tx, ty: e.ty, t0: now };
      if (e.id === 'hero' && G.state.run) { heroDir(e.tx - G.state.run.px, e.ty - G.state.run.py); R.hanim = { anim: 'atk', t0: now }; }
      break;
    }
    case 'quake': { const a = animOf(e.id); a.quake = now; break; }   // monstro treme com o impacto
    case 'face': if (G.state.run) R.face = e.x < G.state.run.px ? -1 : e.x > G.state.run.px ? 1 : R.face; break;
    case 'proj':
      if (e.skill && ((VFX[e.skill] && VFX[e.skill].noProj) || FX_META[e.skill])) break;
      if (G.state.run && e.fx === G.state.run.px && e.fy === G.state.run.py) {
        heroDir(e.tx - e.fx, e.ty - e.fy);
        if (!(R.hanim && R.hanim.anim === 'cast' && now - R.hanim.t0 < 40)) R.hanim = { anim: 'atk', t0: now };
      }
      R.projs.push({ ...e, t0: now, dur: 140 + Math.hypot(e.tx - e.fx, e.ty - e.fy) * 20 }); break;
    case 'burst': burst(e.x, e.y, e.color, e.n || 8, 2, 550, 3); break;
    case 'ring': R.rings.push({ x: e.x + 0.5, y: e.y + 0.5, r: e.r + 0.5, color: e.color, t0: now, dur: 380 }); break;
    case 'shake': R.shake = Math.max(R.shake, e.power || 4); break;
    case 'hphold': if (!R.hold.has(e.uid)) R.hold.set(e.uid, { hp: e.hp, until: now + 2000 }); break;
    case 'dying': R.dying.set(e.uid, { uid: e.uid, type: e.mtype, x: e.x, y: e.y, hp: 0.001, maxHp: e.maxHp || 1, status: {}, lv: 1, until: now + e.until + 200 }); break;
    case 'death': {
      if (e.uid !== undefined) R.dying.delete(e.uid);
      burst(e.x, e.y, e.color, e.boss ? 60 : 18, e.boss ? 5 : 3, e.boss ? 1400 : 700, 3.5);
      if (e.mtype) R.corpses.push({ x: e.x, y: e.y, mtype: e.mtype, t0: now, face: 1 });
      if (e.boss) R.shake = 14;
      break;
    }
    case 'levelup':
      R.texts.push({ x: e.x + 0.5, y: e.y - 0.4, text: 'NÍVEL!', color: '#ffd86b', t0: now, big: true });
      R.rings.push({ x: e.x + 0.5, y: e.y + 0.5, r: 2.5, color: '#ffd86b', t0: now, dur: 700 });
      for (let i = 0; i < 26; i++) R.parts.push({ x: e.x + 0.5 + Math.cos(i) * 0.5, y: e.y + 0.8, vx: Math.cos(i) * 0.4, vy: -2 - Math.random() * 1.5, g: 0, life: 1100, t0: now, color: '#ffe8a0', size: 3, glow: true });
      break;
    case 'cast':
      if (G.state.run && e.x === G.state.run.px && e.y === G.state.run.py) R.hanim = { anim: 'cast', t0: now };
      R.rings.push({ x: e.x + 0.5, y: e.y + 0.5, r: 0.9, color: e.color, t0: now, dur: 450, circle: true }); break;
    case 'skillfx': if (FX_META[e.id]) {
      fxSheet(e.id);
      const mirror = e.tx < e.fx || (e.tx === e.fx && R.face < 0);
      const ev = { ...e, t0: now, mirror };
      // magia em área: o efeito também cai em vários pontos da área (não só no centro), um pouco desencontrados
      if (e.spots) ev.spots = e.spots;
      else if (e.aoe > 0 && !FX_META[e.id].self) {
        const m = G.state.run?.map, tiles = areaTiles(e).filter(([x, y]) => (x !== e.tx || y !== e.ty) && m && x >= 0 && y >= 0 && x < m.w && y < m.h && m.t[y * m.w + x] !== T.WALL);
        let h = (e.tx * 73856093) ^ (e.ty * 19349663) ^ Math.floor(now);
        const rnd = () => ((h = (h * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
        for (let i = tiles.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [tiles[i], tiles[j]] = [tiles[j], tiles[i]]; }
        ev.spots = tiles.slice(0, AOE_SPOTS[e.id] ?? Math.min(6, tiles.length)).map(([x, y], i) => ({ x, y, d: 90 + i * 110 + Math.floor(rnd() * 60) }));
      }
      R.sfx.push(ev);
      if (AOE_OVERLAY[e.id] && VFX[e.id]) { const v = { ...e, t0: now, dur: VFX[e.id].dur * 1.3 }; if (VFX[e.id].start) VFX[e.id].start(v, now); R.vfx.push(v); }
      // coreografia do herói (pulos, giros, investidas) enquanto o efeito toca
      if (FX_META[e.id].ch && G.state.run && ((e.fx === G.state.run.px && e.fy === G.state.run.py) || e.leap)) R.choreo = { id: e.id, t0: now, mirror, vx: e.tx - e.fx, vy: e.ty - e.fy };
    } break;
    case 'falcon': R.falcon.push({ ...e, t0: now }); break;
    case 'vfx': if (FX_META[e.id]) break; if (VFX[e.id]) { const v = { ...e, t0: now, dur: VFX[e.id].dur }; if (VFX[e.id].start) VFX[e.id].start(v, now); R.vfx.push(v); } break;
    case 'meteor': R.projs.push({ fx: e.x - 2, fy: e.y - 6, tx: e.x, ty: e.y, color: '#ff8a3a', big: true, t0: now, dur: 260, meteor: true }); break;
    case 'cardDrop': for (let i = 0; i < 20; i++) R.parts.push({ x: e.x + Math.random(), y: e.y + Math.random(), vx: 0, vy: -0.8, g: 0, life: 1500, t0: now + i * 40, color: '#ffd86b', size: 2.5, glow: true }); break;
    case 'splash': burst(e.x, e.y, '#9ad8ff', 6, 1.5, 400, 2); break;
    case 'hurt': R.hurt = now; if (G.state.settings?.vibrate && navigator.vibrate) try { navigator.vibrate(25); } catch (_) {} break;
    case 'floor': R.flashFloor = now; R.anims.clear(); R.dying.clear(); R.hold.clear(); R.parts = []; R.texts = []; R.projs = []; R.vfx = []; R.corpses = []; snapCamera(); break;
    case 'victory': R.victory = now; break;
  }
}

function pumpFx() {
  const now = R.time;
  while (G.fx.length) {
    const e = G.fx.shift();
    if (e.delay) R.pending.push({ at: now + e.delay, e: { ...e, delay: 0 } });
    else handleFx(e);
  }
  if (R.pending.length) {
    const due = R.pending.filter((p) => p.at <= now);
    R.pending = R.pending.filter((p) => p.at > now);
    due.forEach((p) => handleFx(p.e));
  }
}

function applyZoom() {
  const minZ = Math.max(0.2, (R.W / 42) / R.baseTS);
  R.zoom = Math.max(minZ, Math.min(1.6, R.zoom));
  R.TS = Math.max(8, Math.round(R.baseTS * R.zoom));
}

// Câmera livre: arrastar e pinçar, como no Shattered Pixel Dungeon
export function panCamera(dxPx, dyPx) {
  R.follow = false;
  R.camX -= dxPx / R.TS; R.camY -= dyPx / (R.TS * R.ky);
  const m = G.state?.run?.map;
  if (m) { R.camX = Math.max(0, Math.min(m.w - 1, R.camX)); R.camY = Math.max(0, Math.min(m.h - 1, R.camY)); }
}
export function zoomCamera(factor, cxPx, cyPx) {
  const before = screenToTileF(cxPx, cyPx);
  R.zoom *= factor;
  applyZoom();
  const after = screenToTileF(cxPx, cyPx);
  R.camX += before.x - after.x; R.camY += before.y - after.y;
  if (factor !== 1) R.follow = false;
}
function screenToTileF(px, py) { if (persp()) return R.r3.unproject(px, py) || { x: R.camX, y: R.camY }; return { x: (px - R.W / 2) / R.TS + R.camX, y: (py - viewCY()) / (R.TS * R.ky) + R.camY }; }
export function followHero() { R.follow = true; }
export function resetZoom() { R.zoom = 1; applyZoom(); R.follow = true; }
export const cameraFree = () => !R.follow || Math.abs(R.zoom - 1) > 0.01;

export function snapCamera() {
  const r = G.state?.run;
  if (r) { R.camX = r.px; R.camY = r.py; }
}

// ---------------- Laço principal ----------------
// ritmo de desenho: jogo por turnos não precisa de 60 quadros parado.
// com ação na tela (efeito, andar, câmera, toque) desenha a 30; parado, a 15 (só tocha e respiração).
let busyUntil = 0, lastDraw = 0;
export function poke(ms = 600) { busyUntil = Math.max(busyUntil, performance.now() + ms); }
function busy(ts) {
  if (ts < busyUntil || G.fx.length || R.pending.length || R.parts.length || R.texts.length || R.projs.length || R.rings.length || R.vfx.length || R.sfx.length || R.falcon.length || R.corpses.length || R.choreo || R.shake > 0.2) return true;
  const r = G.state?.run;
  if (G.state?.mode === 'dungeon' && r) { const hp = R.anims.get('hero'); if (Math.abs(R.camX - r.px) + Math.abs(R.camY - r.py) > 0.02 || (hp && ts - (hp.t0 || 0) < 400)) return true; }
  return false;
}
function loop(ts) {
  tickDiag(ts);
  requestAnimationFrame(loop);
  const fast = G.state?.settings?.fps60;
  const gap = busy(ts) ? (fast ? 0 : 32) : 64;
  if (ts - lastDraw < gap - 3) return;
  lastDraw = ts;
  const t0 = performance.now();
  draw(ts);
  const dms = performance.now() - t0; drawTime(dms); if (dms > 60) note(`desenho ${Math.round(dms)}ms`);
}
function draw(ts) {
  const dt = Math.min(50, ts - (R.last || ts));
  R.last = ts; R.time = ts;
  pumpFx();
  const ctx = R.ctx;
  ctx.setTransform(R.dpr, 0, 0, R.dpr, 0, 0);
  const st = G.state;
  const inD = st && st.mode === 'dungeon' && st.run;
  if (R.r3) { R.r3.show3d(R.m3d && !!inD); if (!inD && R.r3.worldBuilt()) { mark('solta andar 3D'); R.r3.freeWorld(); R.env3d = null; R.groundKey = null; } }
  if (inD) drawDungeon(ctx, dt);
  else if (st?.mode === 'town' && document.body.classList.contains('town-on')) { if (!R.townClear) { ctx.clearRect(0, 0, R.W, R.H); R.townClear = true; } }   // a cidade 3D cobre tudo
  else drawBackdrop(ctx, st?.mode);
  if (st?.mode !== 'town') R.townClear = false;
}

// Fundo da cidade / título: aurora suave
const stars = Array.from({ length: 80 }, () => ({ x: Math.random(), y: Math.random() * 0.7, r: Math.random() * 1.4 + 0.3, p: Math.random() * 6 }));
function drawBackdrop(ctx, mode) {
  const W = R.W, H = R.H, t = R.time / 1000;
  ctx.fillStyle = mode === 'dead' ? '#0c0610' : '#07081a';
  ctx.fillRect(0, 0, W, H);
  const blobs = mode === 'dead'
    ? [['255,60,90', 0.5, 0.3, 0.6]]
    : [['167,123,255', 0.25, 0.22, 0.75], ['94,225,255', 0.8, 0.35, 0.65], ['255,110,200', 0.55, 0.75, 0.6]];
  ctx.globalCompositeOperation = 'lighter';
  blobs.forEach(([c, bx, by, r], i) => {
    const x = (bx + Math.sin(t * 0.13 + i * 2) * 0.08) * W, y = (by + Math.cos(t * 0.11 + i) * 0.06) * H, rad = r * Math.max(W, H) * 0.6;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, `rgba(${c},0.32)`); g.addColorStop(1, `rgba(${c},0)`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  });
  ctx.globalCompositeOperation = 'source-over';
  for (const s of stars) { ctx.globalAlpha = 0.25 + 0.35 * Math.sin(t * 1.4 + s.p); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(s.x * W, s.y * H, s.r, 0, 7); ctx.fill(); }
  ctx.globalAlpha = 1;
  if (mode === 'dead') return;
  // silhueta do castelo com janelas acesas
  const base = H * 0.86, cx = W * 0.5;
  ctx.fillStyle = 'rgba(6,6,20,0.9)';
  ctx.beginPath(); ctx.moveTo(0, base + 20);
  for (let i = 0; i <= 12; i++) ctx.lineTo(i * W / 12, base - 10 - Math.sin(i * 1.3) * 14);
  ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
  ctx.fillRect(cx - 60, base - 70, 120, 90);
  for (const [dx, h, w] of [[-62, 120, 22], [40, 132, 22], [-11, 170, 24]]) {
    ctx.fillRect(cx + dx, base - h, w, h);
    ctx.beginPath(); ctx.moveTo(cx + dx - 5, base - h); ctx.lineTo(cx + dx + w / 2, base - h - 30); ctx.lineTo(cx + dx + w + 5, base - h); ctx.fill();
  }
  ctx.save(); ctx.shadowColor = '#5ee1ff'; ctx.shadowBlur = 12;
  for (const [dx, dy] of [[-54, 90], [48, 104], [-3, 140], [-30, 40], [22, 50]]) { ctx.fillStyle = `rgba(160,235,255,${0.6 + 0.3 * Math.sin(t * 2 + dx)})`; ctx.fillRect(cx + dx, base - dy, 5, 8); }
  ctx.restore();
  // partículas subindo
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 22; i++) {
    const x = ((i * 0.137 + Math.sin(t * 0.2 + i) * 0.04) % 1) * W, y = H - ((t * 18 + i * 61) % (H * 0.9));
    const g = ctx.createRadialGradient(x, y, 0, x, y, 6); g.addColorStop(0, 'rgba(160,220,255,0.6)'); g.addColorStop(1, 'rgba(160,220,255,0)');
    ctx.fillStyle = g; ctx.fillRect(x - 6, y - 6, 12, 12);
  }
  ctx.globalCompositeOperation = 'source-over';
}

// tela de carregamento do andar (enquanto os modelos 3D chegam)
function drawLoading(ctx, floor, now) {
  ctx.fillStyle = '#07080c'; ctx.fillRect(0, 0, R.W, R.H);
  const t = now / 1000, cx = R.W / 2, cy = R.H / 2;
  ctx.textAlign = 'center'; ctx.fillStyle = '#ffe3a0'; ctx.font = "600 20px Pixelify, Fredoka, sans-serif";
  ctx.fillText(`Andar ${floor}`, cx, cy - 8);
  ctx.fillStyle = '#b8b0d8'; ctx.font = "500 13px Pixelify, Fredoka, sans-serif";
  ctx.fillText('Acendendo as tochas…', cx, cy + 16);
  for (let i = 0; i < 3; i++) { ctx.globalAlpha = 0.3 + 0.7 * Math.max(0, Math.sin(t * 5 - i * 0.8)); ctx.fillStyle = '#e2bc6e'; ctx.beginPath(); ctx.arc(cx - 14 + i * 14, cy + 36, 3.5, 0, 7); ctx.fill(); }
  ctx.globalAlpha = 1; ctx.textAlign = 'start';
}

// ---------------- Masmorra ----------------
// marcas no chão para o cenário 3D: avisos de golpe dos chefes e alcance da habilidade escolhida
function groundMarks(r, m, now) {
  const out = [];
  for (const tg of r.telegraphs) {
    const left = Math.max(0, tg.at - r.time) / 14, pulse = 0.35 + 0.25 * Math.sin(now / 90);
    out.push({ color: tg.color, alpha: Math.min(0.9, pulse * (1.2 - left * 0.5) + 0.1), tiles: tg.tiles.filter(([x, y]) => m.seen[y * m.w + x]) });
  }
  if (R.targeting) {
    const tgt = R.targeting, tiles = [];
    for (let y = r.py - tgt.range; y <= r.py + tgt.range; y++) for (let x = r.px - tgt.range; x <= r.px + tgt.range; x++) if (visible(x, y) && tileAt(m, x, y) !== T.WALL) tiles.push([x, y]);
    out.push({ color: '#7ad0ff', alpha: 0.16, tiles });
  }
  return out;
}
function drawDungeon(ctx, dt) {
  const r = G.state.run, m = r.map, now = R.time;
  const th = THEMES[m.theme];
  const key = `${m.theme}:${R.TS}:${R.dpr}`;
  if (R.tilesKey !== key) { buildTiles(m.theme); R.tilesKey = key; }
  const TS = R.TS;

  // câmera suave
  const hp = renderPos('hero', r.px, r.py, now);
  if (R.follow) {
    const k = 1 - Math.pow(0.0005, dt / 1000);
    R.camX += (hp.x - R.camX) * k; R.camY += (hp.y - R.camY) * k;
  }
  let shx = 0, shy = 0;
  if (R.shake > 0.2) { shx = (Math.random() - 0.5) * R.shake; shy = (Math.random() - 0.5) * R.shake; R.shake *= Math.pow(0.002, dt / 1000); } else R.shake = 0;

  if (R.m3d) {
    // cenário 3D por baixo; este canvas fica transparente e só desenha efeitos, números e barras
    if (R.groundKey !== m) { R.groundKey = m; R.env3d = null; }
    R.p3 = true;
    const ok = R.r3.render3d({ m, W: R.W, H: R.H, TS, viewCY: viewCY(), camX: R.camX, camY: R.camY, shake: [shx, shy], now,
      hero: hp, fov: G.fov, fovStamp: G.fov,
      envFn: () => (R.env3d = R.env3d || bakeGround(m)), ents: ents3d(r, now, hp), marks: groundMarks(r, m, now) });
    ctx.clearRect(0, 0, R.W, R.H);
    if (ok === false) { if (!R.loadingMark) { R.loadingMark = true; mark(`carregando andar ${r.floor}`); } drawLoading(ctx, r.floor, now); poke(200); return; }
    if (R.loadingMark) { R.loadingMark = false; mark('andar pronto'); }
  } else { ctx.fillStyle = '#07080c'; ctx.fillRect(0, 0, R.W, R.H); }
  ctx.save(); ctx.translate(shx, shy);

  const x0 = Math.max(0, Math.floor(R.camX - R.W / 2 / TS) - 1), x1 = Math.min(m.w - 1, Math.ceil(R.camX + R.W / 2 / TS) + 1);
  const y0 = Math.max(0, Math.floor(R.camY - viewCY() / TS) - 1), y1 = Math.min(m.h - 1, Math.ceil(R.camY + (R.H - viewCY()) / TS) + 1);
  const t = now / 1000;
  const tl = R.tiles;

  if (R.m3d) {
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) if (m.t[y * m.w + x] === T.PORTAL && m.seen[y * m.w + x]) drawPortal(ctx, sx(x, y), sy(y, x), TS, t);
  }
  if (!R.m3d) for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
    const i = y * m.w + x;
    if (!m.seen[i]) continue;
    const tt = m.t[i], X = sx(x, y), Y = sy(y, x);
    if (tt === T.WALL) {
      const below = tileAt(m, x, y + 1);
      if (tl.dc) {
        const v = Math.abs(hash(x, y)) % 2;
        if (tl.dc.natural) ctx.drawImage(tl.dc.base, X, Y, TS, TS); // rocha/terra; a floresta dos Campos vem por cima
        else ctx.drawImage(below === T.WALL ? tl.dc.tops[v] : tl.dc.faces[v], X, Y, TS, TS);
      } else ctx.drawImage(below === T.WALL ? tl.wallTop : tl.wallFace, X, Y, TS, TS);
      if (m.decor[i] === 'torch' && below !== T.WALL && !(tl.dc && tl.dc.trees)) drawTorch(ctx, X, Y, TS, t, th);
      continue;
    }
    drawGroundTile(ctx, m, tl, th, x, y, X, Y, TS, t);
  }

  // floresta dos Campos: copas de árvore sobre as paredes, de cima para baixo para se sobreporem
  if (tl.dc && tl.dc.trees && !R.m3d) {
    ctx.imageSmoothingEnabled = false;
    for (let y = y0; y <= y1 + 1; y++) for (let x = x0; x <= x1; x++) {
      const i = y * m.w + x;
      if (y >= m.h || m.t[i] !== T.WALL || !m.seen[i]) continue;
      const h = Math.abs(hash(x, y)), n = tl.dc.trees.length;
      const tr = tl.dc.trees[(h % 5 === 0 ? 2 + ((h >>> 3) % 2) : (h >>> 3) % 2) % n];
      const w = TS * 1.55, hh = w * tr.height / tr.width;
      ctx.drawImage(tr, sx(x, y) + TS / 2 - w / 2, sy(y, x) + TS * 1.25 - hh, w, hh);
    }
    ctx.imageSmoothingEnabled = true;
  }

  // telegrafias (no 3D vão para o chão do cenário, atrás dos bonecos)
  if (!R.m3d) for (const tg of r.telegraphs) {
    const left = Math.max(0, tg.at - r.time) / 14;
    const pulse = 0.35 + 0.25 * Math.sin(now / 90);
    ctx.fillStyle = tg.color; ctx.globalAlpha = pulse * (1.2 - left * 0.5);
    for (const [x, y] of tg.tiles) if (m.seen[y * m.w + x]) { ctx.beginPath(); tileShape(ctx, x, y, 2, 6); ctx.fill(); }
    ctx.globalAlpha = 1;
  }

  // alcance da habilidade
  if (R.targeting && !R.m3d) {
    const tgt = R.targeting;
    ctx.fillStyle = 'rgba(122,208,255,0.10)';
    for (let y = r.py - tgt.range; y <= r.py + tgt.range; y++) for (let x = r.px - tgt.range; x <= r.px + tgt.range; x++) {
      if (visible(x, y) && tileAt(m, x, y) !== T.WALL) { ctx.beginPath(); tileShape(ctx, x, y, 1, 0); ctx.fill(); }
    }
  }

  // itens no chão
  for (const g of r.items) {
    if (!m.seen[g.y * m.w + g.x]) continue;
    const X = sx(g.x, g.y), Y = sy(g.y, g.x) + Math.sin(t * 3 + g.x) * 2;
    const d = itemDef(g.item);
    if (d.kind === 'card') { ctx.save(); ctx.shadowColor = '#ffd86b'; ctx.shadowBlur = 16; }
    ctx.drawImage(itemSprite(g.item), X + TS * 0.18, Y + TS * 0.15, TS * 0.64, TS * 0.64);
    if (d.kind === 'card') ctx.restore();
  }

  // cadáveres desaparecendo
  R.corpses = R.corpses.filter((c) => now - c.t0 < 450);
  for (const c of R.corpses) {
    const p = (now - c.t0) / 450;
    const spr = monsterSprite(c.mtype);
    const sc = (spr.lpc ? spr.lpc / 64 * (1.3 / 1.35) : (MONSTERS[c.mtype].sprite.scale || 1)) * TS * 1.35;
    ctx.globalAlpha = 1 - p;
    ctx.imageSmoothingEnabled = !spr.pixel;
    ctx.drawImage(spr, sx(c.x, c.y) + TS / 2 - sc / 2, sy(c.y, c.x) + TS * 0.95 - sc * 0.92 + p * 8, sc, sc * (1 - p * 0.5));
    ctx.globalAlpha = 1; ctx.imageSmoothingEnabled = true;
  }

  // entidades ordenadas por y
  const ents = [];
  for (const mo of monstersShown(r)) if (mo.hp > 0 && visible(mo.x, mo.y)) ents.push({ kind: 'm', o: mo, ...renderPos(mo.uid, mo.x, mo.y, now) });
  ents.push({ kind: 'h', ...hp });
  ents.sort((a, b) => a.y - b.y);
  for (const e of ents) drawEntity(ctx, e, now, t);

  // projéteis
  R.projs = R.projs.filter((p) => now - p.t0 < p.dur);
  for (const p of R.projs) {
    const q = (now - p.t0) / p.dur;
    const qx = p.fx + (p.tx - p.fx) * q, qy = p.fy + (p.ty - p.fy) * q, x = sx(qx, qy) + TS / 2, y = sy(qy, qx) + TS / 2 - (p.meteor ? 0 : TS * 0.25);
    ctx.save(); ctx.shadowColor = p.color; ctx.shadowBlur = p.big ? 18 : 8; ctx.fillStyle = p.color;
    if (p.arrow) {
      const a = Math.atan2(p.ty - p.fy, p.tx - p.fx);
      ctx.translate(x, y); ctx.rotate(a); ctx.fillRect(-TS * 0.3, -1.5, TS * 0.5, 3); ctx.beginPath(); ctx.moveTo(TS * 0.25, -5); ctx.lineTo(TS * 0.38, 0); ctx.lineTo(TS * 0.25, 5); ctx.fill();
    } else { ctx.beginPath(); ctx.arc(x, y, p.big ? TS * 0.16 : TS * 0.08, 0, 7); ctx.fill(); if (p.big) R.parts.push({ x: x / TS, y: 0, sx: x, sy: y, screen: true, vx: 0, vy: 0, g: 0, life: 250, t0: now, color: p.color, size: 4, glow: true }); }
    ctx.restore();
  }

  // efeitos das habilidades (folhas novas) e efeitos de habilidade ativa
  drawSkillSheets(ctx, now, r, hp);
  drawFalcon(ctx, now, r, hp);
  // efeitos antigos (desenhados por código) de quem ainda não tem folha
  R.vfx = R.vfx.filter((v) => now - v.t0 < v.dur);
  for (const v of R.vfx) { ctx.save(); VFX[v.id].draw(ctx, v, (now - v.t0) / v.dur, now, sx, sy); ctx.restore(); }

  // anéis
  R.rings = R.rings.filter((g) => now - g.t0 < g.dur);
  for (const g of R.rings) {
    const q = (now - g.t0) / g.dur;
    ctx.save(); ctx.globalAlpha = 1 - q; ctx.strokeStyle = g.color; ctx.lineWidth = 3; ctx.shadowColor = g.color; ctx.shadowBlur = 12;
    ctx.beginPath(); ctx.ellipse(sx(g.x - 0.5, g.y - 0.5) + TS / 2, sy(g.y - 0.5, g.x - 0.5) + TS / 2 + TS * 0.25, g.r * TS * (g.circle ? 1 : q), g.r * TS * 0.55 * (g.circle ? 1 : q), 0, 0, 7); ctx.stroke();
    if (g.circle) { ctx.setLineDash([6, 6]); ctx.lineDashOffset = -now / 20; ctx.beginPath(); ctx.ellipse(sx(g.x - 0.5, g.y - 0.5) + TS / 2, sy(g.y - 0.5, g.x - 0.5) + TS / 2 + TS * 0.25, g.r * TS * 0.7, g.r * TS * 0.38, 0, 0, 7); ctx.stroke(); }
    ctx.restore();
  }

  // partículas (coordenadas de tile)
  R.parts = R.parts.filter((p) => now - p.t0 < p.life);
  for (const p of R.parts) {
    if (now < p.t0) continue;
    const a = (now - p.t0) / 1000;
    const q = (now - p.t0) / p.life;
    let X, Y;
    if (p.screen) { X = p.sx; Y = p.sy; }
    else { const px = p.x + p.vx * a - 0.5, py = p.y + p.vy * a + p.g * a * a * 0.5 - 0.5; X = sx(px, py) + TS / 2; Y = sy(py, px) + TS / 2; }
    ctx.globalAlpha = 1 - q;
    if (p.glow) { ctx.save(); ctx.shadowColor = p.color; ctx.shadowBlur = 8; }
    ctx.fillStyle = p.color; ctx.fillRect(X - p.size / 2, Y - p.size / 2, p.size, p.size);
    if (p.glow) ctx.restore();
  }
  ctx.globalAlpha = 1;

  // iluminação
  if (!R.m3d) drawLighting(ctx, r, m, th, t, x0, x1, y0, y1);

  // números flutuantes
  // armadilhas do Caçador: mandíbula de ferro aberta no chão
  for (const tp of r.traps || []) {
    if (!m.seen[tp.y * m.w + tp.x]) continue;
    const X = sx(tp.x, tp.y) + TS / 2, Y = sy(tp.y, tp.x) + TS * 0.72, rw = TS * 0.34, rh = rw * 0.5;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(X, Y + 2, rw * 1.1, rh * 1.1, 0, 0, 7); ctx.fill();
    ctx.strokeStyle = '#8a8f98'; ctx.lineWidth = Math.max(2, TS * 0.05); ctx.beginPath(); ctx.ellipse(X, Y, rw, rh, 0, 0, 7); ctx.stroke();
    ctx.fillStyle = '#c8ccd4';
    for (let i = 0; i < 10; i++) { const a = i / 10 * 6.283, x1 = X + Math.cos(a) * rw, y1 = Y + Math.sin(a) * rh, x2 = X + Math.cos(a) * rw * 0.62, y2 = Y + Math.sin(a) * rh * 0.62 - TS * 0.05;
      ctx.beginPath(); ctx.moveTo(x1 + Math.sin(a) * 3, y1 - Math.cos(a) * 1.5); ctx.lineTo(x2, y2); ctx.lineTo(x1 - Math.sin(a) * 3, y1 + Math.cos(a) * 1.5); ctx.fill(); }
    ctx.fillStyle = '#d9a840'; ctx.globalAlpha = 0.75 + 0.25 * Math.sin(now / 250); ctx.beginPath(); ctx.ellipse(X, Y, rw * 0.28, rh * 0.28, 0, 0, 7); ctx.fill();
    ctx.restore();
  }
  // Bomba de Fumaça: nuvens cinzas que se mexem devagar sobre as 3×3 casas
  for (const sm of r.smokes || []) {
    ctx.save();
    for (let yy = -1; yy <= 1; yy++) for (let xx = -1; xx <= 1; xx++) {
      const x = sm.x + xx, y = sm.y + yy; if (!m.seen[y * m.w + x]) continue;
      const X = sx(x, y) + TS / 2, Y = sy(y, x) + TS * 0.45;
      for (let k = 0; k < 3; k++) {
        const ph = now / 900 + (xx * 3 + yy * 7 + k * 2.1);
        ctx.globalAlpha = 0.28 + 0.08 * Math.sin(ph * 1.7);
        ctx.fillStyle = k === 1 ? '#a8adb8' : '#7e838e';
        ctx.beginPath(); ctx.ellipse(X + Math.cos(ph) * TS * 0.18, Y + Math.sin(ph * 1.3) * TS * 0.1 - k * TS * 0.12, TS * (0.42 - k * 0.06), TS * (0.26 - k * 0.03), 0, 0, 7); ctx.fill();
      }
    }
    ctx.restore();
  }
  // nenhum texto cobre outro: ao aparecer, cada texto procura a faixa livre logo acima e guarda esse deslocamento
  R.texts = R.texts.filter((tx) => now - tx.t0 < 950);
  const placed = [];
  for (const tx of R.texts) {
    const q = (now - tx.t0) / 950;
    const size = tx.big ? 22 : tx.small ? 13 : 17;
    const X = sx(tx.x - 0.5, tx.y - 0.5) + TS / 2, Y0 = sy(tx.y - 0.5, tx.x - 0.5) + TS * 0.1 - q * TS * 0.9;
    ctx.font = `800 ${size}px system-ui, -apple-system, Roboto, sans-serif`;
    const w = ctx.measureText(tx.text).width + 10, hh = size + 3;
    const hit = (y) => placed.some((p) => Math.abs(p.x - X) < (p.w + w) / 2 && Math.abs(p.y - y) < (p.h + hh) / 2);
    if (tx.off === undefined) { tx.off = 0; while (hit(Y0 + tx.off) && tx.off > -hh * 8) tx.off -= hh; }
    const Y = Y0 + tx.off;
    placed.push({ x: X, y: Y, w, h: hh });
    const pop = q < 0.12 ? 1 + (0.12 - q) * 4 : 1;
    ctx.save();
    ctx.globalAlpha = q > 0.7 ? (1 - q) / 0.3 : 1;
    ctx.font = `800 ${Math.round(size * pop)}px system-ui, -apple-system, Roboto, sans-serif`;
    ctx.textAlign = 'center';
    ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,6,16,0.9)'; ctx.strokeText(tx.text, X, Y);
    ctx.fillStyle = tx.color; ctx.fillText(tx.text, X, Y);
    ctx.restore();
  }

  // marcador de destino / alvo
  if (R.marker && now - R.marker.t0 < 600) {
    const q = (now - R.marker.t0) / 600;
    ctx.save(); ctx.globalAlpha = 1 - q; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(sx(R.marker.x, R.marker.y) + TS / 2, sy(R.marker.y, R.marker.x) + TS * 0.7, TS * 0.35 * (0.6 + q * 0.5), TS * 0.16 * (0.6 + q * 0.5), 0, 0, 7); ctx.stroke(); ctx.restore();
  }
  ctx.restore();

  // dano no herói: vinheta vermelha
  if (now - R.hurt < 300) {
    const q = 1 - (now - R.hurt) / 300;
    const g = ctx.createRadialGradient(R.W / 2, R.H / 2, R.W * 0.3, R.W / 2, R.H / 2, R.H * 0.7);
    g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(200,0,20,${0.45 * q})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, R.W, R.H);
  }
  // HP baixo: pulsação
  const h = G.state.hero;
  if (h && G.d && h.hp < G.d.maxHp * 0.25) {
    const g = ctx.createRadialGradient(R.W / 2, R.H / 2, R.W * 0.35, R.W / 2, R.H / 2, R.H * 0.75);
    g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(160,0,20,${0.18 + 0.12 * Math.sin(now / 200)})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, R.W, R.H);
  }
  // transição de andar
  if (now - R.flashFloor < 600) { ctx.fillStyle = `rgba(0,0,0,${1 - (now - R.flashFloor) / 600})`; ctx.fillRect(0, 0, R.W, R.H); }
}

function quakeOff(a, now) {
  if (!a.quake) return [0, 0];
  const q = (now - a.quake) / 380; if (q >= 1) { a.quake = 0; return [0, 0]; }
  return [Math.sin(q * 48) * 0.05 * (1 - q), Math.sin(q * Math.PI) * 0.16 * (1 - q * 0.5)];   // chacoalha de lado + pulinho
}
function lungeOff(a, e, now) {
  if (!a.lunge) return [0, 0];
  const q = (now - a.lunge.t0) / 180;
  if (q >= 1) return [0, 0];
  const dx = a.lunge.tx - e.x, dy = a.lunge.ty - e.y, len = Math.hypot(dx, dy) || 1;
  const amt = Math.sin(q * Math.PI) * 0.3;
  return [dx / len * amt, dy / len * amt];
}

// lista de sprites para o cenário 3D (herói + monstros visíveis)
// monstros vivos + os que já morreram mas ainda esperam o golpe da animação chegar
function monstersShown(r) {
  if (!R.dying.size) return r.monsters;
  const out = r.monsters.slice();
  for (const [k, d] of R.dying) { if (R.time > d.until) R.dying.delete(k); else if (!r.monsters.some((m) => m.uid === d.uid && m.hp > 0)) out.push(d); }
  return out;
}
function ents3d(r, now, hp) {
  const TS = R.TS, t = now / 1000, out = [];
  const ah = R.anims.get('hero') || {};
  const fr = heroFrameNow(G.state.hero.cls, now);
  const [hx, hy] = lungeOff(ah, hp, now);
  if (fr) out.push({ id: 'hero', kind: 'hero', img: fr.img, sx: fr.sx, sy: fr.sy, cell: CELL, feet: FEET,
    x: hp.x + hx + (fr.dx || 0), y: hp.y + hy + (fr.dy || 0), up: fr.up || 0, flip: !!fr.flip, flash: !!(ah.flash && now - ah.flash < 140),
    alpha: G.state.hero.buffs.some((b) => b.id === 'oculto') ? 0.4 : 1 });
  for (const mo of monstersShown(r)) {
    if (mo.hp <= 0 || !visible(mo.x, mo.y)) continue;
    const p = renderPos(mo.uid, mo.x, mo.y, now);
    const a = R.anims.get(mo.uid) || {};
    const [ox0, oy] = lungeOff(a, p, now), [qx, qup] = quakeOff(a, now), ox = ox0 + qx;
    const sp = MONSTERS[mo.type].sprite, phase = mo.uid % 10;
    const bob = Math.sin(t * 4 + phase) * 0.025 * TS + (a.move ? -Math.abs(Math.sin(t * 25)) * TS * 0.08 : 0);
    const fly = ['bat', 'ghost'].includes(sp.shape) ? -TS * 0.25 + Math.sin(t * 6 + phase) * TS * 0.06 : 0;
    out.push({ id: 'm' + mo.uid, kind: 'mon', canvas: monsterSprite(mo.type), type: mo.type,
      x: p.x + ox, y: p.y + oy, up: -(bob + fly) / TS + qup,
      sq: sp.shape === 'blob' ? 1 + Math.sin(t * 5 + phase) * 0.05 : 1,
      flash: !!(a.flash && now - a.flash < 140), alpha: 1, tint: holdOf(mo) ? null : (mo.status?.freeze || 0) > 0 ? 'ice' : (mo.status?.petrify || 0) > 0 ? 'stone' : null });
  }
  return out;
}

// congelado: cristais de gelo brotando em volta dos pés + brilhinhos; petrificado: pedrinhas no chão
function drawIceShards(ctx, X, Y, TS, t, seed) {
  const cx = X + TS / 2, cy = Y + TS * 0.9, k = TS / 44;
  const shards = [[-13, 10, -0.35], [-6, 15, -0.12], [3, 18, 0.05], [11, 12, 0.3], [16, 8, 0.5], [-17, 7, -0.55]];
  ctx.save();
  for (const [dx, h, a] of shards) {
    const x = cx + dx * k, hh = h * k;
    ctx.save(); ctx.translate(x, cy); ctx.rotate(a);
    ctx.beginPath(); ctx.moveTo(-3 * k, 0); ctx.lineTo(0, -hh); ctx.lineTo(3 * k, 0); ctx.closePath();
    ctx.fillStyle = 'rgba(150,215,255,0.85)'; ctx.fill();
    ctx.beginPath(); ctx.moveTo(-0.6 * k, -1); ctx.lineTo(0, -hh + 2 * k); ctx.lineTo(1.2 * k, -1); ctx.closePath();
    ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.fill();
    ctx.strokeStyle = 'rgba(60,120,190,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-3 * k, 0); ctx.lineTo(0, -hh); ctx.lineTo(3 * k, 0); ctx.stroke();
    ctx.restore();
  }
  ctx.fillStyle = 'rgba(190,235,255,0.35)'; ctx.beginPath(); ctx.ellipse(cx, cy, 15 * k, 4.5 * k, 0, 0, 7); ctx.fill();
  for (let i = 0; i < 3; i++) {   // brilhos de gelo subindo
    const q = (t * 0.8 + i / 3 + seed * 0.13) % 1, sx = cx + Math.sin(seed + i * 2.1) * 10 * k, sy = cy - 6 * k - q * 26 * k;
    ctx.globalAlpha = Math.sin(q * Math.PI); ctx.fillStyle = '#eaf8ff'; ctx.fillRect(sx - 1, sy - 3, 2, 6); ctx.fillRect(sx - 3, sy - 1, 6, 2);
  }
  ctx.restore();
}
function drawRubble(ctx, X, Y, TS, seed) {
  const cx = X + TS / 2, cy = Y + TS * 0.9, k = TS / 44;
  ctx.save();
  for (const [dx, r] of [[-12, 3.2], [-5, 2.2], [8, 3.6], [14, 2.4], [2, 1.8]]) {
    ctx.fillStyle = '#6e6658'; ctx.beginPath(); ctx.ellipse(cx + dx * k, cy, r * k * 1.3, r * k, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#a89e8a'; ctx.beginPath(); ctx.ellipse(cx + dx * k - k, cy - k, r * k * 0.6, r * k * 0.45, 0, 0, 7); ctx.fill();
  }
  ctx.restore();
}

// golpe a caminho: até o efeito acertar, mostra a vida de antes e esconde gelo/pedra/atordoado novos
function holdOf(o) {
  const hd = R.hold.get(o.uid); if (!hd) return null;
  if (R.time > hd.until || hd.hp <= o.hp) { R.hold.delete(o.uid); return null; }
  return hd;
}
// marcas de estado e barra de HP (desenhadas por cima, nos dois modos)
// selinhos de estado em cima da barra de vida: queimando, congelado, petrificado, atordoado, envenenado, preso, no campo
const BADGES = [
  ['burn', '#ff6a2a', (c, x, y, s) => { c.fillStyle = '#ffe36a'; c.beginPath(); c.moveTo(x + s * 0.5, y + s * 0.18); c.lineTo(x + s * 0.78, y + s * 0.78); c.lineTo(x + s * 0.22, y + s * 0.78); c.fill(); }],
  ['freeze', '#3a9be8', (c, x, y, s) => { c.strokeStyle = '#fff'; c.lineWidth = Math.max(1, s * 0.13); c.beginPath(); c.moveTo(x + s / 2, y + s * 0.18); c.lineTo(x + s / 2, y + s * 0.82); c.moveTo(x + s * 0.2, y + s * 0.34); c.lineTo(x + s * 0.8, y + s * 0.66); c.moveTo(x + s * 0.8, y + s * 0.34); c.lineTo(x + s * 0.2, y + s * 0.66); c.stroke(); }],
  ['petrify', '#8c8574', (c, x, y, s) => { c.fillStyle = '#d8d0bc'; c.fillRect(x + s * 0.22, y + s * 0.3, s * 0.56, s * 0.44); c.fillStyle = '#4a443a'; c.fillRect(x + s * 0.46, y + s * 0.3, s * 0.1, s * 0.44); }],
  ['stun', '#e8b820', (c, x, y, s) => { c.fillStyle = '#3a2a00'; c.beginPath(); c.arc(x + s / 2, y + s / 2, s * 0.2, 0, 7); c.fill(); }],
  ['poison', '#8a4ad0', (c, x, y, s) => { c.fillStyle = '#c8ff8a'; c.beginPath(); c.arc(x + s / 2, y + s * 0.6, s * 0.2, 0, 7); c.fill(); c.fillRect(x + s * 0.44, y + s * 0.22, s * 0.12, s * 0.3); }],
  ['snare', '#9a6a3a', (c, x, y, s) => { c.strokeStyle = '#f0d8a8'; c.lineWidth = Math.max(1, s * 0.12); c.beginPath(); c.moveTo(x + s * 0.35, y + s * 0.2); c.lineTo(x + s * 0.35, y + s * 0.8); c.moveTo(x + s * 0.65, y + s * 0.2); c.lineTo(x + s * 0.65, y + s * 0.8); c.moveTo(x + s * 0.2, y + s / 2); c.lineTo(x + s * 0.8, y + s / 2); c.stroke(); }],
  ['bleed', '#b0101e', (c, x, y, s, o) => { c.fillStyle = '#ffd0d4'; c.beginPath(); c.moveTo(x + s * 0.5, y + s * 0.16); c.quadraticCurveTo(x + s * 0.8, y + s * 0.55, x + s * 0.5, y + s * 0.82); c.quadraticCurveTo(x + s * 0.2, y + s * 0.55, x + s * 0.5, y + s * 0.16); c.fill();
    const n = o && o.bleed; if (n > 1) { c.font = `900 ${Math.round(s * 0.62)}px system-ui`; c.textAlign = 'center'; c.lineWidth = 2.5; c.strokeStyle = '#000'; c.strokeText(n, x + s * 0.9, y + s * 1.05); c.fillStyle = '#fff'; c.fillText(n, x + s * 0.9, y + s * 1.05); c.textAlign = 'left'; } }],
  ['presa', '#2e6e3a', (c, x, y, s) => { c.strokeStyle = '#ffe08a'; c.lineWidth = Math.max(1, s * 0.11); c.beginPath(); c.arc(x + s / 2, y + s / 2, s * 0.26, 0, 7); c.moveTo(x + s / 2, y + s * 0.1); c.lineTo(x + s / 2, y + s * 0.34); c.moveTo(x + s / 2, y + s * 0.66); c.lineTo(x + s / 2, y + s * 0.9); c.moveTo(x + s * 0.1, y + s / 2); c.lineTo(x + s * 0.34, y + s / 2); c.moveTo(x + s * 0.66, y + s / 2); c.lineTo(x + s * 0.9, y + s / 2); c.stroke(); }],
  ['abertura', '#e8a010', (c, x, y, s) => { c.fillStyle = '#2a1a00'; c.fillRect(x + s * 0.42, y + s * 0.16, s * 0.16, s * 0.44); c.fillRect(x + s * 0.42, y + s * 0.68, s * 0.16, s * 0.16); }],
  ['gravity', '#5a2ab8', (c, x, y, s) => { c.strokeStyle = '#d8c0ff'; c.lineWidth = Math.max(1, s * 0.12); c.beginPath(); c.arc(x + s / 2, y + s / 2, s * 0.24, 0, 7); c.stroke(); }],
];
function drawStatusBadges(ctx, st, cx, by, TS, o) {
  const on = BADGES.filter(([k]) => (st[k] || 0) > 0); if (!on.length) return;
  const s = Math.max(9, Math.round(TS * 0.2)), gap = 2, w = on.length * s + (on.length - 1) * gap;
  let x = Math.round(cx - w / 2); const y = Math.round(by - s - 2);
  for (const [, bg, glyph] of on) {
    ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillRect(x - 1, y - 1, s + 2, s + 2);
    ctx.fillStyle = bg; ctx.fillRect(x, y, s, s);
    ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.fillRect(x, y, s, Math.max(1, s * 0.15));
    glyph(ctx, x, y, s, o); x += s + gap;
  }
}
// queimando: brasas e chamas pequenas subindo do corpo
function drawEmbers(ctx, X, Y, TS, t, phase, scale) {
  const cx = X + TS / 2, base = Y + TS * 0.8, hgt = TS * 0.9 * scale;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 7; i++) {
    const q = (t * 1.3 + i / 7 + phase * 0.1) % 1, sx2 = cx + Math.sin(i * 2.4 + t * 5) * TS * 0.22 * scale * (1 - q * 0.5), sy2 = base - q * hgt;
    ctx.globalAlpha = Math.sin(q * Math.PI) * 0.9; ctx.fillStyle = q < 0.4 ? '#ffe36a' : q < 0.7 ? '#ff9a3a' : '#ff4a2a';
    const z = (1 - q) * 3 + 1.5; ctx.fillRect(sx2 - z / 2, sy2 - z, z, z * 1.6);
  }
  ctx.restore();
}
function drawEntityExtras(ctx, e, X, Y, TS, t, scale, phase) {
  const isHero = e.kind === 'h';
  if (isHero) return;
  const hd = holdOf(e.o);
  const frozen = !hd && (e.o.status.freeze || 0) > 0;
  const stoned = !hd && (e.o.status.petrify || 0) > 0;
  const sleeping = e.o.asleep;
  if (frozen) drawIceShards(ctx, X, Y, TS, t, e.o.uid || 0);
  if (stoned) drawRubble(ctx, X, Y, TS, e.o.uid || 0);
  if (sleeping) { ctx.font = `700 ${Math.round(TS * 0.3)}px system-ui`; ctx.fillStyle = '#cfe7ff'; ctx.globalAlpha = 0.6 + 0.4 * Math.sin(t * 2 + phase); ctx.fillText('z', X + TS * 0.75, Y - TS * 0.05 - (t * 8 % 8)); ctx.globalAlpha = 1; }
  if (!isHero) {
    const st = hd ? {} : e.o.status;
    if (st.stun) { for (let i = 0; i < 3; i++) { const an = t * 4 + i * 2.1; ctx.fillStyle = '#ffe04a'; ctx.fillRect(X + TS / 2 + Math.cos(an) * TS * 0.25 - 2, Y - TS * 0.2 + Math.sin(an) * 4, 4, 4); } }
    if (st.poison) { ctx.fillStyle = '#b56bff'; ctx.globalAlpha = 0.7; ctx.fillRect(X + TS * 0.15, Y + TS * 0.05 + (t * 20 % 10), 3, 3); ctx.globalAlpha = 1; }
    if (st.burn && !st.petrify) drawEmbers(ctx, X, Y, TS, t, phase, scale);   // na pedra a queimadura fica pausada
    // barra de HP
    const hpNow = hd ? Math.max(e.o.hp, hd.hp) : e.o.hp;
    const showBar = hpNow < e.o.maxHp && !e.o.boss;
    drawStatusBadges(ctx, st, X + TS / 2, Y - TS * (0.32 + (e.o.boss ? 0.62 : 0)) * scale - (showBar ? 4 : -2), TS, e.o);
    // golpe anunciado: quantas ações suas faltam para cair (1 = cai antes da sua próxima ação)
    const tg = G.state.run.telegraphs.find((t) => t.from === e.o.uid);
    if (tg) {
      const n = teleTurns(tg), fs = Math.round(TS * 0.42), cy = Y - TS * (0.32 + (e.o.boss ? 0.62 : 0)) * scale - TS * 0.45;
      ctx.save(); ctx.font = `900 ${fs}px system-ui`; ctx.textAlign = 'center'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.85)';
      ctx.fillStyle = n <= 1 ? '#ff4a4a' : '#ffd23f'; ctx.globalAlpha = n <= 1 ? 0.7 + 0.3 * Math.sin(t * 12) : 1;
      ctx.strokeText(String(n), X + TS / 2, cy); ctx.fillText(String(n), X + TS / 2, cy); ctx.restore();
    }
    if (showBar) {
      const bw = TS * 0.7, bx = X + TS * 0.15, by = Y - TS * 0.32 * scale;
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.beginPath(); ctx.roundRect(bx - 1, by - 1, bw + 2, 6, 3); ctx.fill();
      const p = Math.max(0, hpNow / e.o.maxHp);
      ctx.fillStyle = p > 0.5 ? '#6ae07a' : p > 0.25 ? '#ffc23a' : '#ff4a4a';
      ctx.beginPath(); ctx.roundRect(bx, by, bw * p, 4, 2); ctx.fill();
    }
  }
}

function drawEntity(ctx, e, now, t) {
  const TS = R.TS;
  const isHero = e.kind === 'h';
  const id = isHero ? 'hero' : e.o.uid;
  const a = R.anims.get(id) || {};
  let ox = 0, oy = 0;
  if (a.lunge) {
    const q = (now - a.lunge.t0) / 180;
    if (q >= 1) a.lunge = null;
    else {
      const dx = a.lunge.tx - e.x, dy = a.lunge.ty - e.y, len = Math.hypot(dx, dy) || 1;
      const amt = Math.sin(q * Math.PI) * 0.3;
      ox = dx / len * amt; oy = dy / len * amt;
    }
  }
  { const [qx, qup] = quakeOff(a, now); ox += qx; oy -= qup * 0.6; }
  const X = sx(e.x + ox, e.y + oy), Y = sy(e.y + oy, e.x + ox);
  if (R.m3d && isHero) return;
  let spr, scale = 1, face = 1;
  if (isHero) {
    const h = G.state.hero;
    spr = heroSprite(h.cls, G.d.wtype);
    face = R.face;
  } else {
    spr = monsterSprite(e.o.type);
    scale = MONSTERS[e.o.type].sprite.scale || 1;
    face = e.x > G.state.run.px ? -1 : 1;
    // sprites LPC: mesma escala de pixel dos heróis (64 px = 1,3 casa); chefes já vêm ampliados
    if (spr.lpc) scale = spr.lpc / 64 * (1.3 / 1.35);
  }
  const size = TS * 1.35 * scale;
  const phase = isHero ? 0 : (e.o.uid % 10);
  const moving = a.move ? 1 : 0;
  const bob = Math.sin(t * (isHero ? 3 : 4) + phase) * 0.025 * TS + (moving ? -Math.abs(Math.sin(t * 25)) * TS * 0.08 : 0);
  const squash = !isHero && MONSTERS[e.o.type].sprite.shape === 'blob' ? 1 + Math.sin(t * 5 + phase) * 0.05 : 1;
  const fly = !isHero && ['bat', 'ghost'].includes(MONSTERS[e.o.type].sprite.shape) ? -TS * 0.25 + Math.sin(t * 6 + phase) * TS * 0.06 : 0;

  if (R.m3d) { drawEntityExtras(ctx, e, X, Y, TS, t, scale, phase); return; }
  // sombra
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath(); ctx.ellipse(X + TS / 2, Y + TS * 0.88, TS * 0.32 * scale, TS * 0.11 * scale, 0, 0, 7); ctx.fill();

  // oculto
  const hidden = isHero && G.state.hero.buffs.some((b) => b.id === 'oculto');
  const hd0 = !isHero && holdOf(e.o);
  const frozen = !isHero && !hd0 && (e.o.status.freeze || 0) > 0;
  const stoned = !isHero && !hd0 && (e.o.status.petrify || 0) > 0;
  const sleeping = !isHero && e.o.asleep;
  ctx.save();
  if (hidden) ctx.globalAlpha = 0.4;
  const w = size / squash, hgt = size * squash;
  const fr = isHero ? heroFrameNow(G.state.hero.cls, now) : null;
  if (fr) {
    // sprite LPC: 64px do personagem = 1.3 casa
    const k = TS * 1.3 / 64;
    ctx.translate(X + TS / 2 + (fr.dx || 0) * TS, Y + TS * 0.97 + (fr.dy || 0) * TS * R.ky - (fr.up || 0) * TS);
    if (fr.flip) ctx.scale(-1, 1);
    ctx.imageSmoothingEnabled = false;
    const dw = CELL * k;
    ctx.drawImage(fr.img, fr.sx, fr.sy, CELL, CELL, -dw / 2, -FEET * k, dw, dw);
    if (a.flash && now - a.flash < 140) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.7 * (1 - (now - a.flash) / 140);
      ctx.drawImage(fr.img, fr.sx, fr.sy, CELL, CELL, -dw / 2, -FEET * k, dw, dw);
      ctx.globalCompositeOperation = 'source-over';
    }
    ctx.restore();
    return;
  }
  ctx.translate(X + TS / 2, Y + TS * 0.95 + bob + fly);
  if (spr.pixel) { ctx.imageSmoothingEnabled = false; face = 1; }
  ctx.scale(face, 1);
  if (frozen) ctx.filter = 'grayscale(0.5) sepia(0.4) hue-rotate(165deg) saturate(2.4) brightness(1.18)';
  else if (stoned) ctx.filter = 'grayscale(1) sepia(0.35) brightness(0.82) contrast(1.1)';
  ctx.drawImage(spr, -w / 2, -hgt * 0.92, w, hgt);
  ctx.filter = 'none';
  // flash de dano
  if (a.flash && now - a.flash < 140) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.7 * (1 - (now - a.flash) / 140);
    ctx.drawImage(spr, -w / 2, -hgt * 0.92, w, hgt);
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();
  drawEntityExtras(ctx, e, X, Y, TS, t, scale, phase);
}

function drawTorch(ctx, X, Y, TS, t, th) {
  const fx = X + TS / 2, fy = Y + TS * 0.38;
  ctx.fillStyle = '#4a3020'; ctx.fillRect(fx - 2, fy, 4, TS * 0.2);
  ctx.save(); ctx.shadowColor = th.light; ctx.shadowBlur = 16;
  const f = 1 + Math.sin(t * 13 + X) * 0.15;
  ctx.fillStyle = '#ffb04a'; ctx.beginPath(); ctx.ellipse(fx, fy - 4, 5 * f, 9 * f, 0, 0, 7); ctx.fill();
  ctx.fillStyle = '#fff3c0'; ctx.beginPath(); ctx.ellipse(fx, fy - 2, 2.5, 5, 0, 0, 7); ctx.fill();
  ctx.restore();
}

function drawLiquid(ctx, X, Y, TS, t, th, x, y, deep) {
  const kind = th.liquid;
  let base, hi;
  if (deep) {
    if (kind === 'lava') { base = '#c4401a'; hi = '#ffb04a'; }
    else { ctx.fillStyle = '#05060a'; ctx.fillRect(X, Y, TS, TS); ctx.fillStyle = 'rgba(255,255,255,0.03)'; ctx.fillRect(X, Y, TS, 3); return; }
  } else if (kind === 'lodo') { base = '#3f6a3a'; hi = '#9be36a'; }
  else if (kind === 'gelo') { base = '#8ab8d8'; hi = '#ffffff'; }
  else if (kind === 'vazio') { base = '#2a1440'; hi = '#c47aff'; }
  else if (kind === 'areia') { base = '#b8955e'; hi = '#e8cd96'; }
  else if (kind === 'lava') { base = '#5a2a1a'; hi = '#ff8a4a'; }
  else { base = '#2a5a8a'; hi = '#9ad8ff'; }
  ctx.fillStyle = base; ctx.globalAlpha = deep ? 1 : 0.85; ctx.fillRect(X, Y, TS, TS); ctx.globalAlpha = 1;
  ctx.strokeStyle = hi; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.5;
  for (let i = 0; i < 2; i++) {
    const yy = Y + TS * (0.3 + i * 0.4) + Math.sin(t * 2 + x + i) * 2;
    ctx.beginPath(); ctx.moveTo(X + TS * 0.1, yy); ctx.quadraticCurveTo(X + TS * 0.5, yy - 4, X + TS * 0.9, yy); ctx.stroke();
  }
  ctx.globalAlpha = 1;
  if (deep && kind === 'lava' && Math.random() < 0.01) R.parts.push({ x: x + Math.random(), y: y + 0.5, vx: 0, vy: -1, g: 0, life: 800, t0: R.time, color: '#ffb04a', size: 3, glow: true });
}

function drawStairs(ctx, X, Y, TS, t) {
  ctx.fillStyle = '#0a0a12';
  ctx.beginPath(); ctx.roundRect(X + TS * 0.12, Y + TS * 0.12, TS * 0.76, TS * 0.76, 6); ctx.fill();
  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = `rgba(200,210,230,${0.55 - i * 0.12})`;
    ctx.fillRect(X + TS * (0.18 + i * 0.04), Y + TS * (0.2 + i * 0.16), TS * (0.64 - i * 0.08), TS * 0.07);
  }
  ctx.save(); ctx.strokeStyle = '#7ad0ff'; ctx.globalAlpha = 0.4 + 0.3 * Math.sin(t * 3); ctx.lineWidth = 2; ctx.shadowColor = '#7ad0ff'; ctx.shadowBlur = 10;
  ctx.beginPath(); ctx.roundRect(X + TS * 0.1, Y + TS * 0.1, TS * 0.8, TS * 0.8, 7); ctx.stroke(); ctx.restore();
}

function drawPortal(ctx, X, Y, TS, t) {
  ctx.save();
  ctx.translate(X + TS / 2, Y + TS / 2);
  ctx.shadowColor = '#7ad0ff'; ctx.shadowBlur = 20;
  for (let i = 0; i < 3; i++) {
    ctx.rotate(t * (1 + i * 0.5));
    ctx.strokeStyle = ['#7ad0ff', '#c9a6ff', '#ffffff'][i]; ctx.lineWidth = 3 - i;
    ctx.beginPath(); ctx.ellipse(0, 0, TS * (0.4 - i * 0.08), TS * (0.4 - i * 0.08), 0, 0, Math.PI * 1.4); ctx.stroke();
  }
  ctx.restore();
}

function drawDecor(ctx, d, X, Y, TS, h, t, th) {
  const px = X + TS * (0.25 + (h % 50) / 100), py = Y + TS * (0.3 + ((h >> 8) % 40) / 100);
  ctx.save();
  switch (d) {
    case 'grass': ctx.strokeStyle = '#7ab85a'; ctx.lineWidth = 2; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(px + i * 4, py + 8); ctx.quadraticCurveTo(px + i * 4 + Math.sin(t * 2 + i) * 2, py, px + i * 4 + 2, py - 4); ctx.stroke(); } break;
    case 'flower': ctx.fillStyle = ['#ff8ab0', '#ffe04a', '#9ad8ff'][h % 3]; for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(px + Math.cos(i * 1.256) * 3, py + Math.sin(i * 1.256) * 3, 2.2, 0, 7); ctx.fill(); } ctx.fillStyle = '#fff3c0'; ctx.beginPath(); ctx.arc(px, py, 1.6, 0, 7); ctx.fill(); break;
    case 'rock': ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(px + 4, py + 6, 7, 3, 0, 0, 7); ctx.fill(); ctx.fillStyle = shade(th.wall[0], 0.1); ctx.beginPath(); ctx.ellipse(px + 3, py + 2, 6, 5, 0, 0, 7); ctx.fill(); break;
    case 'puddle': ctx.fillStyle = 'rgba(120,200,160,0.25)'; ctx.beginPath(); ctx.ellipse(px + 4, py + 4, 10, 5, 0, 0, 7); ctx.fill(); break;
    case 'pipe': ctx.fillStyle = '#5a6a6a'; ctx.fillRect(px - 2, py, 14, 5); ctx.fillStyle = '#3a4a4a'; ctx.fillRect(px + 10, py - 1, 4, 7); break;
    case 'bones': ctx.strokeStyle = '#d8d0b8'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(px - 4, py + 4); ctx.lineTo(px + 8, py); ctx.moveTo(px, py - 2); ctx.lineTo(px + 4, py + 6); ctx.stroke(); break;
    case 'sand': ctx.strokeStyle = 'rgba(255,240,200,0.25)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(px - 6, py); ctx.quadraticCurveTo(px, py - 3, px + 8, py); ctx.stroke(); break;
    case 'skull': ctx.fillStyle = '#e8e0c8'; ctx.beginPath(); ctx.arc(px + 3, py + 2, 5, 0, 7); ctx.fill(); ctx.fillStyle = '#2a2018'; ctx.fillRect(px + 0.5, py + 1, 2, 2); ctx.fillRect(px + 3.5, py + 1, 2, 2); break;
    case 'cactus': ctx.fillStyle = '#5a9a4a'; ctx.beginPath(); ctx.roundRect(px, py - 6, 5, 14, 2); ctx.fill(); ctx.beginPath(); ctx.roundRect(px - 4, py - 2, 4, 6, 2); ctx.fill(); break;
    case 'carpet': ctx.fillStyle = 'rgba(140,30,50,0.35)'; ctx.fillRect(X + 2, Y + 2, TS - 4, TS - 4); break;
    case 'candle': ctx.fillStyle = '#e8e0d0'; ctx.fillRect(px, py, 4, 8); ctx.shadowColor = '#ffd890'; ctx.shadowBlur = 10; ctx.fillStyle = '#ffd890'; ctx.beginPath(); ctx.ellipse(px + 2, py - 3, 2, 4 + Math.sin(t * 10 + h) * 0.8, 0, 0, 7); ctx.fill(); break;
    case 'barrel': {
      const bx = X + TS * 0.3, by = Y + TS * 0.25, bw = TS * 0.4, bh = TS * 0.5;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(bx + 2, by + bh - 2, bw, 4);
      ctx.beginPath(); ctx.moveTo(bx + bw * 0.12, by); ctx.lineTo(bx + bw * 0.88, by); ctx.lineTo(bx + bw, by + bh * 0.5); ctx.lineTo(bx + bw * 0.88, by + bh); ctx.lineTo(bx + bw * 0.12, by + bh); ctx.lineTo(bx, by + bh * 0.5); ctx.closePath();
      const g = ctx.createLinearGradient(bx, 0, bx + bw, 0); g.addColorStop(0, '#b07a44'); g.addColorStop(1, '#6a4422'); ctx.fillStyle = g; ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = '#2a1a0e'; ctx.stroke();
      ctx.fillStyle = '#5a5e6a'; ctx.fillRect(bx + 1, by + bh * 0.22, bw - 2, 2.5); ctx.fillRect(bx + 1, by + bh * 0.72, bw - 2, 2.5);
      break;
    }
    case 'crate': {
      const bx = X + TS * 0.28, by = Y + TS * 0.3, bw = TS * 0.44;
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(bx + 2, by + bw - 2, bw, 4);
      const g = ctx.createLinearGradient(bx, by, bx + bw, by + bw); g.addColorStop(0, '#c4945a'); g.addColorStop(1, '#7a5230');
      ctx.fillStyle = g; ctx.fillRect(bx, by, bw, bw); ctx.lineWidth = 1.5; ctx.strokeStyle = '#2a1a0e'; ctx.strokeRect(bx, by, bw, bw);
      ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + bw, by + bw); ctx.moveTo(bx + bw, by); ctx.lineTo(bx, by + bw); ctx.strokeStyle = 'rgba(42,26,14,0.6)'; ctx.stroke();
      break;
    }
    case 'crystal': {
      const cx = X + TS * 0.5, cy = Y + TS * 0.62, c = th.accent;
      ctx.shadowColor = c; ctx.shadowBlur = 12;
      for (const [dx, hh, w] of [[-5, 16, 5], [2, 22, 6], [8, 12, 4]]) {
        ctx.beginPath(); ctx.moveTo(cx + dx - w, cy); ctx.lineTo(cx + dx, cy - hh); ctx.lineTo(cx + dx + w, cy); ctx.closePath();
        ctx.fillStyle = c; ctx.globalAlpha = 0.85; ctx.fill(); ctx.globalAlpha = 1; ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.stroke();
      }
      break;
    }
    case 'ember': ctx.shadowColor = '#ff7a2a'; ctx.shadowBlur = 8; ctx.fillStyle = '#ff7a2a'; ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 3 + h); ctx.fillRect(px, py, 3, 3); ctx.fillRect(px + 6, py + 4, 2, 2); break;
  }
  ctx.restore();
}

function drawLighting(ctx, r, m, th, t, x0, x1, y0, y1) {
  if (!R.lc || R.lc.width !== m.w || R.lc.height !== m.h) {
    R.lc = document.createElement('canvas'); R.lc.width = m.w; R.lc.height = m.h; R.lctx = R.lc.getContext('2d');
    R.limg = R.lctx.createImageData(m.w, m.h);
  }
  const data = R.limg.data;
  const lights = m.lights.filter((l) => Math.abs(l.x - r.px) < 14 && Math.abs(l.y - r.py) < 14);
  const flick = 0.03 * Math.sin(t * 9);
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const i = y * m.w + x;
    let a;
    if (!m.seen[i]) a = 1;
    else if (!G.fov[i]) a = 0.8;
    else {
      const d = Math.hypot(x - r.px, y - r.py);
      a = 0.05 + 0.62 * Math.pow(Math.min(1, d / 7.5), 2) + flick; // névoa até 7 casas
      for (const l of lights) {
        const dl = Math.hypot(x - l.x, y - l.y), lr = l.r || 3.5;
        if (dl < lr) a -= 0.32 * (1 - dl / lr);
      }
      a = Math.max(0, Math.min(0.85, a));
    }
    data[i * 4] = 6; data[i * 4 + 1] = 5; data[i * 4 + 2] = 14; data[i * 4 + 3] = a * 255;
  }
  R.lctx.putImageData(R.limg, 0, 0);
  const TS = R.TS;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(R.lc, sx(0), sy(0), m.w * TS, m.h * TS);
  // brilhos coloridos
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (const l of lights) {
    if (!m.seen[l.y * m.w + l.x]) continue;
    const X = sx(l.x, l.y) + TS / 2, Y = sy(l.y, l.x) + TS / 2, rad = (l.r || 3.5) * TS * (1 + 0.04 * Math.sin(t * 8 + l.x));
    const g = ctx.createRadialGradient(X, Y, 0, X, Y, rad);
    g.addColorStop(0, hexA(l.color || th.light, 0.22)); g.addColorStop(1, hexA(l.color || th.light, 0));
    ctx.fillStyle = g; ctx.fillRect(X - rad, Y - rad, rad * 2, rad * 2);
  }
  const hp = renderPos('hero', r.px, r.py, R.time);
  const X = sx(hp.x, hp.y) + TS / 2, Y = sy(hp.y, hp.x) + TS / 2, rad = TS * 4;
  const g = ctx.createRadialGradient(X, Y, 0, X, Y, rad);
  g.addColorStop(0, hexA(th.light, 0.10)); g.addColorStop(1, hexA(th.light, 0));
  ctx.fillStyle = g; ctx.fillRect(X - rad, Y - rad, rad * 2, rad * 2);
  ctx.restore();
}

function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

export function setTargeting(t) { R.targeting = t; }
export function setMarker(x, y) { R.marker = { x, y, t0: R.time }; }

// ---------------- Folhas de efeitos das habilidades (tools/fx) ----------------
// cada quadro tem 128x84 px; o herói fica em (hx, 74) e o alvo em (tx, 74). Desenhadas na escala do herói (64 px = 1,3 casa).
const FXIMG = new Map();
function fxSheet(id) {
  let im = FXIMG.get(id);
  if (!im) { im = new Image(); im.src = `assets/fx/${id}.png`; FXIMG.set(id, im); note(`folha nova ${id}`); }
  return im.complete && im.naturalWidth ? im : null;
}
const FX_MS = 60, FX_W = 128, FX_H = 84, FX_FY = 74;
// quantas cópias extras cada magia em área espalha; e quais também ganham a camada antiga cobrindo a área (neve caindo)
const AOE_SPOTS = { ofensiva_furiosa: 0, olhar_medusa: 0, meteoro: 6, nevasca: 5, ira_thor: 4, chuva_flechas: 0, campo_gravitacional: 0 };
const AOE_OVERLAY = { nevasca: true, olhar_medusa: true };
// efeitos que ficam pequenos demais no tamanho original (parte do alvo ampliada)
const FX_SCALE = { ofensiva_furiosa: 1.6, olhar_medusa: 2.1, ira_thor: 1.25, nevasca: 1.2, vortice_jupiter: 1.6 };
// posição dos pés de quem está na casa (x, y) na tela
function footAt(x, y) {
  const TS = R.TS;
  if (!R.m3d) return [sx(x, y) + TS / 2, sy(y, x) + TS * 0.97];
  if (persp()) { const p = R.r3.project(x + 0.5, y + 0.78); return p; }
  return [sx(x, y) + TS / 2, sy(y, x) + TS / 2 + 0.28 * TS * R.ky];
}
function drawFxPart(ctx, im, fr, x0, x1, ax, fx_, fy_, mirror, sc = 1) {
  const k = R.TS * 1.3 / 64 * sc;
  ctx.save(); ctx.translate(fx_, fy_); ctx.scale(mirror ? -k : k, k); ctx.imageSmoothingEnabled = false;
  ctx.drawImage(im, fr * FX_W + x0, 0, x1 - x0, FX_H, x0 - ax, -FX_FY, x1 - x0, FX_H);
  ctx.restore();
}
// projétil desenhado pelo jogo entre a mão do herói e o alvo (ex.: a bola de raios do Trovão de Júpiter)
function drawTravelOrb(ctx, e, M, now, r, hp) {
  const im = fxSheet(e.id === 'vortice_jupiter' ? 'jupiter_orb' : e.id + '_orb'); if (!im) return;
  const ms = M.ms || FX_MS, f = (now - e.t0) / ms, [a, b] = M.travel;
  if (f < a || f >= b) return;
  const isHero = e.fx === r.px && e.fy === r.py;
  const P = isHero ? footAt(hp.x, hp.y) : footAt(e.fx, e.fy), Q = footAt(e.tx, e.ty);
  const k = R.TS * 1.3 / 64 * (FX_SCALE[e.id] || 1), S = im.height, n = Math.floor(im.width / S);
  const dir = Q[0] >= P[0] ? 1 : -1;
  const sx = P[0] + dir * 16 * k, sy = P[1] - 30 * k, ex = Q[0], ey = Q[1] - 24 * k;
  ctx.save(); ctx.imageSmoothingEnabled = false;
  for (let g = 2; g >= 0; g--) {   // rastro: duas cópias apagadas atrás
    const p = Math.max(0, (f - a - g * 0.35) / (b - a)); if (p <= 0 && g) continue;
    const x = sx + (ex - sx) * p + Math.sin(now / 37 + g) * 2 * k, y = sy + (ey - sy) * p + Math.cos(now / 29 + g) * 2 * k - Math.sin(p * Math.PI) * 10 * k;
    ctx.globalAlpha = g ? 0.35 / g : 1;
    const fr = (Math.floor(now / 45) + g * 3) % n;
    ctx.drawImage(im, fr * S, 0, S, S, x - S * k / 2, y - S * k / 2, S * k, S * k);
  }
  ctx.restore();
}
// buffs criados sem passar pela habilidade (ex.: Zen acende as esferas)
const BUFF_FX = { esferas: 'esferas_espirituais', clones: 'clones_sombra', fusao: 'fusao_estelar', lua: 'lua_crescente', veneno_arma: 'envenenar_arma', postura: 'postura_taekwon' };
function drawSkillSheets(ctx, now, r, hp) {
  R.sfx = R.sfx.filter((e) => { const M = FX_META[e.id]; return now - e.t0 < M.n * (M.ms || FX_MS) + (e.spots ? e.spots[e.spots.length - 1]?.d || 0 : 0); });
  for (const e of R.sfx) {
    const M = FX_META[e.id], im = fxSheet(e.id); if (!im) continue;
    // cópias espalhadas pela área: só a parte do alvo, cada uma começando um pouco depois
    if (e.spots) for (const sp of e.spots) {
      const f2 = Math.floor((now - e.t0 - sp.d) / (M.ms || FX_MS)); if (f2 < 0 || f2 >= M.n) continue;
      const S = footAt(sp.x, sp.y), mid = Math.round((M.hx + M.tx) / 2);
      drawFxPart(ctx, im, f2, mid, FX_W, M.tx, S[0], S[1], (sp.x + sp.y) % 2 === 1, FX_SCALE[e.id] || 1);
    }
    const fr = Math.min(M.n - 1, Math.floor((now - e.t0) / (M.ms || FX_MS)));
    if (now - e.t0 >= M.n * (M.ms || FX_MS)) continue;
    if (M.travel) drawTravelOrb(ctx, e, M, now, r, hp);
    const isHero = e.fx === r.px && e.fy === r.py;
    const P = isHero ? footAt(hp.x, hp.y) : footAt(e.fx, e.fy);
    const Q = footAt(e.tx, e.ty);
    const same = e.tx === e.fx && e.ty === e.fy;
    const mirror = e.mirror ?? (same ? R.face < 0 : Q[0] < P[0] - 1);
    if (M.self || same || !M.tx) {
      drawFxPart(ctx, im, fr, 0, M.half ? Math.round((M.hx + 98) / 2) : FX_W, M.hx, P[0], P[1], mirror);
    } else {   // metade do lado do herói presa nele, metade do lado do alvo presa no alvo
      const mid = Math.round((M.hx + M.tx) / 2);
      drawFxPart(ctx, im, fr, 0, mid, M.hx, P[0], P[1], mirror);
      drawFxPart(ctx, im, fr, mid, FX_W, M.tx, Q[0], Q[1], mirror, FX_SCALE[e.id] || 1);
    }
  }
  // habilidade ativa: efeito em loop no herói enquanto durar
  const seen = new Set();
  for (const b of G.state.hero.buffs) {
    const id = (b.skill || BUFF_FX[b.id] || b.id) + '_ativo';
    if (seen.has(id) || !FX_META[id]) continue; seen.add(id);
    const im = fxSheet(id); if (!im) continue;
    const M = FX_META[id], fr = Math.floor(now / 90) % M.n, P = footAt(hp.x, hp.y);
    drawFxPart(ctx, im, fr, 0, FX_W, M.hx, P[0], P[1], R.face < 0);
  }
}

// ---------------- Falcão (Caçador / Atirador de Elite) ----------------
// folha LPC Birds (águia repintada): 3 quadros x 8 linhas de 32 px; 0 voa p/ esquerda, 1 costas, 2 frente, 3 direita
function drawFalcon(ctx, now, r, hp) {
  const h = G.state.hero; if (!(h.skills && (h.skills.falcao || h.skills.ataque_falcao))) { R.falcon = []; return; }
  const im = fxSheet('falcao'); if (!im) return;
  const k = R.TS * 1.3 / 64, P = footAt(hp.x, hp.y), face = R.face < 0 ? -1 : 1;
  const home = [P[0] + face * 14 * k, P[1] - 62 * k + Math.sin(now / 260) * 3 * k];
  const bird = (row, col, x, y) => { ctx.save(); ctx.imageSmoothingEnabled = false; ctx.drawImage(im, col * 32, row * 32, 32, 32, x - 16 * k, y - 16 * k, 32 * k, 32 * k); ctx.restore(); };
  R.falcon = R.falcon.filter((e) => now - e.t0 < 900);
  const att = R.falcon[0];
  if (!att) { bird(face > 0 ? 3 : 0, Math.floor(now / 110) % 3, home[0], home[1]); return; }
  const q = (now - att.t0) / 900, Q = footAt(att.tx, att.ty), tgt = [Q[0] - Math.sign(Q[0] - home[0] || 1) * 10 * k, Q[1] - 34 * k];
  const right = tgt[0] >= home[0];
  let x, y, row;
  if (q < 0.45) { const u = q / 0.45; x = home[0] + (tgt[0] - home[0]) * u; y = home[1] + (tgt[1] - home[1]) * u - Math.sin(u * Math.PI) * 22 * k; row = right ? 3 : 0; }
  else if (q < 0.6) { x = tgt[0]; y = tgt[1] + (q - 0.45) * 20 * k; row = right ? 3 : 0; }
  else { const u = (q - 0.6) / 0.4; x = tgt[0] + (home[0] - tgt[0]) * u; y = tgt[1] + (home[1] - tgt[1]) * u - Math.sin(u * Math.PI) * 26 * k; row = right ? 0 : 3; }
  bird(row, Math.floor(now / 70) % 3, x, y);
  if (q > 0.45 && q < 0.75) {   // garras
    const a = 1 - (q - 0.45) / 0.3; ctx.save(); ctx.globalAlpha = a; ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1.5, 2 * k); ctx.shadowColor = '#ffd68a'; ctx.shadowBlur = 8;
    for (let i = 0; i < 3; i++) { const x0 = Q[0] - 12 * k + i * 7 * k, y0 = Q[1] - 40 * k; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + 11 * k, y0 + 20 * k); ctx.stroke(); }
    ctx.restore();
  }
}

// ---------------- Efeitos visuais das habilidades ----------------
// cada efeito desenha em coordenadas de tela; (x, y) de tile -> centro da casa
const cx = (sx, x, y) => sx(x, y) + R.TS / 2, cy = (sy, y, x) => sy(y, x) + R.TS / 2;
const lerp = (a, b, q) => a + (b - a) * q;
function glow(ctx, color, blur) { ctx.shadowColor = color; ctx.shadowBlur = blur; }
// raio em zigue-zague entre dois pontos de tela
function zigzag(ctx, x1, y1, x2, y2, seg, amp, color, width) {
  ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(x1, y1);
  for (let i = 1; i < seg; i++) { const q = i / seg; ctx.lineTo(lerp(x1, x2, q) + (Math.random() - 0.5) * amp, lerp(y1, y2, q) + (Math.random() - 0.5) * amp * 0.4); }
  ctx.lineTo(x2, y2); ctx.stroke();
}
function sparks(x, y, color, n, speed = 2.5, life = 500, size = 2.5) {
  for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, v = (0.4 + Math.random()) * speed; R.parts.push({ x: x + 0.5, y: y + 0.5, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 0.5, g: 2, life, t0: R.time, color, size, glow: true }); }
}
function areaTiles(v) { const out = []; const a = v.aoe || 0; for (let y = -a; y <= a; y++) for (let x = -a; x <= a; x++) out.push([v.tx + x, v.ty + y]); return out; }
// projétil desenhado (lança de fogo, de gelo, orbe elétrico...)

const VFX = {
  // Relâmpago: um raio cai do céu sobre o alvo
  relampago: { dur: 380, noProj: true,
    start: (v) => { setTimeout(() => sparks(v.tx, v.ty, '#d8fff0', 14, 3, 450), 60); R.shake = Math.max(R.shake, 3); },
    draw(ctx, v, q, now, sx, sy) {
      const X = cx(sx, v.tx, v.ty), Y = cy(sy, v.ty, v.tx);
      ctx.globalAlpha = q < 0.6 ? 1 : (1 - q) / 0.4; glow(ctx, '#9cf2ff', 22);
      zigzag(ctx, X + 10, Y - R.TS * 6, X, Y, 9, R.TS * 0.9, '#ffffff', 4);
      zigzag(ctx, X + 10, Y - R.TS * 6, X, Y, 9, R.TS * 1.2, '#7ae8ff', 2);
      if (q < 0.25) { ctx.globalAlpha = 0.35 * (1 - q * 4); ctx.fillStyle = '#e8fbff'; ctx.fillRect(sx(v.tx - 6), sy(v.ty - 6), R.TS * 13, R.TS * 13); }
    } },
  // Trovão de Júpiter: uma esfera elétrica enorme voa crepitando e explode em descargas
  vortice_jupiter: { dur: 720, noProj: true,
    draw(ctx, v, q, now, sx, sy) {
      const fly = 0.55, k = Math.min(1, q / fly);
      const X = lerp(cx(sx, v.fx, v.fy), cx(sx, v.tx, v.ty), k), Y = lerp(cy(sy, v.fy, v.fx), cy(sy, v.ty, v.tx), k) - R.TS * 0.2;
      if (q < fly) {
        const rad = R.TS * (0.46 + 0.06 * Math.sin(now / 30));
        glow(ctx, '#7ae8ff', 26);
        const g = ctx.createRadialGradient(X, Y, 1, X, Y, rad); g.addColorStop(0, '#ffffff'); g.addColorStop(0.5, '#9cf2ff'); g.addColorStop(1, 'rgba(60,120,255,0.2)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X, Y, rad, 0, 7); ctx.fill();
        for (let i = 0; i < 4; i++) { const a = Math.random() * 6.28; zigzag(ctx, X, Y, X + Math.cos(a) * rad * 1.9, Y + Math.sin(a) * rad * 1.9, 4, 8, '#e8fbff', 1.5); }
        if (Math.random() < 0.6) R.parts.push({ x: 0, y: 0, sx: X, sy: Y, screen: true, vx: 0, vy: 0, g: 0, life: 220, t0: now, color: '#9cf2ff', size: 5, glow: true });
      } else {
        const p = (q - fly) / (1 - fly);
        if (!v.boom) { v.boom = 1; sparks(v.tx, v.ty, '#d8fff0', 26, 4, 600); for (const [ax, ay] of areaTiles(v)) if (Math.random() < 0.6) sparks(ax, ay, '#bff6ff', 5, 2, 450); R.shake = Math.max(R.shake, 7); }
        ctx.globalAlpha = 1 - p; glow(ctx, '#7ae8ff', 24);
        const reach = 1 + (v.aoe || 0) * 0.9; for (let i = 0; i < 10; i++) { const a = i / 10 * 6.28 + p; zigzag(ctx, X, Y, X + Math.cos(a) * R.TS * (0.8 + p * 1.3) * reach, Y + Math.sin(a) * R.TS * (0.5 + p) * reach, 6, 12, i % 2 ? '#ffffff' : '#7ae8ff', 2.5); }
        ctx.fillStyle = 'rgba(200,250,255,0.5)'; ctx.beginPath(); ctx.arc(X, Y, R.TS * (0.4 + p * 0.8), 0, 7); ctx.fill();
      }
    } },
  get ira_thor() { return this.vortice_jupiter; },
  // Lança de Fogo: uma lança de chamas com rastro de brasas
  lanca_fogo: { dur: 420, noProj: true,
    draw(ctx, v, q, now, sx, sy) { spear(ctx, v, q, now, sx, sy, ['#fff2a0', '#ff8a3a', '#c4301a'], '#ff7a2a', () => sparks(v.tx, v.ty, '#ff9a3a', 18, 3, 500, 3)); } },
  // Lança de Gelo: um cristal pontudo de gelo com névoa
  lanca_gelo: { dur: 420, noProj: true,
    draw(ctx, v, q, now, sx, sy) { spear(ctx, v, q, now, sx, sy, ['#ffffff', '#bfe8ff', '#4a9ad8'], '#bfe8ff', () => sparks(v.tx, v.ty, '#dff4ff', 16, 2.5, 550, 3), true); } },
  // Congelar: espinhos de gelo brotam do chão em volta
  congelar: { dur: 700,
    draw(ctx, v, q, now, sx, sy) {
      const up = Math.min(1, q * 3), fade = q > 0.7 ? (1 - q) / 0.3 : 1;
      ctx.globalAlpha = fade; glow(ctx, '#bfe8ff', 12);
      for (const [x, y] of areaTiles(v)) {
        const h = ((x * 7 + y * 13) & 7) / 7, X = cx(sx, x, y) + (h - 0.5) * R.TS * 0.4, Y = cy(sy, y, x) + R.TS * 0.3;
        for (let k = -1; k <= 1; k++) { const H = R.TS * (0.35 + h * 0.3 + (k ? 0 : 0.2)) * up; ctx.fillStyle = k ? '#9ad8ff' : '#e8f8ff'; ctx.beginPath(); ctx.moveTo(X + k * 7 - 5, Y); ctx.lineTo(X + k * 7, Y - H); ctx.lineTo(X + k * 7 + 5, Y); ctx.fill(); }
      }
    } },
  // Chuva de Meteoros: rochas em chamas caem uma a uma sobre a área
  meteoro: { dur: 1000,
    start(v) { v.rocks = areaTiles(v).filter(() => Math.random() < 0.45).slice(0, 7).map((t, i) => ({ x: t[0], y: t[1], at: 0.08 + i * 0.1 })); if (!v.rocks.length) v.rocks = [{ x: v.tx, y: v.ty, at: 0.1 }]; },
    draw(ctx, v, q, now, sx, sy) {
      for (const rk of v.rocks) {
        const p = (q - rk.at) / 0.28; if (p < 0) continue;
        const X = cx(sx, rk.x, rk.y), Y = cy(sy, rk.y, rk.x);
        if (p < 1) {
          const mx = X + R.TS * 3 * (1 - p), my = Y - R.TS * 7 * (1 - p);
          glow(ctx, '#ff7a2a', 20); ctx.strokeStyle = 'rgba(255,140,50,0.55)'; ctx.lineWidth = R.TS * 0.22; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(mx + R.TS * 0.9, my - R.TS * 2); ctx.lineTo(mx, my); ctx.stroke();
          ctx.fillStyle = '#5a2a14'; ctx.beginPath(); ctx.arc(mx, my, R.TS * 0.2, 0, 7); ctx.fill();
          ctx.fillStyle = '#ffcf6a'; ctx.beginPath(); ctx.arc(mx - 2, my - 2, R.TS * 0.1, 0, 7); ctx.fill();
        } else if (!rk.hit) { rk.hit = 1; sparks(rk.x, rk.y, '#ff8a3a', 16, 3.5, 600, 3.5); sparks(rk.x, rk.y, '#5a3a2a', 6, 2, 500, 3); R.shake = Math.max(R.shake, 5); }
        else if (p < 2) { ctx.globalAlpha = 2 - p; glow(ctx, '#ff7a2a', 20); ctx.fillStyle = '#ffb36b'; ctx.beginPath(); ctx.ellipse(X, Y + R.TS * 0.25, R.TS * 0.6 * (p - 0.5), R.TS * 0.3 * (p - 0.5), 0, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
      }
    } },
  // Nevasca: uma tempestade de gelo e neve gira sobre a área
  nevasca: { dur: 1000,
    draw(ctx, v, q, now, sx, sy) {
      const X = cx(sx, v.tx, v.ty), Y = cy(sy, v.ty, v.tx), a = (v.aoe + 0.5) * R.TS;
      ctx.globalAlpha = Math.min(1, q * 4, (1 - q) * 3) * 0.13; ctx.fillStyle = '#cfeaff'; ctx.beginPath(); ctx.ellipse(X, Y + R.TS * 0.2, a, a * 0.7, 0, 0, 7); ctx.fill();
      ctx.globalAlpha = Math.min(1, (1 - q) * 3); glow(ctx, '#ffffff', 8);
      for (let i = 0; i < 40; i++) {
        const s = (i * 97) % 100 / 100, ang = s * 6.28 + now / 300, rr = a * ((i * 37) % 100 / 100);
        const fall = ((q * 3 + s) % 1);
        const px = X + Math.cos(ang) * rr, py = Y + Math.sin(ang) * rr * 0.7 - R.TS * 2 * (1 - fall);
        ctx.fillStyle = i % 3 ? '#ffffff' : '#9ad8ff';
        if (i % 4 === 0) { ctx.beginPath(); ctx.moveTo(px, py - 7); ctx.lineTo(px + 3, py); ctx.lineTo(px, py + 7); ctx.lineTo(px - 3, py); ctx.fill(); }
        else ctx.fillRect(px - 1.5, py - 1.5, 3, 3);
      }
    } },
  // Olhar da Medusa: névoa esmeralda, serpentes surgem na borda e encaram o centro; no olhar, a área inteira vira pedra
  olhar_medusa: { dur: 1020,
    draw(ctx, v, q, now, sx, sy) {
      const X = cx(sx, v.tx, v.ty), Y = cy(sy, v.ty, v.tx) + R.TS * 0.2, a = (v.aoe + 0.5) * R.TS, HIT = 0.5;
      const out = Math.min(1, (1 - q) * 4);
      // névoa verde que se fecha para o centro antes do olhar
      if (q < HIT + 0.08) { ctx.globalAlpha = Math.min(1, q * 5) * 0.16 * out; ctx.fillStyle = '#5fd27a'; ctx.beginPath(); ctx.ellipse(X, Y, a, a * 0.62, 0, 0, 7); ctx.fill();
        ctx.globalAlpha = Math.min(1, q * 5) * 0.55; ctx.strokeStyle = '#8be68f'; ctx.lineWidth = 2; ctx.setLineDash([6, 6]); ctx.lineDashOffset = -now / 40;
        ctx.beginPath(); ctx.ellipse(X, Y, a * (1 - q * 0.5), a * 0.62 * (1 - q * 0.5), 0, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
      // serpentes: sobem da borda, ondulam e se inclinam para o centro; viram pedra no olhar
      const N = 7, stone = q >= HIT;
      for (let k = 0; k < N; k++) {
        const ang = k / N * 6.283 + 0.4, bx = X + Math.cos(ang) * a * 0.92, by = Y + Math.sin(ang) * a * 0.57;
        const rise = Math.min(1, Math.max(0, (q - 0.08 - k * 0.025) / 0.25)); if (rise <= 0) continue;
        const crum = stone ? Math.max(0, (q - 0.8) / 0.2) : 0;
        ctx.globalAlpha = out * (1 - crum);
        const L = R.TS * 0.95 * rise, dirx = (X - bx) / a, wig = stone ? 0 : now / 110 + k;
        const pts = []; for (let t = 0; t <= 1.001; t += 0.1) { const lean = t * t * 0.45; pts.push([bx + Math.sin(t * 5 + wig) * 4 * (1 - t * 0.3) + dirx * lean * L, by - t * L + crum * t * 10]); }
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.strokeStyle = stone ? '#5a544a' : '#1f5a32'; ctx.lineWidth = 7; ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke();
        ctx.strokeStyle = stone ? '#a8a08c' : '#4fb860'; ctx.lineWidth = 4; ctx.stroke();
        ctx.strokeStyle = stone ? '#d8d0bc' : '#b7f08a'; ctx.lineWidth = 1.5; ctx.setLineDash([2, 4]); ctx.stroke(); ctx.setLineDash([]);
        const [hx, hy] = pts[pts.length - 1];
        ctx.fillStyle = stone ? '#a8a08c' : '#3e9a50'; ctx.beginPath(); ctx.ellipse(hx + dirx * 3, hy, 5, 3.6, 0, 0, 7); ctx.fill();
        ctx.fillStyle = stone ? '#6a6458' : '#ffe14a'; ctx.fillRect(hx + dirx * 4 - 1, hy - 2, 2, 2);
        if (!stone && Math.floor(now / 120 + k) % 3 === 0) { ctx.strokeStyle = '#ff4d6a'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(hx + dirx * 8, hy + 1); ctx.lineTo(hx + dirx * 13, hy + 1); ctx.stroke(); }
      }
      // o chão vira pedra: onda cinza a partir do centro com rachaduras e brilho na borda
      if (stone) {
        const u = Math.min(1, (q - HIT) / 0.18), fade = Math.min(1, (1 - q) * 3.5);
        ctx.globalAlpha = 0.34 * fade; ctx.fillStyle = '#8c8574'; ctx.beginPath(); ctx.ellipse(X, Y, a * u, a * 0.62 * u, 0, 0, 7); ctx.fill();
        ctx.globalAlpha = 0.9 * fade * (1 - u * 0.5); ctx.strokeStyle = '#efe8d2'; ctx.lineWidth = 2.5; glow(ctx, '#d8f0a0', 10);
        ctx.beginPath(); ctx.ellipse(X, Y, a * u, a * 0.62 * u, 0, 0, 7); ctx.stroke(); glow(ctx, 'transparent', 0);
        ctx.globalAlpha = 0.75 * fade; ctx.strokeStyle = '#3e3a32'; ctx.lineWidth = 1.5;
        for (let k = 0; k < 9; k++) { let ang = k * 0.7 + 0.3, x = X, y = Y; ctx.beginPath(); ctx.moveTo(x, y);
          for (let st = 0; st < 6; st++) { ang += Math.sin(k * 7 + st * 3) * 0.4; const r = a * u / 6; x += Math.cos(ang) * r; y += Math.sin(ang) * r * 0.62; ctx.lineTo(x, y); } ctx.stroke(); }
        for (let k = 0; k < 18; k++) { const s = (k * 53) % 100 / 100, ang = k * 2.4, rr = a * u * s, rise = ((q - HIT) * 2 + s) % 1;
          ctx.globalAlpha = 0.6 * fade * (1 - rise); ctx.fillStyle = k % 2 ? '#c8c0aa' : '#8c8574';
          ctx.fillRect(X + Math.cos(ang) * rr, Y + Math.sin(ang) * rr * 0.62 - rise * R.TS * 0.8, 3, 3); }
      }
    } },
  // Campo Gravitacional: um vórtice roxo que puxa tudo para o centro
  campo_gravitacional: { dur: 1100,
    draw(ctx, v, q, now, sx, sy) {
      const X = cx(sx, v.tx, v.ty), Y = cy(sy, v.ty, v.tx) + R.TS * 0.2, a = (v.aoe + 0.5) * R.TS;
      ctx.globalAlpha = Math.min(1, q * 4, (1 - q) * 2); glow(ctx, '#a37bff', 18);
      for (let k = 0; k < 3; k++) { ctx.strokeStyle = k === 1 ? '#e0c8ff' : '#7a4ae8'; ctx.lineWidth = 3; ctx.beginPath();
        for (let t2 = 0; t2 < 1; t2 += 0.02) { const ang = t2 * 12 + k * 2.09 - now / 200, rr = a * (1 - t2); ctx.lineTo(X + Math.cos(ang) * rr, Y + Math.sin(ang) * rr * 0.6); } ctx.stroke(); }
      ctx.fillStyle = '#1a0a30'; ctx.beginPath(); ctx.ellipse(X, Y, R.TS * 0.25, R.TS * 0.15, 0, 0, 7); ctx.fill();
    } },
  // Chuva de Flechas: flechas despencam do céu sobre a área
  chuva_flechas: { dur: 650,
    draw(ctx, v, q, now, sx, sy) {
      ctx.strokeStyle = '#f0e2b6'; ctx.fillStyle = '#d8d8e0'; ctx.lineWidth = 2;
      areaTiles(v).forEach(([x, y], i) => { for (let k = 0; k < 2; k++) {
        const p = Math.min(1, Math.max(0, (q - ((i * 3 + k * 5) % 9) / 30) * 2.2)); if (p <= 0) continue;
        const X = cx(sx, x, y) + (k ? 8 : -6), Y = cy(sy, y, x) + R.TS * 0.2 - R.TS * 4 * (1 - p);
        ctx.globalAlpha = p >= 1 ? Math.max(0, 1 - (q - 0.6) * 3) : 1;
        ctx.beginPath(); ctx.moveTo(X + 6, Y - R.TS * 0.7); ctx.lineTo(X, Y); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(X - 3, Y - 4); ctx.lineTo(X, Y + 3); ctx.lineTo(X + 3, Y - 4); ctx.fill(); } });
    } },
  // Tiro Preciso / Virote Perfurante: um disparo que atravessa a fileira
  tiro_preciso: { dur: 380, noProj: true, draw: beam('#fff2c0', '#ffd86b') },
  tiro_certeiro: { dur: 340, noProj: true, draw: beam('#f0e2b6', '#c8a060') },
  // Luz Divina: um pilar de luz dourada desce sobre o alvo
  luz_divina: { dur: 600, noProj: true, draw: pillar('#fff2b0', '#ffd86b') },
  // Kunai Sangrenta: um risco vermelho que atravessa a fileira
  kunai_sangrenta: { dur: 360, noProj: true, draw: beam('#ffb0b8', '#c0101e') },
  // Pulsar Sangue: o sangue pulsa no herói e estoura num anel vermelho com gotas voando (3×3)
  pulsar_sangue: { dur: 650, start: (v) => { sparks(v.fx, v.fy, '#c0101e', 22, 3.2, 650, 3.2); R.shake = Math.max(R.shake, 5); },
    draw(ctx, v, q, now, sx, sy) {
      const X = cx(sx, v.fx, v.fy), Y = cy(sy, v.fy, v.fx) + R.TS * 0.2, T = R.TS;
      ctx.save();
      // pulso: encolhe e estoura
      const pr = q < 0.25 ? T * (0.45 - q * 1.2) : T * (0.15 + (q - 0.25) * 2.2);
      ctx.globalAlpha = q < 0.25 ? 0.9 : Math.max(0, 1 - (q - 0.25) / 0.75);
      ctx.strokeStyle = '#ff2a3a'; ctx.lineWidth = Math.max(2, T * 0.12 * (1 - q)); glow(ctx, '#ff1a2a', 10);
      ctx.beginPath(); ctx.ellipse(X, Y, pr, pr * 0.6, 0, 0, 7); ctx.stroke();
      if (q < 0.3) { ctx.fillStyle = 'rgba(160,10,24,0.6)'; ctx.beginPath(); ctx.ellipse(X, Y, pr * 0.8, pr * 0.48, 0, 0, 7); ctx.fill(); }
      // gotas voando para fora
      if (q > 0.2) { const k = (q - 0.2) / 0.8; ctx.fillStyle = '#b0101e';
        for (let i = 0; i < 14; i++) { const an = i / 14 * 6.283 + (i % 3) * 0.2, rr = T * (0.3 + k * (1.1 + (i % 4) * 0.12)), hh = Math.sin(k * Math.PI) * T * (0.35 + (i % 3) * 0.1);
          const s2 = Math.max(1.5, T * 0.07 * (1 - k * 0.6)); ctx.beginPath(); ctx.arc(X + Math.cos(an) * rr, Y + Math.sin(an) * rr * 0.6 - hh, s2, 0, 7); ctx.fill(); } }
      ctx.restore();
    } },
  furia_solar: { dur: 700, draw(ctx, v, q, now, sx, sy) { flames(ctx, { ...v, tx: v.fx, ty: v.fy }, q, now, sx, sy, ['#fff8c0', '#ffcf4a', '#ff7a2a']); } },
  // Redemoinho de Lâminas / Chute Giratório: arcos de corte girando
  redemoinho: { dur: 450, draw: spin('#e8eef8') },
  chute_giratorio: { dur: 400, draw: spin('#ffe8a0') },
  chuva_shuriken: { dur: 600, draw(ctx, v, q, now, sx, sy) {
    const X = cx(sx, v.fx, v.fy), Y = cy(sy, v.fy, v.fx); ctx.fillStyle = '#c8d0e0'; glow(ctx, '#ffffff', 6);
    for (let i = 0; i < 10; i++) { const a = i / 10 * 6.28 + q * 3, rr = R.TS * 2.5 * q; star4(ctx, X + Math.cos(a) * rr, Y + Math.sin(a) * rr * 0.7, 6, now / 40 + i); } } },
  // Destruidor de Almas / Garra Sombria
  destruidor_almas: { dur: 420, noProj: true, draw: beam('#e0b0ff', '#8a3aff') },
  garra_sombria: { dur: 500, draw(ctx, v, q, now, sx, sy) { claws(ctx, v, q, sx, sy, '#a37bff'); } },
  asura: { dur: 600, start: (v) => { sparks(v.tx, v.ty, '#ffd86b', 40, 5, 800, 4); R.shake = Math.max(R.shake, 12); },
    draw(ctx, v, q, now, sx, sy) { const X = cx(sx, v.tx, v.ty), Y = cy(sy, v.ty, v.tx); ctx.globalAlpha = 1 - q; glow(ctx, '#ffd86b', 30); ctx.fillStyle = 'rgba(255,230,140,0.8)'; ctx.beginPath(); ctx.arc(X, Y, R.TS * (0.3 + q * 2.2), 0, 7); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(X, Y, R.TS * (0.5 + q * 3), 0, 7); ctx.stroke(); } },
};
function spear(ctx, v, q, now, sx, sy, cols, trail, onHit, ice) {
  const k = Math.min(1, q / 0.75);
  const x1 = cx(sx, v.fx, v.fy), y1 = cy(sy, v.fy, v.fx) - R.TS * 0.2, x2 = cx(sx, v.tx, v.ty), y2 = cy(sy, v.ty, v.tx) - R.TS * 0.2;
  const X = lerp(x1, x2, k), Y = lerp(y1, y2, k), a = Math.atan2(y2 - y1, x2 - x1);
  if (k < 1) {
    ctx.translate(X, Y); ctx.rotate(a); glow(ctx, trail, 16);
    const L = R.TS * 0.75;
    const g = ctx.createLinearGradient(-L, 0, L * 0.3, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, cols[2]); g.addColorStop(1, cols[1]);
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-L, -3); ctx.lineTo(L * 0.25, -6); ctx.lineTo(L * 0.5, 0); ctx.lineTo(L * 0.25, 6); ctx.lineTo(-L, 3); ctx.fill();
    ctx.fillStyle = cols[0]; ctx.beginPath(); ctx.moveTo(-L * 0.3, -2); ctx.lineTo(L * 0.42, 0); ctx.lineTo(-L * 0.3, 2); ctx.fill();
    if (Math.random() < 0.8) R.parts.push({ x: 0, y: 0, sx: X - Math.cos(a) * L * 0.6 + (Math.random() - 0.5) * 6, sy: Y - Math.sin(a) * L * 0.6 + (Math.random() - 0.5) * 6, screen: true, vx: 0, vy: 0, g: 0, life: ice ? 380 : 260, t0: now, color: trail, size: ice ? 2.5 : 4, glow: true });
  } else if (!v.hit) { v.hit = 1; onHit(); }
}
function beam(core, edge) {
  return (ctx, v, q, now, sx, sy) => {
    const x1 = cx(sx, v.fx, v.fy), y1 = cy(sy, v.fy, v.fx) - R.TS * 0.2;
    let x2 = cx(sx, v.tx, v.ty), y2 = cy(sy, v.ty, v.tx) - R.TS * 0.2;
    if (v.line) { const d = Math.hypot(x2 - x1, y2 - y1) || 1; x2 = x1 + (x2 - x1) / d * R.TS * (v.range || 6); y2 = y1 + (y2 - y1) / d * R.TS * (v.range || 6); }
    const k = Math.min(1, q * 3);
    ctx.globalAlpha = q < 0.5 ? 1 : (1 - q) * 2; glow(ctx, edge, 18); ctx.lineCap = 'round';
    ctx.strokeStyle = edge; ctx.lineWidth = 7 * (1 - q * 0.6); ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(lerp(x1, x2, k), lerp(y1, y2, k)); ctx.stroke();
    ctx.strokeStyle = core; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(lerp(x1, x2, k), lerp(y1, y2, k)); ctx.stroke();
  };
}
function pillar(core, edge, wmul = 1) {
  return (ctx, v, q, now, sx, sy) => {
    const X = cx(sx, v.tx, v.ty), Y = cy(sy, v.ty, v.tx) + R.TS * 0.3, w = R.TS * 0.45 * wmul * (q < 0.2 ? q * 5 : 1);
    ctx.globalAlpha = q < 0.7 ? 0.9 : (1 - q) * 3; glow(ctx, edge, 26);
    const g = ctx.createLinearGradient(X - w, 0, X + w, 0); g.addColorStop(0, 'rgba(255,230,140,0)'); g.addColorStop(0.5, core); g.addColorStop(1, 'rgba(255,230,140,0)');
    ctx.fillStyle = g; ctx.fillRect(X - w, Y - R.TS * 6, w * 2, R.TS * 6);
    ctx.fillStyle = edge; ctx.beginPath(); ctx.ellipse(X, Y, w * 1.4, w * 0.5, 0, 0, 7); ctx.fill();
    if (Math.random() < 0.5) R.parts.push({ x: v.tx + 0.3 + Math.random() * 0.4, y: v.ty + 0.8, vx: 0, vy: -2, g: 0, life: 600, t0: now, color: core, size: 2.5, glow: true });
  };
}
function flames(ctx, v, q, now, sx, sy, cols) {
  glow(ctx, cols[1], 14);
  for (const [x, y] of areaTiles(v)) {
    const X = cx(sx, x, y), Y = cy(sy, y, x) + R.TS * 0.35, h = R.TS * (0.5 + 0.4 * Math.sin(now / 60 + x * 3 + y)) * (q < 0.2 ? q * 5 : 1 - (q - 0.2) / 0.8);
    for (let k = 0; k < 3; k++) { ctx.fillStyle = cols[k]; const w = R.TS * (0.32 - k * 0.08), hh = h * (1 - k * 0.25); ctx.beginPath(); ctx.moveTo(X - w, Y); ctx.quadraticCurveTo(X - w * 0.6, Y - hh * 0.6, X, Y - hh); ctx.quadraticCurveTo(X + w * 0.6, Y - hh * 0.6, X + w, Y); ctx.fill(); }
  }
}
function spin(color) {
  return (ctx, v, q, now, sx, sy) => {
    const X = cx(sx, v.fx, v.fy), Y = cy(sy, v.fy, v.fx) + R.TS * 0.1, a = ((v.aoe || 1) + 0.4) * R.TS;
    ctx.globalAlpha = 1 - q; glow(ctx, color, 14); ctx.strokeStyle = color; ctx.lineCap = 'round';
    for (let k = 0; k < 3; k++) { const st = q * 10 + k * 2.09; ctx.lineWidth = 5 - k; ctx.beginPath(); ctx.ellipse(X, Y, a * (0.6 + 0.4 * q), a * 0.55 * (0.6 + 0.4 * q), 0, st, st + 1.4); ctx.stroke(); }
  };
}
function star4(ctx, x, y, r, rot) { ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.beginPath(); for (let i = 0; i < 8; i++) { const rr = i % 2 ? r * 0.35 : r; ctx.lineTo(Math.cos(i * 0.785) * rr, Math.sin(i * 0.785) * rr); } ctx.fill(); ctx.restore(); }
function claws(ctx, v, q, sx, sy, color) {
  ctx.globalAlpha = 1 - q; glow(ctx, color, 16); ctx.strokeStyle = color; ctx.lineWidth = 4; ctx.lineCap = 'round';
  for (const [x, y] of areaTiles(v)) { const X = cx(sx, x, y), Y = cy(sy, y, x); const k = Math.min(1, q * 3); for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(X - R.TS * 0.35 + i * 8, Y - R.TS * 0.35); ctx.lineTo(lerp(X - R.TS * 0.35, X + R.TS * 0.35, k) + i * 8, lerp(Y - R.TS * 0.35, Y + R.TS * 0.35, k)); ctx.stroke(); } }
}
