// Heróis com sprites LPC (folhas geradas por tools/lpc/export.py)
// Linhas: 0-3 andar, 4-7 ataque, 8-11 magia. Direções: 0 costas, 1 esquerda, 2 frente, 3 direita.
import { HERO_META } from './hero_meta.js';
import { artCls } from './data.js';

export const CELL = 192;       // tamanho da célula na folha
export const FEET = 126;       // y dos pés dentro da célula
const ROW0 = { walk: 0, atk: 4, cast: 8 };
const sheets = new Map();
const portraits = new Map();

function loadImg(src) {
  return new Promise((ok) => {
    const im = new Image();
    im.onload = () => ok(im);
    im.onerror = () => ok(null);
    im.src = src;
  });
}

export function heroSheet(cls) {
  cls = artCls(cls);
  let s = sheets.get(cls);
  if (!s) {
    s = { img: null };
    sheets.set(cls, s);
    loadImg(`assets/heroes/${cls}.png`).then((im) => { s.img = im; });
  }
  return s.img;
}

// retratos (frente, parado), ampliados sem borrar
export async function preloadPortraits() {
  await Promise.all(Object.keys(HERO_META).map(async (cls) => {
    const im = await loadImg(`assets/heroes/${cls}_p.png`);
    if (!im) return;
    const c = document.createElement('canvas');
    c.width = c.height = im.width * 2;
    const x = c.getContext('2d');
    x.imageSmoothingEnabled = false;
    x.drawImage(im, 0, 0, c.width, c.height);
    portraits.set(cls, c);
  }));
}
export const heroPortrait = (cls) => portraits.get(artCls(cls)) || null;

export function frameCount(cls, anim) { return (HERO_META[artCls(cls)] || {})[anim] || 1; }

// devolve recorte {img, sx, sy} ou null se a folha ainda não carregou
export function heroFrame(cls, anim, dir, col) {
  const img = heroSheet(cls);
  if (!img) return null;
  const n = frameCount(cls, anim);
  return { img, sx: (Math.max(0, col) % n) * CELL, sy: (ROW0[anim] + dir) * CELL };
}
