// Atualização automática do jogo.
// - Conteúdo (código, arte, balanceamento): baixado ao abrir o app e aplicado sem reinstalar.
// - App Android em si: quando exigir APK novo, mostra um aviso com botão para baixar.
import { WEB_VERSION } from './version.js';
import { nativePlugin } from './capbridge.js';

const BASE = 'https://raw.githubusercontent.com/rafaelcvalladao99-collab/AnotheRO-versoes/main/';
export const APK_URL = 'https://github.com/rafaelcvalladao99-collab/AnotheRO-versoes/raw/main/AnotheRO.apk';

// plugins nativos via ponte do app (antes usava registerPlugin, que não existe sem o @capacitor/core:
// por isso o atualizador nunca rodava)
const plugin = (name) => nativePlugin(name);

export function updLog(msg) {
  try {
    const l = JSON.parse(localStorage.getItem('upd_log') || '[]');
    const t = new Date();
    l.push(`${String(t.getDate()).padStart(2, '0')}/${String(t.getMonth() + 1).padStart(2, '0')} ${t.toTimeString().slice(0, 8)} ${msg}`);
    localStorage.setItem('upd_log', JSON.stringify(l.slice(-40)));
  } catch (_) {}
}

// chamado logo ao abrir: confirma que esta versão funcionou (senão o atualizador volta para a anterior)
export async function appReady() {
  const Updater = plugin('CapacitorUpdater');
  if (!Updater) return;
  try { await Updater.notifyAppReady(); updLog(`abriu versão ${WEB_VERSION}`); } catch (e) { updLog('notifyAppReady falhou: ' + (e?.message || e)); }
}

export async function checkForUpdates({ canRestartNow, onStatus, onApkNeeded, manual }) {
  const Updater = plugin('CapacitorUpdater');
  if (!Updater) { if (manual) onStatus && onStatus('Atualização só funciona no app instalado.'); return; }
  await appReady();

  let info;
  try {
    const res = await fetch(BASE + 'version.json?t=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) { updLog('version.json HTTP ' + res.status); if (manual) onStatus && onStatus('Servidor respondeu ' + res.status); return; }
    info = await res.json();
  } catch (e) { updLog('sem acesso ao version.json: ' + (e?.message || e)); if (manual) onStatus && onStatus('Sem internet?'); return; } // sem internet: joga a versão atual
  updLog(`servidor tem ${info.web}, aqui ${WEB_VERSION}`);

  // App Android desatualizado demais para o conteúdo novo
  try {
    const App = plugin('App');
    const appInfo = App ? await App.getInfo() : null;
    const build = appInfo ? parseInt(appInfo.build, 10) : 0;
    if (info.minApk && build && build < info.minApk) { onApkNeeded && onApkNeeded(info); return; }
  } catch (_) {}

  if (!info.web || Number(info.web) <= Number(WEB_VERSION)) { if (manual) onStatus && onStatus('Já está na versão mais nova.'); return; }
  try {
    // se já baixou antes (ex.: app fechado no meio), reaproveita em vez de baixar de novo;
    // um download que falhou antes fica registrado com a mesma versão e trava os próximos: apaga
    let bundle = null;
    try {
      const l = await Updater.list();
      for (const b of l.bundles || []) {
        if (!String(b.version).startsWith(String(info.web))) continue;
        if (b.status === 'error' || b.status === 'downloading') { try { await Updater.delete({ id: b.id }); updLog('apagou download quebrado ' + b.id); } catch (_) {} }
        else if (!bundle) bundle = b;
      }
    } catch (_) {}
    if (!bundle) {
      // tenta mais de um endereço: o raw do GitHub às vezes falha no celular
      const repo = 'rafaelcvalladao99-collab/AnotheRO-versoes';
      const urls = [BASE + info.webUrl, `https://cdn.jsdelivr.net/gh/${repo}@main/${info.webUrl}`, `https://github.com/${repo}/raw/main/${info.webUrl}`];
      const errs = [];
      for (let i = 0; i < urls.length && !bundle; i++) {
        onStatus && onStatus(i ? `Baixando atualização (tentativa ${i + 1})...` : 'Baixando atualização...');
        updLog('baixando ' + urls[i]);
        try {
          bundle = await Updater.download({ url: urls[i], version: i ? `${info.web}.${i}` : String(info.web), checksum: info.checksum || '' });
          updLog('baixou: id ' + bundle?.id + ' status ' + bundle?.status);
        } catch (e) { const m = e?.message || e?.errorMessage || JSON.stringify(e); errs.push(m); updLog('falhou: ' + m); bundle = null; }
      }
      if (!bundle) throw new Error(errs.join(' | '));
    } else updLog('reaproveitando download: id ' + bundle.id);
    // o jogo salva a cada passo: dá para recarregar na hora, mesmo dentro da masmorra
    onStatus && onStatus('Atualizando...');
    canRestartNow && canRestartNow();
    updLog('aplicando ' + bundle.id);
    await Updater.set({ id: bundle.id });
  } catch (e) {
    const msg = e?.message || e?.errorMessage || JSON.stringify(e);
    updLog('ERRO: ' + msg);
    onStatus && onStatus('Falha na atualização: ' + msg);
  }
}
