// Efeitos sonoros sintetizados (sem arquivos de áudio)
let ac = null;
let enabled = true;
let lastPlay = {};

function ctx() {
  if (!ac) {
    const A = window.AudioContext || window.webkitAudioContext;
    if (!A) return null;
    ac = new A();
  }
  if (ac.state === 'suspended') ac.resume();
  return ac;
}

function tone({ f = 440, f2 = null, d = 0.12, type = 'square', v = 0.08, delay = 0, noise = false }) {
  const a = ctx();
  if (!a) return;
  const t = a.currentTime + delay;
  const g = a.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(v, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  g.connect(a.destination);
  if (noise) {
    const len = Math.floor(a.sampleRate * d);
    const buf = a.createBuffer(1, len, a.sampleRate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = a.createBufferSource();
    src.buffer = buf;
    const flt = a.createBiquadFilter();
    flt.type = 'lowpass'; flt.frequency.value = f;
    src.connect(flt); flt.connect(g);
    src.start(t); src.stop(t + d);
    return;
  }
  const o = a.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(f, t);
  if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
  o.connect(g);
  o.start(t); o.stop(t + d + 0.02);
}

const SFX = {
  hit: () => tone({ f: 900, d: 0.08, noise: true, v: 0.12 }),
  crit: () => { tone({ f: 1800, d: 0.12, noise: true, v: 0.16 }); tone({ f: 880, f2: 1320, d: 0.1, type: 'triangle', v: 0.06 }); },
  miss: () => tone({ f: 500, f2: 300, d: 0.08, type: 'sine', v: 0.04 }),
  hurt: () => tone({ f: 220, f2: 110, d: 0.14, type: 'sawtooth', v: 0.06 }),
  kill: () => { tone({ f: 660, f2: 990, d: 0.1, type: 'triangle', v: 0.06 }); tone({ f: 600, d: 0.15, noise: true, v: 0.06, delay: 0.02 }); },
  bossdie: () => { for (let i = 0; i < 5; i++) tone({ f: 300 + i * 120, f2: 600 + i * 150, d: 0.25, type: 'triangle', v: 0.07, delay: i * 0.09 }); tone({ f: 300, d: 0.8, noise: true, v: 0.15 }); },
  levelup: () => [523, 659, 784, 1047].forEach((f, i) => tone({ f, d: 0.18, type: 'triangle', v: 0.08, delay: i * 0.08 })),
  pickup: () => tone({ f: 880, f2: 1320, d: 0.07, type: 'triangle', v: 0.05 }),
  coin: () => { tone({ f: 1400, d: 0.05, type: 'square', v: 0.04 }); tone({ f: 1900, d: 0.12, type: 'square', v: 0.04, delay: 0.05 }); },
  card: () => [784, 988, 1175, 1568].forEach((f, i) => tone({ f, d: 0.22, type: 'sine', v: 0.07, delay: i * 0.07 })),
  potion: () => tone({ f: 400, f2: 900, d: 0.18, type: 'sine', v: 0.06 }),
  equip: () => tone({ f: 300, d: 0.09, noise: true, v: 0.07 }),
  skill: () => tone({ f: 300, f2: 700, d: 0.14, type: 'sawtooth', v: 0.05 }),
  magic: () => { tone({ f: 600, f2: 1400, d: 0.22, type: 'sine', v: 0.06 }); tone({ f: 900, f2: 1800, d: 0.22, type: 'triangle', v: 0.03, delay: 0.03 }); },
  stairs: () => [392, 330, 262].forEach((f, i) => tone({ f, d: 0.14, type: 'triangle', v: 0.06, delay: i * 0.09 })),
  death: () => [392, 330, 262, 196].forEach((f, i) => tone({ f, d: 0.35, type: 'triangle', v: 0.08, delay: i * 0.22 })),
  warn: () => { tone({ f: 200, d: 0.2, type: 'square', v: 0.05 }); tone({ f: 200, d: 0.2, type: 'square', v: 0.05, delay: 0.25 }); },
  boom: () => tone({ f: 400, d: 0.4, noise: true, v: 0.18 }),
  refineok: () => [660, 880, 1320].forEach((f, i) => tone({ f, d: 0.2, type: 'triangle', v: 0.08, delay: i * 0.1 })),
  refinefail: () => { tone({ f: 2000, d: 0.3, noise: true, v: 0.15 }); tone({ f: 300, f2: 80, d: 0.5, type: 'sawtooth', v: 0.06, delay: 0.05 }); },
  click: () => tone({ f: 1200, d: 0.03, type: 'sine', v: 0.03 }),
};

export const Audio = {
  play(name) {
    if (!enabled || !SFX[name]) return;
    const now = performance.now();
    if (lastPlay[name] && now - lastPlay[name] < 40) return;
    lastPlay[name] = now;
    try { SFX[name](); } catch (_) {}
  },
  setEnabled(v) { enabled = v; },
  unlock() { ctx(); },
};
