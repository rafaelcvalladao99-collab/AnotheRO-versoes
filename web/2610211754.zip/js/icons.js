// Ícones vetoriais da interface (traço de latão, preenchimento suave)
const wrap = (body, vb = 24) => `<svg viewBox="0 0 ${vb} ${vb}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;

export const ICON = {
  bag: wrap('<path d="M8 7V5.5a4 4 0 0 1 8 0V7"/><path d="M4.5 8.5h15l-1.3 11.2a1.5 1.5 0 0 1-1.5 1.3H7.3a1.5 1.5 0 0 1-1.5-1.3z" fill="currentColor" fill-opacity=".15"/><path d="M9 12h6"/>'),
  hero: wrap('<path d="M14.5 4.5l5 0 0 5-9 9-5-5z" fill="currentColor" fill-opacity=".15"/><path d="M8 13l3 3"/><path d="M6.5 15.5l-3 3 2 2 3-3"/>'),
  explore: wrap('<circle cx="12" cy="12" r="8.5"/><path d="M15.5 8.5l-2 5-5 2 2-5z" fill="currentColor" fill-opacity=".35"/><circle cx="12" cy="12" r=".6" fill="currentColor"/>'),
  wait: wrap('<path d="M7 3.5h10M7 20.5h10"/><path d="M8 3.5c0 5 8 5 8 8.5s-8 3.5-8 8.5"/><path d="M16 3.5c0 5-8 5-8 8.5s8 3.5 8 8.5"/><path d="M10 18.5h4" stroke-width="2.4"/>'),
  menu: wrap('<path d="M5 7h14M5 12h14M5 17h14"/>'),
  stairs: wrap('<path d="M4 20h4v-4h4v-4h4V8h4"/><path d="M14 4l3 3 3-3"/>'),
  portal: wrap('<path d="M12 21c-4.4 0-7-3.6-7-8.5S8 3 12 3s7 4.6 7 9.5-2.6 8.5-7 8.5z"/><path d="M12 17c-2 0-3.2-1.8-3.2-4.2S10 8 12 8s3.2 2.4 3.2 4.8S14 17 12 17z" fill="currentColor" fill-opacity=".3"/>'),
  gate: wrap('<path d="M4 21V9a8 8 0 0 1 16 0v12"/><path d="M8 21v-9a4 4 0 0 1 8 0v9" fill="currentColor" fill-opacity=".25"/><path d="M2.5 21h19"/>'),
  potion: wrap('<path d="M10 3h4M10.5 3v4.5L6 15a4.8 4.8 0 0 0 4.2 6h3.6a4.8 4.8 0 0 0 4.2-6l-4.5-7.5V3"/><path d="M7.5 15h9" /><path d="M7 16.5c1.5 3 8.5 3 10 0" fill="currentColor" fill-opacity=".35"/>'),
  anvil: wrap('<path d="M3 8h13a5 5 0 0 1-5 5H9"/><path d="M16 8h5l-2 3h-3"/><path d="M8 13l-1 4h8l-1-4" fill="currentColor" fill-opacity=".2"/><path d="M5 20h12"/>'),
  chest: wrap('<rect x="3.5" y="9" width="17" height="11" rx="1.5" fill="currentColor" fill-opacity=".15"/><path d="M3.5 9a5 5 0 0 1 5-5h7a5 5 0 0 1 5 5"/><path d="M3.5 13h17"/><rect x="10.5" y="11.5" width="3" height="3.5" rx=".6"/>'),
  scroll: wrap('<path d="M7 4h11a2 2 0 0 1 0 4h-1v10a2 2 0 0 1-2 2H6a2 2 0 0 1 0-4h1z" fill="currentColor" fill-opacity=".12"/><path d="M7 16V4"/><path d="M10 9h4M10 12h4"/>'),
  temple: wrap('<path d="M12 2.5l8.5 5H3.5z" fill="currentColor" fill-opacity=".2"/><path d="M5 9.5v8M9.5 9.5v8M14.5 9.5v8M19 9.5v8"/><path d="M3 20.5h18M4 18h16"/>'),
  gear: wrap('<circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.6M12 18.6v2.6M21.2 12h-2.6M5.4 12H2.8M18.5 5.5l-1.8 1.8M7.3 16.7l-1.8 1.8M18.5 18.5l-1.8-1.8M7.3 7.3L5.5 5.5"/><circle cx="12" cy="12" r="6.2"/>'),
  coin: wrap('<circle cx="12" cy="12" r="8" fill="currentColor" fill-opacity=".25"/><circle cx="12" cy="12" r="5"/><path d="M12 9.5v5"/>'),
  target: wrap('<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2.2" fill="currentColor"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3"/>'),
  close: wrap('<path d="M6 6l12 12M18 6L6 18"/>'),
  plus: wrap('<path d="M12 5v14M5 12h14"/>'),
  skull: wrap('<path d="M12 3a7.5 7.5 0 0 0-4.5 13.5V20h9v-3.5A7.5 7.5 0 0 0 12 3z" fill="currentColor" fill-opacity=".15"/><circle cx="9.3" cy="11" r="1.6"/><circle cx="14.7" cy="11" r="1.6"/><path d="M10.5 20v-2M13.5 20v-2"/>'),
};
