// Arte procedural das classes — cada uma com silhueta própria.
// Todas olham para a direita (3/4). Sistema de coordenadas: 96x96, pés em y≈88.

const OUT = 'rgba(20,12,28,0.95)';

export function shadeC(hex, amt) {
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map((x) => x + x).join('');
  const n = parseInt(c, 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (amt >= 0) { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; }
  else { r *= 1 + amt; g *= 1 + amt; b *= 1 + amt; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}

// ---- Estilo "chibi mobile anguloso": facetas retas, preenchimento suave,
// contorno colorido e luz de borda azulada ----
function toRGB(c) {
  if (typeof c !== 'string') return null;
  if (c[0] === '#') { let h = c.slice(1); if (h.length === 3) h = h.split('').map((x) => x + x).join(''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  const m = c.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
  return m ? [+m[1], +m[2], +m[3]] : null;
}
const rgbStr = ([r, g, b]) => `rgb(${r | 0},${g | 0},${b | 0})`;
function tone(rgb, a) { return rgbStr(rgb.map((v) => (a >= 0 ? v + (255 - v) * a : v * (1 + a)))); }

function buildPath(ctx, pts, close) {
  // curvas viram polilinhas retas (facetas)
  const out = [[pts[0][0], pts[0][1]]];
  let cx = pts[0][0], cy = pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    const p = pts[i];
    if (p.length === 4) {
      const t = 0.5, x = (1 - t) * (1 - t) * cx + 2 * (1 - t) * t * p[0] + t * t * p[2], y = (1 - t) * (1 - t) * cy + 2 * (1 - t) * t * p[1] + t * t * p[3];
      out.push([x, y], [p[2], p[3]]); cx = p[2]; cy = p[3];
    } else if (p.length === 6) {
      for (const t of [0.34, 0.67]) {
        const u = 1 - t;
        out.push([u * u * u * cx + 3 * u * u * t * p[0] + 3 * u * t * t * p[2] + t * t * t * p[4], u * u * u * cy + 3 * u * u * t * p[1] + 3 * u * t * t * p[3] + t * t * t * p[5]]);
      }
      out.push([p[4], p[5]]); cx = p[4]; cy = p[5];
    } else { out.push([p[0], p[1]]); cx = p[0]; cy = p[1]; }
  }
  return out;
}

function paint(ctx, poly, fill, stroke, lw, close = true) {
  const trace = (dx = 0, dy = 0) => { ctx.beginPath(); ctx.moveTo(poly[0][0] + dx, poly[0][1] + dy); for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0] + dx, poly[i][1] + dy); if (close) ctx.closePath(); };
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const [x, y] of poly) { if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; }
  const w = x1 - x0, h = y1 - y0;
  const rgb = toRGB(fill);
  ctx.save();
  ctx.lineJoin = 'miter'; ctx.miterLimit = 2.5;
  if (fill) {
    trace();
    if (rgb) {
      const g = ctx.createLinearGradient(x0, y0, x0 + w * 0.65, y1);
      g.addColorStop(0, tone(rgb, 0.26)); g.addColorStop(0.48, rgbStr(rgb)); g.addColorStop(1, tone(rgb, -0.34));
      ctx.fillStyle = g;
    } else ctx.fillStyle = fill;
    ctx.fill();
    if ((rgb || typeof fill !== 'string') && w > 5 && h > 5) {
      ctx.save(); trace(); ctx.clip();
      trace(-1.3, 1.1); ctx.lineWidth = 1.8; ctx.strokeStyle = 'rgba(175,215,255,0.42)'; ctx.stroke();
      ctx.restore();
    }
  }
  if (stroke) {
    trace();
    ctx.lineWidth = stroke === OUT ? lw * 0.8 : lw;
    ctx.strokeStyle = stroke === OUT ? (rgb ? tone(rgb, -0.66) : '#1a1228') : stroke;
    ctx.stroke();
  }
  ctx.restore();
}

function P(ctx, pts, fill, stroke = OUT, lw = 2.4, close = true) {
  paint(ctx, buildPath(ctx, pts, close), fill, stroke, lw, close);
}
function E(ctx, x, y, rx, ry, fill, stroke = OUT, lw = 2.4) {
  rx = Math.max(0.3, rx); ry = Math.max(0.3, ry);
  const n = Math.max(rx, ry) > 6 ? 8 : 6;
  const poly = [];
  for (let i = 0; i < n; i++) { const a = -Math.PI / 2 + (i + 0.5) * 2 * Math.PI / n; poly.push([x + Math.cos(a) * rx, y + Math.sin(a) * ry]); }
  paint(ctx, poly, fill, stroke, lw);
}
function L(ctx, x0, y0, x1, y1, color, w, outline = true) {
  ctx.lineCap = 'butt';
  ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1);
  if (outline) { const rgb = toRGB(color); ctx.lineWidth = w + 2.2; ctx.strokeStyle = rgb ? tone(rgb, -0.66) : OUT; ctx.stroke(); }
  ctx.lineWidth = w; ctx.strokeStyle = color; ctx.stroke();
}
function V(ctx, y0, y1, stops) {
  const g = ctx.createLinearGradient(0, y0, 0, y1);
  stops.forEach((c, i) => g.addColorStop(i / (stops.length - 1), c));
  return g;
}
function glow(ctx, color, blur, fn) { ctx.save(); ctx.shadowColor = color; ctx.shadowBlur = blur; fn(); ctx.restore(); }

// ---------------- Partes do corpo ----------------
const CX = 46;          // centro do corpo
const FOOT = 88;
const HY = 36;          // centro da cabeça
const HR = 17;          // raio da cabeça

function legs(ctx, pants, boots, wide = false) {
  const w = wide ? 9 : 7.5;
  P(ctx, [[CX - 9, 64], [CX - 9 - (wide ? 1 : 0), 82], [CX - 9 + w, 82], [CX - 1, 64]], pants);
  P(ctx, [[CX + 1, 64], [CX + 2, 82], [CX + 2 + w, 82], [CX + 9, 64]], shadeC(pants, -0.15));
  // botas
  P(ctx, [[CX - 11, 79], [CX - 11, 87], [CX - 1, 87], [CX - 1, 79]], boots, OUT, 2.2);
  P(ctx, [[CX + 1, 79], [CX + 1, 87], [CX + 12, 87], [CX + 11, 79]], shadeC(boots, -0.1), OUT, 2.2);
  E(ctx, CX - 6, 81, 3, 1, 'rgba(255,255,255,0.18)', null);
}

function torso(ctx, c1, c2, opts = {}) {
  const top = 50, bot = opts.long ? 84 : 68;
  const flare = opts.long ? 14 : opts.skirt ? 13 : 11;
  P(ctx, [[CX - 10, top], [CX - flare, bot], [CX + flare, bot], [CX + 11, top], [CX, top - 2, CX - 10, top]], V(ctx, top, bot, [shadeC(c1, 0.18), c1, shadeC(c1, -0.3)]));
  if (opts.belt) P(ctx, [[CX - 11.5, 62], [CX + 12, 62], [CX + 12, 66], [CX - 12, 66]], opts.belt, OUT, 1.8);
  if (c2) { // gola / acabamento
    P(ctx, [[CX - 8, top], [CX, top + 7], [CX + 8, top], [CX, top + 3]], c2, OUT, 1.8);
  }
}

function arm(ctx, side, sleeve, hand = '#ffd9b8', glove = null) {
  // side: -1 trás (esquerda), 1 frente (direita)
  const x = side < 0 ? CX - 13 : CX + 13;
  const hx = side < 0 ? CX - 15 : CX + 17, hy = 64;
  P(ctx, [[x - 4, 51], [x + 4, 51], [hx + 3, hy - 4], [hx - 3, hy - 4]], side < 0 ? shadeC(sleeve, -0.2) : sleeve, OUT, 2.2);
  E(ctx, hx, hy, 4, 4, glove || hand, OUT, 2);
}

function headBase(ctx, skin = '#ffdcbc') {
  // cabeça chibi com maxilar e queixo em ângulo
  P(ctx, [[CX - HR, HY - 4], [CX - HR * 0.72, HY - HR + 1], [CX + HR * 0.15, HY - HR - 1], [CX + HR * 0.92, HY - HR * 0.7], [CX + HR * 1.05, HY + 1],
    [CX + HR * 0.8, HY + HR * 0.62], [CX + HR * 0.3, HY + HR * 0.98], [CX - HR * 0.25, HY + HR * 0.95], [CX - HR * 0.8, HY + HR * 0.55]], skin);
  // orelha
  P(ctx, [[CX - 10.5, HY], [CX - 7, HY - 1], [CX - 6.5, HY + 6], [CX - 10, HY + 6.5]], skin, OUT, 2);
}

function face(ctx, iris = '#3a6ad8', mood = 'neutral', mask = false) {
  const ex = CX + 5, ey = HY + 3;
  if (mask) return;
  const irisRGB = toRGB(iris) || [58, 106, 216];
  // olhos simétricos: topo reto, cantos externos levemente afinados
  for (const [dx, w, sg] of [[-5.2, 0.82, -1], [5, 1, 1]]) {
    const x = ex + dx;
    const eye = () => { ctx.beginPath(); ctx.moveTo(x - sg * 3.0 * w, ey - 3.6); ctx.lineTo(x + sg * 3.4 * w, ey - 3.6); ctx.lineTo(x + sg * 3.0 * w, ey + 3.4); ctx.lineTo(x - sg * 2.6 * w, ey + 3.7); ctx.closePath(); };
    ctx.save();
    eye(); ctx.fillStyle = '#fbfaff'; ctx.fill(); ctx.clip();
    const g = ctx.createLinearGradient(0, ey - 3, 0, ey + 3);
    g.addColorStop(0, tone(irisRGB, -0.6)); g.addColorStop(0.55, rgbStr(irisRGB)); g.addColorStop(1, tone(irisRGB, 0.55));
    ctx.fillStyle = g; ctx.fillRect(x - 1.9 * w + 0.6, ey - 3.6, 3.8 * w, 7.4);
    ctx.fillStyle = '#0c0a1c'; ctx.fillRect(x - 0.7 * w + 0.6, ey - 1.8, 1.5 * w, 3.8);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(x - 1.4 * w + 0.6, ey - 2.8, 1.5, 1.5);
    ctx.restore();
    // pálpebra superior reta
    ctx.beginPath(); ctx.moveTo(x - sg * 3.4 * w, ey - 3.6); ctx.lineTo(x + sg * 3.9 * w, ey - 3.8);
    ctx.lineWidth = 1.9; ctx.strokeStyle = '#160c1c'; ctx.stroke();
  }
  // sobrancelhas
  ctx.lineWidth = 1.6; ctx.strokeStyle = '#1c1220'; ctx.lineCap = 'butt';
  ctx.beginPath();
  if (mood === 'fierce') { ctx.moveTo(ex - 9, ey - 6.6); ctx.lineTo(ex - 2.5, ey - 5); ctx.moveTo(ex + 1.5, ey - 5); ctx.lineTo(ex + 9, ey - 6.8); }
  else if (mood === 'calm') { ctx.moveTo(ex - 9, ey - 6.8); ctx.lineTo(ex - 3, ey - 7.2); ctx.moveTo(ex + 1.5, ey - 7.2); ctx.lineTo(ex + 8.5, ey - 6.8); }
  else { ctx.moveTo(ex - 9, ey - 6.4); ctx.lineTo(ex - 3, ey - 6.6); ctx.moveTo(ex + 1.5, ey - 6.6); ctx.lineTo(ex + 8.5, ey - 6.4); }
  ctx.stroke();
  // nariz e boca retos
  ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(140,70,60,0.6)';
  ctx.beginPath(); ctx.moveTo(ex + 6.5, ey + 3.4); ctx.lineTo(ex + 7.4, ey + 5.4); ctx.stroke();
  ctx.lineWidth = 1.5; ctx.strokeStyle = '#5a2a2a';
  ctx.beginPath();
  if (mood === 'grin') { ctx.moveTo(ex - 0.5, ey + 7.6); ctx.lineTo(ex + 2.5, ey + 8.6); ctx.lineTo(ex + 5, ey + 7.2); }
  else { ctx.moveTo(ex + 0.5, ey + 8.4); ctx.lineTo(ex + 4.5, ey + 7.9); }
  ctx.stroke();
}

const HAIR = {
  messy(ctx, c) {
    P(ctx, [[CX - 17, HY + 4], [CX - 19, HY - 8, CX - 8, HY - 19], [CX - 2, HY - 24], [CX + 2, HY - 18], [CX + 8, HY - 22], [CX + 10, HY - 16], [CX + 18, HY - 15], [CX + 15, HY - 7], [CX + 19, HY - 3], [CX + 9, HY - 6], [CX + 4, HY - 11], [CX - 2, HY - 6], [CX - 7, HY - 9], [CX - 9, HY], [CX - 13, HY + 8]], V(ctx, HY - 24, HY + 8, [shadeC(c, 0.25), c, shadeC(c, -0.3)]));
  },
  spiky(ctx, c) {
    P(ctx, [[CX - 16, HY + 6], [CX - 24, HY - 6], [CX - 14, HY - 10], [CX - 16, HY - 22], [CX - 5, HY - 16], [CX - 1, HY - 28], [CX + 5, HY - 17], [CX + 15, HY - 22], [CX + 13, HY - 11], [CX + 22, HY - 8], [CX + 12, HY - 5], [CX + 6, HY - 10], [CX, HY - 5], [CX - 6, HY - 9], [CX - 10, HY + 1]], V(ctx, HY - 28, HY + 6, [shadeC(c, 0.3), c, shadeC(c, -0.3)]));
  },
  long(ctx, c, back = false) {
    if (back) { P(ctx, [[CX - 15, HY - 6], [CX - 22, HY + 22], [CX - 12, HY + 30], [CX - 4, HY + 22], [CX + 2, HY + 4]], shadeC(c, -0.2)); return; }
    P(ctx, [[CX - 17, HY + 10], [CX - 20, HY - 10, CX - 4, HY - 21], [CX + 10, HY - 21, CX + 18, HY - 8], [CX + 14, HY - 6], [CX + 6, HY - 13, CX - 4, HY - 9], [CX - 8, HY - 2], [CX - 10, HY + 14]], V(ctx, HY - 21, HY + 14, [shadeC(c, 0.3), c, shadeC(c, -0.25)]));
  },
  ponytail(ctx, c, back = false) {
    if (back) { P(ctx, [[CX - 12, HY - 10], [CX - 26, HY - 2, CX - 28, HY + 14], [CX - 22, HY + 10], [CX - 20, HY + 2, CX - 10, HY - 2]], shadeC(c, -0.1)); return; }
    P(ctx, [[CX - 16, HY + 2], [CX - 18, HY - 12, CX - 4, HY - 20], [CX + 10, HY - 21, CX + 18, HY - 7], [CX + 11, HY - 9], [CX + 3, HY - 6], [CX - 2, HY - 11], [CX - 8, HY - 5], [CX - 12, HY + 4]], V(ctx, HY - 21, HY + 4, [shadeC(c, 0.3), c, shadeC(c, -0.25)]));
  },
  bob(ctx, c) {
    P(ctx, [[CX - 17, HY + 9], [CX - 21, HY - 12, CX - 2, HY - 21], [CX + 14, HY - 21, CX + 19, HY - 4], [CX + 17, HY + 2], [CX + 12, HY - 8], [CX + 4, HY - 8], [CX + 6, HY - 12], [CX - 4, HY - 6], [CX - 9, HY + 2], [CX - 12, HY + 11]], V(ctx, HY - 21, HY + 11, [shadeC(c, 0.3), c, shadeC(c, -0.25)]));
  },
  short(ctx, c) {
    P(ctx, [[CX - 16, HY + 3], [CX - 18, HY - 13, CX - 2, HY - 19], [CX + 13, HY - 19, CX + 17, HY - 6], [CX + 10, HY - 8], [CX + 2, HY - 7], [CX - 6, HY - 8], [CX - 10, HY - 1], [CX - 12, HY + 5]], V(ctx, HY - 19, HY + 5, [shadeC(c, 0.3), c, shadeC(c, -0.3)]));
  },
};

// ---------------- Equipamentos de assinatura ----------------
function capeBack(ctx, c, len = 84, flare = 20) {
  P(ctx, [[CX - 10, 48], [CX - flare - 6, len], [CX - flare + 10, len - 3], [CX - 2, len], [CX + 8, len - 4], [CX + 10, 50]], V(ctx, 48, len, [shadeC(c, -0.05), shadeC(c, -0.45)]));
}

function shieldBack(ctx, c, emblem) {
  E(ctx, CX - 15, 60, 11, 13, V(ctx, 47, 73, [shadeC(c, 0.3), c, shadeC(c, -0.35)]));
  E(ctx, CX - 15, 60, 7, 9, null, 'rgba(255,230,160,0.8)', 1.6);
  E(ctx, CX - 15, 60, 3, 3, emblem || '#ffd86b', OUT, 1.5);
}

function quiver(ctx) {
  P(ctx, [[CX - 18, 44], [CX - 10, 72], [CX - 4, 70], [CX - 12, 42]], '#8a5a2e');
  for (const [dx, col] of [[-16, '#e8e0c8'], [-13, '#ff6a5a'], [-10, '#e8e0c8']]) {
    L(ctx, CX + dx, 44, CX + dx - 2, 34, '#6a4a2a', 1.6, false);
    P(ctx, [[CX + dx - 3, 34], [CX + dx - 1, 28], [CX + dx + 1, 34]], col, OUT, 1.2);
  }
}

function backpack(ctx) {
  P(ctx, [[CX - 24, 44], [CX - 26, 74], [CX - 8, 76], [CX - 6, 46]], V(ctx, 44, 76, ['#c48a4a', '#8a5a2e']));
  P(ctx, [[CX - 25, 52], [CX - 7, 54], [CX - 7, 58], [CX - 25, 56]], '#6a3a1a', OUT, 1.6);
  E(ctx, CX - 16, 66, 4, 3, '#ffd86b', OUT, 1.5);
  // rolo de pano
  E(ctx, CX - 16, 42, 11, 4.5, '#d84a4a', OUT, 2);
}

function falcon(ctx, x, y) {
  P(ctx, [[x - 9, y + 2], [x - 2, y - 8], [x + 6, y - 6], [x + 8, y + 2], [x + 2, y + 6]], V(ctx, y - 8, y + 6, ['#c9a06a', '#7a5230']));
  P(ctx, [[x - 8, y], [x - 16, y + 4], [x - 6, y + 4]], '#5a3a20', OUT, 1.6);
  E(ctx, x + 6, y - 6, 4.5, 4, '#f0e2c0', OUT, 1.8);
  P(ctx, [[x + 9, y - 6], [x + 13, y - 4], [x + 9, y - 3]], '#ffc23a', OUT, 1.2);
  E(ctx, x + 7, y - 7, 1, 1, '#140c1c', null);
}

function book(ctx, x, y, c) {
  P(ctx, [[x - 7, y - 5], [x + 7, y - 7], [x + 7, y + 5], [x - 7, y + 7]], c, OUT, 2);
  P(ctx, [[x - 5, y - 3], [x + 5, y - 5], [x + 5, y + 3], [x - 5, y + 5]], '#f4ecd8', null);
  L(ctx, x - 1, y - 3, x - 1, y + 3, '#d4a83a', 1.5, false);
  L(ctx, x - 3, y, x + 1, y - 0.5, '#d4a83a', 1.5, false);
}

function halo(ctx, c) {
  glow(ctx, c, 14, () => { ctx.beginPath(); ctx.ellipse(CX + 1, HY - 3, 22, 22, 0, 0, Math.PI * 2); ctx.lineWidth = 2; ctx.strokeStyle = c; ctx.globalAlpha = 0.55; ctx.stroke(); });
  for (let i = 0; i < 8; i++) {
    const a = i / 8 * Math.PI * 2;
    ctx.save(); ctx.globalAlpha = 0.35; ctx.fillStyle = c;
    ctx.beginPath(); ctx.arc(CX + 1 + Math.cos(a) * 25, HY - 3 + Math.sin(a) * 25, 1.4, 0, 7); ctx.fill(); ctx.restore();
  }
}

function runeRing(ctx, c) {
  glow(ctx, c, 10, () => {
    ctx.save(); ctx.globalAlpha = 0.7; ctx.strokeStyle = c; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.ellipse(CX, 84, 26, 7, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.ellipse(CX, 84, 20, 5, 0, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  });
  for (let i = 0; i < 3; i++) glow(ctx, c, 8, () => { ctx.fillStyle = c; ctx.font = '700 8px serif'; ctx.fillText(['ᚱ', 'ᚢ', 'ᚾ'][i], CX - 26 + i * 22, 30 + (i % 2) * 18); });
}

function swordBlade(ctx, len) {
  P(ctx, [[-2.6, 0], [-2.6, -len], [0, -len - 4], [2.6, -len], [2.6, 0]], '#dfe6f2');
  P(ctx, [[-7, 0], [7, 0], [7, 3.2], [-7, 3.2]], '#d4a83a', OUT, 1.6);
  P(ctx, [[-1.6, 3.2], [1.6, 3.2], [1.6, 9], [-1.6, 9]], '#5a3a20', OUT, 1.4);
}

// ---------------- Chapéus ----------------
function wizardHat(ctx, c, trim, tall = 1, gem = null) {
  P(ctx, [[CX - 24, HY - 9], [CX - 4, HY - 16], [CX + 22, HY - 10], [CX + 4, HY - 5], [CX - 8, HY - 5]], shadeC(c, -0.1));
  P(ctx, [[CX - 12, HY - 11], [CX - 4, HY - 30 * tall], [CX + 2, HY - 42 * tall], [CX + 16, HY - 44 * tall], [CX + 8, HY - 36 * tall], [CX + 12, HY - 12]], V(ctx, HY - 44 * tall, HY - 10, [shadeC(c, 0.2), c, shadeC(c, -0.25)]));
  P(ctx, [[CX - 12, HY - 12], [CX + 12, HY - 13], [CX + 12, HY - 17], [CX - 11, HY - 16]], trim, OUT, 1.6);
  if (gem) glow(ctx, gem, 10, () => E(ctx, CX, HY - 15, 2.6, 2.6, gem, OUT, 1.2));
}

// ---------------- Classes ----------------
const ART = {
  aprendiz(ctx) {
    legs(ctx, '#6a5a48', '#5a3a24');
    arm(ctx, -1, '#c9b48a');
    torso(ctx, '#c9b48a', null, { belt: '#6a4a2a' });
    // bolsa a tiracolo
    L(ctx, CX - 9, 50, CX + 9, 66, '#7a5230', 2.2);
    E(ctx, CX + 10, 68, 5, 4, '#9a6a3a', OUT, 2);
    headBase(ctx);
    HAIR.messy(ctx, '#7a4a2a');
    // bandana
    P(ctx, [[CX - 16, HY - 6], [CX + 16, HY - 9], [CX + 16, HY - 5], [CX - 16, HY - 2]], '#d84a3a', OUT, 1.8);
    P(ctx, [[CX - 16, HY - 4], [CX - 25, HY - 1], [CX - 22, HY + 4], [CX - 15, HY - 1]], '#d84a3a', OUT, 1.6);
    face(ctx, '#4a8a3a', 'grin');
    arm(ctx, 1, '#c9b48a');
  },
  espadachim(ctx) {
    shieldBack(ctx, '#3a62b8', '#ffd86b');
    legs(ctx, '#2a3450', '#4a3a2a');
    arm(ctx, -1, '#3a62b8');
    torso(ctx, '#3a62b8', '#e8eef8', { belt: '#5a3a2a' });
    // ombreira
    P(ctx, [[CX + 4, 48], [CX + 18, 47], [CX + 20, 55], [CX + 7, 56]], V(ctx, 47, 56, ['#f0f4fa', '#9aa8bc']), OUT, 2);
    headBase(ctx);
    HAIR.spiky(ctx, '#3a3a4a');
    // faixa com pontas
    P(ctx, [[CX - 16, HY - 7], [CX + 17, HY - 9], [CX + 17, HY - 5], [CX - 16, HY - 3]], '#e8eef8', OUT, 1.6);
    P(ctx, [[CX - 15, HY - 5], [CX - 28, HY - 3], [CX - 24, HY + 1]], '#e8eef8', OUT, 1.4);
    P(ctx, [[CX - 15, HY - 4], [CX - 26, HY + 5], [CX - 20, HY + 6]], '#c9d4ea', OUT, 1.4);
    face(ctx, '#3a6ad8', 'fierce');
    arm(ctx, 1, '#3a62b8', '#ffd9b8', '#6a4a2a');
  },
  mago(ctx) {
    HAIR.long(ctx, '#b8c8ff', true);
    legs(ctx, '#3a2a5a', '#2a1a3a');
    arm(ctx, -1, '#6a3ab0');
    torso(ctx, '#6a3ab0', '#f0d080', { long: true });
    // estrelas no manto
    ctx.fillStyle = '#f0d080';
    for (const [x, y] of [[CX - 6, 72], [CX + 6, 66], [CX + 2, 78], [CX - 8, 60]]) { ctx.beginPath(); ctx.arc(x, y, 1.3, 0, 7); ctx.fill(); }
    P(ctx, [[CX - 13, 84], [CX + 13, 84], [CX + 14, 80], [CX - 13, 80]], '#f0d080', OUT, 1.6);
    headBase(ctx);
    HAIR.long(ctx, '#b8c8ff');
    face(ctx, '#9a4ae8', 'calm');
    wizardHat(ctx, '#5a2aa0', '#f0d080', 0.85, '#7affe8');
    // broche de lua
    glow(ctx, '#fff3a0', 8, () => { ctx.beginPath(); ctx.arc(CX + 8, HY - 26, 3.5, 0.6, 5.4); ctx.lineWidth = 2; ctx.strokeStyle = '#fff3a0'; ctx.stroke(); });
    arm(ctx, 1, '#6a3ab0');
  },
  arqueiro(ctx) {
    quiver(ctx);
    // capinha curta com capuz
    P(ctx, [[CX - 12, 46], [CX - 20, 66], [CX - 4, 62], [CX + 6, 66], [CX + 12, 48]], V(ctx, 46, 66, ['#4a9a5a', '#2a5a32']));
    legs(ctx, '#5a4a32', '#6a4a2a');
    arm(ctx, -1, '#e8dcb8');
    torso(ctx, '#e8dcb8', '#4a9a5a', { belt: '#6a4a2a' });
    headBase(ctx);
    HAIR.ponytail(ctx, '#e8a84a', true);
    HAIR.ponytail(ctx, '#e8a84a');
    // presilha de folha
    P(ctx, [[CX - 12, HY - 12], [CX - 4, HY - 18, CX, HY - 14], [CX - 6, HY - 8, CX - 12, HY - 12]], '#6ad06a', OUT, 1.6);
    face(ctx, '#3a9a6a', 'neutral');
    arm(ctx, 1, '#e8dcb8', '#ffd9b8', '#8a5a2e');
  },
  gatuno(ctx) {
    legs(ctx, '#2a2a34', '#1a1a22');
    arm(ctx, -1, '#2a2a34');
    torso(ctx, '#3c3f4a', null, { belt: '#7a5230' });
    // bolsinhas no cinto
    E(ctx, CX - 8, 67, 3, 3, '#9a6a3a', OUT, 1.5); E(ctx, CX + 8, 67, 3, 3, '#9a6a3a', OUT, 1.5);
    // manga só de um lado (braço da frente descoberto)
    headBase(ctx, '#f0c8a0');
    HAIR.spiky(ctx, '#c4c8d4');
    face(ctx, '#e8b83a', 'fierce');
    // lenço cobrindo a boca, ponta esvoaçante
    P(ctx, [[CX - 8, HY + 6], [CX + 17, HY + 3], [CX + 16, HY + 12], [CX - 6, HY + 15]], '#a83a4a', OUT, 2);
    P(ctx, [[CX - 8, HY + 8], [CX - 26, HY + 6], [CX - 30, HY + 14], [CX - 8, HY + 14]], '#a83a4a', OUT, 2);
    arm(ctx, 1, '#f0c8a0', '#f0c8a0', '#2a2a34');
  },
  novico(ctx) {
    legs(ctx, '#d8d0c0', '#6a5a4a');
    arm(ctx, -1, '#f2ede2');
    torso(ctx, '#f2ede2', null, { long: true });
    // estola azul
    P(ctx, [[CX - 7, 50], [CX - 5, 82], [CX - 1, 82], [CX - 2, 52]], '#4a62b0', OUT, 1.8);
    P(ctx, [[CX + 7, 50], [CX + 6, 82], [CX + 10, 82], [CX + 11, 52]], '#4a62b0', OUT, 1.8);
    ctx.fillStyle = '#ffd86b'; ctx.fillRect(CX - 5, 74, 3, 6); ctx.fillRect(CX + 7, 74, 3, 6);
    headBase(ctx);
    HAIR.bob(ctx, '#e8c88a');
    // solidéu
    P(ctx, [[CX - 12, HY - 12], [CX - 8, HY - 22, CX + 4, HY - 22], [CX + 12, HY - 20, CX + 13, HY - 12], [CX, HY - 15]], '#4a62b0', OUT, 1.8);
    face(ctx, '#4a8ad8', 'calm');
    book(ctx, CX - 17, 62, '#4a62b0');
    arm(ctx, 1, '#f2ede2');
  },
  mercador(ctx) {
    backpack(ctx);
    legs(ctx, '#5a4a3a', '#4a2a1a', true);
    arm(ctx, -1, '#e8d0a8');
    torso(ctx, '#e8d0a8', null, { belt: '#6a3a1a' });
    // avental
    P(ctx, [[CX - 8, 56], [CX - 10, 76], [CX + 10, 76], [CX + 8, 56]], '#c9822f', OUT, 2);
    E(ctx, CX + 3, 66, 3.5, 3.5, '#ffd86b', OUT, 1.5);
    ctx.fillStyle = OUT; ctx.font = '700 5px sans-serif'; ctx.fillText('z', CX + 1.5, 68);
    headBase(ctx, '#f8d0a8');
    HAIR.short(ctx, '#b85a2a');
    // boina com pena
    E(ctx, CX - 1, HY - 15, 17, 6.5, '#2f7a6a');
    E(ctx, CX - 6, HY - 20, 3, 2, '#2f7a6a', OUT, 1.6);
    P(ctx, [[CX + 8, HY - 18], [CX + 18, HY - 32], [CX + 14, HY - 18]], '#ffd86b', OUT, 1.6);
    face(ctx, '#8a5a2a', 'grin');
    arm(ctx, 1, '#e8d0a8');
  },
  cavaleiro(ctx) {
    capeBack(ctx, '#b82a3a', 86, 22);
    legs(ctx, '#9aa8bc', '#5a6478');
    arm(ctx, -1, '#c9d2e0', '#ffd9b8', '#8a95a8');
    torso(ctx, '#c9d2e0', null, {});
    // tabardo
    P(ctx, [[CX - 7, 50], [CX - 8, 72], [CX, 76], [CX + 8, 72], [CX + 7, 50]], '#1f4fa8', OUT, 2);
    P(ctx, [[CX, 56], [CX + 3, 61], [CX, 66], [CX - 3, 61]], '#ffd86b', OUT, 1.2);
    // ombreiras
    E(ctx, CX + 12, 51, 7, 5, V(ctx, 46, 56, ['#f0f4fa', '#8a95a8']));
    headBase(ctx);
    face(ctx, '#3a6ad8', 'fierce');
    // elmo com visor aberto e penacho
    P(ctx, [[CX - 18, HY + 2], [CX - 19, HY - 18, CX, HY - 21], [CX + 18, HY - 20, CX + 19, HY - 4], [CX + 12, HY - 4], [CX + 10, HY - 10], [CX - 4, HY - 9], [CX - 8, HY + 8], [CX - 14, HY + 10]], V(ctx, HY - 21, HY + 10, ['#f4f7fc', '#b8c2d4', '#6a7488']));
    L(ctx, CX - 2, HY - 20, CX + 16, HY - 12, '#9aa4b8', 1.4, false);
    P(ctx, [[CX - 4, HY - 20], [CX - 10, HY - 34, CX - 26, HY - 30], [CX - 20, HY - 26], [CX - 14, HY - 24, CX - 10, HY - 18]], '#d83a3a', OUT, 1.8);
    arm(ctx, 1, '#c9d2e0', '#ffd9b8', '#8a95a8');
  },
  monge(ctx) {
    // contas de oração grandes ao redor do pescoço, faixa laranja
    legs(ctx, '#6a4a2a', '#3a2a1a', true);
    arm(ctx, -1, '#e8b088', '#e8b088', '#f4e2b8');
    torso(ctx, '#d8742a', null, { belt: '#3a2a6a' });
    // abertura do peito
    P(ctx, [[CX - 4, 50], [CX + 4, 50], [CX + 2, 60], [CX - 2, 60]], '#e8b088', OUT, 1.6);
    // faixa pendente
    P(ctx, [[CX + 6, 66], [CX + 10, 66], [CX + 13, 78], [CX + 8, 78]], '#3a2a6a', OUT, 1.6);
    headBase(ctx, '#e8b088');
    // cabelo curto preso em coque
    HAIR.short(ctx, '#2a1a12');
    P(ctx, [[CX - 4, HY - 20], [CX + 4, HY - 22], [CX + 6, HY - 15], [CX - 3, HY - 14]], '#2a1a12');
    face(ctx, '#6a3a1a', 'fierce');
    for (let i = 0; i < 7; i++) E(ctx, CX - 9 + i * 3, 50 + Math.abs(i - 3) * -0.6 + 1.5, 1.9, 1.9, '#8a2a1a', OUT, 1);
    arm(ctx, 1, '#e8b088', '#e8b088', '#f4e2b8');
  },
  ninja(ctx) {
    // pergaminho nas costas
    ctx.save(); ctx.translate(CX - 12, 54); ctx.rotate(-0.7);
    P(ctx, [[-3.5, -16], [3.5, -16], [3.5, 16], [-3.5, 16]], '#e8dcc0', OUT, 1.6);
    P(ctx, [[-4.5, -18], [4.5, -18], [4.5, -14], [-4.5, -14]], '#c43a4a', OUT, 1.2); P(ctx, [[-4.5, 14], [4.5, 14], [4.5, 18], [-4.5, 18]], '#c43a4a', OUT, 1.2);
    ctx.restore();
    // lenço vermelho esvoaçando para trás
    P(ctx, [[CX - 6, 48], [CX - 26, 44], [CX - 32, 50], [CX - 20, 52], [CX - 30, 58], [CX - 6, 54]], '#c43a4a');
    legs(ctx, '#232838', '#151822');
    // porta-shurikens na coxa e bandagens
    P(ctx, [[CX + 2, 70], [CX + 10, 70], [CX + 10, 76], [CX + 2, 76]], '#3a3048', OUT, 1.4);
    shurikenSmall(ctx, CX + 6, 73, 3.4);
    L(ctx, CX - 10, 74, CX - 2, 74, '#e8e0d0', 1.2, false); L(ctx, CX - 10, 77, CX - 2, 77, '#e8e0d0', 1.2, false);
    arm(ctx, -1, '#2a2f45', '#f0c8a0', '#1a1e2a');
    torso(ctx, '#2a2f45', null, { belt: '#c43a4a' });
    P(ctx, [[CX - 10, 50], [CX + 10, 60], [CX + 10, 63], [CX - 10, 53]], '#3a4058', OUT, 1.4);
    // faixa caindo do cinto
    P(ctx, [[CX - 9, 66], [CX - 5, 66], [CX - 7, 76], [CX - 11, 75]], '#c43a4a', OUT, 1.4);
    headBase(ctx, '#f0c8a0');
    HAIR.spiky(ctx, '#151520');
    // bandana com placa de metal
    P(ctx, [[CX - 16, HY - 8], [CX + 16, HY - 11], [CX + 16, HY - 5], [CX - 16, HY - 2]], '#2a2f45', OUT, 1.6);
    P(ctx, [[CX - 2, HY - 9], [CX + 10, HY - 10.5], [CX + 10, HY - 5], [CX - 2, HY - 3.6]], '#c9d2e0', OUT, 1.4);
    face(ctx, '#3a3a5a', 'fierce');
    // máscara na parte de baixo do rosto
    P(ctx, [[CX - 8, HY + 5], [CX + 17, HY + 2], [CX + 15, HY + 12], [CX - 6, HY + 15]], '#2a2f45', OUT, 1.8);
    arm(ctx, 1, '#2a2f45', '#f0c8a0', '#1a1e2a');
  },
  taekwon(ctx) {
    // dobok branco, faixa vermelha, coque alto
    legs(ctx, '#f4f2ec', '#e8c8a8', true);
    arm(ctx, -1, '#e8b088', '#e8b088', '#f4f2ec');
    torso(ctx, '#d83a3a', null, { belt: '#1a1a24' });
    P(ctx, [[CX - 10, 52], [CX + 10, 52], [CX + 10, 56], [CX - 10, 56]], '#2a5ad8', OUT, 1.2);
    P(ctx, [[CX + 4, 66], [CX + 8, 66], [CX + 9, 76], [CX + 5, 76]], '#1a1a24', OUT, 1.4);
    headBase(ctx, '#f0c8a0');
    HAIR.ponytail(ctx, '#3a2a1a', true);
    HAIR.short(ctx, '#3a2a1a');
    P(ctx, [[CX - 3, HY - 20], [CX + 5, HY - 22], [CX + 6, HY - 15], [CX - 2, HY - 14]], '#3a2a1a');
    face(ctx, '#3a6a3a', 'fierce');
    arm(ctx, 1, '#e8b088', '#e8b088', '#f4f2ec');
  },
  mestre_taekwon(ctx) {
    // aura dourada, jaqueta escura com estrelas, faixa preta
    glow(ctx, '#ffcf4a', 18, () => { ctx.save(); ctx.globalAlpha = 0.18; E(ctx, CX, 62, 22, 26, '#ffcf4a', null); ctx.restore(); });
    HAIR.long(ctx, '#d83a3a', true);
    P(ctx, [[CX - 10, 48], [CX - 20, 84], [CX - 8, 80], [CX - 2, 86], [CX + 4, 50]], '#1a1a24');
    legs(ctx, '#1a1a24', '#e8c8a8', true);
    arm(ctx, -1, '#e8b088', '#e8b088', '#ffcf4a');
    torso(ctx, '#1a1a24', null, { belt: '#ffcf4a' });
    ctx.fillStyle = '#ffcf4a';
    for (const [x, y] of [[CX - 5, 56], [CX + 5, 54], [CX, 60]]) { ctx.beginPath(); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 4 * Math.PI / 5; i ? ctx.lineTo(x + Math.cos(a) * 2.4, y + Math.sin(a) * 2.4) : ctx.moveTo(x + Math.cos(a) * 2.4, y + Math.sin(a) * 2.4); } ctx.closePath(); ctx.fill(); }
    headBase(ctx, '#f0c8a0');
    HAIR.spiky(ctx, '#d83a3a');
    P(ctx, [[CX - 16, HY - 7], [CX + 16, HY - 10], [CX + 16, HY - 5], [CX - 16, HY - 2]], '#ffcf4a', OUT, 1.6);
    face(ctx, '#e8a83a', 'fierce');
    arm(ctx, 1, '#e8b088', '#e8b088', '#ffcf4a');
  },
  shinobi(ctx) {
    // cachecol longo e rasgado roxo
    P(ctx, [[CX - 6, 46], [CX - 30, 40], [CX - 40, 48], [CX - 30, 50], [CX - 42, 60], [CX - 26, 58], [CX - 34, 70], [CX - 6, 56]], '#6a2ac4');
    // fuuma shuriken gigante nas costas
    ctx.save(); ctx.translate(CX - 14, 44); ctx.rotate(0.25); fuumaStar(ctx, 17); ctx.restore();
    legs(ctx, '#1c1830', '#100c1c');
    arm(ctx, -1, '#2a2440', '#e8d0c0', '#100c1c');
    torso(ctx, '#2a2440', null, { belt: '#8a4ae8' });
    // ombreira laqueada
    P(ctx, [[CX + 4, 47], [CX + 16, 46], [CX + 19, 54], [CX + 7, 56]], '#8a4ae8', OUT, 2);
    P(ctx, [[CX - 9, 52], [CX + 9, 52], [CX + 9, 56], [CX - 9, 56]], '#3a3058', OUT, 1.2);
    headBase(ctx, '#e8d0c0');
    // cabelo branco longo preso
    HAIR.ponytail(ctx, '#e8e8f4', true);
    HAIR.ponytail(ctx, '#e8e8f4');
    face(ctx, '#9a4aff', 'fierce');
    // meia máscara
    P(ctx, [[CX - 8, HY + 6], [CX + 17, HY + 3], [CX + 15, HY + 12], [CX - 6, HY + 15]], '#1c1830', OUT, 1.8);
    arm(ctx, 1, '#2a2440', '#e8d0c0', '#100c1c');
  },
  bruxo(ctx) {
    runeRing(ctx, '#c47aff');
    // grimório flutuante
    glow(ctx, '#c47aff', 12, () => {
      P(ctx, [[CX - 32, 40], [CX - 20, 37], [CX - 19, 50], [CX - 31, 53]], '#3a1a6a', OUT, 1.8);
      P(ctx, [[CX - 30, 41], [CX - 21, 39], [CX - 20.5, 49], [CX - 29.5, 51]], '#e8dcc0', null);
      L(ctx, CX - 26, 43, CX - 23, 42.5, '#9a4ae8', 1.2, false); L(ctx, CX - 26, 46, CX - 23, 45.5, '#9a4ae8', 1.2, false);
    });
    capeBack(ctx, '#2a1450', 86, 24);
    legs(ctx, '#2a1a40', '#1a0e2a');
    arm(ctx, -1, '#4a1f8a');
    torso(ctx, '#4a1f8a', null, { long: true });
    // gola alta dourada
    P(ctx, [[CX - 12, 48], [CX - 14, 40], [CX - 8, 46], [CX + 8, 46], [CX + 14, 40], [CX + 12, 50]], '#e8b84a', OUT, 2);
    P(ctx, [[CX - 2, 50], [CX - 3, 84], [CX + 3, 84], [CX + 2, 50]], '#e8b84a', OUT, 1.6);
    headBase(ctx, '#f4dcc8');
    HAIR.long(ctx, '#e8e8f4');
    face(ctx, '#e8483a', 'fierce');
    wizardHat(ctx, '#2a1450', '#e8b84a', 1.15, '#ff5aa8');
    arm(ctx, 1, '#4a1f8a');
  },
  cacador(ctx) {
    quiver(ctx);
    // capa com gola de pele
    capeBack(ctx, '#3e5a2e', 80, 18);
    legs(ctx, '#4a3a28', '#3a2a1a');
    arm(ctx, -1, '#6a5a3a');
    torso(ctx, '#6a5a3a', null, { belt: '#3a2a1a' });
    P(ctx, [[CX - 13, 47], [CX - 6, 53], [CX, 49], [CX + 6, 53], [CX + 13, 47], [CX, 44]], '#e8dcc0', OUT, 2);
    headBase(ctx, '#e8c098');
    HAIR.short(ctx, '#3a2a1a');
    face(ctx, '#3a8a5a', 'neutral');
    // chapéu de abas com pena longa
    P(ctx, [[CX - 22, HY - 9], [CX - 8, HY - 14], [CX + 20, HY - 12], [CX + 6, HY - 6], [CX - 10, HY - 6]], '#5a4a2a');
    P(ctx, [[CX - 12, HY - 12], [CX - 10, HY - 24], [CX + 10, HY - 24], [CX + 12, HY - 12]], V(ctx, HY - 24, HY - 12, ['#7a6a3a', '#4a3a1a']));
    P(ctx, [[CX - 10, HY - 18], [CX - 30, HY - 36, CX - 34, HY - 30], [CX - 24, HY - 24, CX - 10, HY - 14]], '#f0f0f0', OUT, 1.6);
    falcon(ctx, CX - 20, 52);
    arm(ctx, 1, '#6a5a3a', '#e8c098', '#5a3a1a');
  },
  assassino(ctx) {
    // cachecol longo esvoaçando
    P(ctx, [[CX - 6, 48], [CX - 24, 50, CX - 38, 62], [CX - 30, 66], [CX - 20, 58, CX - 4, 56]], '#c42a3a');
    P(ctx, [[CX - 4, 50], [CX - 22, 60, CX - 32, 76], [CX - 24, 76], [CX - 16, 64, CX - 2, 56]], '#8a1a2a');
    legs(ctx, '#2a1a22', '#1a0e14');
    arm(ctx, -1, '#4a1a2a', '#ffd9b8', '#2a1a22');
    torso(ctx, '#3a1422', null, { belt: '#c42a3a' });
    L(ctx, CX - 10, 52, CX + 10, 64, '#1a0e14', 2);
    headBase(ctx, '#e8c8b8');
    // capuz
    P(ctx, [[CX - 20, HY + 10], [CX - 22, HY - 14, CX - 2, HY - 22], [CX + 18, HY - 22, CX + 20, HY - 2], [CX + 14, HY - 4], [CX + 8, HY - 10, CX - 4, HY - 8], [CX - 10, HY + 4], [CX - 12, HY + 14]], V(ctx, HY - 22, HY + 14, ['#5a1a2e', '#2a0a14']));
    // máscara
    P(ctx, [[CX - 8, HY + 4], [CX + 18, HY + 1], [CX + 16, HY + 12], [CX - 6, HY + 15]], '#1a0e14', OUT, 2);
    glow(ctx, '#ff3a4a', 8, () => { E(ctx, CX + 1, HY - 1, 2.5, 1.6, '#ff6a7a', null); E(ctx, CX + 10, HY - 2, 2.8, 1.8, '#ff6a7a', null); });
    arm(ctx, 1, '#4a1a2a', '#ffd9b8', '#2a1a22');
  },
  sacerdote(ctx) {
    halo(ctx, '#ffe9a3');
    capeBack(ctx, '#f4efe3', 86, 18);
    legs(ctx, '#d8d0c0', '#8a6a3a');
    arm(ctx, -1, '#f4efe3');
    torso(ctx, '#f4efe3', null, { long: true });
    // tabardo dourado longo
    P(ctx, [[CX - 6, 50], [CX - 7, 84], [CX + 7, 84], [CX + 6, 50]], V(ctx, 50, 84, ['#e8c34a', '#b38a2e']), OUT, 1.8);
    P(ctx, [[CX - 1.5, 58], [CX + 1.5, 58], [CX + 1.5, 74], [CX - 1.5, 74]], '#fff6d0', null);
    P(ctx, [[CX - 5, 62], [CX + 5, 62], [CX + 5, 65], [CX - 5, 65]], '#fff6d0', null);
    headBase(ctx);
    HAIR.long(ctx, '#f0d890');
    face(ctx, '#d8a83a', 'calm');
    // mitra alta
    P(ctx, [[CX - 13, HY - 10], [CX - 11, HY - 32], [CX + 1, HY - 42], [CX + 13, HY - 32], [CX + 14, HY - 11]], V(ctx, HY - 42, HY - 10, ['#ffffff', '#e8e2d2']));
    P(ctx, [[CX - 1.5, HY - 38], [CX + 2.5, HY - 38], [CX + 2.5, HY - 14], [CX - 1.5, HY - 14]], '#e8c34a', null);
    P(ctx, [[CX - 6, HY - 30], [CX + 7, HY - 30], [CX + 7, HY - 27], [CX - 6, HY - 27]], '#e8c34a', null);
    arm(ctx, 1, '#f4efe3');
  },
  ferreiro(ctx) {
    legs(ctx, '#4a3a30', '#2a1a10', true);
    // braços musculosos
    P(ctx, [[CX - 16, 50], [CX - 10, 50], [CX - 14, 66], [CX - 21, 64]], '#e8b088', OUT, 2.2);
    torso(ctx, '#8a3b1f', null, {});
    // avental de couro com rebites
    P(ctx, [[CX - 10, 52], [CX - 12, 78], [CX + 12, 78], [CX + 10, 52]], V(ctx, 52, 78, ['#a86a3a', '#6a3a1a']), OUT, 2);
    for (const [x, y] of [[CX - 8, 56], [CX + 8, 56], [CX - 9, 74], [CX + 9, 74]]) E(ctx, x, y, 1.2, 1.2, '#d8d0c0', null);
    headBase(ctx, '#e8b088');
    HAIR.spiky(ctx, '#2a2a2a');
    // bandana e óculos de solda
    P(ctx, [[CX - 16, HY - 8], [CX + 16, HY - 11], [CX + 16, HY - 6], [CX - 16, HY - 3]], '#f2c48a', OUT, 1.6);
    E(ctx, CX + 1, HY - 10, 4.5, 3.5, V(ctx, HY - 14, HY - 6, ['#9ae8ff', '#3a8ab8']), OUT, 1.8);
    E(ctx, CX + 11, HY - 11, 4.5, 3.5, V(ctx, HY - 14, HY - 6, ['#9ae8ff', '#3a8ab8']), OUT, 1.8);
    face(ctx, '#8a4a2a', 'grin');
    // fuligem
    E(ctx, CX + 12, HY + 9, 2, 1, 'rgba(40,30,30,0.45)', null);
    P(ctx, [[CX + 12, 50], [CX + 17, 50], [CX + 23, 64], [CX + 16, 66]], '#e8b088', OUT, 2.2);
    E(ctx, CX + 19, 65, 5, 4.5, '#e8b088', OUT, 2);
  },
};

// Armas segurando na mão da frente
function fuumaStar(ctx, r) {
  // shuriken gigante de 4 lâminas
  for (let i = 0; i < 4; i++) {
    ctx.save(); ctx.rotate(i * Math.PI / 2);
    P(ctx, [[0, -r * 0.18], [r * 0.25, -r * 0.3], [r * 0.12, -r], [-r * 0.08, -r * 0.35]], '#dfe6f2');
    ctx.restore();
  }
  E(ctx, 0, 0, r * 0.26, r * 0.26, '#3a3048', OUT, 1.6);
  E(ctx, 0, 0, r * 0.1, r * 0.1, '#c9d2e0', null);
}
function shurikenSmall(ctx, x, y, r) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(0.3);
  P(ctx, [[0, -r], [r * 0.25, -r * 0.25], [r, 0], [r * 0.25, r * 0.25], [0, r], [-r * 0.25, r * 0.25], [-r, 0], [-r * 0.25, -r * 0.25]], '#c9d2e0', OUT, 1.2);
  E(ctx, 0, 0, r * 0.2, r * 0.2, '#3a3048', null);
  ctx.restore();
}
export { shurikenSmall, fuumaStar };

export function drawHeroWeapon(ctx, wtype, hx = CX + 18, hy = 64, flip = false) {
  ctx.save();
  ctx.translate(hx, hy);
  if (flip) ctx.scale(-0.85, 0.85);
  ctx.lineJoin = 'round';
  const blade = (len, w, col = '#e8eef8') => {
    P(ctx, [[-w / 2, 0], [-w / 2, -len], [0, -len - w], [w / 2, -len], [w / 2, 0]], V(ctx, -len, 0, ['#ffffff', col, '#8a95a8']), OUT, 2);
    L(ctx, 0, -2, 0, -len + 2, 'rgba(255,255,255,0.6)', 1, false);
  };
  switch (wtype) {
    case 'adaga': ctx.rotate(0.6); blade(14, 4.5); P(ctx, [[-6, 0], [6, 0], [6, 3], [-6, 3]], '#d4a83a', OUT, 1.6); L(ctx, 0, 3, 0, 8, '#5a3a20', 3); break;
    case 'espada': ctx.rotate(0.35); blade(30, 5.5); P(ctx, [[-8, 0], [8, 0], [8, 3.5], [-8, 3.5]], '#d4a83a', OUT, 1.6); L(ctx, 0, 4, 0, 10, '#5a3a20', 3.2); E(ctx, 0, 11, 2.2, 2.2, '#d4a83a', OUT, 1.4); break;
    case 'lanca': ctx.rotate(0.12); L(ctx, 0, 18, 0, -40, '#8a5a2e', 3.4); P(ctx, [[-4.5, -38], [0, -56], [4.5, -38], [0, -34]], V(ctx, -56, -34, ['#ffffff', '#b8c2d4']), OUT, 1.8); P(ctx, [[-3, -36], [-8, -30], [-2, -33]], '#d83a3a', OUT, 1.2); break;
    case 'cajado': ctx.rotate(0.1); L(ctx, 0, 10, 0, -22, '#6a4a2a', 3); P(ctx, [[0, -22], [-5, -26, -3, -31], [0, -28], [3, -31, 5, -26]], '#d4a83a', OUT, 1.6); glow(ctx, '#7ad8ff', 12, () => E(ctx, 0, -30, 3.8, 3.8, '#bff0ff', OUT, 1.6)); break;
    case 'arco': ctx.translate(2, -4); ctx.beginPath(); ctx.moveTo(-3, -24); ctx.lineTo(9, -14); ctx.lineTo(12, -3); ctx.lineTo(9, 8); ctx.lineTo(-3, 17); ctx.lineWidth = 6; ctx.strokeStyle = OUT; ctx.stroke(); ctx.lineWidth = 3.4; ctx.strokeStyle = '#a86a2a'; ctx.stroke(); L(ctx, -3, -24, -3, 17, '#f4f0e0', 0.9, false); break;
    case 'maca': ctx.rotate(0.35); L(ctx, 0, 6, 0, -20, '#6a4a2a', 3.4); E(ctx, 0, -25, 7, 7, V(ctx, -32, -18, ['#e8eef8', '#7a88a0'])); for (const a of [0, 1.57, 3.14, 4.71]) P(ctx, [[Math.cos(a) * 6, -25 + Math.sin(a) * 6], [Math.cos(a) * 10, -25 + Math.sin(a) * 10], [Math.cos(a + 0.4) * 6, -25 + Math.sin(a + 0.4) * 6]], '#c9d2e0', OUT, 1.2); break;
    case 'machado': ctx.rotate(0.28); L(ctx, 0, 10, 0, -32, '#6a4a2a', 3.4); P(ctx, [[0, -32], [14, -40, 18, -24], [12, -16], [0, -20]], V(ctx, -40, -16, ['#ffffff', '#9aa8bc']), OUT, 2); P(ctx, [[0, -30], [-7, -32, -8, -24], [0, -22]], '#9aa8bc', OUT, 1.6); break;
    case 'besta': ctx.rotate(-0.05);
      P(ctx, [[-4, -3], [16, -6], [16, -2], [-4, 1]], '#6a4a2a', OUT, 1.8);
      P(ctx, [[12, -16], [15, -14], [15, 6], [12, 8]], '#9aa8bc', OUT, 1.6);
      L(ctx, 13.5, -15, 2, -3, '#e8e0c8', 0.9, false); L(ctx, 13.5, 7, 2, -1, '#e8e0c8', 0.9, false);
      P(ctx, [[0, -4.5], [14, -5.5], [14, -4], [0, -3]], '#d8dce8', null);
      break;
    case 'katar': ctx.rotate(0.15);
      P(ctx, [[-4, 2], [4, 2], [4, -4], [-4, -4]], '#5a3a2a', OUT, 1.6);
      P(ctx, [[-4, -4], [4, -4], [2, -26], [0, -32], [-2, -26]], '#dfe6f2');
      P(ctx, [[-6, -4], [-4, -4], [-4, 4], [-6, 4]], '#b8c2d4', OUT, 1.2); P(ctx, [[4, -4], [6, -4], [6, 4], [4, 4]], '#b8c2d4', OUT, 1.2);
      break;
    case 'soqueira':
      P(ctx, [[-5, -5], [5, -5], [6, 2], [-5, 3]], '#9aa8bc', OUT, 1.8);
      for (const dx of [-3.5, 0, 3.5]) P(ctx, [[dx - 1.4, -5], [dx + 1.4, -5], [dx, -9]], '#e8eef8', OUT, 1.2);
      break;
    case 'kunai': // empunhadura invertida: lâmina para baixo
      ctx.rotate(2.6);
      P(ctx, [[-2.4, 0], [2.4, 0], [0, -14]], '#dfe6f2');
      P(ctx, [[-1.3, 0], [1.3, 0], [1.3, 6], [-1.3, 6]], '#2a2f45', OUT, 1.2);
      E(ctx, 0, 8.5, 2.6, 2.6, null, '#c9d2e0', 1.4);
      break;
    case 'fuuma': ctx.translate(4, -10); ctx.rotate(0.4); fuumaStar(ctx, 15); break;
    case 'treino': ctx.rotate(0.35);
      P(ctx, [[-2.8, 0], [-2.8, -24], [0, -28], [2.8, -24], [2.8, 0]], '#c49a64');
      L(ctx, 0, -3, 0, -24, '#a87a48', 1, false);
      P(ctx, [[-6, 0], [6, 0], [6, 3], [-6, 3]], '#7a5230', OUT, 1.4);
      P(ctx, [[-1.6, 3], [1.6, 3], [1.6, 9], [-1.6, 9]], '#5a3a20', OUT, 1.2);
      break;
    default: break;
  }
  ctx.restore();
}

export function drawHero(ctx, cls, wtype) {
  ctx.lineJoin = 'miter';
  ctx.save();
  ctx.translate(2, 0);
  const DUAL = { gatuno: ['adaga', 'kunai'], assassino: ['katar', 'adaga'], cavaleiro: ['espada', 'treino'], ninja: ['kunai'], shinobi: ['kunai', 'adaga'] };
  if (wtype && (DUAL[cls] || []).includes(wtype)) drawHeroWeapon(ctx, wtype, CX - 15, 64, true);
  (ART[cls] || ART.aprendiz)(ctx);
  if (wtype) drawHeroWeapon(ctx, wtype);
  // mão por cima do cabo
  if (wtype && cls !== 'ferreiro') E(ctx, CX + 17, 64, 3.8, 3.8, '#ffd9b8', OUT, 1.8);
  ctx.restore();
}

// Arma "de assinatura" de cada classe, para retratos e galeria
export const CLASS_WEAPON = {
  aprendiz: 'treino', espadachim: 'espada', mago: 'cajado', arqueiro: 'arco', gatuno: 'adaga', novico: 'maca', ninja: 'kunai',
  cavaleiro: 'espada', bruxo: 'cajado', cacador: 'besta', assassino: 'katar', monge: 'soqueira', shinobi: 'fuuma', taekwon: null, mestre_taekwon: null,
  mercador: 'machado', ferreiro: 'machado', sacerdote: 'maca',
};
