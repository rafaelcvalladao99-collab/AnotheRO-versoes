// Acesso aos plugins nativos do Capacitor sem o @capacitor/core.
// O jogo é carregado sem empacotador, então Capacitor.registerPlugin pode não existir.
// A ponte nativa injetada pelo app sempre oferece nativePromise (métodos) e nativeCallback (eventos).
export function isNative() {
  const cap = window.Capacitor;
  if (!cap) return false;
  if (typeof cap.isNativePlatform === 'function') return cap.isNativePlatform();
  if (typeof cap.getPlatform === 'function') return cap.getPlatform() !== 'web';
  return !!(cap.platform && cap.platform !== 'web') || typeof cap.nativePromise === 'function';
}

export function nativePlugin(name) {
  const cap = window.Capacitor;
  if (!cap || !isNative()) return null;
  if (typeof cap.registerPlugin === 'function') { try { return cap.registerPlugin(name); } catch (_) {} }
  if (typeof cap.nativePromise !== 'function') return null;
  return new Proxy({}, {
    get: (_, method) => {
      if (method === 'then') return undefined; // não é uma Promise
      if (method === 'addListener') {
        return (eventName, cb) => {
          const id = cap.nativeCallback(name, 'addListener', { eventName }, cb);
          const handle = { remove: () => cap.nativePromise(name, 'removeListener', { eventName, callbackId: id }) };
          return Object.assign(Promise.resolve(handle), handle);
        };
      }
      return (opts = {}) => cap.nativePromise(name, String(method), opts);
    },
  });
}
