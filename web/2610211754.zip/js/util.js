// Utilitários gerais
export const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
export const chance = (pct) => Math.random() * 100 < pct;
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const dist = (ax, ay, bx, by) => Math.max(Math.abs(ax - bx), Math.abs(ay - by));
export const edist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
let _uid = Date.now() % 100000;
export const uid = () => ++_uid;
export function setUidFloor(n) { if (n > _uid) _uid = n; }

export function weighted(list) {
  // list: [[item, weight], ...]
  let total = 0;
  for (const [, w] of list) total += w;
  let r = Math.random() * total;
  for (const [it, w] of list) { r -= w; if (r <= 0) return it; }
  return list[list.length - 1][0];
}

export function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export const DIRS8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
export const DIRS4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];

export function fmt(n) {
  return Math.floor(n).toLocaleString('pt-BR');
}
