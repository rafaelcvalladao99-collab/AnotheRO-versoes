// Cenário e monstros com tiles do Dungeon Crawl Stone Soup (CC0), gerados por tools/dcss/export.py
import { DCSS_META } from './dcss_meta.js';

const tileSheets = [];
let stairs = null;
const mons = new Map();

function loadImg(src) {
  return new Promise((ok) => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => ok(null); im.src = src; });
}

export async function preloadDcss() {
  const jobs = DCSS_META.biomes.map((_, i) => loadImg(`assets/tiles/${i}.png`).then((im) => { tileSheets[i] = im; }));
  jobs.push(loadImg('assets/tiles/stairs.png').then((im) => { stairs = im; }));
  for (const k of Object.keys(DCSS_META.mon)) {
    jobs.push(loadImg(`assets/mon/${k}.png`).then((im) => {
      if (!im) return;
      // tela quadrada no tamanho nativo, criatura apoiada embaixo e centralizada
      const S = Math.max(im.width, im.height);
      const c = document.createElement('canvas'); c.width = c.height = S;
      c.getContext('2d').drawImage(im, Math.floor((S - im.width) / 2), S - im.height);
      c.pixel = true;
      mons.set(k, c);
    }));
  }
  await Promise.all(jobs);
}

export const dcssMonster = (type) => mons.get(type) || null;
export const dcssStairs = () => stairs;

// recorta os pisos e paredes do bioma em telas do tamanho da casa (sem borrar os pixels)
export function dcssTiles(theme, s) {
  const im = tileSheets[theme];
  const b = DCSS_META.biomes[theme];
  if (!im || !b) return null;
  const cut = (col, row) => {
    const c = document.createElement('canvas'); c.width = c.height = s;
    const x = c.getContext('2d'); x.imageSmoothingEnabled = false;
    x.drawImage(im, col * 32, row * 32, 32, 32, 0, 0, s, s);
    return c;
  };
  const floors = [], walls = [];
  for (let i = 0; i < b.floors; i++) floors.push(cut(i, 0));
  for (let i = 0; i < b.walls; i++) walls.push(cut(i, 1));
  return { floors, walls };
}
