// Cenário com o terreno base do LPC (gerado por tools/terrain/build.py)
// Biomas naturais (Campos, Dunas, Abismo): o chão tem bordas arredondadas sobre a rocha.
export const NATURAL = new Set([0, 2, 4, 6]);
// Pisos sem costura, paredes em topo/face, líquidos e buracos com autotile (bordas contínuas).
const sheets = [], liquids = [], floorsAuto = [];
const bases = [];
const img = {};

function loadImg(src) {
  return new Promise((ok) => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => ok(null); im.src = src; });
}

export async function preloadTerrain() {
  const jobs = [];
  for (let i = 0; i < 8; i++) {
    jobs.push(loadImg(`assets/terrain/${i}.png`).then((im) => { sheets[i] = im; }));
    jobs.push(loadImg(`assets/terrain/${i}_liq.png`).then((im) => { liquids[i] = im; }));
    if (NATURAL.has(i)) jobs.push(loadImg(`assets/terrain/${i}_floor.png`).then((im) => { floorsAuto[i] = im; }));
  }
  jobs.push(loadImg('assets/terrain/0_base.png').then((im) => { bases[0] = im; }));
  for (const k of ['hole', 'stairs', 'tree0', 'tree1', 'pine0', 'pine1']) jobs.push(loadImg(`assets/terrain/${k}.png`).then((im) => { img[k] = im; }));
  await Promise.all(jobs);
}

function cut(im, sx, sy, s) {
  const c = document.createElement('canvas'); c.width = c.height = s;
  const x = c.getContext('2d'); x.imageSmoothingEnabled = false;
  x.drawImage(im, sx, sy, 32, 32, 0, 0, s, s);
  return c;
}

// pedaços de 16px do formato de terreno LPC (96x192) para cada quarto da casa
// mask: bits de vizinhos iguais (h = horizontal, v = vertical, d = diagonal) por quarto
function quarter(qx, qy, h, v, d) {
  if (h && v && d) return [32 + qx * 16, 96 + qy * 16];
  if (h && v) return [[[64, 32], [48, 32]], [[64, 16], [48, 16]]][qy][qx];
  if (h) return [32 + qx * 16, qy === 0 ? 64 : 144];
  if (v) return [qx === 0 ? 0 : 80, 96 + qy * 16];
  return [qx === 0 ? 0 : 80, qy === 0 ? 64 : 144];
}

export function makeAuto(im, s) {
  if (!im) return null;
  const cache = new Map();
  return (same) => { // same(dx, dy) -> bool
    let key = 0, bit = 0;
    for (const [dx, dy] of [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]]) { if (same(dx, dy)) key |= 1 << bit; bit++; }
    let c = cache.get(key);
    if (c) return c;
    c = document.createElement('canvas'); c.width = c.height = s;
    const x = c.getContext('2d'); x.imageSmoothingEnabled = false;
    const half = s / 2;
    for (const [qx, qy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) {
      const dx = qx ? 1 : -1, dy = qy ? 1 : -1;
      const [sx, sy] = quarter(qx, qy, same(dx, 0), same(0, dy), same(dx, dy));
      x.drawImage(im, sx, sy, 16, 16, qx * half, qy * half, half, half);
    }
    cache.set(key, c);
    return c;
  };
}

export function terrainTiles(theme, s) {
  const im = sheets[theme];
  if (!im) return null;
  return {
    floors: [0, 1, 2, 3].map((k) => cut(im, k * 32, 0, s)),
    tops: [0, 1].map((k) => cut(im, k * 32, 32, s)),
    faces: [0, 1].map((k) => cut(im, 64 + k * 32, 32, s)),
    liquid: makeAuto(liquids[theme], s),
    hole: makeAuto(img.hole, s),
    stairs: img.stairs ? cut(img.stairs, 0, 0, s) : null,
    natural: NATURAL.has(theme),
    floorAuto: NATURAL.has(theme) ? makeAuto(floorsAuto[theme], s) : null,
    base: theme === 0 && bases[0] ? cut(bases[0], 0, 0, s) : cut(im, 0, 32, s),
    trees: theme === 0 ? [img.tree0, img.tree1, img.pine0, img.pine1].filter(Boolean) : null,
  };
}
