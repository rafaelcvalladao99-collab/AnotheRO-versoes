// Ilustrações da cidade (prédios desenhados em canvas)
import { drawHero, shadeC } from './heroes.js';

const OUT = 'rgba(20,12,28,0.95)';
const cache = new Map();

function poly(x, pts, fill, lw = 2.5) {
  x.beginPath(); x.moveTo(pts[0][0], pts[0][1]);
  for (const p of pts.slice(1)) x.lineTo(p[0], p[1]);
  x.closePath();
  if (fill) { x.fillStyle = fill; x.fill(); }
  if (lw) { x.lineWidth = lw; x.strokeStyle = OUT; x.stroke(); }
}
function rect(x, a, b, w, h, fill, lw = 2.5, r = 0) {
  x.beginPath(); x.roundRect(a, b, w, h, r);
  if (fill) { x.fillStyle = fill; x.fill(); }
  if (lw) { x.lineWidth = lw; x.strokeStyle = OUT; x.stroke(); }
}
function vg(x, y0, y1, ...cs) { const g = x.createLinearGradient(0, y0, 0, y1); cs.forEach((c, i) => g.addColorStop(i / (cs.length - 1), c)); return g; }
function windowLit(x, a, b, w, h, arch = true) {
  x.save(); x.shadowColor = '#ffc860'; x.shadowBlur = 14;
  x.beginPath();
  if (arch) { x.moveTo(a, b + h); x.lineTo(a, b + w / 2); x.arc(a + w / 2, b + w / 2, w / 2, Math.PI, 0); x.lineTo(a + w, b + h); }
  else x.rect(a, b, w, h);
  x.closePath(); x.fillStyle = vg(x, b, b + h, '#fff0b0', '#ffb040'); x.fill(); x.restore();
  x.lineWidth = 2; x.strokeStyle = OUT; x.stroke();
  x.beginPath(); x.moveTo(a + w / 2, b + 2); x.lineTo(a + w / 2, b + h); x.moveTo(a, b + h * 0.55); x.lineTo(a + w, b + h * 0.55); x.lineWidth = 1.5; x.strokeStyle = 'rgba(60,30,10,0.7)'; x.stroke();
}
function roofTiles(x, pts, c) {
  poly(x, pts, vg(x, pts[1][1], pts[0][1], shadeC(c, 0.15), shadeC(c, -0.25)));
  x.save(); x.clip();
  x.strokeStyle = 'rgba(0,0,0,0.25)'; x.lineWidth = 1.5;
  for (let y = Math.min(...pts.map((p) => p[1])); y < Math.max(...pts.map((p) => p[1])); y += 8) { x.beginPath(); x.moveTo(0, y); x.lineTo(400, y); x.stroke(); }
  x.restore();
}
function stoneWall(x, a, b, w, h, c) {
  rect(x, a, b, w, h, vg(x, b, b + h, shadeC(c, 0.1), shadeC(c, -0.2)));
  x.save(); x.beginPath(); x.rect(a, b, w, h); x.clip();
  x.strokeStyle = 'rgba(0,0,0,0.22)'; x.lineWidth = 1.2;
  for (let y = b + 10, r = 0; y < b + h; y += 10, r++) {
    x.beginPath(); x.moveTo(a, y); x.lineTo(a + w, y); x.stroke();
    for (let xx = a + (r % 2 ? 9 : 0); xx < a + w; xx += 18) { x.beginPath(); x.moveTo(xx, y - 10); x.lineTo(xx, y); x.stroke(); }
  }
  x.restore();
}
function sky(x, W, H) {
  x.fillStyle = vg(x, 0, H, '#242a5c', '#4a3870', '#8a5a78'); x.fillRect(0, 0, W, H);
  x.fillStyle = 'rgba(255,255,255,0.8)';
  for (let i = 0; i < 18; i++) { x.globalAlpha = 0.3 + (i % 3) * 0.2; x.beginPath(); x.arc((i * 71) % W, (i * 37) % (H * 0.5), (i % 3) * 0.5 + 0.6, 0, 7); x.fill(); }
  x.globalAlpha = 1;
  x.fillStyle = '#2a2448'; x.beginPath(); x.moveTo(0, H * 0.72);
  for (let i = 0; i <= 8; i++) x.lineTo(i * W / 8, H * 0.7 - Math.sin(i * 1.9) * 8);
  x.lineTo(W, H); x.lineTo(0, H); x.fill();
  x.fillStyle = vg(x, H * 0.82, H, '#3a3050', '#2a2238'); x.fillRect(0, H * 0.84, W, H);
  // calçada
  x.strokeStyle = 'rgba(255,255,255,0.05)'; x.lineWidth = 1;
  for (let i = 0; i < 12; i++) { x.beginPath(); x.moveTo(i * 30, H * 0.88); x.lineTo(i * 30 - 10, H); x.stroke(); }
}
function npc(x, cls, px, py, s = 0.62, flip = false) {
  x.save(); x.translate(px, py); x.scale(flip ? -s : s, s); x.translate(-48, -88); drawHero(x, cls, null); x.restore();
}
function lamp(x, px, py) {
  x.fillStyle = '#2a2030'; x.fillRect(px - 1.5, py, 3, 46);
  x.save(); x.shadowColor = '#ffd080'; x.shadowBlur = 20; x.fillStyle = '#ffe0a0'; x.beginPath(); x.arc(px, py - 2, 5, 0, 7); x.fill(); x.restore();
  const g = x.createRadialGradient(px, py, 0, px, py, 50); g.addColorStop(0, 'rgba(255,210,120,0.25)'); g.addColorStop(1, 'rgba(255,210,120,0)');
  x.fillStyle = g; x.fillRect(px - 50, py - 50, 100, 100);
}

const SCENES = {
  gate(x, W, H) {
    sky(x, W, H);
    // muralha
    stoneWall(x, 0, H * 0.32, W, H * 0.56, '#5a5470');
    for (let i = 0; i < W; i += 28) rect(x, i + 2, H * 0.27, 18, 12, '#5a5470', 2);
    // arco do portão
    const cx = W / 2, top = H * 0.2;
    stoneWall(x, cx - 80, top, 160, H * 0.68, '#6a6480');
    x.save(); x.beginPath(); x.moveTo(cx - 52, H * 0.88); x.lineTo(cx - 52, top + 62); x.arc(cx, top + 62, 52, Math.PI, 0); x.lineTo(cx + 52, H * 0.88); x.closePath();
    x.fillStyle = '#0a0818'; x.fill(); x.clip();
    // vórtice
    const g = x.createRadialGradient(cx, top + 92, 4, cx, top + 92, 70); g.addColorStop(0, '#e8f6ff'); g.addColorStop(0.25, '#7ad0ff'); g.addColorStop(0.6, '#6a3ab0'); g.addColorStop(1, '#0a0818');
    x.fillStyle = g; x.fillRect(cx - 60, top, 120, H);
    x.strokeStyle = 'rgba(255,255,255,0.45)'; x.lineWidth = 2;
    for (let i = 0; i < 5; i++) { x.beginPath(); x.arc(cx, top + 92, 12 + i * 9, i, i + 3.6); x.stroke(); }
    x.restore();
    x.lineWidth = 3; x.strokeStyle = OUT; x.beginPath(); x.moveTo(cx - 52, H * 0.88); x.lineTo(cx - 52, top + 62); x.arc(cx, top + 62, 52, Math.PI, 0); x.lineTo(cx + 52, H * 0.88); x.stroke();
    // pedra chave e estandartes
    poly(x, [[cx - 10, top + 6], [cx + 10, top + 6], [cx + 7, top + 22], [cx - 7, top + 22]], '#8a84a0');
    for (const s of [-1, 1]) {
      const bx = cx + s * 66;
      poly(x, [[bx - 9, top + 14], [bx + 9, top + 14], [bx + 9, top + 60], [bx, top + 52], [bx - 9, top + 60]], vg(x, top, top + 60, '#c43a4a', '#7a1a2a'));
      x.fillStyle = '#ffd86b'; x.beginPath(); x.arc(bx, top + 32, 4, 0, 7); x.fill();
    }
    lamp(x, cx - 112, H * 0.5); lamp(x, cx + 112, H * 0.5);
    npc(x, 'cavaleiro', cx - 96, H * 0.98, 0.75);
    npc(x, 'espadachim', cx + 96, H * 0.98, 0.75, true);
  },
  shop(x, W, H) {
    sky(x, W, H);
    stoneWall(x, 40, H * 0.36, W - 80, H * 0.52, '#c8a87a');
    roofTiles(x, [[24, H * 0.4], [W / 2, H * 0.08], [W - 24, H * 0.4]], '#c4503a');
    windowLit(x, 62, H * 0.5, 30, 34);
    // toldo listrado
    for (let i = 0; i < 6; i++) poly(x, [[W / 2 - 54 + i * 18, H * 0.5], [W / 2 - 36 + i * 18, H * 0.5], [W / 2 - 34 + i * 18, H * 0.62], [W / 2 - 52 + i * 18, H * 0.62]], i % 2 ? '#f0e8d0' : '#3a9a7a', 1.5);
    rect(x, W / 2 - 50, H * 0.62, 100, 30, '#7a4a2a');
    // poções no balcão
    for (const [dx, c] of [[-34, '#e8434a'], [-16, '#ff9a3a'], [2, '#4a8aff'], [20, '#5fd16a']]) {
      x.save(); x.shadowColor = c; x.shadowBlur = 8; x.fillStyle = c; x.beginPath(); x.arc(W / 2 + dx, H * 0.6, 6, 0, 7); x.fill(); x.restore();
      x.lineWidth = 1.6; x.strokeStyle = OUT; x.beginPath(); x.arc(W / 2 + dx, H * 0.6, 6, 0, 7); x.stroke();
      rect(x, W / 2 + dx - 2, H * 0.6 - 11, 4, 5, '#b88a5a', 1.2);
    }
    // placa
    rect(x, W - 92, H * 0.44, 46, 24, '#e8d0a0', 2, 4);
    x.fillStyle = '#7a3a1a'; x.font = '700 15px serif'; x.textAlign = 'center'; x.fillText('⚗', W - 69, H * 0.44 + 18);
    npc(x, 'mercador', W / 2 + 74, H * 0.98, 0.7, true);
  },
  smith(x, W, H) {
    sky(x, W, H);
    // chaminé com fumaça
    stoneWall(x, W - 90, H * 0.08, 26, H * 0.4, '#6a5a5a');
    x.fillStyle = 'rgba(200,200,220,0.25)'; for (let i = 0; i < 4; i++) { x.beginPath(); x.arc(W - 77 + i * 6, H * 0.04 - i * 6, 8 + i * 3, 0, 7); x.fill(); }
    stoneWall(x, 30, H * 0.4, W - 60, H * 0.48, '#7a6a6a');
    roofTiles(x, [[16, H * 0.44], [60, H * 0.2], [W - 60, H * 0.2], [W - 16, H * 0.44]], '#4a4a5a');
    // forja brilhando
    x.save(); x.beginPath(); x.moveTo(60, H * 0.88); x.lineTo(60, H * 0.62); x.arc(90, H * 0.62, 30, Math.PI, 0); x.lineTo(120, H * 0.88); x.closePath();
    const g = x.createRadialGradient(90, H * 0.78, 4, 90, H * 0.78, 50); g.addColorStop(0, '#fff0a0'); g.addColorStop(0.4, '#ff8a3a'); g.addColorStop(1, '#5a1a0a');
    x.fillStyle = g; x.shadowColor = '#ff8a3a'; x.shadowBlur = 24; x.fill(); x.restore();
    x.lineWidth = 2.5; x.strokeStyle = OUT; x.stroke();
    // bigorna
    poly(x, [[W / 2 - 4, H * 0.76], [W / 2 + 44, H * 0.76], [W / 2 + 34, H * 0.82], [W / 2 + 6, H * 0.82]], '#4a4a58');
    poly(x, [[W / 2 + 10, H * 0.82], [W / 2 + 30, H * 0.82], [W / 2 + 34, H * 0.9], [W / 2 + 6, H * 0.9]], '#3a3a48');
    // faíscas
    x.fillStyle = '#ffd060'; for (let i = 0; i < 9; i++) { x.globalAlpha = 0.5 + (i % 3) * 0.2; x.fillRect(W / 2 + 10 + (i * 13) % 34, H * 0.6 + (i * 17) % 26, 2.5, 2.5); }
    x.globalAlpha = 1;
    // escudos na parede
    for (const [dx, c] of [[W - 120, '#3a62b8'], [W - 84, '#c43a4a']]) { x.beginPath(); x.ellipse(dx, H * 0.56, 11, 13, 0, 0, 7); x.fillStyle = c; x.fill(); x.lineWidth = 2; x.strokeStyle = OUT; x.stroke(); }
    npc(x, 'ferreiro', W / 2 + 76, H * 0.98, 0.72, true);
  },
  storage(x, W, H) {
    sky(x, W, H);
    stoneWall(x, 36, H * 0.34, W - 72, H * 0.54, '#8a7a62');
    roofTiles(x, [[20, H * 0.38], [W / 2, H * 0.1], [W - 20, H * 0.38]], '#4a6a8a');
    // porta grande de madeira
    rect(x, W / 2 - 34, H * 0.5, 68, H * 0.38, vg(x, H * 0.5, H * 0.88, '#9a6a3a', '#5a3a1a'), 2.5, 6);
    for (let i = 1; i < 4; i++) { x.beginPath(); x.moveTo(W / 2 - 34 + i * 17, H * 0.5); x.lineTo(W / 2 - 34 + i * 17, H * 0.88); x.lineWidth = 1.5; x.strokeStyle = 'rgba(0,0,0,0.35)'; x.stroke(); }
    // caixotes e barris
    const crate = (a, b, s) => { rect(x, a, b, s, s, '#b88a4a', 2); x.beginPath(); x.moveTo(a, b); x.lineTo(a + s, b + s); x.moveTo(a + s, b); x.lineTo(a, b + s); x.lineWidth = 1.6; x.strokeStyle = 'rgba(60,30,10,0.6)'; x.stroke(); };
    crate(50, H * 0.7, 30); crate(66, H * 0.56, 24); crate(W - 84, H * 0.72, 28);
    x.beginPath(); x.ellipse(W - 100, H * 0.76, 12, 16, 0, 0, 7); x.fillStyle = '#8a5a2a'; x.fill(); x.lineWidth = 2; x.strokeStyle = OUT; x.stroke();
    windowLit(x, W / 2 - 10, H * 0.24, 20, 22);
    npc(x, 'novico', W / 2 - 64, H * 0.98, 0.66);
  },
  guild(x, W, H) {
    sky(x, W, H);
    stoneWall(x, 30, H * 0.3, W - 60, H * 0.58, '#7a7a9a');
    // torre central
    stoneWall(x, W / 2 - 30, H * 0.08, 60, H * 0.8, '#8a8aaa');
    poly(x, [[W / 2 - 38, H * 0.1], [W / 2, -6], [W / 2 + 38, H * 0.1]], '#3a3a7a');
    windowLit(x, W / 2 - 12, H * 0.2, 24, 30);
    // estandartes de classes
    const cols = ['#3a62b8', '#7c3fbf', '#3f9a52', '#3c3f4a', '#e9e3d3', '#c9822f'];
    cols.forEach((c, i) => {
      const bx = 44 + i * ((W - 88) / 5);
      if (Math.abs(bx - W / 2) < 34) return;
      poly(x, [[bx - 9, H * 0.36], [bx + 9, H * 0.36], [bx + 9, H * 0.68], [bx, H * 0.62], [bx - 9, H * 0.68]], c, 2);
    });
    rect(x, W / 2 - 22, H * 0.66, 44, H * 0.22, '#3a2a1a', 2.5, 4);
    npc(x, 'bruxo', W / 2 - 70, H * 0.98, 0.66);
    npc(x, 'ninja', W / 2 + 70, H * 0.98, 0.66, true);
  },
  temple(x, W, H) {
    sky(x, W, H);
    stoneWall(x, 50, H * 0.34, W - 100, H * 0.54, '#e8e0d0');
    poly(x, [[36, H * 0.38], [W / 2, H * 0.06], [W - 36, H * 0.38]], vg(x, 0, H * 0.4, '#f4ecd8', '#c9b898'));
    // rosácea
    x.save(); x.shadowColor = '#c0a8ff'; x.shadowBlur = 18;
    const cx = W / 2, cy = H * 0.24;
    for (let i = 0; i < 8; i++) { x.beginPath(); x.moveTo(cx, cy); x.arc(cx, cy, 16, i * Math.PI / 4, (i + 1) * Math.PI / 4); x.fillStyle = ['#ff8ab0', '#8ad0ff', '#ffe08a', '#a8ff9a'][i % 4]; x.fill(); }
    x.restore();
    x.beginPath(); x.arc(cx, cy, 16, 0, 7); x.lineWidth = 2.5; x.strokeStyle = OUT; x.stroke();
    // colunas
    for (let i = 0; i < 4; i++) { const px = 70 + i * ((W - 140) / 3); rect(x, px - 7, H * 0.42, 14, H * 0.46, vg(x, 0, 0, '#fff', '#d8d0c0'), 2); }
    windowLit(x, W / 2 - 14, H * 0.5, 28, 38);
    npc(x, 'monge', W / 2 + 84, H * 0.98, 0.66, true);
  },
};

export function sceneURL(kind, W = 340, H = 190) {
  const key = kind + W + 'x' + H;
  if (cache.has(key)) return cache.get(key);
  const c = document.createElement('canvas');
  const R = 2;
  c.width = W * R; c.height = H * R;
  const x = c.getContext('2d');
  x.scale(R, R);
  x.lineJoin = 'round';
  SCENES[kind](x, W, H);
  // vinheta
  const g = x.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.7);
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(10,6,24,0.55)');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  const url = c.toDataURL('image/png');
  cache.set(key, url);
  return url;
}
